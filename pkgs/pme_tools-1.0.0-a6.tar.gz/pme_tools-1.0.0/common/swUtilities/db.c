/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : db.c
 *
 *   This file contains the implementation of a simple Data Base (DB)
 *   module.
 *
 ****************************************************************************/




/*--------------------- Include Files -----------------------------*/

#include <string.h>


#include <db.h>
#include <dll.h>
#include <generic_types.h>
#include <idx.h>
#include <log.h>
#include <mem.h>









/*--------------------- Macro Definitions--------------------------*/

/* The next two macros define the size of the DB name table.  The
 * factor macro is used to determines the size of the name table.  The
 * actual size of the name table is  2 ^ _DB_NAME_TABLE_SIZE_FACTOR,
 * e.g., 2 ^ 10 = 1024.  The size is defined through such a factor so
 * that the name hashing factions can be adjusted automatically when
 * the table size changes.  In the current implementation of the hash
 * function used for the names the maximum value for this macro is
 * 16. */
#define _DB_NAME_TABLE_SIZE_FACTOR        10
#define _DB_NAME_TABLE_SIZE               (1 << _DB_NAME_TABLE_SIZE_FACTOR)


/* This macro defines the DB signature. */
#define _DB_DB_SIGNATURE                  0xadded002
#define _DB_NULL_SIGNATURE                0









/*--------------------- Type Definitions---------------------------*/

/* This type defines a generic record in a DB. */
typedef struct {
  dll_node_t  recordDllNode;            /* record DLL node */
  char        name_s[DB_NAME_MAX_SIZE]; /* name of the record */
  uint32_t    recordIndex;              /* index of the record */
  void       *userRecord_p;             /* user record pointer */
} _db_record_t;


/* This type defines the DB structure. */
typedef struct {
  uint32_t       dbSignature;                    /* DB signature */
  char           name_s[DB_NAME_MAX_SIZE];       /* DB name */
  uint32_t       recordMaxNum;                   /* max. num. of DB records */
  uint32_t       recordNum;                      /* number of records in DB */
  handle_t       idxHandle;                      /* handle of the index table*/
  dll_list_t     nameTable[_DB_NAME_TABLE_SIZE]; /* DB name table */
  _db_record_t **recordTable_p;                  /* record table */
} _db_db_t;




  



/*--------------------- Global Data Definitions -------------------*/

/* This variable defines the DB error string table. */
static const char *const _db_error_code_strings_cg[] = {
  /* db_ok_e */
  "DB: Operation successful.",

  /* db_error_e */
  "DB: Operation failed.",

  /* db_invalid_db_handle_e */
  "DB: Invalid DB handle.",

  /* db_null_ptr_parameter_e */
  "DB: NULL pointer parameter.",

  /* db_name_is_in_use_e */
  "DB: Name is in use.",

  /* db_name_is_not_in_use_e */
  "DB: Name is not in use.",

  /* db_failed_to_create_idx_table_e */
  "DB: Failed to create an index table.",

  /* db_too_few_error_strings_e */
  "DB: Internal error: more error codes than strings are defined.",

  /* db_too_many_error_strings_e */
  "DB: Internal error: more error strings than codes are defined.",

  /* db_too_many_records_e */
  "DB: Too many records.",

  /* db_failed_to_allocate_index_e */
  "DB: Failed to allocate an index.",

  /* db_out_of_memory_e */
  "DB: Ran out of memory.",

  /* db_index_is_not_allocated_e */
  "DB: Index is not allocated.",

  /* db_failed_to_destroy_idx_table_e */
  "DB: Failed to destroy DB index table.",

  /* db_invalid_name_e */
  "DB: Invalid name.",
};







/*--------------------- Static Function Definitions ---------------*/

/*
 * Sort strings in the passed in table.
 *
 * param strings_p   Table of pointers to strings to be sorted.
 * param size        Number of elements in the strings_p table.
 * retval            The strings in the passed in strings_p table are
 *                   sorted alphabetically.
 */
static void
_db_string_sort(
  char     **strings_p, 
  uint32_t   size
  )
{
  uint32_t  i     = 0;
  uint32_t  j     = 0;
  char     *tmp_p = NULL;
  bool      swaps = false;
  

  for (i = 0;i < size;i++) {
    swaps = false;
    for (j = 0;j < size - i - 1;j++) {
      if (strcmp(strings_p[j], strings_p[j + 1]) > 0) {
         /* Swap the strings. */
        tmp_p            = strings_p[j];
        strings_p[j]     = strings_p[j + 1];
        strings_p[j + 1] = tmp_p;
        swaps            = true;
      }
    }
    if (false == swaps) {
      /* We are done. */
      break;
    }
  }
} /* _db_string_sort */


/*
 * Validate the passed in DB handle.
 *
 * param handle      The DB handle to be validated.
 * param logFlag     When set to true, the logs are generated; when set
 *                   to false, the logs are not generated.
 * retval            true when the validation was successful; false
 *                   otherwise. 
 */
static bool
_db_handle_validate(
  const handle_t  handle,
  const bool      logFlag
  )
{
  if (HANDLE_NULL == handle) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL table handle.");
    }
    return false;
  }
  _db_db_t const* db_p = (_db_db_t *)handle;

  /* Check the signature of the table. */
  if (_DB_DB_SIGNATURE != db_p->dbSignature) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "Handle %"PRI_HANDLE" is not "
                 "a valid DB handle.", handle);
    }
    return false;
  }
  
  return true;
} /* _db_handle_validate */


/*
 * Validate the passed in index.
 */
static bool
_db_index_validate(
  const handle_t  handle,
  const uint32_t  idx,
  const bool      logFlag
  )
{
  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, logFlag)) { 
    return false;
  }
  _db_db_t const* db_p = (_db_db_t *)handle;

  /* Validate the passed in index. */
  if (0 == idx) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "Index value of 0 is invalid.");
    }
    return false;
  }
  else if (idx > db_p->recordMaxNum) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "Index value of %"PRIu32" is "
                 "too big;  there are only %"PRIu32" entries in the \"%s\" "
                 "DB.", idx, db_p->recordMaxNum, db_p->name_s);
    }
    return false;
  }

  return true;
} /* _db_index_validate */


/*
 * Perform a 32-bit FNV hash on the passed in buffer.
 *
 * param buffer_p  Pointer to the buffer with the data to hash.
 * param size      Number of bytes to hash.
 * param hashValue Previous hash value (0 for the first call).
 * retval          The hash value.
 */
static uint32_t
_db_fnv_hash(
  const char     *buffer_p,
  const uint32_t  size,
  uint32_t        hashValue
  )
{
  uint32_t        i          = 0;
  const uint32_t  fnvPrime_c = 16777619;  /* inialize the FNV prime number */


  if (NULL == buffer_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL buffer pointer passed in.");
    return hashValue;
  }
    
  /* Hash each byte in the buffer. */
  for (i = 0;i < size;i++, buffer_p++) {
    /* Multiply (modulo 2^32) the hash value by the 32 bit FNV magic
     * prime number. */
    hashValue *= fnvPrime_c;

    /* Xor the hash value with the "current" byte. */
    hashValue ^= (uint32_t)*buffer_p;
  }

  /* Return the new hash value. */
  return hashValue;
} /* _db_fnv_hash */


/*
 * Perform a 10-bit hash on the name string passed in.
 *
 * NOTE: The maximum hash value that can be generated is currently 2^10 -
 * 1 = 1023.  This can be changed by changing the value of the
 * _DB_NAME_TABLE_SIZE_FACTOR macro but the maximum hash value is
 * still limited to 2^16 - 1 = 65535, which limits
 * _DB_NAME_TABLE_SIZE_FACTOR to 16.
 *
 * param  string_p  The string to be hashed.
 * retval           The hash value for the passed in string.
 */
static uint16_t
_db_string_hash(
  const char *string_p
  )
{
  uint32_t  sizeMask  = _DB_NAME_TABLE_SIZE - 1;
  uint32_t  hashValue = 0;
  
  
  if (NULL == string_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL name pointer passed in.");
    return hashValue;
  }
  
  hashValue = _db_fnv_hash(string_p, strlen(string_p), hashValue);  
  
  /* Now we produce the 10-bit hash value. */
  hashValue = ((hashValue >> 16) ^ hashValue) & 0x0000FFFF;
  hashValue = ((hashValue >> _DB_NAME_TABLE_SIZE_FACTOR) ^ hashValue) 
    & sizeMask;
  
  return (uint16_t)hashValue;
} /* _db_string_hash */


/*
 * Search the indicated DB for a record with the specified name.
 *
 * param handle      Handle of the DB to use.
 * param name_p      Name of the record to display.
 * retval            Pointer to the DB record wiht the specified
 *                   name;  NULL if there is no record in the DB with
 *                   the specified name. 
 */
static _db_record_t *
_db_record_by_name_get(
  const handle_t  handle,
  const char     *name_p
  )
{
  _db_db_t *const  db_p       = (_db_db_t *)handle;
  _db_record_t    *dbRecord_p = NULL;
  uint32_t         nameIndex  = 0;
  dll_list_t      *dllList_p  = NULL;
  dll_node_t      *dllNode_p  = NULL;  


  /* Hash the name string; the hash value is the index into the name table. */
  nameIndex = _db_string_hash(name_p);

  /* Check the index to make sure it points into the table (in case
   * the string hash function was modified). */
  if (nameIndex >= _DB_NAME_TABLE_SIZE) {
    LOG_STRING(LOG_ERROR, DB_MODULE_NAME, "Name index of %"PRIu32" points "
               "outside of the name table (valid range is <0, %u>) in DB "
               "\"%s\".  Applying module division to force the name index "
               "into the name table.", nameIndex, _DB_NAME_TABLE_SIZE, 
               db_p->name_s);
    nameIndex %= _DB_NAME_TABLE_SIZE;
  }
  

  /* Search the DLL list at the name index position for the specified
   * name. */
  dllList_p = &db_p->nameTable[nameIndex];
  if (false == dll_is_list_empty(dllList_p)) {
    /* There are entries in the name table for this name index. */
    dllNode_p = dll_get_first(dllList_p);
    do {
      dbRecord_p = DLL_STRUCT_FROM_NODE_GET(dllNode_p, _db_record_t, 
                                            recordDllNode);
      /* Compare the specified name with the name in the DB record. */
      if (0 == strcmp(name_p, dbRecord_p->name_s)) {
        /* We found a DB record with the specified name. */
        return dbRecord_p;
      }
    } while (NULL != (dllNode_p = dll_get_next_node(dllList_p, dllNode_p)));
  }
    
  /* We did not find a record with the specified name. */
  return NULL;
} /* _db_record_by_name_get */


/*
 * Add the passed in DB record to the name table in the indicated DB.
 *
 * param handle      Handle of the DB to use.
 * param dbRecord_p  Pointer to the DB record to add.
 */
static void
_db_record_to_name_table_add(
  const handle_t  handle,
  _db_record_t   *dbRecord_p
  )
{
  _db_db_t *const db_p = (_db_db_t *)handle;


  /* Hash the record name string; the hash value is the index into the
   * DB name table. */
  uint16_t nameIndex = _db_string_hash(dbRecord_p->name_s);

  /* Check the index to make sure it points into the table (in case
   * the string hash function was modified). */
  if (nameIndex >= _DB_NAME_TABLE_SIZE) {
    LOG_STRING(LOG_ERROR, DB_MODULE_NAME, "Name index of %"PRIu32" points "
               "outside of the name table (valid range is <0, %u>) in DB "
               "\"%s\".  Applying module division to force the name index "
               "into the name table.", nameIndex, _DB_NAME_TABLE_SIZE, 
               db_p->name_s);
    nameIndex %= _DB_NAME_TABLE_SIZE;
  }

  /* Add the record DLL node to the name table at the name index
   * location. */
  dll_add_to_back(&db_p->nameTable[nameIndex], &dbRecord_p->recordDllNode);

} /* _db_record_to_name_table_add */


/*
 * Remove the passed in DB record from its name table.
 *
 * param dbRecord_p  Pointer to the DB record to remove.
 */
static void
_db_record_from_name_table_remove(
  _db_record_t *dbRecord_p
  )
{
  /* Remove the record from the name table. */
  if ((dbRecord_p->recordDllNode.next_p != NULL) && 
      (dbRecord_p->recordDllNode.prev_p != NULL)) {    
    dll_remove_node(&dbRecord_p->recordDllNode);
  }
} /* _db_record_from_name_table_remove */


/*
 * Delete the passed in record from the indicated DB.
 *
 * param handle      Handle of the DB to delete the record from.
 * param dbRecord_p  The record to be deleted.
 */
static void
_db_record_delete(
  const handle_t  handle,
  _db_record_t   *dbRecord_p
  )
{
  _db_db_t *const  db_p = (_db_db_t *)handle;


  /* Remove the DB record from the DB record table. */
  db_p->recordTable_p[dbRecord_p->recordIndex] = NULL;
  
  /* Remove the DB record from the DB name table. */
  _db_record_from_name_table_remove(dbRecord_p);
  
  /* Free the index. */
  idx_index_free(db_p->idxHandle, dbRecord_p->recordIndex);
  
  /* Clear the record entries (just in case...) */
  LOG_STRING(LOG_MEMORY, DB_MODULE_NAME,
             "Freeing memory of a DB record \"%s\" in DB "
             "with name \"%s\".", dbRecord_p->name_s, db_p->name_s);
  dbRecord_p->name_s[0]    = 0;
  dbRecord_p->recordIndex  = IDX_NULL_INDEX;
  dbRecord_p->userRecord_p = NULL;
  
  /* Free the record's memory */
  mem_free(dbRecord_p);
  
  /* Decrement the DB record counter. */
  if (0 == db_p->recordNum) {
    LOG_STRING(LOG_ERROR, DB_MODULE_NAME, "Cannot decrement a already 0 "
               "record counter in the \"%s\" DB.", db_p->name_s);
  }
  else {
    db_p->recordNum--;
  }
} /* _db_record_delete */


/*
 * Show the passed in record.
 *
 * param dbRecord_p  The record to be shown.
 */
static void
_db_record_show(
  const _db_record_t *dbRecord_p  
  )
{
  log_printf(LOG_STDOUT, "dllNode=%10p, index=%5"PRIu32", record_p=%10p, "
             "name=%s\n", 
             &dbRecord_p->recordDllNode, dbRecord_p->recordIndex, 
             dbRecord_p->userRecord_p, dbRecord_p->name_s);
} /* _db_record_show */









/*--------------------- Public Function Definitions ---------------*/

/*
 * Initialize the DB module.
 */
db_status_t
db_module_init(void)
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(void).", __func__);

  /* Check if the error code string table has been fully initialized. */
  const uint32_t  currentSize = sizeof(_db_error_code_strings_cg);
  const uint32_t  desiredSize = sizeof(char *) * db_last_error_code_e;
  if (currentSize < desiredSize) {
    LOG_STRING(LOG_ERROR, DB_MODULE_NAME,
               "More error codes than strings are defined.");
    return db_too_few_error_strings_e;
  }
  if (currentSize > desiredSize) {
    LOG_STRING(LOG_ERROR, DB_MODULE_NAME,
               "More error strings than codes are defined.");
    return db_too_many_error_strings_e;
  }

  return db_ok_e;
} /* db_module_init */


/*
 * Return error string for the passed in error code.
 */
const char *
db_error_string_get(
  db_status_t errorCode
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(errorCode=%d).", __func__, errorCode);

  /* Validate the parameters. */
  if ((errorCode < 0) || (errorCode >= db_last_error_code_e)) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "%d is an invalid error code; "
               "supported error codes must be >= 0 and < %d.", errorCode, 
               db_last_error_code_e);
    return "The passed in error code is invalid.";
  }
  
  return _db_error_code_strings_cg[errorCode];
} /* db_error_string_get */


/*
 * Create a new DB.
 */
db_status_t 
db_db_create(
  uint32_t    recordMaxNum,
  const char *name_p,
  handle_t   *handle_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(recordMaxNum=%"PRIu32", "
             "name_p=%p).", __func__, recordMaxNum, name_p);

  /* Validate the passed in pointers. */
  if ((NULL == handle_p) || (NULL == name_p)) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL pointer parameter.");
    return db_null_ptr_parameter_e;
  }

  size_t        size      = 0;
  idx_status_t  idxStatus = idx_error_e;
  
  
  /* Allocate and clear memory for the main DB structure. */
  size = sizeof(_db_db_t);
  LOG_STRING(LOG_MEMORY, DB_MODULE_NAME, "Allocating %Zd bytes of memory for "
             "the main structure in a new DB with name \"%s\".", 
             size, name_p);
  _db_db_t *db_p = mem_calloc(1, size);
  if (NULL == db_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME,
               "Failed to allocate %Zd bytes of memory when trying to "
               "create DB with name \"%s\".", size, name_p);
    return db_out_of_memory_e;
  }

  /* Create an index table to be used with the new DB. */
  idxStatus = idx_index_table_create(recordMaxNum, "DB index table",
                                     &db_p->idxHandle);
  if (idx_ok_e != idxStatus) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME,
               "Failed to create an index table when trying "
               "to create DB with name \"%s\".  \"%s\"", name_p, 
               idx_error_string_get(idxStatus));
    LOG_STRING(LOG_MEMORY, DB_MODULE_NAME,
               "Freeing memory of the main structure in DB "
               "with name \"%s\".", name_p);
    mem_free(db_p);
    return db_failed_to_create_idx_table_e;
  }

  /* Allocate and clear memory for the record table. */
  size = sizeof(_db_record_t *) * (recordMaxNum + 1);
  LOG_STRING(LOG_MEMORY, DB_MODULE_NAME, "Allocating %Zd bytes of memory "
             "for the record table in a new DB with name \"%s\".",
             size, name_p);
  db_p->recordTable_p = mem_calloc(1, size);
  if (NULL == db_p->recordTable_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "Failed to allocate %Zd bytes "
               "of memory for the record table when trying to create DB "
               "with name \"%s\"", size, name_p);
    /* Destroy the created IDX table. */
    idxStatus = idx_index_table_destroy(db_p->idxHandle);
    if (idx_ok_e != idxStatus) {
      LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "Failed to destroy an index "
                 "table.  \"%s\".", idx_error_string_get(idxStatus));
    }
    LOG_STRING(LOG_MEMORY, DB_MODULE_NAME,
               "Freeing memory of the main structure in DB "
               "with name \"%s\".", name_p);
    mem_free(db_p);
    return db_out_of_memory_e;
  }


  /* Initialize the new DB. */
  /* Save the name of the DB. */
  strncpy(db_p->name_s, name_p, DB_NAME_MAX_SIZE - 1);
  
  /* Save the maximum number of records in the DB. */
  db_p->recordMaxNum = recordMaxNum;

  /* Initialize the name table link-lists */
  uint32_t  i = 0;
  for (i = 0;i < _DB_NAME_TABLE_SIZE;i++) {
    dll_list_init(&db_p->nameTable[i]);
  }

  /* Set the DB signature entry. */
  db_p->dbSignature = _DB_DB_SIGNATURE;

  *handle_p = (handle_t)db_p;
  return db_ok_e;
} /* db_db_create */


/*
 * Destroy the indicated DB.
 */
db_status_t
db_db_destroy(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(handle=%"PRI_HANDLE").", 
             __func__, handle);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return db_invalid_db_handle_e;
  }
  _db_db_t *const db_p   = (_db_db_t *)handle;
  db_status_t     status = db_ok_e;


  /* Reset the DB signature. */
  db_p->dbSignature = _DB_NULL_SIGNATURE;

  /* Free the record table memory. */
  LOG_STRING(LOG_MEMORY, DB_MODULE_NAME, "Freeing memory of the record "
             "table in DB with name \"%s\" and handle=%"PRI_HANDLE".", 
             db_p->name_s, handle);
  mem_free(db_p->recordTable_p);
  
  /* Free the index table allocated for the DB. */
  idx_status_t idxStatus = idx_index_table_destroy(db_p->idxHandle);
  if (idx_ok_e != idxStatus) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "Failed to destroy the index "
               "table while destroying the \"%s\" DB", db_p->name_s);
    status = db_failed_to_destroy_idx_table_e;
  }
  
  /* Free the DB main structure memory. */
  LOG_STRING(LOG_MEMORY, DB_MODULE_NAME,
             "Freeing memory of the main structure in DB "
             "with handle=%"PRI_HANDLE".", handle);
  mem_free(db_p);
  
  return status;
} /* db_db_destroy */


/* 
 * Add a record to the indicated DB.
 */
db_status_t
db_record_add(
  handle_t    handle,
  const char *name_p,
  const void *record_p,
  uint32_t   *index_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", name_p=%p=\"%s\", "
             "record_p=%p).", __func__, handle, name_p, 
             (NULL == name_p)? "NULL name pointer":name_p, record_p);
  
  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return db_invalid_db_handle_e;
  }
  _db_db_t *const db_p = (_db_db_t *)handle;
  

  if ((NULL == name_p) || (NULL == record_p) || (NULL == index_p)) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL pointer passed in "
               "(name_p=%p, record_p=%p, index_p=%p).", name_p, record_p, 
               index_p);
    return db_null_ptr_parameter_e;
  }

  /* Validate the passed in record name. */
  if (strlen(name_p) > (DB_NAME_MAX_SIZE - 1)) {
    /* The record name length is too big. */
    return db_invalid_name_e;
  }
  
  
  db_status_t   status     = db_ok_e;
  _db_record_t *dbRecord_p = NULL;
  uint32_t      idx        = IDX_NULL_INDEX;
  

  /* Each record in the DB must have a unique name.  Check if the name
   * of the record to be added is not already in use. */
  dbRecord_p = _db_record_by_name_get(handle, name_p);
  if (NULL != dbRecord_p) {
    /* The name is in use. */
    LOG_STRING(LOG_TEST, DB_MODULE_NAME,
               "Cannot add a record with name \"%s\" to the "
               "\"%s\" DB.  \"%s\"", name_p, db_p->name_s, 
               db_error_string_get(db_name_is_in_use_e));
    status = db_name_is_in_use_e;
  }
  else {
    /* The name is not in use.  Check if adding the record would not
     * violate the maximum number of records limit. */
    if (db_p->recordNum + 1 > db_p->recordMaxNum) {
      LOG_STRING(LOG_TEST, DB_MODULE_NAME,
                 "Cannot add a record with name \"%s\" to the "
                 "\"%s\" DB.  \"%s\"", name_p, db_p->name_s, 
                 db_error_string_get(db_too_many_records_e));
      status = db_too_many_records_e;
    }
    else {
      /* Allocate an index for the new record. */
      idx = idx_index_allocate(db_p->idxHandle);
      if (IDX_NULL_INDEX == idx) {
        /* Since the max. record number check passed, the index
         * allocation should not fail. */
        LOG_STRING(LOG_ERROR, DB_MODULE_NAME, "Failed to allocate an "
                   "index in the \"%s\" DB.", db_p->name_s);
        status = db_failed_to_allocate_index_e;
      }
      else {
        /* Allocate a new record. */
        LOG_STRING(LOG_MEMORY, DB_MODULE_NAME, "Allocating %Zd bytes of "
                   "memory for a new DB record with name \"%s\" in DB "
                   "\"%s\".", sizeof(_db_record_t), name_p, db_p->name_s);
        dbRecord_p = mem_calloc(1, sizeof(_db_record_t));
        if (NULL == dbRecord_p) {
          LOG_STRING(LOG_WARNING, DB_MODULE_NAME,
                     "Failed to allocate a record in the DB "
                     "\"%s\".", db_p->name_s);
          status = db_out_of_memory_e;
        }
        else {
          /* Initialize the newly allocated record.  Note that since
           * the dbRecord_p structure was zeroed when it was allocated
           * by mem_calloc() and that the maximum name size is
           * DB_NAME_MAX_SIZE - 1, the name_s string will always be
           * NULL terminated. */
          strncpy(dbRecord_p->name_s, name_p, DB_NAME_MAX_SIZE - 1);
          dbRecord_p->recordIndex  = idx;
          dbRecord_p->userRecord_p = (void *)record_p;
          
          /* Add the initialized record to the DB name table. */
          _db_record_to_name_table_add(handle, dbRecord_p);
          
          /* Add the initialized record to the DB record table. */
          db_p->recordTable_p[idx] = dbRecord_p;
          
          /* Increment the DB record counter. */
          db_p->recordNum++;
        } /* else - initialize the newly allocated record */
      } /* else - the record was allocated successfully */
    } /* else - a new index was allocated successfully */
  } /* else - the name is not in use */

  /* Set the return value for the index parameter. */
  *index_p = idx;
  
  return status;
} /* pmc_RecordAdd */


/*
 * Delete the indexed record from the indicated DB.
 */
db_status_t
db_record_by_index_delete(
  handle_t  handle,
  uint32_t  idx
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", index=%"PRIu32").",
             __func__, handle, idx);

  /* Validate the passed in index (this validates the handle too). */
  if (false == _db_index_validate(handle, idx, true)) {
    return db_invalid_db_handle_e;
  }
  _db_db_t *const db_p   = (_db_db_t *)handle;
  db_status_t     status = db_ok_e;


  /* Check if the specified index is allocated. */
  if (false == idx_is_index_allocated(db_p->idxHandle, idx)) {
    /* The specified index has not been allocated. */
    LOG_STRING(LOG_INFO, DB_MODULE_NAME, "Index %"PRIu32" in DB \"%s\" "
               "is not allocated.", idx, db_p->name_s);
    status = db_index_is_not_allocated_e;
  }
  else {
    /* Delete the DB record. */
    _db_record_delete(handle, db_p->recordTable_p[idx]);
  }
    
  return status;
} /* db_record_by_index_delete */


/*
 * Delete the named record from the indicated DB.
 */
db_status_t
db_record_by_name_delete(
  handle_t    handle,
  const char *name_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", name_p=%p).",
             __func__, handle, name_p);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return db_invalid_db_handle_e;
  }
  /* Validate the passed in name. */
  if (NULL == name_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL name_p pointer passed in.");
    return db_null_ptr_parameter_e;
  }

  _db_db_t *const  db_p       = (_db_db_t *)handle;
  db_status_t      status     = db_ok_e;
  _db_record_t    *dbRecord_p = NULL;

  
  /* Check if there exists a record with the indicated name. */
  dbRecord_p = _db_record_by_name_get(handle, name_p);
  if (NULL == dbRecord_p) {
    /* The name is not in use. */
    LOG_STRING(LOG_TEST, DB_MODULE_NAME,
               "Record with name \"%s\" does not exist in "
               "the \"%s\" DB.", name_p, db_p->name_s);
    status = db_name_is_not_in_use_e;
  }
  else {
    /* Delete the DB record. */
    _db_record_delete(handle, dbRecord_p);
  }
    
  return status;
} /* pmc_RecordByNameDelete */


/*
 * Delete all the records in the specified DB.
 */
db_status_t
db_record_all_delete(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(handle=%"PRI_HANDLE").",
             __func__, handle);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return db_invalid_db_handle_e;
  }
  _db_db_t *const  db_p = (_db_db_t *)handle;
  uint32_t         idx  = 0;
  

  /* Walk through all the entries in the DB record table and delete
   * all the used records found. */
  for (idx = 1;idx < db_p->recordMaxNum + 1;idx++) {
    if (NULL != db_p->recordTable_p[idx]) {
      _db_record_delete(handle, db_p->recordTable_p[idx]);   
    }
  }
  
  return db_ok_e;
} /* db_record_all_delete */


/*
 * Get the user record pointer using the record index.
 */
void *
db_record_by_index_get(
  handle_t  handle,
  uint32_t  idx
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", index=%"PRIu32").", 
             __func__, handle, idx);

  /* Validate the passed in index (this validates the handle too). */
  if (false == _db_index_validate(handle, idx, true)) {
    return NULL;
  }
  _db_db_t *const db_p = (_db_db_t *)handle;


  /* Check if the specified index is allocated. */
  if (false == idx_is_index_allocated(db_p->idxHandle, idx)) {
    /* The specified index has not been allocated. */
    LOG_STRING(LOG_INFO, DB_MODULE_NAME, "Index %"PRIu32" in DB \"%s\" "
               "is not allocated.", idx, db_p->name_s);
    return NULL;
  }
    
  return db_p->recordTable_p[idx]->userRecord_p;
} /* db_record_by_index_get */


/*
 * Get the user record pointer using the record name.
 */
void *
db_record_by_name_get(
  handle_t    handle,
  const char *name_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", name_p=%p).", 
             __func__, handle, name_p);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return NULL;
  }
  /* Validate the passed in name. */
  if (NULL == name_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL name_p pointer passed in.");
    return NULL;
  }
  _db_record_t *dbRecord_p = NULL;

  
  /* Check if there exists a record with the indicated name. */
  dbRecord_p = _db_record_by_name_get(handle, name_p);
  if (NULL == dbRecord_p) {
    return NULL;
  }
    
  return dbRecord_p->userRecord_p;
} /* db_record_by_name_get */


/*
 * Display fields of the indexed record.
 */
db_status_t
db_record_by_index_show(
  handle_t              handle,
  uint32_t              idx,
  db_record_show_func_t *showFunc_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", index=%"PRIu32", "
             "showFunc_p=%p).", __func__, handle, idx, showFunc_p);

  /* Validate the passed in index (this validates the handle too). */
  if (false == _db_index_validate(handle, idx, true)) {
    return db_invalid_db_handle_e;
  }

  _db_db_t *const db_p       = (_db_db_t *)handle;
  db_status_t     status     = db_ok_e;
  _db_record_t   *dbRecord_p = NULL;


  /* Check if the specified index is allocated. */
  if (false == idx_is_index_allocated(db_p->idxHandle, idx)) {
    /* The specified index has not been allocated. */
    LOG_STRING(LOG_INFO, DB_MODULE_NAME, "Index %"PRIu32" in DB \"%s\" "
               "is not allocated.", idx, db_p->name_s);
    status = db_index_is_not_allocated_e;
  }
  else {
    /* Show the record. */
    if (NULL != showFunc_p) {
      showFunc_p(dbRecord_p->userRecord_p, dbRecord_p->name_s, 
                 dbRecord_p->recordIndex);
    }
    else {
      _db_record_show(dbRecord_p);
    }
  }

  return status;
} /* db_record_by_index_show */


/* 
 * Display fields of the named record.
 */
db_status_t
db_record_by_name_show(
  handle_t               handle,
  const char            *name_p,
  db_record_show_func_t *showFunc_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", name_p=%p, "
             "showFunc_p=%p).", __func__, handle, name_p, showFunc_p);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return db_invalid_db_handle_e;
  }
  /* Validate the passed in name. */
  if (NULL == name_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL name_p pointer passed in.");
    return db_null_ptr_parameter_e;
  }

  db_status_t   status     = db_ok_e;
  _db_record_t *dbRecord_p = NULL;

  
  /* Check if there exists a record with the indicated name. */
  dbRecord_p = _db_record_by_name_get(handle, name_p);
  if (NULL == dbRecord_p) {
    status = db_name_is_not_in_use_e;
  }
  else {
    /* Show the record. */
    if (NULL != showFunc_p) {
      showFunc_p(dbRecord_p->userRecord_p, dbRecord_p->name_s, 
                 dbRecord_p->recordIndex);
    }
    else {
      _db_record_show(dbRecord_p);
    }
  }

  return status;
} /* db_record_by_name_show */
 

/*
 * Display fields of all the records in the specified DB.
 */
db_status_t
db_record_all_show(
  handle_t               handle,
  db_record_show_func_t *showFunc_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(handle=%"PRI_HANDLE
             ", showFunc_p=%p).", __func__, handle, showFunc_p);
  
  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return db_invalid_db_handle_e;
  }
  _db_db_t *const db_p         = (_db_db_t *)handle;
  bool            sortedOkFlag = true;
  uint32_t        recFoundNum  = 0;
  uint32_t        i            = 0;
  uint32_t        j            = 0;
  db_status_t     dbStatus     = db_error_e;
  
  
  /* Allocate a table of string pointers and initialize it to contain
   * the name string pointers for all the allocated records. */
  LOG_STRING(LOG_MEMORY, DB_MODULE_NAME, "Allocating %Zd bytes of memory for "
             "record name sorting.", db_p->recordNum * sizeof(char *));
  char **names_p = mem_calloc(db_p->recordNum, sizeof(char *));
  if (NULL == names_p) {
    sortedOkFlag = false;
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "Failed to allocate %Zd bytes "
               "of memory needed for record name sorting.", 
               db_p->recordNum * sizeof(char *));
  }
  else {
    /* Initialize the name pointer table. */
    for (i = 1;i < db_p->recordMaxNum + 1;i++) {
      if (NULL != db_p->recordTable_p[i]) {
        if ((recFoundNum + 1) > db_p->recordNum) {
          LOG_STRING(LOG_ERROR, DB_MODULE_NAME,
                     "Found more records in the \"%s\" DB "
                     "than the current record count of %u.",
                     db_p->name_s, db_p->recordNum);
          sortedOkFlag = false;
          break;
        }
        else {
          recFoundNum++;
          names_p[j++] = &db_p->recordTable_p[i]->name_s[0];
        }
      }
    }
    if (true == sortedOkFlag) {
      if (recFoundNum != db_p->recordNum) {
        sortedOkFlag = false;
        LOG_STRING(LOG_ERROR, DB_MODULE_NAME, "Found %u records in the "
                   "\"%s\" DB for which the current record count is %u.",
                   recFoundNum, db_p->name_s, db_p->recordNum);
      }
      else {
        /* Sort the name strings; */
        _db_string_sort(names_p, db_p->recordNum);
      }
    }
  } /* else - allocation of name_s table was successful */
  

  /* Show the records. */
  if (true == sortedOkFlag) {
    /* Show the records sorted by record name. */
    for (i = 0;i < db_p->recordNum;i++) {
      dbStatus = db_record_by_name_show(handle, names_p[i], showFunc_p);
      if (db_ok_e != dbStatus) {
        LOG_STRING(LOG_ERROR, DB_MODULE_NAME, "Failed to show a DB record "
                   "with name \"%s\" and index %u from a name sorted "
                   "table.  \"%s\"", names_p[i], i, 
                   db_error_string_get(dbStatus));
      }
    }
  } /* if - show the records sorted by record name */
  else {
    /* Walk through all the entries in the DB record table and show
     * all the used records found. */
    for (i = 1;i < db_p->recordMaxNum + 1;i++) {
      if (NULL != db_p->recordTable_p[i]) {
        /* Show the record. */
        if (NULL != showFunc_p) {
          showFunc_p(db_p->recordTable_p[i]->userRecord_p,
                     db_p->recordTable_p[i]->name_s, 
                     db_p->recordTable_p[i]->recordIndex);
        }
        else {
          _db_record_show(db_p->recordTable_p[i]->userRecord_p);
        }
      }
    }
  } /* else - show the records in the DB (unsorted) */
  
  
  if (NULL != names_p) {
    LOG_STRING(LOG_MEMORY, DB_MODULE_NAME,
               "Freeing memory used for record name sorting.");
    mem_free(names_p);
  }
  
  return db_ok_e;
} /* db_record_all_show */
 

/*
 * Get the next allocated record pointer.
 */
void *
db_record_next_get(
  handle_t   handle,
  uint32_t  *idx_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, 
             "Entering %s(handle=%"PRI_HANDLE", idx_p=%p).",
             __func__, handle, idx_p);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return NULL;
  }
  /* Validate the passed in index pointer. */
  if (NULL == idx_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL idx_p pointer passed in.");
    return NULL;
  }
  /* Validate the passed in index.  Note that the IDX_NULL_INDEX index
   * is valid in this case. */
  if (IDX_NULL_INDEX != *idx_p) {
    if (false == _db_index_validate(handle, *idx_p, true)) {
      return NULL;
    }
  }
  _db_db_t *const  db_p      = (_db_db_t *)handle;
  uint32_t         nextIndex = 0;

  
  nextIndex = idx_index_next_allocated_get(db_p->idxHandle, *idx_p);
  if (IDX_NULL_INDEX == nextIndex) {
    return NULL;
  }
 
  *idx_p = nextIndex;
  return db_p->recordTable_p[nextIndex]->userRecord_p;
} /* db_record_next_get */


/*
 * Check if the passed index is valid.
 */
bool
db_is_index_valid(
  handle_t  handle,
  uint32_t  idx
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", index=%"PRIu32").",
             __func__, handle, idx);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return false;
  }
  
  return _db_index_validate(handle, idx, false);
} /* db_is_index_allocated */


/*
 * Check if the passed handle is valid.
 */
bool
db_is_handle_valid(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(handle=%"PRI_HANDLE").",
             __func__, handle);

  return _db_handle_validate(handle, false);
} /* db_is_handle_valid */


/*
 * Get the name of the record using the record index.
 */
const char *
db_record_name_get(
  handle_t  handle,
  uint32_t  idx
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", index=%"PRIu32").", 
             __func__, handle, idx);

  /* Validate the passed in index (this validates the handle too). */
  if (false == _db_index_validate(handle, idx, true)) {
    return NULL;
  }
  _db_db_t *const db_p = (_db_db_t *)handle;
    
  return db_p->recordTable_p[idx]->name_s;
} /* db_record_name_get */


/*
 * Get the index of the named record.
 */
uint32_t
db_record_index_get(
  handle_t    handle,
  const char *name_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME,
             "Entering %s(handle=%"PRI_HANDLE", name_p=%p).",
             __func__, handle, name_p);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return IDX_NULL_INDEX;
  }
  /* Validate the passed in name. */
  if (NULL == name_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL name_p pointer passed in.");
    return IDX_NULL_INDEX;
  }

  _db_record_t *dbRecord_p = NULL;

  
  /* Check if there exists a record with the indicated name. */
  dbRecord_p = _db_record_by_name_get(handle, name_p);
  if (NULL == dbRecord_p) {
    return IDX_NULL_INDEX;
  }
    
  return dbRecord_p->recordIndex;
} /* db_record_by_name_get */


/*
 * Get the number of records present in the indicated DB.
 */
uint32_t
db_record_number_get(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(handle=%"PRI_HANDLE").",
             __func__, handle);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return 0;
  }
  _db_db_t *const db_p = (_db_db_t *)handle;
    
  return db_p->recordNum;
} /* db_record_number_get */


/*
 * Get the maximum number of records in the indicated DB.
 */
uint32_t
db_record_max_number_get(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(handle=%"PRI_HANDLE").",
             __func__, handle);

  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return 0;
  }
  _db_db_t *const db_p = (_db_db_t *)handle;
    
  return db_p->recordMaxNum;
} /* db_record_max_number_get */


/*
 * Displays the name table data and statistics in the indicated DB.
 */
void
db_name_table_show(
  handle_t             handle,
  db_record_show_func_t *showFunc_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(handle=%"PRI_HANDLE
             ", showFunc_p=%p).", __func__, handle, showFunc_p);
  
  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return;
  }

  _db_db_t *const  db_p                 = (_db_db_t *)handle;
  dll_list_t      *dllList_p            = NULL;
  dll_node_t      *dllNode_p            = NULL;
  _db_record_t    *dbRecord_p           = NULL;
  uint32_t         idx                  = 0;
  uint32_t         nameNum              = 0;
  uint32_t         collisionNum         = 0;
  uint32_t         indexCollisionNum    = 0;
  uint32_t         maxIndexCollisionNum = 0;
  uint32_t         maxCollisionIndex    = 0;
  uint32_t         minIndexCollisionNum = 0;
  uint32_t         minCollisionIndex    = 0;
  uint32_t         collisionIndexNum    = 0;
  uint32_t         indexNum             = 0;
  char            *naString_p           = "N/A\n";
  
  
  /* Walk through all the entries in the name table. */
  for (idx = 0;idx < _DB_NAME_TABLE_SIZE;idx++) {
    dllList_p = &db_p->nameTable[idx];
    if (false == dll_is_list_empty(dllList_p)) {
      /* There are entries in the name table at this index.  Display
       * the head entry in the list. */
      dllNode_p  = dll_get_first(dllList_p);
      dbRecord_p = DLL_STRUCT_FROM_NODE_GET(dllNode_p, _db_record_t, 
                                            recordDllNode);
      log_printf(LOG_STDOUT, "index %4"PRIu32": name=%16s, index=%5u", 
                 idx, dbRecord_p->name_s, dbRecord_p->recordIndex);
      /* Display the extra data for this entry. */
      if (NULL != showFunc_p) {
        showFunc_p(dbRecord_p->userRecord_p, dbRecord_p->name_s, 
                   dbRecord_p->recordIndex);
      } 
      log_printf(LOG_STDOUT, "\n");
      
      /* Update statistics. */
      indexNum++;
      nameNum++;
      indexCollisionNum = 0;      


      /* Check if there are more entries at this index (in this
       * DLlist). */
      while (NULL != (dllNode_p = dll_get_next_node(dllList_p, dllNode_p))) {
        /* There are entries that collide at this index.  Display them. */
        dbRecord_p = DLL_STRUCT_FROM_NODE_GET(dllNode_p, _db_record_t, 
                                              recordDllNode);
        log_printf(LOG_STDOUT, "index %4"PRIu32": name=%16s, index=%5u", 
                   idx, dbRecord_p->name_s, dbRecord_p->recordIndex);
        /* Display the extra data for this entry. */
        if (NULL != showFunc_p) {
          showFunc_p(dbRecord_p->userRecord_p, dbRecord_p->name_s, 
                     dbRecord_p->recordIndex);
        }
        log_printf(LOG_STDOUT, "\n");
                
        /* Update statistics. */
        nameNum++;
        indexCollisionNum++;
      }

      /* Update stats. */
      if (0 != indexCollisionNum) {
        collisionNum += indexCollisionNum;
        collisionIndexNum++;
        if (indexCollisionNum > maxIndexCollisionNum) {
          maxIndexCollisionNum = indexCollisionNum;
          maxCollisionIndex    = idx;
        }
        if ((indexCollisionNum <  minIndexCollisionNum) ||
            (0                 == minIndexCollisionNum)) {
          minIndexCollisionNum = indexCollisionNum;
          minCollisionIndex    = idx;
        }
      }
    } /* if - there are entries at this index (DLL list is not empty) */
  } /* for - walk through all the entries in the table */


  log_printf(LOG_STDOUT, 
             "Statistics for the name table in the \"%s\" DB:\n", 
             db_p->name_s);
  log_printf(LOG_STDOUT, 
             "\tmaximum number of entries                = %u\n", 
             db_p->recordMaxNum);
  log_printf(LOG_STDOUT, 
             "\tnumber of currently used entries         = %"PRIu32"\n", 
             nameNum);
  log_printf(LOG_STDOUT, 
             "\tnumber of indexes in the table           = %"PRIu32"\n",
             _DB_NAME_TABLE_SIZE);
  log_printf(LOG_STDOUT, 
             "\tnumber of used indexes in the table      = %"PRIu32"\n",
             indexNum);
  log_printf(LOG_STDOUT, 
             "\tnumber of name collisions                = %"PRIu32"\n",
             collisionNum);
  log_printf(LOG_STDOUT, 
             "\ttable usage ((used/total) indexes)       = %.2f%%\n", 
             (100 * (float)indexNum / (float)_DB_NAME_TABLE_SIZE));
  log_printf(LOG_STDOUT, 
             "\tcollision rate (collisions/used entries) = ");
  if (0 != nameNum) {
    log_printf(LOG_STDOUT, 
               "%.2f%%\n", (100 * (float)collisionNum) / (float)nameNum);
  }
  else { log_printf(LOG_STDOUT, "%s", naString_p); }
  log_printf(LOG_STDOUT, 
             "\tnumber of indexes with name collisions   = %"PRIu32"\n", 
             collisionIndexNum);
  log_printf(LOG_STDOUT, 
             "\tmaximum collisions in an index           = %"PRIu32"\n", 
             maxIndexCollisionNum);
  log_printf(LOG_STDOUT, 
             "\tan index with maximum collisions         = ");
  if (0 != collisionNum) { 
    log_printf(LOG_STDOUT, "%"PRIu32"\n", maxCollisionIndex); 
  }
  else { log_printf(LOG_STDOUT, "%s", naString_p); }

  log_printf(LOG_STDOUT, 
             "\tminimum collisions in an index           = %"PRIu32"\n", 
             minIndexCollisionNum);
  log_printf(LOG_STDOUT, 
             "\tan index with minimum collisions         = ");
  if (0 != collisionNum) { 
    log_printf(LOG_STDOUT, "%"PRIu32"\n", minCollisionIndex); 
  }
  else { log_printf(LOG_STDOUT, "%s", naString_p); }
  
} /* db_name_table_show */


/*
 * Collect the statistics for the indicated DB.
 */
db_status_t
db_stats_get(
  handle_t    handle,
  db_stats_t *dbStats_p
  )
{
  LOG_STRING(LOG_TEST, DB_MODULE_NAME, "Entering %s(handle=%"PRI_HANDLE
             ", dbStats_p=%p).", __func__, handle, dbStats_p);
  
  /* Validate the passed in handle. */
  if (false == _db_handle_validate(handle, true)) { 
    return db_invalid_db_handle_e;
  }
  if (NULL == dbStats_p) {
    LOG_STRING(LOG_WARNING, DB_MODULE_NAME, "NULL pointer parameter.");
    return db_null_ptr_parameter_e;
  }

  _db_db_t *const  db_p       = (_db_db_t *)handle;
  dll_list_t      *dllList_p  = NULL;
  dll_node_t      *dllNode_p  = NULL;
  _db_record_t    *dbRecord_p = NULL;
  uint32_t         idx        = 0;


  /* Reset the statistics structure. */
  memset(dbStats_p, 0, sizeof(*dbStats_p));

  /* Start filling the dbStats_p structure. */
  strncpy(dbStats_p->name_s, db_p->name_s, DB_NAME_MAX_SIZE - 1);
  dbStats_p->recordMaxNum = db_p->recordMaxNum;
  
  
  /* Walk through all the entries in the name table and complete
   * collecting the statistics. */
  for (idx = 0;idx < _DB_NAME_TABLE_SIZE;idx++) {
    dllList_p = &db_p->nameTable[idx];
    if (false == dll_is_list_empty(dllList_p)) {
      /* There are entries in the name table at this index.  Display
       * the head entry in the list. */
      dllNode_p  = dll_get_first(dllList_p);
      dbRecord_p = DLL_STRUCT_FROM_NODE_GET(dllNode_p, _db_record_t, 
                                            recordDllNode);      
      /* Update statistics. */
      dbStats_p->usedEntryNum++;
      dbStats_p->nameNum++;
      dbStats_p->indexCollisionNum = 0;      

      /* Check if there are more entries at this index (in this
       * DLlist). */
      while (NULL != (dllNode_p = dll_get_next_node(dllList_p, dllNode_p))) {
        /* There are entries that collide at this index.  Display them. */
        dbRecord_p = DLL_STRUCT_FROM_NODE_GET(dllNode_p, _db_record_t, 
                                              recordDllNode);                
        /* Update statistics. */
        dbStats_p->nameNum++;
        dbStats_p->indexCollisionNum++;
      }

      /* Update stats. */
      if (0 != dbStats_p->indexCollisionNum) {
        dbStats_p->collisionNum += dbStats_p->indexCollisionNum;
        dbStats_p->indexCollisionNum++;
        if (dbStats_p->indexCollisionNum > dbStats_p->maxIndexCollisionNum) {
          dbStats_p->maxIndexCollisionNum = dbStats_p->indexCollisionNum;
          dbStats_p->maxCollisionIndex    = idx;
        }
        if ((dbStats_p->indexCollisionNum < dbStats_p->minIndexCollisionNum) ||
            (0                 == dbStats_p->minIndexCollisionNum)) {
          dbStats_p->minIndexCollisionNum = dbStats_p->indexCollisionNum;
          dbStats_p->minCollisionIndex    = idx;
        }
      }
    } /* if - there are entries at this index (DLL list is not empty) */
  } /* for - walk through all the entries in the table */
  
  return db_ok_e;
} /* db_stats_get */


