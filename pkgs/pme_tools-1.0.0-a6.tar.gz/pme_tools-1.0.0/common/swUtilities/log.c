/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 *   File Name : log.c
 *
 * This file contains the implementation of the logging (log) module.
 *
 **********************************************************************/

/**********************************************************************
 * Include Files
 **********************************************************************/

#include <stdarg.h>
#include <sys/time.h>
#include <time.h>
#include <ctype.h>


#include <generic_types.h>
#include <log.h>






/**********************************************************************
 * Macro Definitions
 **********************************************************************/

/* The next few macros define some of the escape codes used while
 * generating logs. */
#define _LOG_NORMAL                  "\033[0m"
#define _LOG_RED                     "\033[1;37;41m"
#define _LOG_YELLOW                  "\033[1;37;43m"
#define _LOG_BLUE                    "\033[1;37;44m"



#define _LOG_DATA(logHandle, fileName_p, lineNum, functionName_p,     \
                  prefix_p, endMode_p, format_p)                      \
  {                                                                   \
    if (log_verbosity_mask_g & LOG_VERBOSITY_PREFIX)                  \
      {fprintf(logHandle, "%-5s:", prefix_p);}                        \
                                                                      \
    if (log_verbosity_mask_g & LOG_VERBOSITY_FILE)                    \
      {fprintf(logHandle, "%s:", fileName_p);}                        \
                                                                      \
    if (log_verbosity_mask_g & LOG_VERBOSITY_LNUM)                    \
      {fprintf(logHandle, "%u:", lineNum);}                           \
                                                                      \
    if (log_verbosity_mask_g & LOG_VERBOSITY_FUNC)                    \
      {fprintf(logHandle, "%s:", functionName_p);}                    \
                                                                      \
    if (log_verbosity_mask_g & LOG_VERBOSITY_MULTILINE)               \
      {fprintf(logHandle, "\n\t");}                                   \
                                                                      \
    va_start(arg, format_p);                                          \
    vfprintf(logHandle, format_p, arg);                               \
    va_end(arg);                                                      \
                                                                      \
    fprintf(logHandle, "%s\n", endMode_p);                            \
    fflush(logHandle);                                                \
  }                                      





/**********************************************************************
 * Type Definitions
 **********************************************************************/






/**********************************************************************
 * Global Data Definitions
 **********************************************************************/

/* This variable stores the global log level. */
static  log_log_Level_t log_logMask_g = 1;


/* This variable stores the global log verbosity. */
static  log_verbosity_t log_verbosity_mask_g = LOG_VERBOSE_FULL;


/* This variable stores the default logging device handle. */
static  handle_t log_handle_gp = NULL;


/* This variable holds the function that retrieves time of day */
static  log_get_time_of_day_t log_tod_func_gp = gettimeofday;




/**********************************************************************
 * Private Function Declarations
 **********************************************************************/







/**********************************************************************
 * Private Function Definitions
 **********************************************************************/







/**********************************************************************
 * Public Function Definitions
 **********************************************************************/

void 
log_string_log(
  log_log_Level_t  logLevel, 
  const char      *fileName_p,
  uint32_t         lineNum,
  const char      *functionName_p,
  const char      *prefix_p,
  const char      *format_p, 
  ...
  )
{
#define PRINTED_MICROSECS_FIELD_WIDTH  6
#define PRINTED_TIMESTAMP_MAX_SIZE     64
  va_list             arg;
  struct   timeval    timeValue;
  struct   timezone   timeZone;
  struct   tm         tmTime;
  /* The 64 byte size in the time_s declared below is sufficient for
   * how time_s[] is used at this time.  This size m */
  char                time_s[PRINTED_TIMESTAMP_MAX_SIZE] = "";
  handle_t            logHandle = LOG_STDOUT;
  char               *endMode_p = "";

  if (NULL == log_handle_gp) {
    /* Do not log when the log handle is not set, except if the log is
     * LOG_ERROR or LOG_WARNING. */
    if ((logLevel != LOG_ERROR) && (logLevel != LOG_WARNING)) {
      return;
    }
  }
  else {
    logHandle = log_handle_gp;
  }

    
  if ((logLevel & log_logMask_g) == 0 ) {
    return;
  }

  if (log_verbosity_mask_g & LOG_VERBOSITY_DATE)
  {
    if (0 == log_tod_func_gp(&timeValue, &timeZone)) {
      /* Build the current time string. */
      localtime_r(&timeValue.tv_sec, &tmTime);
      strftime(time_s, sizeof(time_s) - PRINTED_MICROSECS_FIELD_WIDTH,
               "%b %e %Y %k:%M:%S", &tmTime);
      sprintf(time_s, "%s:%06ld", time_s, timeValue.tv_usec);
    }
    else {
      sprintf(time_s, "Timestamp unknown");
    }
    fprintf(logHandle, "%s:", time_s);
  }
    
  if (log_verbosity_mask_g & LOG_VERBOSITY_LOGLVL)
  {
    if (logLevel & LOG_ERROR & log_logMask_g) {
      fprintf(logHandle, "%s%s  :", _LOG_RED, LOG_ERROR_STR);
      endMode_p = _LOG_NORMAL;
    } 
    else if (logLevel & LOG_WARNING & log_logMask_g) {
      fprintf(logHandle, "%s%s:", _LOG_YELLOW, LOG_WARNING_STR);
      endMode_p = _LOG_NORMAL;
    } 
    else if (logLevel & LOG_TMP & log_logMask_g) {
      fprintf(logHandle, "%s%s    :", _LOG_BLUE, LOG_TMP_STR);
      endMode_p = _LOG_NORMAL;
    }
    else if (logLevel & log_logMask_g) {
      if (logLevel & LOG_INFO & log_logMask_g) {
        fprintf(logHandle, "%s   :", LOG_INFO_STR);
      }
      else if (logLevel & LOG_TEST & log_logMask_g) {
        fprintf(logHandle, "%s   :", LOG_TEST_STR);
      }
      else if (logLevel & LOG_MUTEX & log_logMask_g) {
        fprintf(logHandle, "%s  :", LOG_MUTEX_STR);
      }
      else if (logLevel & LOG_MEMORY & log_logMask_g) {
        fprintf(logHandle, "%s :", LOG_MEMORY_STR);
      }
    } 
    else {
      return;
    }
  }
  else {
    if (logLevel & LOG_ERROR & log_logMask_g) {
      fprintf(logHandle, "%s", _LOG_RED);
      endMode_p = _LOG_NORMAL;
    } 
    else if (logLevel & LOG_WARNING & log_logMask_g) {
      fprintf(logHandle, "%s", _LOG_YELLOW);
      endMode_p = _LOG_NORMAL;
    } 
    else if (logLevel & LOG_TMP & log_logMask_g) {
      fprintf(logHandle, "%s", _LOG_BLUE);
      endMode_p = _LOG_NORMAL;
    }
    else if (logLevel & log_logMask_g) {
      /* Do nothing */
    } 
    else {
      return;
    }
  }

  /* Generate the log. */
  _LOG_DATA(logHandle, fileName_p, lineNum, functionName_p,
            prefix_p, endMode_p, format_p);


  /* Generate a copy of the LOG_ERROR, LOG_WARNING, and LOG_TMP logs
   * to stderr. */  
  if ((logHandle != stderr) && (logHandle != stdout)) {
    if (logLevel & LOG_ERROR & log_logMask_g) {
      fprintf(stderr, "%s:%s%s  :", time_s, _LOG_RED, LOG_ERROR_STR);
      _LOG_DATA(stderr, fileName_p, lineNum, functionName_p,
                prefix_p, _LOG_NORMAL, format_p);
    }
    else if (logLevel & LOG_WARNING & log_logMask_g) {
      fprintf(stderr, "%s:%s%s:", time_s, _LOG_YELLOW, LOG_WARNING_STR);
      _LOG_DATA(stderr, fileName_p, lineNum, functionName_p,
                prefix_p, _LOG_NORMAL, format_p);
    } 
    else if (logLevel & LOG_TMP & log_logMask_g) {
      fprintf(stderr, "%s:%s%s    :", time_s, _LOG_BLUE, LOG_TMP_STR);
      _LOG_DATA(stderr, fileName_p, lineNum, functionName_p,
                prefix_p, _LOG_NORMAL, format_p);
    }
  }
} /* log_string_log */


void 
log_memory_log(
  log_log_Level_t  logLevel,
  const char      *prefix_p,
  const void      *addr_p, 
  int              length, 
  bool             showString
  )
{
  int      width     = 16;
  uint8_t *_mem_p     = (uint8_t *)addr_p;
  int      i         = 0;
  void    *logHandle = LOG_STDOUT;
  char     ascii[width+1];


  if (NULL == log_handle_gp) {
    /* Do not log when the log handle is not set, except if the log is
     * LOG_ERROR or LOG_WARNING. */
    if ((logLevel != LOG_ERROR) && (logLevel != LOG_WARNING)) {
      return;
    }
  }
  else {
    logHandle = log_handle_gp;
  }


  /* Eventually, we may want to filter based on prefix */
  if ( prefix_p == NULL ) {
    return;
  }

  /* Only process the appropriate log level */
  if ( logLevel & log_logMask_g ) {
    for (i=0; i<length; i++) {
      /* Show memory address on a new line */
      if ( (i%width) == 0 ) {
        log_printf(logHandle, "        %8p: ", _mem_p);
      }

      /* Cumulate the ASCII string */
      if ( isprint(*_mem_p) ) {
        ascii[i%width] = *_mem_p;
      }
      else {
        ascii[i%width] = '.';
      }

      /* Show the current character as two hex digit */
      log_printf(logHandle, "%02x ", *_mem_p++);

      /* Check for end of line */
      if ( ((i+1)%width) == 0 ) {
        if ( showString ) {
          ascii[width] = 0;
          log_printf(logHandle, "     %s\n", ascii);
        }
        else {
          log_printf(logHandle, "\n");
        }
      }
    }

    /* Take care of the case where last line is not full */
    if ( (i%width) != 0 ) {
      ascii[i%width] = 0;
      while (i++%width) {
        log_printf(logHandle, "   ");
      }
      if ( showString ) {
        log_printf(logHandle, "     %s\n", ascii);
      }
      else {
        log_printf(logHandle, "\n");
      }
    }

    fflush(logHandle);
  }

} /* log_memory_log */


bool 
log_is_log_level_enabled(
  log_log_Level_t logLevel
  )
{
  if (0 != (logLevel & log_logMask_g)) {
    return true;
  }
  
  return false;
} /* log_is_log_level_enabled */


void 
log_level_set(
  log_log_Level_t  logLevel, 
  bool             value
  )
{
  if (true == value) {
    log_logMask_g |= logLevel;
  }
  else {
    log_logMask_g &= ~logLevel;
  }
} /* log_level_set */


log_log_Level_t 
log_mask_get(void)
{
  return log_logMask_g;
} /* log_mask_get */


void 
log_mask_set(
  log_log_Level_t  newLogMask
  )
{
  log_logMask_g = newLogMask;
} /* log_mask_set */


int 
log_printf(
  handle_t    logHandle, 
  const char *format_p, 
  ...
  )
{
  va_list  arg;
  int      result;
    
  if (HANDLE_NULL == logHandle) {
    /* Do not generate the log. */
    return 0;
  }
    
  va_start(arg, format_p);
  result = vfprintf(logHandle, format_p, arg);
  va_end(arg);
    
  return result;
} /* log_printf */


void 
log_handle_set(
  handle_t logHandle
  )
{
  log_handle_gp = logHandle;
} /* log_handle_set */


handle_t
log_handle_get(void)
{
  return log_handle_gp;
} /* log_handle_get */


handle_t
log_log_to_file(
  char *fileName_p
  )
{
  FILE *logFile_p = fopen(fileName_p, "w");


  log_handle_set(logFile_p);
  return logFile_p;
} /* log_log_to_file */


void 
log_clock_source_set(
  log_get_time_of_day_t  func
  )
{
  if ( func != HANDLE_NULL ) {
    log_tod_func_gp = func;
  }
} /* log_clock_source_set */


log_get_time_of_day_t 
log_clock_source_get(void)
{
  return log_tod_func_gp;
} /* log_clock_source_get */

log_verbosity_t
log_verbosity_mask_get(void)
{
   return log_verbosity_mask_g;
} /* log_verbosity_mask_get */

void
log_verbosity_mask_set(log_verbosity_t mask)
{
   log_verbosity_mask_g = mask;
} /* log_verbosity_mask_get */
