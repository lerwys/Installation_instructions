/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/********************************************************************************
 *   File Name : cli.c
 *
 *   This file contains the implementation of the Command Line Interface
 *   (CLI) module.
 *
 *******************************************************************************/

#define USE_READLINE

/* Do not use realline on platform that cannot support it. */
#ifdef DP_ROC
#undef USE_READLINE
#endif

#ifdef PMM_FOR_PMGEN
#undef USE_READLINE
#endif

// TODO PME2 still need readline?
#undef USE_READLINE

/*--------------------- Include Files -----------------------------------------*/

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <linux/if_ether.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>

#ifdef USE_READLINE
#include <editline/readline.h>
#endif

#include <cli.h>
#include <db.h>
#include <generic_types.h>
#include <log.h>
#include <idx.h>
#include <mem.h>


#ifdef DP_ROC

#undef CLOCK_MONOTONIC

#endif /* DP_ROC */

/* For the new toolchain */
#define index(s, c) (char *)(memchr(s, c, (size_t)strlen(s)))




/*--------------------- Macro Definitions--------------------------------------*/

/* The next definitions define the min() and max() macros.  Watch out
 * how you use them.  For example min = pmllMin_d(i++, j++) will
 * increment the smaller counter twice. */
#define _CLI_MIN(x, y)            ((x) < (y) ? (x) : (y))
#define _CLI_MAX(x, y)            ((x) > (y) ? (x) : (y))


#define _CLI_MAX_MENU_NAME_LEN      20
#define _CLI_MAX_MENU_DESCR_LEN     60 

#define _CLI_MAX_CMD_NAME_LEN       20
#define _CLI_MAX_CMD_DESCR_LEN      60

#define _CLI_MAX_PROMPT_LEN         80


#define _CLI_MENU_SIGNATURE         0x0c113456
#define _CLI_NULL_SIGNATURE         0


#define _CLI_VAR_CMD                "$"
#define _CLI_SYSTEM_CMD             "system"
#define _CLI_SCRIPT_CMD             "source"
#define _CLI_QUIT_CMD               "quit"
#define _CLI_QMARK_CMD              "?"
#define _CLI_HELP_CMD               "help"
#define _CLI_BACK_CMD               "back"
#define _CLI_ADD_CMD                "add"

#define _CLI_SPACE_CHARS            " \t"
#define _CLI_MENU_SEPERATOR         '/'

/* This macro defines the maximum number of parameters in a CLI command.  This
   macro is used by some of the built-in commands. */
#define _CLI_PARAM_MAX_NUM          32


/* The next few macros display common command option strings. */
#define _CLI_QM_STRING_DISPLAY()                                        \
  log_printf(log_handle, "\n\t%s"                                       \
             "\n\t   Like the %s option; displays the synopsis of the " \
             "command.\n", _cli_qm_keyword_sg, _cli_h_keyword_sg);

#define _CLI_HSTRING_DISPLAY()                                          \
  log_printf(log_handle, "\n\t%s"                                       \
             "\n\t   Like the %s option; displays the synopsis of the " \
             "command.\n",                                              \
             _cli_h_keyword_sg, _cli_qm_keyword_sg);

#define _CLI_HELP_STRING_DISPLAY()                                      \
  log_printf(log_handle, "\n\t%s"                                       \
             "\n\t   Displays the help information for the command.\n", \
             _cli_help_keyword_sg);


/* The next few macros define the maximum lengths of the presentation string for
 * different types of the CLI variable. */
#define _CLI_IPV6_ADDR_VAR_STR_LEN    INET6_ADDRSTRLEN
#define _CLI_IPV4_ADDR_VAR_STR_LEN    INET_ADDRSTRLEN
#define _CLI_UINT_VAR_STR_LEN         11
#define _CLI_ETH_ADDR_VAR_STR_LEN     18
#define _CLI_VAR_STR_LEN                                \
  _CLI_MAX(_CLI_IPV6_ADDR_VAR_STR_LEN,                  \
           _CLI_MAX(_CLI_IPV4_ADDR_VAR_STR_LEN,         \
                    _CLI_MAX(_CLI_UINT_VAR_STR_LEN,     \
                             _CLI_ETH_ADDR_VAR_STR_LEN)))


/* This macro defines the maximum size of the CLI variable type string. */
#define _CLI_VAR_TYPE_STR_LEN     9


/* This macro defines the maximum number of CLI variables. */
#define _CLI_VAR_MAX_NUM          2048


/* This macro defines the characters that can be used in a variable name. */
#define _CLI_VAR_NAME_CHARS           \
  "abcdefghijklmnoprstuvxyzABCDEFGHIJKLMNOPRSTUVXYZ1234567890_"









/*--------------------- Type Definitions---------------------------------------*/

/*
 * CLI Command info.
 */
typedef struct _cli_cmd_info_st {
  char                     cmd_name[_CLI_MAX_CMD_NAME_LEN];
  char                     cmd_descr[_CLI_MAX_CMD_DESCR_LEN];
  void                    *context_p;
  cli_cmd_handler_t        cmd_handler;
  uint32_t                 cmdFlags;
  struct _cli_cmd_info_st *next_cmd;  /* Next cmd in link list */
} _cli_cmd_info_t;


/* This type defines the CLI variable menu structure.  Each CLI menu tree will
 * have one CLI variable structure associated with it.  Each menu structure
 * contains a pointer to its CLI variable menu structure. */
typedef struct {
  handle_t  var_db_handle; /* CLI variable name DB */  
  long      seed;          /* seed value for generating random variables */
  bool      echo_on_flag;  /* true/false = on/off - echoing the parsed line */
} _cli_menu_var_t;
  

/* CLI Menu type.  The var_db_handle is a handle to a DB holding the names of
 * the CLI variables.  Only the root menu structure has this entry set. */
typedef struct _cli_menu_st {
  uint32_t              signature;
  char                  menu_name[_CLI_MAX_MENU_NAME_LEN];
  char                  menu_descr[_CLI_MAX_MENU_DESCR_LEN];
  uint32_t              option;
  struct _cli_menu_st  *parent_menu;   /* The menu directy parent to us */
  struct _cli_menu_st  *submenu;       /* Head of submenu link list */
  struct _cli_menu_st  *next_menu;     /* Next menu of same level menu list */
  _cli_cmd_info_t      *cmd_info;      /* Head cmd link list */
  _cli_menu_var_t      *menu_var_p;    /* CLI variable menu structure */
} _cli_menu_t;


/* This type defines the generic value of a CLI variable. */
typedef union {
  uint32_t  words[4];
  uint8_t   ipv6_addr[16];
  struct {
    uint64_t  high;
    uint64_t  low;
  } ipv6_addr_uint64;
  uint32_t  ipv4_addr;
  uint8_t   ipv4_addr_bytes[4];
  uint64_t  uint;
  uint8_t   eth_addr[ETH_ALEN];
  uint64_t  eth_addr_uint64;
} _cli_var_value_t;


/* This type defines the supported CLI variable types. */
typedef enum {
  _cli_null_var_type_e      = 0, /* null variable type */
  _cli_ipv6_addr_var_type_e = 1, /* IPv6 address variable type */
  _cli_ipv4_addr_var_type_e = 2, /* IPv4 address variable type */
  _cli_uint_var_type_e      = 3, /* unsigned integer variable type */
  _cli_eth_addr_var_type_e  = 4, /* Ethernet address variable type */
} _cli_var_type_t;


/* This type defines the supported CLI variable bases used when outputting the
 * values of the CLI variables.  Note that the concept of base is used with
 * unsigned numbers only, i.e., IPv4, IPv6 and Ethernet addresses do not use the
 * concept of base. */ 
typedef enum {
  _cli_null_var_base_e = 0, /* null variable base */
  _cli_dec_var_base_e  = 1, /* decimal variable base */
  _cli_hex_var_base_e  = 2, /* hexadecimal variable base */
} _cli_var_base_t;


/* This type defines the generic CLI variable. */
typedef struct {
  char              name[CLI_NAME_MAX_LENGTH]; /* variable name */
  _cli_var_type_t   type;                      /* variable type */
  _cli_var_base_t   base;                      /* variable base */
  bool              base_defined_flag;         /* is "base" defined flag */
  _cli_var_value_t  value;                     /* variable value */
  bool              value_defined_flag;        /* is "value" defined flag */
  _cli_var_value_t  mask;                      /* variable "mask" value */
  bool              mask_defined_flag;         /* is "mask" defined flag */
  _cli_var_value_t  from;                      /* variable "from" value */
  _cli_var_value_t  to;                        /* variable "to" value */
  bool              range_defined_flag;        /* is "range" defined flag */
  _cli_var_value_t  step;                      /* variable "step" value */
  bool              step_defined_flag;         /* is "step" defined flag */
  _cli_var_value_t  last_evaluated_value;      /* last evaluated var. value */
  uint32_t          evaluation_count;          /* numbero of var. evaluations */
} _cli_var_t;










/*--------------------- Global Data Definitions -------------------------------*/

/* This variable defines the CLI error string table. */
static const char *const _cli_error_code_strings_cg[] = {
  "CLI: Operation successful.",          /* cli_ok_e */
  "CLI: Operation failed.",              /* cli_error_e */
  "CLI: Invalid menu handle.",           /* cli_invalid_menu_handle_e */
  "CLI: NULL pointer parameter.",        /* cli_null_ptr_parameter_e */
  "CLI: Name is invalid.",               /* cli_name_is_invalid_e */
  "CLI: Name is too long.",              /* cli_name_is_too_long_e */
  "CLI: Out of memory.",                 /* cli_out_of_memory_e */
  "CLI: Corrupted menu.",                /* cli_corrupted_menu_e */
  "CLI: Too many parameters."            /* cli_too_many_parameters_e */
};


/* This is a cheat for command completion */
static char          **_cli_all_commands             = NULL;
static int             _cli_num_commands             = 0;
const int              _cli_max_commands             = 1024;


/* The next few variables define the keywords used in the built-in CLI
 * commands. */ 
static const char *_cli_all_name_keyword_sg      = "*";
static const char *_cli_base_keyword_sg          = "base";
static const char *_cli_dash_keyword_sg          = "-";
static const char *_cli_dec_keyword_sg           = "dec";
static const char *_cli_echo_keyword_sg          = "echo";
static const char *_cli_equal_keyword_sg         = "=";
static const char *_cli_from_keyword_sg          = "from";
static const char *_cli_from_value_keyword_sg    = "from_value";
static const char *_cli_h_keyword_sg             = "h";
static const char *_cli_help_keyword_sg          = "help";
static const char *_cli_hex_keyword_sg           = "hex";
static const char *_cli_qm_keyword_sg            = "?";
static const char *_cli_mask_keyword_sg          = "mask";
static const char *_cli_mask_value_keyword_sg    = "mask_value";
static const char *_cli_off_keyword_sg           = "off";
static const char *_cli_on_keyword_sg            = "on";
static const char *_cli_seed_keyword_sg          = "seed";
static const char *_cli_step_keyword_sg          = "step";
static const char *_cli_step_value_keyword_sg    = "step_value";
static const char *_cli_to_keyword_sg            = "to";
static const char *_cli_to_value_keyword_sg      = "to_value";
static const char *_cli_var_name_keyword_sg      = "var_name";
static const char *_cli_value_keyword_sg         = "value";






/*---------------- Internal functions protoptypes -----------------------------*/

int _cli_source_script(char* filename, _cli_menu_t **menu, int *quit_cmd, uint32_t option);








/*----------------- Private Function Definitions ------------------------------*/

static void 
_cli_add_command_to_global_list(
  const char *cmd)
{
  int i;

  /* Ensure memory exists to hold all of the commands */
  if ( _cli_all_commands == NULL ) {
    _cli_all_commands = malloc(_cli_max_commands * sizeof(char *));
    if ( _cli_all_commands == NULL ) {
      /* Can't hold that list */
      return;
    }
  }

  /* Ensure the command isn't alread there */
  for (i=0; i<_cli_num_commands; i++) {
    if ( strcmp(_cli_all_commands[i], cmd ) == 0) {
      /* Command already there */
      return;
    }
  }

  /* Blindly store the command into the global table */
  _cli_all_commands[_cli_num_commands++] = strdup(cmd);
}


/* @brief Returns menu handle from menu structure pointer, 
 *        or HANDLE_NULL if invalid */
static handle_t 
_cli_menu_to_handle(
  const _cli_menu_t *menu)
{
  if(menu == NULL || menu->signature != _CLI_MENU_SIGNATURE) 
    return(HANDLE_NULL);
  return((handle_t) menu);
}


/* @brief Returns internal menu structure pointer of handle is valid, 
 *        other wise NULL */
static _cli_menu_t* 
_cli_handle_to_menu(
  const handle_t handle)
{
  _cli_menu_t *menu = (_cli_menu_t*) handle;
  if(menu == NULL || menu->signature != _CLI_MENU_SIGNATURE) return NULL;
  return(menu);
}


/* @brief Check if the input string match a command.
 *        return 1 if it's a match, else 0. */
static int 
_cli_check_cmd(
  const char *input, 
  const char *cmd)
{
  if(strncmp(input, cmd, strlen(cmd)) == 0)
  {
    input += strlen(cmd);
    /* Make sure nothing follows, or what follows is only space/tab. */
    if(*input == '\0' || strspn(input, _CLI_SPACE_CHARS) > 0)
    {
      return 1;
    }
  }
  return 0;
}


/* @brief Check if the new command/menu name already exists in this menu. */
static cli_status_t 
_cli_check_name(
  const _cli_menu_t *menu, 
  const char        *name_p)
{
  
  _cli_menu_t* tmp_menu;
  _cli_cmd_info_t* tmp_cmd;
  
  if(strlen(name_p) == 0)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Blank menu/command name is "
               "invalid.");
    return(cli_name_is_invalid_e);
  }

  if(index(name_p, ' ') != NULL || index(name_p, '\t') != NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME,
               "Cannot use space/tab in menu/command name.");
    return(cli_name_is_invalid_e);
  }
  
  if(index(name_p, _CLI_MENU_SEPERATOR) != NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME,
               "Cannot use '%c' in menu/command name.", _CLI_MENU_SEPERATOR);
    return(cli_name_is_invalid_e);
  }

  if(_cli_check_cmd(name_p, _CLI_VAR_CMD)    ||
     _cli_check_cmd(name_p, _CLI_SYSTEM_CMD) ||
     _cli_check_cmd(name_p, _CLI_SCRIPT_CMD) ||
     _cli_check_cmd(name_p, _CLI_QUIT_CMD)   ||
     _cli_check_cmd(name_p, _CLI_QMARK_CMD)  ||
     _cli_check_cmd(name_p, _CLI_HELP_CMD)   ||
     _cli_check_cmd(name_p, _CLI_BACK_CMD))
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "'%s' is a reserved command.", 
               name_p);
    return(cli_name_is_invalid_e);
  }

  if(menu == NULL)
  {
    return(cli_ok_e);
  }

  tmp_menu = menu->submenu;
  while(tmp_menu != NULL)
  {
    if(_cli_check_cmd(name_p, tmp_menu->menu_name))
    {
      LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, 
                 "'%s' is already in use as a menu.", name_p);
      return(cli_name_is_invalid_e);
    }
    tmp_menu = tmp_menu->next_menu;
  }

  tmp_cmd = menu->cmd_info;
  while(tmp_cmd != NULL)
  {
    if(_cli_check_cmd(name_p, tmp_cmd->cmd_name))
    {
      LOG_STRING(LOG_WARNING, CLI_MODULE_NAME,
                 "'%s' is already in use as a command.", name_p);
      return(cli_name_is_invalid_e);
    }
    tmp_cmd = tmp_cmd->next_cmd;
  }
  
  return(cli_ok_e);
}


/* @brief Default help of a menu */
static int 
_cli_menu_usage(
  void *menu_ptr)
{
  _cli_menu_t      *menu = (_cli_menu_t *)menu_ptr,
    *menu_temp;
  _cli_cmd_info_t   *cmd_temp;

  printf("\nCommands available in the menu: \"%s\"\n", menu->menu_name);

  printf("%15s - Exit the cli application\n",  _CLI_QUIT_CMD);
  printf("%15s - Print this usage message\n",
         _CLI_HELP_CMD "|" _CLI_QMARK_CMD);

  if (menu->parent_menu != NULL)
  {
    printf("%15s - Go back to menu \"%s\"\n",
           _CLI_BACK_CMD, menu->parent_menu->menu_name);
  }
  printf("%15s - Run a system command\n", _CLI_SYSTEM_CMD " <cmd>");
  printf("%15s - Source a command file\n", _CLI_SCRIPT_CMD " <file>");
  printf("%15s - CLI variables\n", _CLI_VAR_CMD);
  
  /*
   * Print the list of submenu's
   */
  menu_temp = menu->submenu;
  while(menu_temp != NULL)
  {
    printf("%15s - %s\n", menu_temp->menu_name, menu_temp->menu_descr);
    menu_temp = menu_temp->next_menu;  
  }

  /*
   * Print the list of commands in this menu.
   */
  cmd_temp = menu->cmd_info;
  while(cmd_temp != NULL)
  {
    printf("%15s - %s\n", cmd_temp->cmd_name, cmd_temp->cmd_descr);
    cmd_temp = cmd_temp->next_cmd;
  }
  printf("\n");

  return(0);
} 


/* @brief Get the promt string.
 */
static int 
_cli_get_prompt(
  _cli_menu_t *menu, 
  char        *prompt)
{
  _cli_menu_t        *temp = menu;
  char              *position;
  char               tmp_prompt[_CLI_MAX_PROMPT_LEN];
  unsigned int       len;
  const char        *hide_str = "...";
  char               time_s[32]     = { 0 };
  unsigned int       timeStringSize = 0;
  unsigned int       promptMaxSize  = _CLI_MAX_PROMPT_LEN;
  

#ifdef CLI_DISABLE_TIME_IN_PROMPT
  struct   timeval   timeValue;
  struct   timezone  timeZone;
  struct   tm        tmTime;

  if (0 == gettimeofday(&timeValue, &timeZone)) {
    /* Build the current time string. */
    localtime_r(&timeValue.tv_sec, &tmTime);
    strftime(time_s, sizeof(time_s), "%b %e %Y %k:%M:%S ", &tmTime);
    timeStringSize = strlen(time_s);
  }
#endif

  /* Adjust the space available for the prompt (less the time stamp). */
  promptMaxSize -= timeStringSize;
  

  *prompt = '\0';
  /*
   * We'll build up the string of menu names from the end.
   */
  position = tmp_prompt + promptMaxSize - 1;
  
  strcpy(position - strlen(menu->menu_name), menu->menu_name);
  position -= strlen(menu->menu_name);
  len = strlen(menu->menu_name);
  
  temp = menu->parent_menu;
  
  while (temp != NULL)
  {
    /* If adding this menu name will give us too little room then we
     * hide this menu and all menu above. */
    if(len + (strlen(temp->menu_name) + 1) + strlen(hide_str)+1 >=
       promptMaxSize)
    {
      position -= (strlen(hide_str) + 1);
      strcpy(position, hide_str);
      *(position + strlen(position)) = _CLI_MENU_SEPERATOR;
      break;
    }

    position -= (strlen(temp->menu_name) + 1);
    len += (strlen(temp->menu_name) + 1);
    if(position < tmp_prompt || len > promptMaxSize)
    {
      LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Corrupted menu structure."); 
      return(1);
    }
    strcpy(position, temp->menu_name);
    *(position + strlen(position)) = _CLI_MENU_SEPERATOR;
    temp = temp->parent_menu;
  }


  /* Copy the time stamp to appear at the beginning of the prompt. */
  position -= timeStringSize;
  strncpy(position, time_s, timeStringSize);


  /* Copy the built prompt to the provided buffer. */
  strcpy(prompt, position);

  return(0);
}


/********************************************************************************
 * Validate the passed in variable name.
 *
 * param var_name_p  The variable name to validate.
 * retval            true if the validations was successful; false otherwise.
 *******************************************************************************/
static bool
_cli_var_name_validate(
  char *var_name_p)
{
  size_t  original_length = strlen(var_name_p);
  size_t  length          = 0;    

  length = strspn(var_name_p, _CLI_VAR_NAME_CHARS);
  if(length != original_length) {
    return false;
  }
  
  if ((0 == length) || (length > (CLI_NAME_MAX_LENGTH - 1))) {
    return false;
  }
  
  return true;
} /* _cli_var_name_validate */


/********************************************************************************
 * Compares the two passed in CLI variable values.
 *
 * NOTE: The function relies on all the variable value bytes that are not used
 *       by the variable value to be set to zero.
 *
 * param val1_p    One of the values to be compared.
 * param val2_p    The other value to be compared.
 * param var_type  The CLI variable type to use.  Both values are required to
 *                 be of the same, i.e., the var_type, type. 
 * retval          -1 when val1 is smaller than val2, 0 when val1 is equal to
 *                 val2 and 1 when val1 is greater than val2. 
 *******************************************************************************/
static int
_cli_var_value_cmp(
  _cli_var_value_t *val1_p,
  _cli_var_value_t *val2_p,
  _cli_var_type_t   var_type)
{
  uint64_t  low1  = 0;
  uint64_t  low2  = 0;
  uint64_t  high1 = 0;
  uint64_t  high2 = 0;


  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    low1  = ntohll(val1_p->ipv6_addr_uint64.low);
    low2  = ntohll(val2_p->ipv6_addr_uint64.low);
    high1 = ntohll(val1_p->ipv6_addr_uint64.high);
    high2 = ntohll(val2_p->ipv6_addr_uint64.high);

    if (high1 < high2) {
      return -1;
    }
    else if (high1 > high2) {
      return 1;
    }
    if (low1 < low2) {
      return -1;
    }
    else if (low1 > low2) {
      return 1;
    }
    else {
      return 0;
    }
    break;
  }

  case _cli_ipv4_addr_var_type_e: {
    low1 = ntohl(val1_p->ipv4_addr);
    low2 = ntohl(val2_p->ipv4_addr);

    if (low1 < low2) {
      return -1;
    }
    else if (low1 > low2) {
      return 1;
    }
    else {
      return 0;
    }
    break;
  }
  
  case _cli_uint_var_type_e: {
    if (val1_p->uint < val2_p->uint) {
      return -1;
    }
    else if (val1_p->uint > val2_p->uint) {
      return 1;
    }
    else {
      return 0;
    }
    break;
  }

  case _cli_eth_addr_var_type_e: {
    low1  = ntohll(val1_p->eth_addr_uint64);
    low2  = ntohll(val2_p->eth_addr_uint64);

    if (low1 < low2) {
      return -1;
    }
    else if (low1 > low2) {
      return 1;
    }
    else {
      return 0;
    }
    break;
  }

  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    break;
  }
  } /* switch */
  
  return 0;
} /* _cli_var_value_cmp */


/********************************************************************************
 * Adds the two passed in CLI variable values.
 *
 * param val1_p    One of the values to be added.
 * param val2_p    The other value to be added.
 * param sum_p     Where to store the result of adding the two values.
 * param var_type  The CLI variable type to use.  Both values are required to
 *                 be of the same, i.e., the var_type, type. 
 * retval          Pointer to the passed in sum_p value.
 *******************************************************************************/
static _cli_var_value_t *
_cli_var_value_add(
  _cli_var_value_t *val1_p,
  _cli_var_value_t *val2_p,
  _cli_var_value_t *sum_p,
  _cli_var_type_t   var_type)
{
  uint64_t  low1  = 0;
  uint64_t  low2  = 0;
  uint64_t  lows  = 0;
  uint64_t  high1 = 0;
  uint64_t  high2 = 0;
  uint64_t  highs = 0;


  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    low1  = ntohll(val1_p->ipv6_addr_uint64.low);
    low2  = ntohll(val2_p->ipv6_addr_uint64.low);
    high1 = ntohll(val1_p->ipv6_addr_uint64.high);
    high2 = ntohll(val2_p->ipv6_addr_uint64.high);

    lows  = low1 + low2;
    highs = high1 + high2;
    if (lows < low1) {
      highs++;
    }
    sum_p->ipv6_addr_uint64.low  = htonll(lows);
    sum_p->ipv6_addr_uint64.high = htonll(highs);
    break;
  }

  case _cli_ipv4_addr_var_type_e: {
    sum_p->ipv4_addr = val1_p->ipv4_addr + val2_p->ipv4_addr;
    break;
  }
  
  case _cli_uint_var_type_e: {
    sum_p->uint = val1_p->uint + val2_p->uint;
    break;
  }
    
  case _cli_eth_addr_var_type_e: {
    low1  = ntohll(val1_p->uint);
    low2  = ntohll(val2_p->uint);
    sum_p->uint = htonll(low1 + low2) & 0xffffffffffffULL;
    break;
  }

  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    break;
  }
  } /* switch */
  
  return sum_p;
} /* _cli_var_value_add */


/********************************************************************************
 * Subtract the val2_p value from the val1_p value.
 *
 * param val1_p    One of the CLI variable values to be use.
 * param val2_p    The other CLI variable value to be use.
 * param diff_p    Where to store the result of subtracting the two values.
 * param var_type  The CLI variable type to use.  Both values are required to
 *                 be of the same, i.e., the var_type, type. 
 * retval          Pointer to the passed in diff_p value.
 *******************************************************************************/
static _cli_var_value_t *
_cli_var_value_subtract(
  _cli_var_value_t *val1_p,
  _cli_var_value_t *val2_p,
  _cli_var_value_t *diff_p,
  _cli_var_type_t   var_type)
{
  uint64_t  low1  = 0;
  uint64_t  low2  = 0;
  uint64_t  lowd  = 0;
  uint64_t  high1 = 0;
  uint64_t  high2 = 0;
  uint64_t  highd = 0;


  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    low1  = ntohll(val1_p->ipv6_addr_uint64.low);
    low2  = ntohll(val2_p->ipv6_addr_uint64.low);
    high1 = ntohll(val1_p->ipv6_addr_uint64.high);
    high2 = ntohll(val2_p->ipv6_addr_uint64.high);

    /* Perform two's complement of val2_p. */
    low2 = ~low2;
    high2 = ~high2;
    low2++;
    if (low2 < 1) {
      high2++;
    }
    
    /* Do the regular addition. */
    lowd  = low1 + low2;
    highd = high1 + high2;
    if (lowd < low1) {
      highd++;
    }
    diff_p->ipv6_addr_uint64.low  = htonll(lowd);
    diff_p->ipv6_addr_uint64.high = htonll(highd);
    break;
  }

  case _cli_ipv4_addr_var_type_e: {
    low1 = ntohl(val1_p->ipv4_addr);
    low2 = ntohl(val2_p->ipv4_addr);
    diff_p->ipv4_addr = htonl(low1 - low2);
    break;
  }
  
  case _cli_uint_var_type_e: {
    diff_p->uint = val1_p->uint - val2_p->uint;
    break;
  }

  case _cli_eth_addr_var_type_e: {
    low1  = ntohll(val1_p->uint);
    low2  = ntohll(val2_p->uint);
    diff_p->uint = htonll(low1 - low2) & 0xffffffffffffULL;
    break;
  }
    
  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    break;
  }
  } /* switch */
  
  return diff_p;
} /* _cli_var_value_subtract */


/********************************************************************************
 * AND (bit-wise) the two passed in CLI variable values.
 *
 * param val1_p    One of the values to be ANDed.
 * param val2_p    The other value to be ANDed.
 * param and_p     Where to store the result of ANDing of the two values.
 * param var_type  The CLI variable type to use.  Both values are required to
 *                 be of the same, i.e., the var_type, type. 
 * retval          Pointer to the passed in and_p value.
 *******************************************************************************/
static _cli_var_value_t *
_cli_var_value_and(
  _cli_var_value_t *val1_p,
  _cli_var_value_t *val2_p,
  _cli_var_value_t *and_p,
  _cli_var_type_t   var_type)
{
  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    and_p->ipv6_addr_uint64.low  = (val1_p->ipv6_addr_uint64.low  &
                                    val2_p->ipv6_addr_uint64.low);
    and_p->ipv6_addr_uint64.high = (val1_p->ipv6_addr_uint64.high &
                                    val2_p->ipv6_addr_uint64.high);
    break;
  }

  case _cli_ipv4_addr_var_type_e: {
    and_p->ipv4_addr = val1_p->ipv4_addr & val2_p->ipv4_addr;
    break;
  }
  
  case _cli_uint_var_type_e:
  case _cli_eth_addr_var_type_e: {
    and_p->uint = val1_p->uint & val2_p->uint;
    break;
  }
    
  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    break;
  }
  } /* switch */
  
  return and_p;
} /* _cli_var_value_and */


/********************************************************************************
 * OR (bit-wise) the two passed in CLI variable values.
 *
 * param val1_p    One of the values to be ORed.
 * param val2_p    The other value to be ORed.
 * param or_p      Where to store the result of ORing of the two values.
 * param var_type  The CLI variable type to use.  Both values are required to
 *                 be of the same, i.e., the var_type, type. 
 * retval          Pointer to the passed in or_p value.
 *******************************************************************************/
static _cli_var_value_t *
_cli_var_value_or(
  _cli_var_value_t *val1_p,
  _cli_var_value_t *val2_p,
  _cli_var_value_t *or_p,
  _cli_var_type_t   var_type)
{
  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    or_p->ipv6_addr_uint64.low  = (val1_p->ipv6_addr_uint64.low  |
                                   val2_p->ipv6_addr_uint64.low);
    or_p->ipv6_addr_uint64.high = (val1_p->ipv6_addr_uint64.high |
                                   val2_p->ipv6_addr_uint64.high);
    break;
  }

  case _cli_ipv4_addr_var_type_e: {
    or_p->ipv4_addr = val1_p->ipv4_addr | val2_p->ipv4_addr;
    break;
  }
  
  case _cli_uint_var_type_e:
  case _cli_eth_addr_var_type_e: {
    or_p->uint = val1_p->uint | val2_p->uint;
    break;
  }
    
  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    break;
  }
  } /* switch */
  
  return or_p;
} /* _cli_var_value_or */


/********************************************************************************
 * NOT (bit-wise negate) the two passed in CLI variable value.
 *
 * param val1_p    One of the values to be NOTed.
 * param or_p      Where to store the result of NOTing of the value.
 * param var_type  The CLI variable type to use.
 * retval          Pointer to the passed in not_p value.
 *******************************************************************************/
static _cli_var_value_t *
_cli_var_value_not(
  _cli_var_value_t *val_p,
  _cli_var_value_t *not_p,
  _cli_var_type_t   var_type)
{
  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    not_p->ipv6_addr_uint64.low  = ~val_p->ipv6_addr_uint64.low;
    not_p->ipv6_addr_uint64.high = ~val_p->ipv6_addr_uint64.high;
    break;
  }

  case _cli_ipv4_addr_var_type_e: {
    not_p->ipv4_addr = ~val_p->ipv4_addr;
    break;
  }
  
  case _cli_uint_var_type_e:
  case _cli_eth_addr_var_type_e: {
    not_p->uint = ~val_p->uint;
    break;
  }
    
  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    break;
  }
  } /* switch */
  
  return not_p;
} /* _cli_var_value_not */


/********************************************************************************
 * Get a random CLI variabel value.
 *
 * param val_p     Where to store the generated random variable value.
 * param var_type  The CLI variable type to use. 
 * retval          The passed in val_p parameter.
 *******************************************************************************/
static _cli_var_value_t *
_cli_random_var_value_get(
  _cli_var_value_t *val_p,
  _cli_var_type_t   var_type)
{
  uint8_t  i = 0;
  

  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    for (i = 0;i < 4;i++) {
      val_p->words[i] = mrand48();
    }
    break;
  }

  case _cli_ipv4_addr_var_type_e: {
    val_p->ipv4_addr = mrand48();
    break;
  }
  
  case _cli_uint_var_type_e: {
    for (i = 0;i < 2;i++) {
      val_p->words[i] = mrand48();
    }
    break;
  }

  case _cli_eth_addr_var_type_e: {
    for (i = 0;i < 2;i++) {
      val_p->words[i] = mrand48();
    }
    val_p->eth_addr_uint64 &= 0xffffffffffffULL;
    break;
  }

  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    break;
  }
  } /* switch */
  
  return 0;
} /* _cli_random_var_value_get */


/********************************************************************************
 * Given the CLI variable type return the corresponding variable type string.
 *
 * NOTE: When you modify this function make sure that the _CLI_VAR_TYPE_STR_LEN
 *       macro is set appropriately.
 *
 * param var_type  The CLI variable type to use.
 * retval          String corresponding to the passed in variable type.
 *******************************************************************************/
static char *
_cli_var_type_ntop(
  _cli_var_type_t  var_type)
{
  switch (var_type) {
  case _cli_null_var_type_e:      return "null";
  case _cli_ipv6_addr_var_type_e: return "ipv6_addr";
  case _cli_ipv4_addr_var_type_e: return "ipv4_addr";
  case _cli_uint_var_type_e:      return "unsigned";
  case _cli_eth_addr_var_type_e:  return "eth_addr";
  default:
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    break;
  }
  
  return "unsupported";
} /* _cli_var_type_ntop */


/********************************************************************************
 * Given the CLI variable base return the corresponding variable base string.
 *
 * param var_base  The CLI variable base to use.
 * retval          String corresponding to the passed in variable base.
 *******************************************************************************/
static const char *
_cli_var_base_ntop(
  _cli_var_base_t  var_base)
{
  switch (var_base) {
  case _cli_null_var_base_e: return "null";
  case _cli_dec_var_base_e:  return _cli_dec_keyword_sg;
  case _cli_hex_var_base_e:  return _cli_hex_keyword_sg;
  default:
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_base_t "
               "variable type of %d.", var_base);
    break;
  }
  
  return "unsupported";
} /* _cli_var_base_ntop */


/********************************************************************************
 * Delete all variables in the specified CLI variable DB.
 *
 * param handle  Handle to the CLI DB to use.
 * retval        N/A
 *******************************************************************************/
static void
_cli_all_vars_delete(
  handle_t  handle)
{
  uint32_t     idx            = IDX_NULL_INDEX;
  uint32_t     safety_counter = 0;
  _cli_var_t  *var_p          = NULL;
  db_status_t  db_status      = db_ok_e;


  /* Deleting all variables. */
  while (true) {
    var_p = db_record_next_get(handle, &idx);
    if (NULL != var_p) {
      db_status = db_record_by_index_delete(handle, idx); 
      if (db_ok_e != db_status) {
        LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "DB failed to delete CLI "
                   "variable with index %u.  %s\n", idx,
                   db_error_string_get(db_status)); 
      }
      else {
        /* Free the variable record. */
        mem_free(var_p);
      }
    }
    else {
      break;
    }
    if (++safety_counter == -1U) {
      LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Had to break out from a "
                 "while() loop - check the logic.");
      break;
    }
  }

} /* _cli_all_vars_delete */


/********************************************************************************
 * Extract the CLI variable value and type from the specified string.
 *
 * Given a string, the function attempts to convert that string to a value of a
 * CLI variable.  While doing so the function determines the type of the CLI
 * variable.  If the conversion of the string to a value is successful the
 * function sets both the var_value_p and var_type_p parameters and returns
 * true.  Otherwise the function sets the var_type_p to _cli_null_var_type_e and
 * returns false.
 *
 * At present the following variable types are supported:
 *   - IPv6 address
 *   - IPv4 address
 *   - unsigned integer
 *   - Ethernet address
 *
 * An IPv6 address is expected to be specified using the "x:x:x:x:x:x:x:x"
 * format, where each "x" is a hexadecimal value of the eight 16-bit pieces of
 * the  address. 
 *
 * An IPv4 address is expected to be specified using the "ddd.ddd.ddd.ddd"
 * dotted-decimal notation where "ddd" is a one to three digit decimal number
 * between 0 and 255.  
 *
 * The Ethernet address is expected to be specified using the
 * "xx:xx:xx:xx:xx:xx" notation where "xx" is a hexadecimal number between 0 and
 * ff. 
 *
 * NOTE: The passed in var_str_p variable string may be altered by this function.
 *
 * param var_str_p    Pointer to the value string.
 * param var_value_p  Pointer to the extracted value of the variable.
 * param var_type_p   Pointer to the extracted type of the variable.
 * retval             true upon success; false otherwise.
 *******************************************************************************/
static bool
_cli_var_pton(
  char             *var_str_p,
  _cli_var_value_t *var_value_p,
  _cli_var_type_t  *var_type_p)
{
  int           status      = 0;
  bool          bool_status = false;
  uint8_t       i           = 0;
  cli_status_t  cli_status  = cli_error_e;
  uint32_t      hex_length  = 0;
  int32_t       argc        = 0;
  char         *argv_p[ETH_ALEN];
   

  /* Reset the variable type. */
  *var_type_p = _cli_null_var_type_e;
  

  /* Check if the passed in string can be converted an IPv6 address. */
  status = inet_pton(AF_INET6, var_str_p, var_value_p->ipv6_addr);
  if (1 == status) {
    *var_type_p = _cli_ipv6_addr_var_type_e;
    return true;
  }


  /* Check if the passed in string  can be converted an IPv4 address. */
  status = inet_pton(AF_INET, var_str_p, var_value_p->ipv4_addr_bytes);
  if (1 == status) {
    *var_type_p = _cli_ipv4_addr_var_type_e;
    return true;
  }
  

  /* Check if the passed in string  can be converted to an unsigned integer. */
  bool_status = cli_uint64get(var_str_p, &var_value_p->uint);
  if (true == bool_status) {
    *var_type_p = _cli_uint_var_type_e;
    return true;
  }


  /* Check if the passed in string  can be converted to an Ethernet address. */
  cli_status = cli_command_parse(var_str_p, &argc, argv_p, ETH_ALEN, ":");
  if((cli_status == cli_ok_e) && (ETH_ALEN == argc)) {
    for (i = 0;i < ETH_ALEN;i++) {
      bool_status = cli_hex_get(argv_p[i], &var_value_p->eth_addr[i], 1, 
                                &hex_length);
      if ((false == bool_status) || (1 != hex_length)) {
        break;
      }
    }
    if (ETH_ALEN == i) {
      *var_type_p = _cli_eth_addr_var_type_e;
      return true;
    }
  }
  
  return false;
} /* _cli_var_pton */


/********************************************************************************
 * Convert the specified CLI variable value to a string.
 *
 * param var_type      Type of the CLI variable to convert.
 * param var_nvalue_p  Pointer to the value of the CLI variable to convert.
 * param var_base      Variable base to use.
 * param var_pvalue_p  Pointer to the buffer where the function stores the
 *                     resulting presentation string.
 * param buffer_size   Size of the var_pvalue_p buffer.
 * retval              The function shall return a pointer to the buffer
 *                     containing the string, i.e., var_pvalue_p, if the
 *                     conversion succeeds, and NULL otherwise,  
 *******************************************************************************/
static const char *
_cli_var_ntop(
  _cli_var_type_t   var_type,
  _cli_var_value_t *var_value_p,
  _cli_var_base_t   var_base,
  char             *var_pvalue_p,
  uint8_t           buffer_size)
{
  const char *buffer_p = NULL;
  
  
  /* Make sure that the passed in buffer is not NULL. */
  if (NULL == var_pvalue_p) {
    return NULL;
  }
  

  /* Perform the conversion. */
  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    buffer_p = inet_ntop(AF_INET6, var_value_p, var_pvalue_p, buffer_size);
    break;
  }
  case _cli_ipv4_addr_var_type_e: {
    buffer_p = inet_ntop(AF_INET, var_value_p, var_pvalue_p, buffer_size);
    break;
  }
  case _cli_uint_var_type_e: {
    if (buffer_size >= _CLI_UINT_VAR_STR_LEN) {
      if (_cli_dec_var_base_e == var_base) {
        sprintf(var_pvalue_p, "%"PRIu64"", var_value_p->uint);
      }
      else {
        sprintf(var_pvalue_p, "0x%"PRIx64"", var_value_p->uint);
      }
      buffer_p = var_pvalue_p;
    }
    break;
  }
  case _cli_eth_addr_var_type_e: {
    if (buffer_size > _CLI_ETH_ADDR_VAR_STR_LEN) {
      sprintf(var_pvalue_p, "%02x:%02x:%02x:%02x:%02x:%02x", 
              var_value_p->eth_addr[0], var_value_p->eth_addr[1], 
              var_value_p->eth_addr[2], var_value_p->eth_addr[3], 
              var_value_p->eth_addr[4], var_value_p->eth_addr[5]);
      buffer_p = var_pvalue_p;
    }
    break;
  }
  case _cli_null_var_type_e: {
    break;
  }
  default:
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    break;
  }

  return buffer_p;
} /* _cli_var_ntop */


/********************************************************************************
 * Display the CLI variable record. 
 *
 * param cli_var_p   Pointer to the CLI variable to be displayed. 
 * param var_name    Name of the CLI variable to be displayed.
 * param var_index   DB index of the CLI variable to be displayed.
 * retval            0 upon success; error code otherwise.
 *******************************************************************************/
static void 
_cli_var_db_record_show(
  void     *cli_var_p, 
  char     *var_name_p,
  uint32_t  var_index)
{
  handle_t    log_handle                   = stdout;
  _cli_var_t *var_p                        = cli_var_p;
  char        var_pvalue[_CLI_VAR_STR_LEN] = {0};
  char       *type_s                       = "  type = ";
  char       *na_s                         = "N/A";
  char       *value_s                      = ", value = ";
  uint8_t     pad_name_size                = 8;
  uint32_t    spaces                       = strlen(_CLI_VAR_CMD) + 
    _CLI_MAX(pad_name_size,  strlen(var_name_p)) + strlen(type_s) + 
    _CLI_VAR_TYPE_STR_LEN + strlen(_cli_base_keyword_sg) + 2 + strlen(na_s) +
    strlen(value_s);
  
  var_index = 0;  /* suppress the "not used" compiler warning */


  switch (var_p->type) {
  case _cli_ipv6_addr_var_type_e: {
    log_printf(log_handle, "%s%-*s%s%*s %s %s%s",  _CLI_VAR_CMD,
               pad_name_size, var_name_p, type_s, _CLI_VAR_TYPE_STR_LEN,
               _cli_var_type_ntop(var_p->type), _cli_base_keyword_sg,
               (_cli_uint_var_type_e != var_p->type) ? 
               na_s : _cli_var_base_ntop(var_p->base), value_s);
    if (true == var_p->value_defined_flag) {
      log_printf(log_handle, "%s", _cli_var_ntop(var_p->type, &var_p->value, 
                                                 var_p->base, var_pvalue, 
                                                 _CLI_VAR_STR_LEN));
    }
    if (true == var_p->range_defined_flag) {
      if(true == var_p->value_defined_flag) {
        log_printf(log_handle, "\n%*s", spaces, "");
      }
      log_printf(log_handle, "%s - ", 
                 _cli_var_ntop(var_p->type, &var_p->from, var_p->base,
                               var_pvalue, _CLI_VAR_STR_LEN)); 
      log_printf(log_handle, "%s", 
                 _cli_var_ntop(var_p->type, &var_p->to, var_p->base, var_pvalue, 
                               _CLI_VAR_STR_LEN));
    }
    if ((true == var_p->step_defined_flag) ||
        (true == var_p->mask_defined_flag)) {
      log_printf(log_handle, "\n%*s", spaces, "");
      if (true == var_p->step_defined_flag) {
        log_printf(log_handle, "%s %s ", _cli_step_keyword_sg, 
                   _cli_var_ntop(var_p->type, &var_p->step, var_p->base,
                                 var_pvalue, _CLI_VAR_STR_LEN));
      }
      if (true == var_p->mask_defined_flag) {
        log_printf(log_handle, "%s %s ", _cli_mask_keyword_sg, 
                   _cli_var_ntop(var_p->type, &var_p->mask, var_p->base,
                                 var_pvalue, _CLI_VAR_STR_LEN));
      }
    }
    log_printf(log_handle, "\n");
    break;  
  }
 
  case _cli_ipv4_addr_var_type_e:
  case _cli_uint_var_type_e:
  case _cli_eth_addr_var_type_e: {
    log_printf(log_handle, "%s%-*s%s%*s %s %s%s", _CLI_VAR_CMD,
               pad_name_size, var_name_p, type_s, _CLI_VAR_TYPE_STR_LEN, 
               _cli_var_type_ntop(var_p->type), _cli_base_keyword_sg, 
               (_cli_uint_var_type_e != var_p->type) ?
               na_s : _cli_var_base_ntop(var_p->base), value_s);
    if (true == var_p->value_defined_flag) {
      log_printf(log_handle, "%s", _cli_var_ntop(var_p->type, &var_p->value, 
                                                  var_p->base, var_pvalue, 
                                                  _CLI_VAR_STR_LEN));
    }
    if (true == var_p->range_defined_flag) {
      if (true == var_p->value_defined_flag) {
        log_printf(log_handle, " ");
      }
      log_printf(log_handle, "%s - ", 
                 _cli_var_ntop(var_p->type, &var_p->from, var_p->base,
                               var_pvalue, _CLI_VAR_STR_LEN));
      log_printf(log_handle, "%s", 
                 _cli_var_ntop(var_p->type, &var_p->to, var_p->base, var_pvalue, 
                               _CLI_VAR_STR_LEN));
    }
    if (true == var_p->step_defined_flag) {
      log_printf(log_handle, " %s %s", _cli_step_keyword_sg, 
                 _cli_var_ntop(var_p->type, &var_p->step, var_p->base,
                               var_pvalue, _CLI_VAR_STR_LEN));
    }
    if (true == var_p->mask_defined_flag) {
      log_printf(log_handle, " %s %s", _cli_mask_keyword_sg, 
                 _cli_var_ntop(var_p->type, &var_p->mask, var_p->base,
                               var_pvalue, _CLI_VAR_STR_LEN));
    }
    log_printf(log_handle, "\n");
    break;
  }
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_p->type);
    break;
  }
  } /* switch */
  
} /* _cli_var_db_record_show */


/********************************************************************************
 * Get the order of the passed in CLI variable value. 
 *
 * param val_p     The CLI variable value to use.
 * param var_type  The CLI variable type to use.
 * retval          The binary order of the passed in variable value.
 *******************************************************************************/
static uint8_t
_cli_var_value_order_get(
  _cli_var_value_t *val_p,
  _cli_var_type_t   var_type)
{
  uint8_t           bit      = 0;
  uint8_t           byte     = 0;
  uint8_t           byte_num = 0;
  uint8_t           order    = 0;
  _cli_var_value_t  v        = *val_p;
  uint64_t          uint64   = ntohll(val_p->uint);
  uint8_t          *byte_p   = (uint8_t *)&v;

 
  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    byte_num = sizeof(val_p->ipv6_addr);
    break;
  }

  case _cli_ipv4_addr_var_type_e: {
    byte_num = sizeof(val_p->ipv4_addr);
   break;
  }

  case _cli_uint_var_type_e: {
    byte_p   = (uint8_t *)&uint64;
    byte_num = sizeof(val_p->uint);
    break;
  }

  case _cli_eth_addr_var_type_e: {
    byte_num = ETH_ALEN;
    break;
  }

  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    return 0;
  }
  } /* switch */


  /* Get the number of leading zeros. */
  for (byte = 0;byte < byte_num;byte++) {
    for (bit = 0;bit < 8;bit++) {
      if (0 == (byte_p[byte] & 0x80)) { 
        order++; 
      }
      else { 
        order = byte_num * 8 - order;  
        return order;
      }
      byte_p[byte] <<= 1;
    }
  }

  order = byte_num * 8 - order;  
  return order;
} /* _cli_var_value_order_get */


/********************************************************************************
 * Mask the indicated number of least significant bits in the given value.
 *
 * param val_p     The CLI variable value to use.
 * param var_type  The CLI variable type to use.
 * retval          The passed in val_p parameter.
 *******************************************************************************/
static _cli_var_value_t *
_cli_value_mask(
  _cli_var_value_t *val_p,
  uint8_t           bit_num,
  _cli_var_type_t   var_type)
{
  uint8_t  *byte_p        = (uint8_t *)val_p;
  uint8_t   byte_num      = 0;
  uint8_t   reset_bit_num = 0;
  uint8_t   byte          = 0;
  uint8_t   bit           = 0;
  uint64_t  uint64        = ntohll(val_p->uint);
  
 
  switch (var_type) {
  case _cli_ipv6_addr_var_type_e: {
    byte_num      = sizeof(val_p->ipv6_addr);
    reset_bit_num = byte_num * 8 - bit_num;
    break;
  }

  case _cli_ipv4_addr_var_type_e: {
    byte_num      = sizeof(val_p->ipv4_addr);
    reset_bit_num = byte_num * 8 - bit_num;
   break;
  }

  case _cli_uint_var_type_e: {
    byte_p        = (uint8_t *)&uint64;
    byte_num      = sizeof(val_p->uint);
    reset_bit_num = byte_num * 8 - bit_num;
    break;
  }

  case _cli_eth_addr_var_type_e: {
    byte_num      = ETH_ALEN;
    reset_bit_num = byte_num * 8 - bit_num;
    break;
  }

  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    return val_p;
  }
  } /* switch */


  /* Check if the passed in number was within the size of the variable value. */
  if (reset_bit_num > sizeof(_cli_var_value_t) * 8) {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "The number of bits to be reset "
               "%u is larger than the number of bits in the variable.", 
               reset_bit_num);
    return val_p;
  }

  /* Reset the most significant bits in the value. */
  for (byte = 0;(byte < byte_num) && (reset_bit_num > 0);byte++) {
    for (bit = 0;(bit < 8) && (reset_bit_num > 0);bit++, reset_bit_num--) {
      byte_p[byte] &= ~(0x80 >> bit);
    }
  }

  /* Adjust the value for the "unsigned" case. */
  if (_cli_uint_var_type_e == var_type) {
    val_p->uint = htonll(uint64);
  }
  
  return val_p;
} /* _cli_value_mask */


/********************************************************************************
 * Get a random variable from within a range.
 *
 * param val_from_p   The "from" CLI variable value.
 * param val_to_p     The "to" CLI variable value.
 * param val_rand_p   Where to store the generated random value.
 * param var_type     The CLI variable type to use.
 * retval             The passed in val_rand_p pointer.
 *******************************************************************************/
static _cli_var_value_t *
_cli_random_var_value_in_range_get(
  _cli_var_value_t *val_from_p,
  _cli_var_value_t *val_to_p,
  _cli_var_value_t *val_rand_p,
  _cli_var_type_t   var_type)
{
  uint8_t           range_order = 0;
  _cli_var_value_t  range_val;
  

  memset(&range_val, 0, sizeof(_cli_var_value_t));
  
  /* Get the size of the range. */
  _cli_var_value_subtract(val_to_p, val_from_p, &range_val, var_type);

  /* Get the number of the significant bits in the range. */
  range_order = _cli_var_value_order_get(&range_val, var_type);
  
  /* Get a random value. */
  _cli_random_var_value_get(val_rand_p, var_type);
    
  /* Mask the "range_order" number of the least significant bits in the random
   * variable value. */ 
  _cli_value_mask(val_rand_p, range_order, var_type);


  /* Forse the masked random value to be within the range. */
  if (_cli_var_value_cmp(val_rand_p, &range_val, var_type) > 0) {
    _cli_var_value_subtract(val_rand_p, &range_val, val_rand_p, var_type);
  }
  
  /* Add the random value to the beginning of the range (from). */
  _cli_var_value_add(val_rand_p, val_from_p, val_rand_p, var_type);
    
  return val_rand_p;
} /* _cli_random_var_value_in_range_get */


/********************************************************************************
 * Evaluate the value for the indicated variable.
 *
 * param var_name_p     The CLI variable to use.
 * retval               N/A  The newly evaluated value is stored in the
 *                      last_evaluated_value field of the passed in variable.
 *******************************************************************************/
static void
_cli_var_evaluate(
  _cli_var_t  *var_p)
{
  _cli_var_type_t   var_type = var_p->type;
  _cli_var_value_t  val_tmp;
  _cli_var_value_t  val_negated_mask;
  

  memset(&val_tmp, 0, sizeof(_cli_var_value_t));
  memset(&val_negated_mask, 0, sizeof(_cli_var_value_t));

  if ((true  == var_p->value_defined_flag) &&
      (false == var_p->range_defined_flag) &&
      (false == var_p->mask_defined_flag)) {
    /* This is a fixed variable.  Evaluate it. */
    var_p->last_evaluated_value = var_p->value;
  }
  else if ((false == var_p->value_defined_flag) &&
           (true  == var_p->range_defined_flag) &&
           (true  == var_p->step_defined_flag)  &&
           (false == var_p->mask_defined_flag)) {
    /* This is a volatile but not random range variable.  Evaluate it. */
    if (0 == var_p->evaluation_count) {
      var_p->last_evaluated_value = var_p->from;
    }
    else {
      /* check if the current value is the same as the "to" value. */
      if (0 == _cli_var_value_cmp(&var_p->last_evaluated_value, &var_p->to,
                                  var_type)) {
        var_p->last_evaluated_value = var_p->from;
      }
      else {
        /* Add the step to the current variable value. */
        _cli_var_value_add(&var_p->last_evaluated_value, &var_p->step, 
                           &var_p->last_evaluated_value, var_type);
        if ((0 >= _cli_var_value_cmp(&var_p->last_evaluated_value, &var_p->to,
                                     var_type)) &&
            (0 <= _cli_var_value_cmp(&var_p->last_evaluated_value, &var_p->from,
                                     var_type))) {
          /* The new variable is within the range;  use it (even if it wrapped
           * around both the from and to values). */
        }
        else {
          if (_cli_var_value_cmp(&var_p->last_evaluated_value, &var_p->from, 
                                 var_type) > 0) {
            /* The new variable would be larger than the "to" value.  Wrap around
             * the range. */
            _cli_var_value_subtract(&var_p->last_evaluated_value, &var_p->to, 
                                    &var_p->last_evaluated_value, var_type);
          }
          _cli_var_value_add(&var_p->from, &var_p->last_evaluated_value, 
                             &var_p->last_evaluated_value, var_type);
        }
      }
    }
  }
  else if ((false == var_p->value_defined_flag) &&
           (true  == var_p->range_defined_flag) &&
           (false == var_p->step_defined_flag)  &&
           (false == var_p->mask_defined_flag)) {
    /* This is a volatile random range variable.  Evaluate it. */
    _cli_random_var_value_in_range_get(&var_p->from, &var_p->to, 
                                       &var_p->last_evaluated_value, var_type);
  }
  else if ((true  == var_p->value_defined_flag) &&
           (false == var_p->range_defined_flag) &&
           (true  == var_p->mask_defined_flag)) {
    /* This is a volatile random variable with a mask.  Evaluate it. *
     * Get a random value. */
    _cli_random_var_value_get(&var_p->last_evaluated_value, var_type);
    /* Mask the random value. */
    _cli_var_value_and(&var_p->last_evaluated_value, &var_p->mask,
                       &var_p->last_evaluated_value, var_type);
    /* Mask the initial variable value. */
    _cli_var_value_not(&var_p->mask, &val_negated_mask, var_type);
    _cli_var_value_and(&var_p->value, &val_negated_mask, &val_tmp, var_type);
    /* Or the masked random value with the masked initial value. */
    _cli_var_value_or(&var_p->last_evaluated_value, &val_tmp, 
                      &var_p->last_evaluated_value, var_type);
  }
  else {
    LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Unsupported combination of "
               "arguments.");
  }
  
  
  /* Increment the evaluation count for this variable. */
  var_p->evaluation_count++;

} /* _cli_var_evaluate */


/********************************************************************************
 * Get the presentation value of the indicated variable.
 *
 * param var_db_handle  The CLI DB to use.
 * param var_name_p     Name of the CLI variable to use.
 * param var_pvalue_p   Pointer to the buffer where the function stores the
 *                      resulting presentation string.
 * param buffer_size    Size of the var_pvalue_p buffer.
 * retval               true upon success;  false otherwise.
 *******************************************************************************/
static bool
_cli_var_pvalue_get(
  handle_t  var_db_handle,
  char     *var_name_p,
  char     *var_pvalue_p,
  uint8_t   buffer_size)
{
  _cli_var_t *var_p = NULL;
  

  /* Check if a variable with the indicated name exists. */
  var_p = db_record_by_name_get(var_db_handle, var_name_p);
  if (NULL == var_p) {
    /* A variable with such a name does not exist. */
    return false;
  }
  
  
  /* Evaluate the variable, i.e., get the current value of the variable. */
  _cli_var_evaluate(var_p);
  
  /* Get the presentation string for the evaluated variable value. */
  if (NULL == _cli_var_ntop(var_p->type, &var_p->last_evaluated_value, 
                            var_p->base, var_pvalue_p, buffer_size)) {
    LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Failed to get the presentation "
               "value for the \"%s\" %s%s variable.", 
               _cli_var_type_ntop(var_p->type), _CLI_VAR_CMD, var_name_p);
    return false;
  }

  return true;
} /* _cli_var_pvalue_get */
        

/********************************************************************************
 * Parse a command for CLI variables.
 *
 * NOTE: The function assumes tha the maximum input command string length in
 *       CLI_USER_INPUT_MAX_LEN characters.
 *
 * param cmd_line_p  The command line to parse.
 * param menu_p      The CLI menu the command was invoked from.
 * retval            The function returns the parsed string upon success and
 *                   NULL upon a failure.  The caller is responsible for
 *                   freeing, using the mem_free() function, the returned
 *                   command string.
 *******************************************************************************/
static char *
_cli_var_parse(
  char        *in_cmd_line_p,
  _cli_menu_t *menu_p)
{
  bool              bool_status                     = true;
  char             *out_cmd_line_p                  = NULL;
  uint32_t          in_cmd_length                   = strlen(in_cmd_line_p);;
  uint32_t          in_cmd_position                 = 0;
  uint32_t          out_cmd_position                = 0;
  char             *in_cmd_var_position_p           = NULL;
  unsigned          var_prefix_length               = strlen(_CLI_VAR_CMD);
  char              var_name_s[CLI_NAME_MAX_LENGTH] = {0};  
  char              var_pvalue[_CLI_VAR_STR_LEN]    = {0};
  uint32_t          var_pvalue_length               = 0;
  uint32_t          var_name_length                 = 0;
  uint32_t          chunk_size                      = 0;
  char             *in_cmd_too_long_s               = 
    "The command entered exceeds the maximum allowed length of %u characters.\n";
  char             *out_cmd_too_long_s              = 
    "After variable parsing the resulting command exceeds the maximum allowed "
    "length of %u characters.\n";

  
  /* Make sure the input command is not too long. */
  if (in_cmd_length > (CLI_USER_INPUT_MAX_LEN - 1)) {
    log_printf(stdout, in_cmd_too_long_s, CLI_USER_INPUT_MAX_LEN - 1);
    return NULL;
  }
  

  /* Allocate space for the output command string. */
  out_cmd_line_p = mem_calloc(CLI_USER_INPUT_MAX_LEN, 1);
  if(NULL == out_cmd_line_p) {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unable to allocate %u bytes of "
               "memory needed for CLI variable parsing.", 
               CLI_USER_INPUT_MAX_LEN);
    return NULL;
  }
  out_cmd_line_p[0] = 0;
         

  /* Skip, i.e., do not evaluate, the first argument in the command line if it
   * is a CLI variable.  This makes it possible to redefine a CLI variable
   * without having to delete it first. */ 
  in_cmd_position = strspn(in_cmd_line_p, _CLI_SPACE_CHARS);
  in_cmd_var_position_p = strstr(&in_cmd_line_p[in_cmd_position], _CLI_VAR_CMD);
  if ((in_cmd_line_p + in_cmd_position) == in_cmd_var_position_p) {
    in_cmd_position++;
    if (out_cmd_position + in_cmd_position > CLI_USER_INPUT_MAX_LEN - 1) {
      log_printf(stdout, out_cmd_too_long_s, CLI_USER_INPUT_MAX_LEN - 1);
      bool_status = false;
    }
    else {
      strncpy(&out_cmd_line_p[out_cmd_position], &in_cmd_line_p[0], 
              in_cmd_position);
      out_cmd_position += in_cmd_position;
    }
  }
  
 
  /* Parse the input command line; search for variable names and replace them
   * with variable values. */
  while (true == bool_status) {
    in_cmd_var_position_p = strstr(&in_cmd_line_p[in_cmd_position],
                                   _CLI_VAR_CMD);
    if (NULL == in_cmd_var_position_p) {
      /* There are no more variables in the input command string. */
      chunk_size = in_cmd_length - in_cmd_position;
    }
    else {
      /* There is at least one more variable in the input command string. */
      chunk_size = (in_cmd_var_position_p - in_cmd_line_p) - in_cmd_position;
    }
    if ((NULL == in_cmd_var_position_p) && (0 == chunk_size)) {
      /* We are done! */
      break;
    }
    
    /* Copy the chunk from the current position to the next variable position to
       * the output command string.  First check if the output command would
       * not get too long. */
    if (out_cmd_position + chunk_size > CLI_USER_INPUT_MAX_LEN - 1) {
      log_printf(stdout, out_cmd_too_long_s, CLI_USER_INPUT_MAX_LEN - 1);
      bool_status = false;
      break;
    }
    strncpy(&out_cmd_line_p[out_cmd_position], &in_cmd_line_p[in_cmd_position],
            chunk_size);
    out_cmd_position += chunk_size;
    in_cmd_position  += chunk_size;
    

    if (NULL != in_cmd_var_position_p) {
      /* There is a variable prefix present. Extract the variable name. */
      var_name_length = strspn(in_cmd_var_position_p + var_prefix_length,
                               _CLI_VAR_NAME_CHARS);
      /* Validate the variable name. */
      if ((0 == var_name_length) || 
          (var_name_length > (CLI_NAME_MAX_LENGTH - 1))) {
        /* This is not a valid variable name; move passed the variable prefix. */
        if (out_cmd_position + var_prefix_length > CLI_USER_INPUT_MAX_LEN - 1) {
          log_printf(stdout, out_cmd_too_long_s, CLI_USER_INPUT_MAX_LEN - 1);
          bool_status = false;
          break;
        }
        strncpy(&out_cmd_line_p[out_cmd_position], 
                &in_cmd_line_p[in_cmd_position], var_prefix_length);
        out_cmd_position += var_prefix_length;
        in_cmd_position  += var_prefix_length;
      }
      else {
        /* We have a valid variable name. */
        strncpy(var_name_s, in_cmd_var_position_p + var_prefix_length, 
                var_name_length);
        var_name_s[var_name_length] = 0;
        
        /* Get the presentation value for this variable.  If the function fails
         * it means that the variable does not exist. */
        if (false == _cli_var_pvalue_get(menu_p->menu_var_p->var_db_handle, 
                                         var_name_s, var_pvalue, 
                                         _CLI_VAR_STR_LEN)) {
          /* The variabel does not exist.  Ignore it. */
          if (out_cmd_position + var_prefix_length + var_name_length > 
              CLI_USER_INPUT_MAX_LEN - 1) {
            log_printf(stdout, out_cmd_too_long_s, CLI_USER_INPUT_MAX_LEN - 1);
            bool_status = false;
            break;
          }
          strncpy(&out_cmd_line_p[out_cmd_position], 
                  &in_cmd_line_p[in_cmd_position], 
                  var_name_length + var_prefix_length);
          out_cmd_position += var_prefix_length + var_name_length;
          in_cmd_position  += var_prefix_length + var_name_length;
        }
        else {
          /* The variable exists.  Insert the value in the output
           * command. string */
          var_pvalue_length = strlen(var_pvalue);
          if (out_cmd_position + var_pvalue_length 
              > CLI_USER_INPUT_MAX_LEN - 1) {
            log_printf(stdout, out_cmd_too_long_s, CLI_USER_INPUT_MAX_LEN - 1);
            bool_status = false;
            break;
          }
          strncpy(&out_cmd_line_p[out_cmd_position], var_pvalue,
                  var_pvalue_length);
          out_cmd_position += var_pvalue_length;
          in_cmd_position  += var_prefix_length + var_name_length;
        }
      }
    }
  } /* while */


  if (false == bool_status) {
    /* Something went wrong.  Free the output command string. */
    mem_free(out_cmd_line_p);
    out_cmd_line_p = NULL;
  }
  
  return out_cmd_line_p;
} /* _cli_var_parse */


#ifdef these_are_testing_routines
/********************************************************************************
 * Test function generating random CLI variable values.
 *
 * param var_type  The CLI variable type to use. 
 * param var_base  The CLI variable bae to use. 
 * retval          N/A
 *******************************************************************************/
static void
_cli_var_random_value_test(
  _cli_var_type_t  var_type,
  _cli_var_base_t  var_base)
{
  _cli_var_value_t  val;
  _cli_var_value_t  min_val;
  _cli_var_value_t  max_val;
  uint64_t          counter = 0;
  char              var_pvalue1[_CLI_VAR_STR_LEN] = {0};
  char              var_pvalue2[_CLI_VAR_STR_LEN] = {0};
 

  _cli_random_var_value_get(&val, var_type);
  min_val = val;
  max_val = val;
  

  while (1) {
    counter++;

    _cli_random_var_value_get(&val, var_type);

    if (_cli_var_value_cmp(&val, &min_val, var_type) < 0) {
      min_val = val;
      log_printf(stdout, "(counter=%10llu) min_val changed: %*s - %*s\n",
                 counter, _CLI_VAR_STR_LEN, 
                 _cli_var_ntop(var_type, &min_val, var_base, 
                               var_pvalue1, _CLI_VAR_STR_LEN),
                 _CLI_VAR_STR_LEN,
                 _cli_var_ntop(var_type, &max_val, var_base, 
                               var_pvalue2, _CLI_VAR_STR_LEN));
    }
    if (_cli_var_value_cmp(&val, &max_val, var_type) > 0) {
      max_val = val;
      log_printf(stdout, "(counter=%10llu) max_val changed: %*s - %*s\n",
                 counter, _CLI_VAR_STR_LEN, 
                 _cli_var_ntop(var_type, &min_val, var_base, 
                               var_pvalue1, _CLI_VAR_STR_LEN),
                 _CLI_VAR_STR_LEN,
                 _cli_var_ntop(var_type, &max_val, var_base, 
                               var_pvalue2, _CLI_VAR_STR_LEN));
    }
  }
} /* _cli_var_random_value_test */


/********************************************************************************
 * Test the CLI variable add and subtract functions. 
 *
 * param var_type  The CLI variable type to use. 
 * retval          N/A
 *******************************************************************************/
static void
_cli_var_add_subtract_test(
  _cli_var_t *var_p)
{
  char              var_pvalue[_CLI_VAR_STR_LEN] = {0};
  char             *val_conversion_failed_p      = 
    "CLI variable conversion failed.";
  _cli_var_type_t   var_type                     = _cli_null_var_type_e;
  char              eth_addr_one[]               = "00:00:00:00:00:01";
  _cli_var_value_t  val_one;
  _cli_var_value_t  val_result;
  

  memset(&val_one, 0, sizeof(_cli_var_value_t));
  memset(&val_result, 0, sizeof(_cli_var_value_t));

  switch (var_p->type) {
  case _cli_ipv6_addr_var_type_e: {
    if (false == _cli_var_pton("0::1", &val_one, &var_type) ||
        (_cli_ipv6_addr_var_type_e != var_type)) {
      LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, val_conversion_failed_p);
      return;
    }
    break;
  }
    
  case _cli_ipv4_addr_var_type_e: {
    if (false == _cli_var_pton("0.0.0.1", &val_one, &var_type) ||
        (_cli_ipv4_addr_var_type_e != var_type)) {
      LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, val_conversion_failed_p);
      return;
    }
    break;
  }
  
  case _cli_uint_var_type_e: {
    if (false == _cli_var_pton("1", &val_one, &var_type) ||
        (_cli_uint_var_type_e != var_type)) {
      LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, val_conversion_failed_p);
      return;
    }
    break;
  }
    
  case _cli_eth_addr_var_type_e: {
    if (false == _cli_var_pton(eth_addr_one, &val_one, &var_type) ||
        (_cli_eth_addr_var_type_e != var_type)) {
      LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, val_conversion_failed_p);
      return;
    }
    break;
  }
    
  case _cli_null_var_type_e:
  default: {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Unsupported _cli_var_type_t "
               "variable type of %d.", var_type);
    return;
  }
  } /* switch */
  
 
  if (true == var_p->value_defined_flag) {
    /* Do the addition test. */
    log_printf(stdout, "%s + ", _cli_var_ntop(var_p->type, &var_p->value, 
                                              var_p->base, var_pvalue, 
                                              _CLI_VAR_STR_LEN));
    log_printf(stdout, "%s = ", _cli_var_ntop(var_p->type, &val_one, 
                                              var_p->base, var_pvalue, 
                                              _CLI_VAR_STR_LEN));
    log_printf(stdout, "%s\n", _cli_var_ntop(
                 var_p->type, _cli_var_value_add(
                   &var_p->value, &val_one, &val_result, var_p->type),
                 var_p->base, var_pvalue, _CLI_VAR_STR_LEN));

    /* Do the subtraction test. */
    log_printf(stdout, "%s - ", _cli_var_ntop(var_p->type, &var_p->value, 
                                              var_p->base, var_pvalue, 
                                              _CLI_VAR_STR_LEN));
    log_printf(stdout, "%s = ", _cli_var_ntop(var_p->type, &val_one, 
                                              var_p->base, var_pvalue, 
                                              _CLI_VAR_STR_LEN));
    log_printf(stdout, "%s\n", _cli_var_ntop(
                 var_p->type, _cli_var_value_subtract(
                   &var_p->value, &val_one, &val_result, var_p->type),
                 var_p->base, var_pvalue, _CLI_VAR_STR_LEN));
  }
  
} /* _cli_var_add_subtract_test */


/********************************************************************************
 * Test function generating random CLI variable values in a range.
 *
 * param var_type  The CLI variable type to use. 
 * retval          N/A
 *******************************************************************************/
static void
_cli_var_random_range_test(
  _cli_var_t *var_p)
{
  uint8_t           i                            = 0;
  char              var_pvalue[_CLI_VAR_STR_LEN] = {0};
  _cli_var_value_t  val_rand;
  

  if (true == var_p->range_defined_flag) {
    for (i = 0;i <= 32;i++) {          
      log_printf(stdout, "%s\n", _cli_var_ntop(
                   var_p->type, _cli_random_var_value_in_range_get(
                     &var_p->from, &var_p->to, &val_rand, var_p->type),
                   var_p->base, var_pvalue, _CLI_VAR_STR_LEN));
    }
  }
  
} /* _cli_var_random_range_test */
#endif


/********************************************************************************
 * Process the CLI variable command.
 *
 * param cmd_p   The CLI variable command string.
 * param menu_p  The CLI menu the command was invoked from.
 * retval        0 upon success; error code otherwise.
 *******************************************************************************/
static int
_cli_var_cmd(
  char        *cmd_p,
  _cli_menu_t *menu_p)
{
  handle_t          log_handle         = LOG_STDOUT;
  int               status             = 0;
  bool              bool_status        = false;
  cli_status_t      cli_status         = cli_error_e;
  char             *invalid_cmd_p      = "Invalid command.\n";
  char             *invalid_var_name_p = "Invalid variable name.\n";
  unsigned          var_prefix_length  = strlen(_CLI_VAR_CMD);
  db_status_t       db_status          = db_ok_e;
  _cli_var_t       *old_var_p          = NULL;
  _cli_var_t       *new_var_p          = NULL;
  _cli_var_type_t   var_type           = _cli_null_var_type_e;
  char             *var_name_p         = NULL;
  uint32_t          idx                = IDX_NULL_INDEX;
  uint32_t          arg_left           = 0;
  uint32_t          arg_id             = 0;
  uint32_t          arg_advance        = 0;
  int32_t           argc               = 0;
  uint64_t          seed               = 0;
  char             *argv_p[_CLI_PARAM_MAX_NUM];
  _cli_var_t        var;
  _cli_var_value_t  tmp_var;
  
  
  memset(&var, 0, sizeof(var));
  

  /* Process the command line parameters. */
  cli_status = cli_command_parse(cmd_p, &argc, argv_p, _CLI_PARAM_MAX_NUM, 
                                _CLI_SPACE_CHARS);  
  if(cli_status != cli_ok_e) {
    log_printf(log_handle, "%s\n", cli_error_string_get(cli_status));
    return EINVAL;
  }


  /* Process the CLI variable ?, h and help commands. */
  if ((argc >= 2) && (0 == strcmp(argv_p[0], _CLI_VAR_CMD)) &&
      ((0 == strcmp(argv_p[1], _cli_qm_keyword_sg)) ||
       (0 == strcmp(argv_p[1], _cli_h_keyword_sg))  ||
       (0 == strcmp(argv_p[1], _cli_help_keyword_sg)))) {
    log_printf(log_handle,
               "Synopsis:"
               "\n\t%s %s|%s"
               "\n\t%s %s"
               "\n\t%s%s %s %s [%s %s] [%s %s|%s]"
               "\n\t%s%s %s %s %s %s [%s] [%s %s|%s]"
               "\n\t%s%s %s"
               "\n\t%s%s %s"
               "\n\t%s%s %s"
               "\n\t%s%s %s"
               "\n\t%s %s %s|%s"
               "\n\t%s %s %s"
               "\n",
               _CLI_VAR_CMD, _cli_qm_keyword_sg, _cli_h_keyword_sg,
               _CLI_VAR_CMD, _cli_help_keyword_sg, 
               _CLI_VAR_CMD, _cli_var_name_keyword_sg, _cli_equal_keyword_sg, 
               _cli_value_keyword_sg, _cli_mask_keyword_sg, 
               _cli_mask_value_keyword_sg, _cli_base_keyword_sg,
               _cli_dec_keyword_sg, _cli_hex_keyword_sg,
               _CLI_VAR_CMD, _cli_var_name_keyword_sg, _cli_equal_keyword_sg, 
               _cli_from_value_keyword_sg, _cli_dash_keyword_sg,
               _cli_to_value_keyword_sg, _cli_step_value_keyword_sg,
               _cli_base_keyword_sg, _cli_dec_keyword_sg, _cli_hex_keyword_sg,
               _CLI_VAR_CMD, _cli_all_name_keyword_sg, _cli_qm_keyword_sg,
               _CLI_VAR_CMD, _cli_var_name_keyword_sg, _cli_qm_keyword_sg,
               _CLI_VAR_CMD, _cli_all_name_keyword_sg, _cli_equal_keyword_sg,
               _CLI_VAR_CMD, _cli_var_name_keyword_sg, _cli_equal_keyword_sg,
               _CLI_VAR_CMD, _cli_echo_keyword_sg, _cli_on_keyword_sg, 
               _cli_off_keyword_sg,
               _CLI_VAR_CMD, _cli_seed_keyword_sg, _cli_value_keyword_sg);
    if (0 == strcmp(argv_p[1], _cli_help_keyword_sg)) {
      log_printf(log_handle, 
        "\nDescription:"
    "\n\tThe \"%s\" command or prefix can be used to create and reference CLI"
    "\n\tvariables.  Currently, four types of CLI variables are supported:"
    "\n\t"
    "\n\t   - IPv6 address variables     (size of 16 bytes),"
    "\n\t   - IPv4 address variables     (size of 4 bytes),"
    "\n\t   - unsigned integer variables (size of up to 8 bytes),"
    "\n\t   - Ethernet address variables (size of 6 bytes)."
    "\n\t"
    "\n\tAn IPv6 address is expected to be specified using the"
    "\n\t\"x:x:x:x:x:x:x:x\" format, where each \"x\" is a hexadecimal value of"
    "\n\tthe eight 16-bit pieces of the address. An IPv4 address is expected to"
    "\n\tbe specified using the \"ddd.ddd.ddd.ddd\" dotted-decimal notation"
    "\n\twhere \"ddd\" is a one to three digit decimal number between 0 and 255."
    "\n\tThe Ethernet address is expected to be specified using the"
    "\n\t\"xx:xx:xx:xx:xx:xx\" notation where \"xx\" is a hexadecimal number"
    "\n\tbetween 0 and ff."
    "\n"
    "\n\tA CLI variable can be defined using one of the following commands:"
    "\n"
    "\n\t   %s%s %s %s [%s %s] [%s %s|%s]"
    "\n\t   %s%s %s %s %s %s [%s] [%s %s|%s]"
    "\n"
    "\n\tThe \"%s%s\" construct indicates the variable name.  Each variable name"
    "\n\tmust have the \"%s\" prefix followed by a non-empty string built from"
    "\n\tlower case characters 'a' through 'z', and/or upper case characters"
    "\n\t'A' through 'Z', and/or digits '0' through '9' and/or the '_'"
    "\n\tcharacter.  Any other characters are illegal in the variable name."
    "\n\tNote also that the \"%s\" and \"%s\" keywords must be delimited by"
    "\n\tspaces."
    "\n"
    "\n\tThe value of a CLI variable can be either fixed or volatile.  If a"
    "\n\trange or a non-zero mask is specified then the variable has a volatile"
    "\n\tvalue;  otherwise the variable has a fixed value.  Each time a variable"
    "\n\tis used in a CLI command, the CLI command parser replaces that variable"
    "\n\tname in the command with the value of the variable.  For a fixed"
    "\n\tvariable the value is always the same.  For a volatile variable every"
    "\n\treference to the variable generates a different value.  The value is"
    "\n\tgenerated subject to the range, step or mask if they were specified."
    "\n\tIf a range is specified without a step value, then a random value is"
    "\n\tgenerated from within the specified range.  If a mask is specified then"
    "\n\tthe random value is generated first and then that value is ANDed with"
    "\n\tthe mask and finally it is ORed with the masked initial value of the"
    "\n\tvariable."
    "\n\t"
    "\n\tUniform distribution is used for generating all random values."
    "\n",
                 _CLI_VAR_CMD, 
                 _CLI_VAR_CMD, _cli_var_name_keyword_sg, _cli_equal_keyword_sg, 
                 _cli_value_keyword_sg, _cli_mask_keyword_sg, 
                 _cli_mask_value_keyword_sg, _cli_base_keyword_sg,
                 _cli_dec_keyword_sg, _cli_hex_keyword_sg,
                 _CLI_VAR_CMD, _cli_var_name_keyword_sg, _cli_equal_keyword_sg, 
                 _cli_from_value_keyword_sg, _cli_dash_keyword_sg,
                 _cli_to_value_keyword_sg, _cli_step_value_keyword_sg,
                 _cli_base_keyword_sg, _cli_dec_keyword_sg, _cli_hex_keyword_sg,
                 _CLI_VAR_CMD, _cli_var_name_keyword_sg, 
                 _CLI_VAR_CMD, 
                 _cli_equal_keyword_sg, _cli_dash_keyword_sg);

      log_printf(log_handle, "\nParameters:");
      log_printf(log_handle, "\n\t%s%s %s"
    "\n\t   Requests the CLI variable module to display all the currently"
    "\n\t   defined CLI variables.\n",
                 _CLI_VAR_CMD, _cli_all_name_keyword_sg, _cli_qm_keyword_sg);
      log_printf(log_handle, "\n\t%s%s %s"
    "\n\t   Requests the CLI variable module to display the information for the"
    "\n\t   \"%s%s\" variable.\n",
                 _CLI_VAR_CMD, _cli_var_name_keyword_sg, _cli_qm_keyword_sg, 
                 _CLI_VAR_CMD, _cli_var_name_keyword_sg);
      log_printf(log_handle, "\n\t%s%s %s"
    "\n\t   Requests the CLI variable module to delete all the currently defined"
    "\n\t   CLI variables.\n",
                 _CLI_VAR_CMD, _cli_all_name_keyword_sg, _cli_equal_keyword_sg);
      log_printf(log_handle, "\n\t%s%s %s"
    "\n\t   Requests the CLI variable module to delete the \"%s%s\" variable.\n",
                 _CLI_VAR_CMD, _cli_var_name_keyword_sg, _cli_equal_keyword_sg, 
                 _CLI_VAR_CMD, _cli_var_name_keyword_sg);
      log_printf(log_handle, "\n\t%s %s %s|%s"
    "\n\t   Instructs the CLI variable module whether it should or should not"
    "\n\t   print the parsed command to the standard output.  Printing a parsed"
    "\n\t   command to the standard output is a way to find out what value has"
    "\n\t   been assigned to a variable in a given command.  Note that the"
    "\n\t   parsed command is printed, provided the %s option is set to %s, only"
    "\n\t   if the original command was modified by the CLI parser.  By default"
    "\n\t   the %s option is set to %s.\n",
                 _CLI_VAR_CMD, _cli_echo_keyword_sg, _cli_on_keyword_sg, 
                 _cli_off_keyword_sg, _cli_echo_keyword_sg, _cli_on_keyword_sg,
                 _cli_echo_keyword_sg, _cli_on_keyword_sg);
      log_printf(log_handle, "\n\t%s %s %s"
    "\n\t   Instructs the CLI variable module to use the specified, rather than"
    "\n\t   a pseudo-random, seed value while generating random values.  This"
    "\n\t   option can be used to create reproducible results.\n",
                 _CLI_VAR_CMD, _cli_seed_keyword_sg, _cli_value_keyword_sg);
      _CLI_QM_STRING_DISPLAY();
      log_printf(log_handle, "\n\t%s [%s|%s]"
    "\n\t   Instructs the CLI variable module to use the decimal or hexadecimal"
    "\n\t   format when displaying the variable.  By default the decimal base"
    "\n\t   is used, however, if a mask is specified then the default base"
    "\n\t   becomes the hexadecimal base.  Note that this option is applicable"
    "\n\t   to the unsigned variables only.\n",
                 _cli_base_keyword_sg, _cli_dec_keyword_sg, _cli_hex_keyword_sg);
      _CLI_HSTRING_DISPLAY();
      _CLI_HELP_STRING_DISPLAY();
      log_printf(log_handle, "\nExamples:");
      log_printf(log_handle, 
    "\n\tConsider the following CLI variable definitions:"
    "\n\t"
    "\n\t   %svar1 %s 1777"
    "\n\t   %svar2 %s 0 %s 0xff"
    "\n\t   %svar3 %s 0x1234 %s 0xffff0000"
    "\n\t"
    "\n\tVariable var1 has a fixed value of 1777.  Every reference to this"
    "\n\tvariable generates the same value of 1777.  Variable var2 has a"
    "\n\tvolatile value that is selected randomly from within the 0 to 0xff"
    "\n\trange.  Variable var3 has a 4-byte long volatile value.  The value of"
    "\n\tthe two least significant bytes is 0x1234 and the value of the two most"
    "\n\tsignificant bytes is selected randomly.  The value of this variable"
    "\n\tcould be 0xcb671234, 0xd8321234, etc."
    "\n",
                 _CLI_VAR_CMD, _cli_equal_keyword_sg,
                 _CLI_VAR_CMD, _cli_equal_keyword_sg, _cli_mask_keyword_sg,
                 _CLI_VAR_CMD, _cli_equal_keyword_sg, _cli_mask_keyword_sg);
      log_printf(log_handle, 
    "\n\tConsider the following CLI variable definitions involving ranges:"
    "\n\t"
    "\n\t   %svar4 %s 100 %s 200"
    "\n\t   %svar5 %s 100 %s 200 %s 70"
    "\n\t"
    "\n\tVariable var4 has a volatile value that is selected randomly from"
    "\n\twithin the 100 to 200 range.  Variable var5 has a volatile value.  The"
    "\n\tfirst reference to variable var5 generates the value of 100.  The"
    "\n\tsubsequent references to variable var5 generate values: 170, 140, 110,"
    "\n\t180, 150, 120, etc."
    "\n",
                 _CLI_VAR_CMD, _cli_equal_keyword_sg, _cli_dash_keyword_sg,
                 _CLI_VAR_CMD, _cli_equal_keyword_sg, _cli_dash_keyword_sg,
                 _cli_step_keyword_sg);
      log_printf(log_handle, 
    "\n\tFinally, consider the following CLI variable definitions.  These"
    "\n\tdefinitions involve references to already defined CLI variables:"
    "\n\t"
    "\n\t   %svar6 %s %svar4"
    "\n\t   %svar7 %s 0 %s %svar1 %s %svar2"
    "\n\t"
    "\n\tVariable var6 has a fixed value, i.e., every reference to this variable"
    "\n\tyields the same value, however, this fixed value is selected randomly"
    "\n\tfrom within the 100 - 200 range, as per the definitions of variable"
    "\n\tvar4.  The definition of variable var7 shows that multiple references"
    "\n\tto existing CLI variables can be used.",
                 _CLI_VAR_CMD, _cli_equal_keyword_sg, _CLI_VAR_CMD,
                 _CLI_VAR_CMD, _cli_equal_keyword_sg, _cli_dash_keyword_sg,
                 _CLI_VAR_CMD, _cli_step_keyword_sg, _CLI_VAR_CMD);
      log_printf(log_handle, "\n");
    }
  } /* if - ?, h and help commands */
  else if ((argc >= 3) && 
           (0 == strncmp(argv_p[0], _CLI_VAR_CMD, var_prefix_length)) &&
           (0 == strcmp(argv_p[1], _cli_equal_keyword_sg))) {
    /* Defining a variable.  Validate the variable name. */
    if (false == _cli_var_name_validate(argv_p[0] + var_prefix_length)) {
      /* The variable name is not specified. */
      log_printf(log_handle, invalid_var_name_p); 
      status = EINVAL;
    }
    else {     
      /* Allocate a new variable record. */
      new_var_p = mem_malloc(sizeof(_cli_var_t));
      if (NULL == new_var_p) {
        status = ENOMEM;
      }
      else {
        /* Reset the variable record. */
        memset(new_var_p, 0, sizeof(_cli_var_t));
        strcpy(new_var_p->name, argv_p[0] + var_prefix_length);
        new_var_p->type               = _cli_null_var_type_e;
        new_var_p->base               = _cli_dec_var_base_e;
        new_var_p->base_defined_flag  = false;
        new_var_p->value_defined_flag = false;
        new_var_p->mask_defined_flag  = false;
        new_var_p->range_defined_flag = false;
        new_var_p->step_defined_flag  = false;
        
        
        /* Read the remaining options in the command line. */
        arg_left = argc - 2; /* for the already read "$name =" part */
        arg_id   = 2;        /* for the already read "$name =" part */
        
        while ((0 == status) && (arg_left > 0)) {
          /* Check for the "base" option. */
          if ((arg_left >= 2) && 
              (0 == strcmp(argv_p[arg_id], _cli_base_keyword_sg))) {
            arg_advance = 2;
            if (0 == strcmp(argv_p[arg_id + 1], _cli_dec_keyword_sg)) {
              new_var_p->base_defined_flag  = true;
              new_var_p->base               = _cli_dec_var_base_e;
            }
            else if (0 == strcmp(argv_p[arg_id + 1], _cli_hex_keyword_sg)) {
              new_var_p->base_defined_flag  = true;
              new_var_p->base               = _cli_hex_var_base_e;
            }
            else {
              log_printf(log_handle, "The %s value of \"%s\" is not "
                         "supported.\n", _cli_base_keyword_sg, 
                         argv_p[arg_id + 1]);
              status = EINVAL;
              break;
            }
            if (_cli_uint_var_type_e != new_var_p->type) {
              log_printf(log_handle, "Specifying the \"%s\" option for an %s "
                         "variable is invalid.\n", _cli_base_keyword_sg,
                         _cli_var_type_ntop(new_var_p->type));
              status = EINVAL;
              break;
            }
          } /* base */
          
          /* Check for the "mask" option. */
          if ((arg_left >= 2) && 
              (0 == strcmp(argv_p[arg_id], _cli_mask_keyword_sg))) {
            arg_advance = 2;
            bool_status = _cli_var_pton(argv_p[arg_id + 1], &new_var_p->mask, 
                                        &var_type);
            if (false == bool_status) {
              log_printf(log_handle, "\"%s\" is not a valid %s value.\n",
                         argv_p[arg_id + 1], _cli_mask_keyword_sg);
              status = EINVAL;
              break;
            }
            if (_cli_null_var_type_e == new_var_p->type) {
              /* The mask option cannot be defined prior to defining the
               * variable value or range. */
              log_printf(log_handle, "The %s option canot specified prior to "
                         "variable value or range.\n", _cli_mask_keyword_sg);
              status = EINVAL;
              break; 
            } 
            if (var_type != new_var_p->type) {
              log_printf(log_handle, "The variable type of %s must be the same "
                         "as that of the variable value.\n", 
                         _cli_mask_keyword_sg);
              status = EINVAL;
              break;
            }
            new_var_p->mask_defined_flag = true;
          } /* mask */

          /* Check for the "from - to" option. */
          if ((arg_left >= 3) && 
              (0 == strcmp(argv_p[arg_id + 1], _cli_dash_keyword_sg))) {
            arg_advance = 3;
            bool_status = _cli_var_pton(argv_p[arg_id], &new_var_p->from, 
                                        &var_type);
            if (false == bool_status) {
              log_printf(log_handle, "\"%s\" is not a valid \"%s\" value.\n",
                         argv_p[arg_id], _cli_from_keyword_sg);
              status = EINVAL;
              break;
            }
            if ((_cli_null_var_type_e != new_var_p->type) &&
                (var_type             != new_var_p->type)) {
              log_printf(log_handle, "The variable type of the %s option must "
                         "be the same as that of the variable value.\n",
                         _cli_from_keyword_sg);
              status = EINVAL;
              break;
            }
            new_var_p->type = var_type;

            bool_status = _cli_var_pton(argv_p[arg_id + 2], &new_var_p->to, 
                                        &var_type);
            if (false == bool_status) {
              log_printf(log_handle, "\"%s\" is not a valid \"%s\" value.\n",
                         argv_p[arg_id + 2], _cli_to_keyword_sg);
              status = EINVAL;
              break;
            }
            if (var_type != new_var_p->type) {
              log_printf(log_handle, "The variable type of the %s option must "
                         "be the same as that of the %s option.\n",
                         _cli_to_keyword_sg, _cli_from_keyword_sg);
              status = EINVAL;
              break;
            }
            if (0 > _cli_var_value_cmp(&new_var_p->to, &new_var_p->from, 
                                       new_var_p->type)) {
              log_printf(log_handle, "The start value of the range cannot be "
                         "larger than the end value of the range.\n");
              status = EINVAL;
              break;
            }
            new_var_p->range_defined_flag = true;
          } /* from - to */

          /* Check for the "step" option. */
          if ((arg_left >= 2) && 
              (0 == strcmp(argv_p[arg_id], _cli_step_keyword_sg))) {
            arg_advance = 2;
            bool_status = _cli_var_pton(argv_p[arg_id + 1], &new_var_p->step, 
                                        &var_type);
            if (false == bool_status) {
              log_printf(log_handle, "\"%s\" is not a valid %s value.\n",
                         argv_p[arg_id + 1], _cli_step_keyword_sg);
              status = EINVAL;
              break;
            }
            if (_cli_null_var_type_e == new_var_p->type) {
              log_printf(log_handle, "The %s option canot specified prior to "
                         "variable value or range.\n", _cli_step_keyword_sg);
              status = EINVAL;
              break; 
            } 
            if (false == new_var_p->range_defined_flag) {
              log_printf(log_handle, "The %s option canot specified prior to "
                         "range option.\n", _cli_step_keyword_sg);
              status = EINVAL;
              break; 
            } 
            if ((_cli_null_var_type_e != new_var_p->type) &&
                (var_type             != new_var_p->type)) {
              log_printf(log_handle, "The variable type of the %s option must "
                         "be the same as that of the variable value.\n",
                         _cli_step_keyword_sg);
              status = EINVAL;
              break;
            }
            memset(&tmp_var, 0, sizeof(_cli_var_value_t));
            _cli_var_value_subtract(&new_var_p->to, &new_var_p->from, &tmp_var, 
                                    new_var_p->type);
            if (0 > _cli_var_value_cmp(&tmp_var, &new_var_p->step, 
                                       new_var_p->type)) {
              log_printf(log_handle, "The value of the step cannot be larger "
                         "than the value of the range.\n");
              status = EINVAL;
              break;
            }
            memset(&tmp_var, 0, sizeof(_cli_var_value_t));
            if (0 == _cli_var_value_cmp(&tmp_var, &new_var_p->step, 
                                        new_var_p->type)) {
              log_printf(log_handle, "The value of the step cannot be zero.\n");
              status = EINVAL;
              break;
            }
            new_var_p->type = var_type;
            new_var_p->step_defined_flag = true;
          } /* step */

          /* Check for the variable "value" option.  We do this check only for
           * the first argument after the '=' character, i.e., argument 2. */
          if ((0 == arg_advance) && (2 == arg_id)) {
            arg_advance = 1;
            bool_status = _cli_var_pton(argv_p[arg_id], &new_var_p->value, 
                                        &new_var_p->type);
            if (false == bool_status) {
              log_printf(log_handle, "\"%s\" is not a valid variable value.\n", 
                         argv_p[arg_id]);
              status = EINVAL;
              break;
            }
            new_var_p->value_defined_flag = true;
          } /* variable value */
          
          
          /* Move to the next argument. */
          if (0 == arg_advance) {
            log_printf(log_handle, "\"%s\" is not a valid option.\n", 
                       argv_p[arg_id]);
            status = EINVAL;
            break;
          }
          arg_left   -= arg_advance;
          arg_id     += arg_advance;
          arg_advance = 0;
        } /* while */
        if ((0 != status) && (NULL != new_var_p)) {
          /* Something went wrong; free the new variable record. */
          mem_free(new_var_p);
        }
      }
        
      if (0 == status) {
        /* Check if the combiantion of options is acceptable. */
        if (! (((true  == new_var_p->value_defined_flag) &&
                (false == new_var_p->range_defined_flag) &&
                (false == new_var_p->step_defined_flag)  &&
                (false == new_var_p->mask_defined_flag))
               ||
               ((true  == new_var_p->value_defined_flag) &&
                (false == new_var_p->range_defined_flag) &&
                (false == new_var_p->step_defined_flag)  &&
                (true  == new_var_p->mask_defined_flag))
               ||
               ((false == new_var_p->value_defined_flag) &&
                (true  == new_var_p->range_defined_flag) &&
                (false == new_var_p->step_defined_flag)  &&
                (false == new_var_p->mask_defined_flag))
               ||
               ((false == new_var_p->value_defined_flag) &&
                (true  == new_var_p->range_defined_flag) &&
                (true  == new_var_p->step_defined_flag)  &&
                (false == new_var_p->mask_defined_flag)))) {
          log_printf(log_handle, "The combination of options is invalid.\n");
          status = EINVAL;
        }
        else if ((false == new_var_p->value_defined_flag) &&
                 (false == new_var_p->range_defined_flag)) {
          log_printf(log_handle, "Neither the variable value nor variable range "
                     "was specified.\n");
          status = EINVAL;
        }
        else if ((true  == new_var_p->range_defined_flag) &&
                 (true  == new_var_p->mask_defined_flag)  &&
                 (false == new_var_p->value_defined_flag)) {
          log_printf(log_handle, "Specifying the mask requires that the "
                     "variable value be specified as well.\n");
          status = EINVAL;
        }

        /* Check for optional behaviours. */
        if ((true  == new_var_p->mask_defined_flag) &&
            (false == new_var_p->base_defined_flag)) {
          new_var_p->base = _cli_hex_var_base_e;
        }
      }
      
      if (0 == status) {
        /* Check if a variable with such a name does not already exist.  Delete
         * the variable if it exists. */
        old_var_p = db_record_by_name_get(menu_p->menu_var_p->var_db_handle, 
                                          new_var_p->name);
        if (NULL != old_var_p) {
          /* Delete the existing variable. */
          db_status = db_record_by_name_delete(
            menu_p->menu_var_p->var_db_handle, old_var_p->name);
          if (db_ok_e != db_status) {
            LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Failed to delete existing "
                       "variable %s%s from the CLI variable DB.  %s\n",
                       _CLI_VAR_CMD, old_var_p->name, 
                       db_error_string_get(db_status)); 
            status = EINVAL;          
          }              
        }
      }
      
      if (0 == status) {
        /* Add the new variable to the CLI variable DB. */
        db_status = db_record_add(menu_p->menu_var_p->var_db_handle,
                                  new_var_p->name, new_var_p, &idx);
        if (db_ok_e != db_status) {
          LOG_STRING(LOG_INFO, CLI_MODULE_NAME, "Failed to add new "
                     "variable %s%s to the CLI variable DB.  %s\n",
                     _CLI_VAR_CMD, new_var_p->name, 
                     db_error_string_get(db_status)); 
          status = EINVAL;          
        }
      }
    }
  } /* else if - defining a variable command */
  else if ((argc == 2)                                                && 
           (0 == strncmp(argv_p[0], _CLI_VAR_CMD, var_prefix_length)) &&
           (0 == strcmp(argv_p[0] + var_prefix_length, 
                        _cli_all_name_keyword_sg))                    &&
           (0 == strcmp(argv_p[1], _cli_equal_keyword_sg))) {
    /* Deleting all variables. */
    _cli_all_vars_delete(menu_p->menu_var_p->var_db_handle);
  } /* else if - delete all variables command */
  else if ((argc == 2)                                                && 
           (0 == strncmp(argv_p[0], _CLI_VAR_CMD, var_prefix_length)) &&
           (0 == strcmp(argv_p[1], _cli_equal_keyword_sg))) {
    /* Deleting a specific variable. */
    var_name_p = argv_p[0] + var_prefix_length;
    if (false == _cli_var_name_validate(var_name_p)) {
      log_printf(log_handle, invalid_var_name_p); 
      status = EINVAL;
    }
    else {
      /* Delete the variable.  First try to retrieve the record. */
      new_var_p = db_record_by_name_get(menu_p->menu_var_p->var_db_handle,
                                        var_name_p);
      if (NULL == new_var_p) {
        log_printf(log_handle, "Variable %s%s does not exist.\n", _CLI_VAR_CMD,
                   var_name_p);
      }
      else {
        db_status = db_record_by_name_delete(menu_p->menu_var_p->var_db_handle,
                                             var_name_p);
        if (db_ok_e != db_status) {
          LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "DB failed to delete the "
                     "%s%s CLI variable.  %s\n", _CLI_VAR_CMD, var_name_p,
                     db_error_string_get(db_status)); 
          status = EINVAL;          
        }
        else {
          /* Free the variable record. */
          mem_free(new_var_p);
        }
      }
    }
  } /* else if - delete a variable command */
  else if ((argc == 2)                                                && 
           (0 == strncmp(argv_p[0], _CLI_VAR_CMD, var_prefix_length)) &&
           (0 == strcmp(argv_p[0] + var_prefix_length, 
                        _cli_all_name_keyword_sg))                    &&
           (0 == strcmp(argv_p[1], _cli_qm_keyword_sg))) {
    /* Displaying all variables. */
    db_status = db_record_all_show(menu_p->menu_var_p->var_db_handle, 
                                   _cli_var_db_record_show);
    if (db_ok_e != db_status) {
      LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "DB failed to display all the "
                 "CLI variables.  %s\n", db_error_string_get(db_status)); 
      status = EINVAL;          
    }              
  } /* else if - display all variables command */
  else if ((argc == 2)                                                && 
           (0 == strncmp(argv_p[0], _CLI_VAR_CMD, var_prefix_length)) &&
           (0 == strcmp(argv_p[1], _cli_qm_keyword_sg))) {
    /* Displaying a specific variable. */
    var_name_p = argv_p[0] + var_prefix_length;
    if (false == _cli_var_name_validate(var_name_p)) {
      log_printf(log_handle, invalid_var_name_p); 
      status = EINVAL;
    }
    else {
      /* Display the variable. */
      db_status = db_record_by_name_show(menu_p->menu_var_p->var_db_handle,
                                         var_name_p, _cli_var_db_record_show);
      if (db_name_is_not_in_use_e == db_status) {
        log_printf(log_handle, "Variable %s%s does not exist.\n",
                   _CLI_VAR_CMD, var_name_p);
      }
      else if (db_ok_e != db_status) {
        LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "DB failed to display the %s "
                   "CLI variable.  %s\n", var_name_p,
                   db_error_string_get(db_status)); 
        status = EINVAL;          
      }              
    }
  } /* else if - display a variable command */
  else if ((argc == 3)                                                && 
           (0 == strncmp(argv_p[0], _CLI_VAR_CMD, var_prefix_length)) &&
           (0 == strcmp(argv_p[1], _cli_echo_keyword_sg))) {
    /* Setting the echo flag. */
    if (0 == strcmp(argv_p[2], _cli_on_keyword_sg)) {
      menu_p->menu_var_p->echo_on_flag = true;
      log_printf(log_handle, "Successfully set the %s option to \"%s\".\n",
                 _cli_echo_keyword_sg, argv_p[2]);
    }
    else if (0 == strcmp(argv_p[2], _cli_off_keyword_sg)) {
      menu_p->menu_var_p->echo_on_flag = false;
      log_printf(log_handle, "Successfully set the %s option to \"%s\".\n",
                 _cli_echo_keyword_sg, argv_p[2]);
    }
    else {
      log_printf(log_handle, "\"%s\" is not a valid value for the %s option.\n",
                 argv_p[2], _cli_echo_keyword_sg);
    }
  } /* else if - setting the echo flag command */
  else if ((argc == 3)                                                && 
           (0 == strncmp(argv_p[0], _CLI_VAR_CMD, var_prefix_length)) &&
           (0 == strcmp(argv_p[1], _cli_seed_keyword_sg))) {
    /* Setting the seed value. */
    if (true == cli_uint64get(argv_p[2], &seed)) {
      menu_p->menu_var_p->seed = seed;
      srand48(seed);
      log_printf(log_handle, "Successfully set the %s value to %"PRIu64".\n",
                 _cli_seed_keyword_sg, seed);
    }
    else {
      log_printf(log_handle, "\"%s\" is not a valid %s value.\n", 
                 argv_p[2], _cli_seed_keyword_sg);
    }
  } /* else if - setting the seed command */
  else {
    /* Invalid command. */
    log_printf(log_handle, invalid_cmd_p);
    status = EINVAL;
  } /* else - invalid command */
  
  return status;
} /* _cli_var_cmd */


/* @brief Decode user entered command and calls the correct handler. 
 *        May change menu. 
 *        return 1 for quit command. otherwise return what the handler returns. */
static int 
_cli_handle_short_cmd(
  char         *cmd,
  _cli_menu_t **menu,
  int          *quit_cmd,
  uint32_t      option)
{
  _cli_menu_t      *menu_temp;
  _cli_cmd_info_t   *cmd_temp;
  int             rc;

  /*
   * Skip "space" characters at the begining of the command.
   */
  cmd += strspn(cmd, _CLI_SPACE_CHARS);
  if (strlen(cmd) == 0)
    return 0;
  
  if(_cli_check_cmd(cmd, _CLI_QUIT_CMD)) {
    LOG_STRING(LOG_INFO, CLI_MODULE_NAME,
               "Execute command: \"%s\".", _CLI_QUIT_CMD);
    *quit_cmd = 1;
    return 0;
  }
  
  if(_cli_check_cmd(cmd, _CLI_QMARK_CMD) || _cli_check_cmd(cmd, _CLI_HELP_CMD))
  {
    _cli_menu_usage(*menu);
    return 0;
  }
  
  if(_cli_check_cmd(cmd, _CLI_BACK_CMD))
  {
    if((*menu)->parent_menu != NULL)
    {
      *menu = (*menu)->parent_menu;
      return 0;
    }
    printf("Invalid command.  Currently at root menu.\n");
    if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) return EINVAL;
    return 0;
  }
  
  if(_cli_check_cmd(cmd, _CLI_SYSTEM_CMD))
  {
    /* Skip the command */
    cmd += strlen(_CLI_SYSTEM_CMD);
    cmd += strspn(cmd, _CLI_SPACE_CHARS);
    if(*cmd != '\0')
    {
      rc = system(cmd);
      printf("system command return code: %d\n", rc);
      return 0;
    }
    printf("'%s' command requires the system command.\n", _CLI_SCRIPT_CMD);
    if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) return EINVAL;
    return 0;
  }

  if(_cli_check_cmd(cmd, _CLI_SCRIPT_CMD))
  {
    /* Skip the source command */
    strtok(cmd, _CLI_SPACE_CHARS);
    /* Extract the filename */
    cmd = strtok(NULL, _CLI_SPACE_CHARS);
    if(cmd != NULL)
    {
      rc = _cli_source_script(cmd, menu, quit_cmd, option);
      return rc;
    }
    printf("'%s' command requires a filename parameter.\n", _CLI_SCRIPT_CMD);
    if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) return EINVAL;
    return 0;
  }


  /* Process the CLI variable command. */
  if (0 == strncmp(cmd, _CLI_VAR_CMD, strlen(_CLI_VAR_CMD))) {
    rc = _cli_var_cmd(cmd, *menu);
    if ((0 != rc) && (CLI_MENU_EXIT_ON_ERROR_OPTION == 
                      (option & CLI_MENU_EXIT_ON_ERROR_OPTION))) {
      return rc;
    }
    return 0;
  }


  /*
   * Compare the command with the list of submenus.
   */
  menu_temp = (*menu)->submenu;
  while(menu_temp != NULL)
  {
    if(_cli_check_cmd(cmd, menu_temp->menu_name))
    {
      *menu = menu_temp;
      LOG_STRING(LOG_INFO, CLI_MODULE_NAME, "Execute command: \"%s\".", cmd);
      return 0;
    }
    menu_temp = menu_temp->next_menu;
  }

  /*
   * Compare the command with the list of supported commands in this menu.
   */
  cmd_temp = (*menu)->cmd_info;
  while(cmd_temp != NULL)
  {
    if(_cli_check_cmd(cmd, cmd_temp->cmd_name))
    {
      LOG_STRING(LOG_INFO, CLI_MODULE_NAME, "Execute commad: \"%s\".", cmd);


#if defined(CLOCK_MONOTONIC)
      /* Get a time stamp before executing the command. */
      struct timespec  timeStamp1;
      struct timespec  timeStamp2;
      clockid_t clockSource = CLOCK_MONOTONIC;
      long timeStamp1Status = clock_gettime(clockSource, &timeStamp1);
      if (CLI_SHOW_EXEC_TIME_CMD_FLAG == 
          (cmd_temp->cmdFlags & CLI_SHOW_EXEC_TIME_CMD_FLAG)) {
        if (0 != timeStamp1Status) {
          printf("CLI: Warning!  Unable to compute execution time "
                 "using a monotonic clock as it is unavailable.  "
                 "Using the realtime clock instead which may results "
                 "in unreliable measurements.\n");
          clockSource = CLOCK_REALTIME;
          timeStamp1Status = clock_gettime(clockSource, &timeStamp1);
        }
      }
#endif

      /* Execute the command. */
      rc = cmd_temp->cmd_handler(cmd, cmd_temp->context_p);

      /* Display the command execution time if the
       * CLI_SHOW_EXEC_TIME_CMD_FLAG flag is on for this command. */
      if (CLI_SHOW_EXEC_TIME_CMD_FLAG == 
          (cmd_temp->cmdFlags & CLI_SHOW_EXEC_TIME_CMD_FLAG)) {
#if defined(CLOCK_MONOTONIC)
        /* Get a time stamp after executing the command. */
        long timeStamp2Status = clock_gettime(clockSource, &timeStamp2);

        /* Check the time stamp statuses. */
        if ((0 == timeStamp1Status) && (0 == timeStamp2Status)) {
          time_t  execTimeInSecs = timeStamp2.tv_sec - timeStamp1.tv_sec;
          printf("Command execution time: %02ld:%02ld:%02ld [hour:min:sec].\n",
                 execTimeInSecs/3600, (execTimeInSecs%3600)/60, 
                 (execTimeInSecs%3600)%60);         
        }
        else {
          printf("Command execution time: failed to get a time stamp(s) "
                 "(%d/%d/%d/%s).\n", (int)timeStamp1Status, 
                 (int)timeStamp2Status, errno, strerror(errno));
        }
#else
        printf("Command execution time: posix realtime timers are not "
               "supported by this OS.\n");
#endif
      } /* if - the CLI_SHOW_EXEC_TIME_CMD_FLAG flag is on. */

      return rc;
    }
    cmd_temp = cmd_temp->next_cmd;
  }

  /*
   * If we're here its because they entered an invalid command.
   */
  printf("Invalid command.  Enter '%s' for a list of valid commands.\n",
         _CLI_QMARK_CMD);
  if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) return EINVAL;
  return 0;
}


/* @brief Handle special long command. 
 *        e.g. menu1/menu2/command para...
 *        Only perform menu traverse when '/' is present in the first parameter.
 *        May change menu. 
 *        return 0 for internal commands. otherwise return what the
 *        handler returns. 
 *        *quit_cmd = 1 if 'quit' command was issued.  */
static int 
_cli_handle_cmd(
  char         *in_cmd,
  _cli_menu_t **menu,
  int          *quit_cmd,
  uint32_t      option)
{
  int              rc;
  int              first_seg_len;
  _cli_menu_t*     old_menu = *menu;
  _cli_menu_t*     last_menu;
  char*            tmp_s;
  char*            first_seg_end;
  char*            cmd = NULL;
  char*            cmd_original_p = NULL;
    
      
  cmd = _cli_var_parse(in_cmd, *menu);
  if (NULL == cmd) {
    return EINVAL;
  }
  cmd_original_p = cmd;
  if (true == (*menu)->menu_var_p->echo_on_flag) {
    if (0 != strcmp(cmd, in_cmd)) {
      log_printf(stdout, "%s\n", cmd);
    }
  }
  

  cmd += strspn(cmd, _CLI_SPACE_CHARS);
  first_seg_len = strcspn(cmd, _CLI_SPACE_CHARS);

  tmp_s = strchr(cmd, _CLI_MENU_SEPERATOR);
  if(tmp_s == NULL || tmp_s > cmd + first_seg_len) {
    /* Short command, no '/' to sort out. */
    rc = _cli_handle_short_cmd(cmd, menu, quit_cmd, option);
    mem_free(cmd_original_p);
    return rc;
  }

  first_seg_end = cmd + first_seg_len;

  /* Jump to root menu first */
  if(*cmd == _CLI_MENU_SEPERATOR) {
    while((*menu)->parent_menu != NULL) *menu = (*menu)->parent_menu;
  }
  
  /* Loop through the menu1/menu2/cmd */
  while(tmp_s != NULL && tmp_s < first_seg_end)
  {
    /* remove any "//" */
    while(*tmp_s == _CLI_MENU_SEPERATOR) {
      *tmp_s = '\0';
      tmp_s++;
    }
    if(strlen(cmd) > 0) {
      last_menu = *menu;
      rc = _cli_handle_short_cmd(cmd, menu, quit_cmd, option);


      if(rc || *quit_cmd) {
        mem_free(cmd_original_p);
        return rc;
      }
      
      if(last_menu == *menu) {
        /* Current menu wasn't changed.  That means the menu name was bad or a 
          command was executed. */
        *menu = old_menu;
        mem_free(cmd_original_p);
        return rc;
      }
    }
    cmd = tmp_s;
    tmp_s = strchr(cmd, _CLI_MENU_SEPERATOR);
  }

  /* Actual command after the last '/' */
  rc = _cli_handle_short_cmd(cmd, menu, quit_cmd, option);
  
  /* Return to the original menu */
  *menu = old_menu;
  mem_free(cmd_original_p);
  return rc;
}

#ifdef USE_READLINE
/* @brief Generate no suggestion for the command completion. */
static char *
_cli_no_suggestion(
  const char *text, 
  int         state)
{
  /* Avoid compiler warning */
  if(text && state) {}

  return NULL;
}
#endif

#ifdef USE_READLINE
/* @brief Generate a good candidate for completing the command.
 *        Return the good candidate string or NULL if none found. */
static char *
_cli_command_generator(
  const char *text, 
  int         state)
{
  static int list_index, len;
  char *name;

  /* If this is a new word to complete, initialize now.  This
     includes saving the length of TEXT for efficiency, and
     initializing the index variable to 0. */
  if (!state) {
    list_index = 0;
    len = strlen (text);
  }

  /* Walk down the list of commands for completion */
  while (list_index < _cli_num_commands) {
    name = _cli_all_commands[list_index];
    list_index++;

    if (strncmp (name, text, len) == 0) {
      return (strdup(name));
    }
  }

  /* If no names matched, then return NULL. */
  return ((char *)NULL);
}
#endif

#ifdef USE_READLINE
/* @brief Provides the ability to complete commands.
 *        Return pointer to pointers of matches. If we want simple
 *        file completion, simply return NULL would do the trick. */
static char 
**_cli_completion(
  const char *text, 
  int         start, 
  int         end)
{
  char **matches;

  matches = (char **)NULL;
  /* Avoid compiler warning */
  if (end < start) {
    return (matches);
  }

  /* For now, we are trying to complete the first command only. */
  if (start == 0) {
    matches = completion_matches (text, _cli_command_generator);
  }
  else if (strncmp(_CLI_SCRIPT_CMD, rl_line_buffer, 
                   strlen(_CLI_SCRIPT_CMD)) == 0) {
    matches = completion_matches (text, filename_completion_function);
  }
  else if (strncmp(_CLI_ADD_CMD, rl_line_buffer, strlen(_CLI_ADD_CMD)) == 0) {
    matches = completion_matches (text, filename_completion_function);
  }
  else {
    matches = completion_matches (text, _cli_no_suggestion);
  }

  /* By now, if matches is still null, it's because we are trying to do
   * file name completion. */  
  return (matches);
}
#endif

/* @brief Source command script from the specified file. May recursively
 *        source another file within a script. May change menu.
 *        return what user command returns.
 *        *quit_cmd = 1 for 'quit' command. */
int 
_cli_source_script(
  char*         filename, 
  _cli_menu_t **menu,
  int          *quit_cmd,
  uint32_t      option)
{
  char *idx = NULL;
  char* cmd_temp = NULL;
  FILE *scr = NULL;
  int rc = 0;
  int final_rc = 0;
  int line = 0;
  char  prompt[_CLI_MAX_PROMPT_LEN];
  
  rc = 0;
  if(filename != NULL)
  {
    if(strlen(filename) == 0)
    {
      printf("Source filename missing\n");
      if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) return EINVAL;
      return 0;
    }
    scr = fopen(filename, "r");
    if(scr != NULL)
    {
      cmd_temp = malloc(CLI_USER_INPUT_MAX_LEN);
      if(cmd_temp == NULL)
      {
        LOG_STRING(LOG_WARNING, CLI_MODULE_NAME,
                   "Unable to allocate script command buffer.");
        fclose(scr);
        if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) return EINVAL;
        return 0;
      }
      while(fgets(cmd_temp, CLI_USER_INPUT_MAX_LEN, scr)) {
        line++;
        if ((idx = index(cmd_temp, '\n')) != NULL) {
          _cli_get_prompt(*menu, prompt);
          printf("%s: %s", prompt, cmd_temp);
          /* Clean up the '\n' */
          *idx = '\0';
          /* Comment out everything after '#' */
          idx = index(cmd_temp, '#');
          if (idx) *idx = '\0';
          /* Handle the quit command first */
          if(_cli_check_cmd(cmd_temp, _CLI_QUIT_CMD)) {
            LOG_STRING(LOG_INFO, CLI_MODULE_NAME,
                "Execute command: \"%s\".", _CLI_QUIT_CMD);
            /* Quit CLI loop in this case. */
            final_rc = 1;
            break;
          }

          rc = _cli_handle_cmd(cmd_temp, menu, quit_cmd, option);
          if(rc) {
              final_rc = rc;
              if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) break;
          }
          if(*quit_cmd) break;
        }
        else {
          /* we arrived here because the command in the script
           * file was too long for us to process.  All we can do
           * is abort the script */
          printf("\nCommand at line %d exceeds maximum length (%d bytes)\n",
                 line, CLI_USER_INPUT_MAX_LEN);
          printf("The command as read was: '%s'\n", cmd_temp);
          if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) final_rc = EINVAL;
          break;
        }
      }
      free(cmd_temp);
      fclose(scr);
    }
    else 
    {
      printf("Unable to source file '%s'\n", filename);
      perror("");
      if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) final_rc = EINVAL;
    }
    return final_rc;
  }
  else
  {
    LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Null string pointer passed in.");
    if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) return EINVAL;
    return 0;
  }
}









/*----------------- Public Function Definitions -------------------------------*/

/*
 * @brief Start the CLI from the specified menu.
 *
 * @param menuHandle         Start the CLI from this menu.
 * @param historyFileName_p  Filename of the history file.  If NULL,
 *                           then the "._cli_history" name will be
 *                           used.  
 * @retval                   cli_ok_e upon success; an error code otherwise.
 */
cli_status_t 
cli_start(
  handle_t    menuHandle,
  const char *historyFileName_p
  )
{
  char        prompt[_CLI_MAX_PROMPT_LEN];
  char       *cmd        = NULL;
  char       *idx        = NULL;
  _cli_menu_t *menu      = _cli_handle_to_menu(menuHandle);
  int         rc         = 0;
  uint32_t    option     = 0;
  char       *user_input = NULL;
  int        quit_cmd = 0;
#ifdef USE_READLINE
  int history_file_writable = 1;
#endif

  if(menu == NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Invalid menu handle");
    return(cli_invalid_menu_handle_e);
  }
  
  if(historyFileName_p == NULL) {
    historyFileName_p = "._cli_history";
  }
#ifdef USE_READLINE
  using_history();
  stifle_history(512);
  rl_attempted_completion_function = _cli_completion;
  read_history(historyFileName_p);
  rl_reset_terminal(NULL);
#endif
  
  for (;;) 
  {
    option = menu->option;
    _cli_get_prompt(menu, prompt);
    strcat(prompt, "> ");
#ifdef USE_READLINE
    user_input = readline (prompt);

    if (user_input == NULL) {
      printf("\n");
      break;  /* this is useful when input is read from a file, etc. */
    }
    
    if( strlen(user_input) == 0 )
    {
      free(user_input);        
      continue;
    }
    
    rc = history_expand(user_input, &cmd);
    /* If rc != 0, cmd contains a sucessful expansion or error message */
    if (rc) {
      printf("%s\n", cmd);
    }
    /* rc == -1 -> error / rc == 2 -> not error but don't execute the
     * command. */
    if ((rc < 0) || (2 == rc)) {
      free(user_input);
      free(cmd);
      continue;
    }
        
    if (strlen(cmd) >= (CLI_USER_INPUT_MAX_LEN - 1)) {
      printf("Command entered exceeds the maximum allowed length.\n");
      free(user_input);
      free(cmd);
      if(option & CLI_MENU_EXIT_ON_ERROR_OPTION) return cli_error_e;
      
      continue;
    }
    free(user_input);
    
    if(strlen(cmd) > 0)
    {
      /* record the command in the history */
      add_history(cmd);
      if(history_file_writable) {
        /* write it to the history file for the next time we run */
        rc = write_history(historyFileName_p);
        if (0 != rc) {
            LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, 
                    "Failed to update the \"%s\" history file."
                    "  %s.\n", historyFileName_p, strerror(errno));
            history_file_writable = 0;
        }
      }
    }
    else
    {
      free(cmd);
      continue;
    }

    /* Comment out everything after first '#' */
    idx = index(cmd, '#');
    if (idx) *idx = '\0';
    
    rc = _cli_handle_cmd(cmd, &menu, &quit_cmd, option);
    free(cmd);
#else
    user_input = calloc(CLI_USER_INPUT_MAX_LEN, 1);
    if(user_input == NULL) return cli_out_of_memory_e;
    printf("%s", prompt);
    if(fgets(user_input, CLI_USER_INPUT_MAX_LEN, stdin) == NULL) { /* EOF */
      free(user_input);
      break;
    }
    /* Comment out everything after first '#' */    
    idx = index(user_input, '#');
    if (idx) *idx = '\0';
    /* Also need to take out the last \n */
    idx = index(user_input, '\n');
    if (idx) *idx = '\0';
    rc = _cli_handle_cmd(user_input, &menu, &quit_cmd, option);
    free(user_input);
    cmd = cmd;
#endif
    
    if(quit_cmd) break;
 
    if(rc && (option & CLI_MENU_EXIT_ON_ERROR_OPTION)) return cli_error_e;
  } /* for(ever) */

  return(cli_ok_e);
}

/*
 * @brief Run a CLI command from the 
 *
 * @param menuHandle         Run command from this menu, may be modified.
 * @param cmd                The CLI command.  String content will not be modified.  
 * @retval                   cli_ok_e upon success; an error code otherwise.
 */
int
cli_run_cmd(
  handle_t   *menuHandle,
  const char *cmd
  )
{
  int rc, quit_cmd = 0;
  char* cmd_clone;
  _cli_menu_t *menu       = _cli_handle_to_menu(*menuHandle);
  if(menu == NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Invalid menu handle");
    return(cli_invalid_menu_handle_e);
  }
  
  /* Do nothing for empty string. */
  if(cmd[0] == '\0') return cli_ok_e;
  
  cmd_clone = strdup(cmd);
  if(cmd_clone == NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME,
                   "Unable to duplicate command string.");
    return cli_out_of_memory_e;
  }

  rc = _cli_handle_cmd(cmd_clone, &menu, &quit_cmd, 0);
  free(cmd_clone);

  *menuHandle = _cli_menu_to_handle(menu);
  return rc;
}


/* 
 * @brief Divides the passed in string into independent parameters.
 */
cli_status_t
cli_command_parse(
  char      *string_p,
  int32_t   *argc,
  char     **argv_p,
  uint32_t   paramMaxNum,
  char      *delimiters_p
  )
{
  char *word_p = NULL;
  *argc = 0;

  /* Get the first parameter. */
  word_p = strtok(string_p, delimiters_p);
  
  while (NULL != word_p) {
    /* Save the last parameter and increment the parameter count. */
    argv_p[*argc] = word_p;
    (*argc)++;
    if (*argc > (int32_t) paramMaxNum) {
      return cli_too_many_parameters_e;
    }
    
    /* Get the next parameter. */
    word_p = strtok(NULL, delimiters_p);
  }
  
  return cli_ok_e;
} /* cli_command_parse */


/* 
 * @brief Attemp to convert the passed string to an int32_t value
 */
bool
cli_int32get(
  char    *string_p,
  int32_t *value_p
  )
{
  char *end_p = NULL;


  /* Try to convert the value argument to a uint32_t. */
  *value_p = strtol(string_p, &end_p, 0);

  if (0 != *end_p) {
    /* The conversion failed. */
    return false;
  }
  
  return true;
} /* cli_int32get */


/* 
 * @brief Attemp to convert the passed string to an uint32_t value
 */
bool
cli_uint32get(
  char     *string_p,
  uint32_t *value_p
  )
{
  char *end_p = NULL;


  /* Try to convert the value argument to a uint32_t. */
  *value_p = strtoul(string_p, &end_p, 0);

  if (0 != *end_p) {
    /* The conversion failed. */
    return false;
  }
  
  return true;
} /* cli_uint32get */


/* 
 * @brief Attemp to convert the passed string to an uint64_t value
 */
bool
cli_uint64get(
  char     *string_p,
  uint64_t *value_p
  )
{
  char *end_p = NULL;


  /* Try to convert the value argument to a uint64_t. */
  *value_p = strtoull(string_p, &end_p, 0);

  if (0 != *end_p) {
    /* The conversion failed. */
    return false;
  }
  
  return true;
} /* cli_uint64get */


/*
 * @brief Attempt to convert the passed string to a hexadecimal value.
 */
bool
cli_hex_get(
  char     *string_p,
  uint8_t  *valueBuffer_p,
  uint32_t  valueBufferSize,
  uint32_t *valueLength_p
  )
{
  /* Validate the passed parameters. */
  if ((NULL == string_p) || (NULL == valueBuffer_p)) {
    return false;
  }

  uint32_t  stringLength = strlen(string_p);
  uint32_t  valueLength  = stringLength / 2;
  int       status       = 0;
  uint32_t  i            = 0;
  int       toBeByte     = 0;
  

  /* Make sure that the length of the string is even.  We cannot
   * convert a single character to a hexadecimal value. */
  if (0 != (stringLength % 2)) {
    return false;
  }

  /* Make sure that the resulting hexadecimal value will fit into the
   * provided value buffer. */
  if (valueLength > valueBufferSize ) {
    return false;
  }
  
  
  /* Convert the string. */
  for (i = 0; i < valueLength; i++) {
    if ((0 == isxdigit(string_p[2 * i])) ||
        (0 == isxdigit(string_p[2 * i + 1]))) {
      /* We found a "non-hexadecimal" digit in the passed string. */
      return false;
    }
    
    status = sscanf(&string_p[2 * i], "%2x", &toBeByte);
    if (1 != status) {
      return false;
    }
    valueBuffer_p[i] = toBeByte;
  }
  
  if (NULL != valueLength_p) {
    *valueLength_p = valueLength;
  }
  
  return true;
}


/*
 * @brief Returns CLI Error string by error code.
 * 
 * @param errorCode  Error code returned from CLI functions.
 *
 * @retval           String of error description. 
 */
const char *
cli_error_string_get(
  cli_status_t errorCode)
{
  /* Validate the parameters. */
  if ((errorCode < 0) || (errorCode >= cli_last_error_code_e)) {
    LOG_STRING(LOG_WARNING,  CLI_MODULE_NAME,
               "%d is an invalid error code; supported error "
               "codes must be >= 0 and < %d.", errorCode, 
               cli_last_error_code_e);
    return "";
  }

  return _cli_error_code_strings_cg[errorCode];
} /* cli_error_string_get */


/*
 * @brief Add a command to a menu.
 *
 * @param menuHandle  Menu handle of the target menu.
 * @param name_p      Name of the command.
 * @param descr_p     Description of the command.
 * @param context_p   A context pointer that will be passed to the 
 *                    command handler.
 * @param cmdHandler  Command handler that will be called if this command 
 *                    is involked.
 * @param cmdFlags    "Or'ed" flags for this command.
 *
 * @retval            cli_ok_e upon success; an error code otherwise.
 */
cli_status_t cli_register_cmd(
  handle_t           menuHandle,
  const char        *name_p,
  const char        *descr_p,
  void              *context_p,
  cli_cmd_handler_t  cmd_handler_p,
  uint32_t           cmdFlags
  )
{
  cli_status_t    rc;
  _cli_cmd_info_t   *cmd_info, *tmp_cmd_info;
  _cli_menu_t      *_cli_menu = _cli_handle_to_menu(menuHandle);

  LOG_STRING(LOG_TEST, CLI_MODULE_NAME,
             "Entering %s(menuHandle=%"PRI_HANDLE", name_p=%p, descr_p=%p, "
             "context_p=%p, cmd_handler_p=%p, cmdFlags=%x).",
             __func__, menuHandle, name_p, descr_p, context_p, cmd_handler_p,
             cmdFlags);
    
  if(_cli_menu == NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Invalid menu handle.");
    return(cli_invalid_menu_handle_e);
  }
    
  if (name_p == NULL || descr_p == NULL || cmd_handler_p == NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, 
               "Invalid registration parameter.");
    return(cli_null_ptr_parameter_e);
  }

  if ((strlen(name_p) >= _CLI_MAX_CMD_NAME_LEN)  ||
      (strlen(descr_p) >= _CLI_MAX_CMD_DESCR_LEN))
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "The menu name or description "
               "exceeds the maximum length.");
    return(cli_name_is_too_long_e);
  }

  if((rc=_cli_check_name(_cli_menu, name_p)) != cli_ok_e)
    return(rc);
  
  /* Allocate and setup this new command */
  cmd_info = calloc(1, sizeof(_cli_cmd_info_t));
  if (cmd_info == NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME,"calloc() failure.");
    return(cli_out_of_memory_e);
  }
  strcpy(cmd_info->cmd_name, name_p);
  strcpy(cmd_info->cmd_descr, descr_p);
  cmd_info->context_p   = context_p;
  cmd_info->cmd_handler = cmd_handler_p;
  cmd_info->cmdFlags    = cmdFlags;
  cmd_info->next_cmd    = NULL;
  
  /* Append it in the list of commands for this menu. */
  if(_cli_menu->cmd_info == NULL)
  {
    _cli_menu->cmd_info = cmd_info;
  }
  else
  {
    tmp_cmd_info = _cli_menu->cmd_info;
    while(tmp_cmd_info->next_cmd != NULL) 
      tmp_cmd_info = tmp_cmd_info->next_cmd;
    tmp_cmd_info->next_cmd = cmd_info;
  }

  /* Insert that command to the global list for command completion */
  _cli_add_command_to_global_list(name_p);

  LOG_STRING(LOG_TEST, CLI_MODULE_NAME, "Successfully created the \"%s\" "
             "command.", cmd_info->cmd_name);

  return(cli_ok_e);
}

/*
 * @brief Create a new CLI menu.
 * 
 * @param name_p            name of the menu.
 * @param descr_p           description of the menu.
 * @param *newMenu          Location to store the new menu handle.
 * @param parentMenuHandle  Parent menu handle.  New menu will become a
 *                          submenu of that parent menu.
 *                          Use HANDLE_NULL if the new menu has
 *                          no parent menu.
 *
 * @retval                  cli_ok_e upon success and new menu handle in
 *                          *newMenu; an error code otherwise.
 */
cli_status_t 
cli_create_menu(
  const char     *name_p,
  const char     *descr_p,
  handle_t       *newMenu_p,
  handle_t        parentMenuHandle,
  uint32_t        menuOption)
{
  cli_status_t  rc;
  _cli_menu_t  *_cli_menu, *tmp_menu;
  _cli_menu_t  *parent                 = _cli_handle_to_menu(parentMenuHandle);
  db_status_t   db_status              = db_ok_e;
  idx_status_t  idx_status             = idx_ok_e;
  static bool   db_modules_initialized = false;
  

  LOG_STRING(LOG_TEST, CLI_MODULE_NAME,
             "Entering %s(name_p=%p, descr_p=%p, newMenu_p=%p, "
             "parentMenuHandle=%"PRI_HANDLE").",
             __func__, name_p, descr_p, newMenu_p, parentMenuHandle);

  
  if(newMenu_p == NULL || name_p == NULL || descr_p == NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Invalid menu create parameter.");
    return(cli_null_ptr_parameter_e);
  }
    
  *newMenu_p = HANDLE_NULL;

  if(parent == NULL && parentMenuHandle != HANDLE_NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, 
               "Invalid parent menu handle (%"PRI_HANDLE").", 
               parentMenuHandle);
    return(cli_invalid_menu_handle_e);
  }

  if ((strlen(name_p) >= _CLI_MAX_MENU_NAME_LEN)  ||
      (strlen(descr_p) >= _CLI_MAX_MENU_DESCR_LEN))
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "menu name or description "
               "exceeds maximum length.");
    return(cli_name_is_too_long_e);
  }

  
  if((rc=_cli_check_name(parent, name_p)) != cli_ok_e)
    return(rc);
 

  _cli_menu = calloc(1, sizeof(_cli_menu_t));
  if (_cli_menu == NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "calloc() failure.");
    return(cli_out_of_memory_e);
  }

  /* Initialize the newly created menu structure. */
  strcpy(_cli_menu->menu_name, name_p);
  strcpy(_cli_menu->menu_descr, descr_p);
  _cli_menu->option = menuOption;
  _cli_menu->parent_menu   = parent;
  _cli_menu->submenu       = NULL;
  _cli_menu->next_menu     = NULL;
  _cli_menu->cmd_info      = NULL;
  _cli_menu->menu_var_p    = NULL;
  
  /* If the new menu is a "root" menu we need to create the CLI variable DB for
   * this menu tree. */
  if (NULL == parentMenuHandle) {
    /* Initialize the DB and IDX modules and create the CLI variable DB. */
    if (false == db_modules_initialized) {
      db_status  = db_module_init();
      idx_status = idx_module_init();
      if ((db_ok_e != db_status) || (idx_ok_e != idx_status)) {
        if (db_ok_e != db_status) {
          LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Failed to initialize the DB "
                     "module.");
        }
        if (idx_ok_e != idx_status) {
          LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Failed to initialize the IDX "
                     "module.");
        }
        /* Free the newly allocated menu structure. */
        free (_cli_menu);
        return(cli_error_e);
      }
    }
    
    /* Allocate a variable menu structure for this menu tree. */
    _cli_menu->menu_var_p = mem_calloc(1, sizeof(_cli_menu_var_t));
    if (NULL == _cli_menu->menu_var_p) {
      free (_cli_menu);
      return cli_out_of_memory_e;
    }
    _cli_menu->menu_var_p->var_db_handle = HANDLE_NULL;
    /* Set the seed for the rand() calls.  We set the seed to what is returned
     * by the time() call. */
    _cli_menu->menu_var_p->seed          = time(NULL);
    srand48(_cli_menu->menu_var_p->seed);
    _cli_menu->menu_var_p->echo_on_flag  = true;
  
    /* Create the CLI variable DB. */
    db_status = db_db_create(_CLI_VAR_MAX_NUM, "CLI Variable DB", 
                             &_cli_menu->menu_var_p->var_db_handle);
    if (db_ok_e != db_status) {
      LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Failed to create the CLI "
                 "variable DB.  %s", db_error_string_get(db_status));
      /* Free the newly allocated variable and menu structures. */
      mem_free(_cli_menu->menu_var_p);
      free (_cli_menu);
      return(cli_error_e);
    }
    else {
      LOG_STRING(LOG_INFO, CLI_MODULE_NAME, "Successfully created the CLI "
                 "variable DB for the \"%s\" menu tree.", descr_p);
    }
  } /* if - "root" menu initialization */
  else {
    /* This is not the "root" menu.  Set the CLI variable DB handle. */
    _cli_menu->menu_var_p = parent->menu_var_p;
  }

  /* We need to modify the parents node to  
   * add the new submenu to the link list.
   */
  if (parent != NULL)
  {
    if(parent->submenu == NULL)
    {
      parent->submenu = _cli_menu;
    }
    else
    {
      /* Loop the submenu link list to find the last menu. */
      tmp_menu = parent->submenu;
      while(tmp_menu->next_menu != NULL) 
        tmp_menu = tmp_menu->next_menu;
      tmp_menu->next_menu = _cli_menu;
    }
  }
    
  _cli_menu->signature = _CLI_MENU_SIGNATURE;
  *newMenu_p = _cli_menu_to_handle(_cli_menu);
  LOG_STRING(LOG_TEST, CLI_MODULE_NAME, "Create menu %s successful.",
             _cli_menu->menu_name);

  if ( parentMenuHandle == NULL ) {
    /* Add the built-in commands. */
    _cli_add_command_to_global_list(_CLI_BACK_CMD);
    _cli_add_command_to_global_list(_CLI_QUIT_CMD);
    _cli_add_command_to_global_list(_CLI_HELP_CMD);
    _cli_add_command_to_global_list(_CLI_SCRIPT_CMD);
    _cli_add_command_to_global_list(_CLI_VAR_CMD);
  }
  else {
    /* Add the sub-menu name for sub-menu */
    _cli_add_command_to_global_list(name_p);
  }

  return(cli_ok_e);
}


/*
 * @brief Destroy a menu, and it's sub menu. (recursive)
 *
 * @param menuHandle  Menu handle of the menu to destroy.
 *
 * @retval            cli_ok_e upon success; an error code otherwise.
 */
cli_status_t 
cli_destroy_menu(
  handle_t menuHandle)
{
  _cli_menu_t *_cli_menu = _cli_handle_to_menu(menuHandle);
  _cli_menu_t *parent_menu, *tmp_menu, *next_menu;
  _cli_cmd_info_t *tmp_cmd, *next_cmd;
  cli_status_t rc;
  db_status_t  db_status = db_ok_e;
  
    
  LOG_STRING(LOG_TEST, CLI_MODULE_NAME,
             "Entering %s(menuHandle=%"PRI_HANDLE").", __func__, menuHandle);

  if(_cli_menu == NULL)
  {
    LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "Invalid menu handle");
    return(cli_invalid_menu_handle_e);
  }

  LOG_STRING(LOG_TEST, CLI_MODULE_NAME, "Deleting menu %s.", 
             _cli_menu->menu_name);
  /* If it has a parent menu, unlink from it. */
  parent_menu = _cli_menu->parent_menu;
  if(parent_menu != NULL)
  {
    if(parent_menu->submenu == NULL)
    {
      LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "parent menu list is empty");
      return(cli_corrupted_menu_e);
    }
    if(parent_menu->submenu == _cli_menu)
      parent_menu->submenu = _cli_menu->next_menu;
    else
    {
      tmp_menu = parent_menu->submenu;
      rc = 0;
      while(tmp_menu->next_menu != NULL)
      {
        if(tmp_menu->next_menu == _cli_menu)
        {
          /* Found it, remove it from the chain. */
          rc = 1;
          tmp_menu->next_menu = _cli_menu->next_menu;
          break;
        }
        else {
          /* Move to the next sub-menu in the chain. */
          tmp_menu = tmp_menu->next_menu;
        }
      }
      if(rc == 0)
      {
        LOG_STRING(LOG_WARNING, CLI_MODULE_NAME, "link from parent menu "
                   "not found");
        return(cli_corrupted_menu_e);
      }
    }
    _cli_menu->next_menu = NULL;
  }
    
  if(_cli_menu->submenu != NULL)
  {
    tmp_menu = _cli_menu->submenu;
    while(tmp_menu != NULL)
    {
      next_menu = tmp_menu->next_menu;
      rc = cli_destroy_menu(_cli_menu_to_handle(tmp_menu));
      if(rc != cli_ok_e) return rc;
      tmp_menu = next_menu;
    }
  }

  if(_cli_menu->cmd_info != NULL)
  {
    tmp_cmd = _cli_menu->cmd_info;
    while(tmp_cmd != NULL)
    {
      next_cmd = tmp_cmd->next_cmd;
      free(tmp_cmd);
      tmp_cmd = next_cmd;
    }
    _cli_menu->cmd_info = NULL;
  }
  
  /* If this menu is a "root" menu we need to destroy the CLI variable DB
   * associated with this menu tree. */
  if ((NULL == _cli_menu->parent_menu) && (NULL != _cli_menu->menu_var_p)) {
    if (HANDLE_NULL != _cli_menu->menu_var_p->var_db_handle) {
      /* Delete all the variables in the CLI DB. */
      _cli_all_vars_delete(_cli_menu->menu_var_p->var_db_handle);

      /* Destroy the CLI DB. */
      db_status = db_db_destroy(_cli_menu->menu_var_p->var_db_handle);
      if (db_ok_e != db_status) {
        LOG_STRING(LOG_ERROR, CLI_MODULE_NAME, "Failed to destroy the \"%s\" "
                   "CLI variable DB.  %s", _cli_menu->menu_descr,
                   db_error_string_get(db_status));
      }
      else {
        LOG_STRING(LOG_INFO, CLI_MODULE_NAME, "Successfully destroyed the CLI "
                   "variable DB for the \"%s\" menu tree.", 
                   _cli_menu->menu_descr);
      }
    }

    /* Free the CLI menu structure. */
    mem_free(_cli_menu->menu_var_p);
  }
  
  _cli_menu->signature = _CLI_NULL_SIGNATURE;
  free(_cli_menu);
  return(cli_ok_e);
}

