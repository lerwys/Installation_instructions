/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : mem.c
 *
 *   This file contains the implementation of the MEMory (MEM) management
 *   module.
 *
 ****************************************************************************/




/*--------------------- Include Files -----------------------------*/

#include <ctype.h>
#include <stdlib.h>
#include <string.h>


#include <generic_types.h>
#include <log.h>
#include <mem.h>








/*--------------------- Macro Definitions--------------------------*/

#ifdef MEM_DEBUG_ENABLED
/* This macro defines the size of the memory allocation table used in */
/* debugging. */
#define _MEM_ALLOC_TABLE_SIZE                    (1024 * 512)
#endif









/*--------------------- Type Definitions---------------------------*/

#ifdef MEM_DEBUG_ENABLED
/* This type defines an entry in the memory allocation debug table. */
typedef struct {
  void *pointer_p;  /* pointer to the allocated memory block */
  long  size;       /* size of the allocated memory block */
} _mem_allocate_table_entry_t;
#endif



  



/*--------------------- Global Data Definitions -------------------*/

#ifdef MEM_DEBUG_ENABLED
/* This table is used by the memory allocation debug functions. */
static _mem_allocate_table_entry_t 
            _mem_allocate_table_pg[_MEM_ALLOC_TABLE_SIZE];

/* This flag is used to clear the memory allocation table. */
static bool  _mem_firstTimeFlag_g = true;
#endif







/*--------------------- Static Function Definitions ---------------*/








/*--------------------- Public Function Definitions ---------------*/

/* 
 * @brief Allocate and zero an array of bytes in memory.
 */
void *
mem_calloc(
  size_t  nmemb, 
  size_t  size
  )
{
#ifdef MEM_DEBUG_ENABLED
  if (true == _mem_firstTimeFlag_g) {
    _mem_firstTimeFlag_g = false;
    /* Reset the entries in the memory allocation table (used for
     * debugging). */
    memset(_mem_allocate_table_pg, 0, sizeof(_mem_allocate_table_pg));
  }
#endif

  void *pointer_p = calloc(nmemb, size);

#ifdef MEM_DEBUG_ENABLED
  if (NULL != pointer_p) {
    LOG_STRING(LOG_MEMORY, MEM_MODULE_NAME, "Allocated a memory region "
               "starting at %p and with size of %Zd.", pointer_p, 
               nmemb * size);

    /* Search for an available entry in the memory allocation table. */
    long  i = 0;
    for (i = 0;i < _MEM_ALLOC_TABLE_SIZE;i++) {
      if (NULL == _mem_allocate_table_pg[i].pointer_p) {
        /* Save the pointer to the allocated memory region. */
        _mem_allocate_table_pg[i].pointer_p = pointer_p;
        _mem_allocate_table_pg[i].size      = nmemb * size;
        break;
      }
    }
    if (_MEM_ALLOC_TABLE_SIZE == i) {
      LOG_STRING(LOG_ERROR, MEM_MODULE_NAME, "Memory allocation table is "
                 "full.");
    }
  }
  else {
    LOG_STRING(LOG_MEMORY, MEM_MODULE_NAME, "Failed to allocate memory "
               "region: calloc(nmemb=%Zd, size=%Zd) ", nmemb, size);    
  }
#endif

  return pointer_p;
} /* mem_calloc */


/* 
 * @brief Allocate an array of bytes in memory.
 */
void *
mem_malloc(
  size_t  size
  )
{
#ifdef MEM_DEBUG_ENABLED
  if (true == _mem_firstTimeFlag_g) {
    _mem_firstTimeFlag_g = false;
    /* Reset the entries in the memory allocation table (used for
     * debugging). */
    memset(_mem_allocate_table_pg, 0, sizeof(_mem_allocate_table_pg));
  }
#endif

  void *pointer_p = malloc(size);

#ifdef MEM_DEBUG_ENABLED
  if (NULL != pointer_p) {
    LOG_STRING(LOG_MEMORY, MEM_MODULE_NAME, "Allocated a memory region "
               "starting at %p and with size of %Zd.", pointer_p, size);

    /* Search for an available entry in the memory allocation table. */
    long  i = 0;
    for (i = 0;i < _MEM_ALLOC_TABLE_SIZE;i++) {
      if (NULL == _mem_allocate_table_pg[i].pointer_p) {
        /* Save the pointer to the allocated memory region. */
        _mem_allocate_table_pg[i].pointer_p = pointer_p;
        _mem_allocate_table_pg[i].size      = size;
        break;
      }
    }
    if (_MEM_ALLOC_TABLE_SIZE == i) {
      LOG_STRING(LOG_ERROR, MEM_MODULE_NAME, "Memory allocation table is "
                 "full.");
    }
  }
  else {
    LOG_STRING(LOG_MEMORY, MEM_MODULE_NAME, "Failed to allocate memory "
               "region: malloc(size=%Zd) ", size);    
  }
#endif

  return pointer_p;
} /* mem_malloc */
















/* 
 * @brief Free a previously allocated array of bytes in memory.
 */
void
mem_free(
  void *pointer_p
  )
{
#ifdef MEM_DEBUG_ENABLED
  /* Search for the pointer in the debug allocation table. */
  long  i = 0;
  
  for (i = 0;i < _MEM_ALLOC_TABLE_SIZE;i++) {
    if (pointer_p == _mem_allocate_table_pg[i].pointer_p) {
      /* We found it! */
      _mem_allocate_table_pg[i].pointer_p = NULL;
      _mem_allocate_table_pg[i].size      = 0;
      break;
    }
  }
  if (_MEM_ALLOC_TABLE_SIZE == i) {
    LOG_STRING(LOG_ERROR, MEM_MODULE_NAME, "Failed to find the %p pointer "
               "in the allocation table.", pointer_p);
  }
#endif

  free(pointer_p);

#ifdef MEM_DEBUG_ENABLED
  LOG_STRING(LOG_MEMORY, MEM_MODULE_NAME, "Freed memory region starting "
             "at %p.", pointer_p);
#endif
} /* mem_free */


/* 
 * @brief Show the currently allocated memory blocks.
 */
#ifdef MEM_DEBUG_ENABLED
void
mem_show(
  handle_t  logHandle,
  char     *headerStr_p
  )
{
  long  i            = 0;
  long  blockCounter = 0;
  long  totalSize    = 0;
  

  if (NULL != headerStr_p) {
    log_printf(logHandle, "%s", headerStr_p);
  }
  
  
  for (i = 0;i < _MEM_ALLOC_TABLE_SIZE;i++) {
    if (NULL != _mem_allocate_table_pg[i].pointer_p) {
      log_printf(logHandle, "%5ld: pointer = %14p, size = %ld\n",
                 i, _mem_allocate_table_pg[i].pointer_p, 
                 _mem_allocate_table_pg[i].size);
      blockCounter++;
      totalSize += _mem_allocate_table_pg[i].size;
    }
  }
  log_printf(logHandle, "Number of allocated memory blocks = %ld\n", 
             blockCounter);
  log_printf(logHandle, "Total number of allocated bytes   = %ld\n",
             totalSize);
} /* mem_show */
#endif /* MEM_DEBUG_ENABLED */


/*
 * @brief Dump the indicated memory region.
 */
void
mem_memory_dump(
  handle_t    logHandle,
  const void *buffer_p,
  uint32_t    size,
  uint32_t    lineSize,
  bool        lineHeaderFlag,
  bool        lineHeaderInHexFlag,
  const void *lineHeaderOffset_p,
  bool        lineFooterFlag
  )
{
  const uint8_t *const data_p        = buffer_p;
  const uint8_t *const offset_p      = lineHeaderOffset_p;
  const uint32_t       maxLineSize   = 1024;
  uint32_t             i             = 0;
  char                 string[maxLineSize + 1];
  uint64_t             tmpHeaderSize = (uint64_t)(data_p + size - offset_p);
  int                  headerSize    = 1;


  if (lineSize > maxLineSize) {
    lineSize = maxLineSize;
  }
  string[0]        = 0;   
  string[lineSize] = 0;


  for (i = 0;i < size;i++) {
    /* Print the line header, i.e., the address of the first byte in
     * the line. */
    if (true == lineHeaderFlag) {
      if ((0 != lineSize) && (0 == (i % lineSize))) {
        if (true == lineHeaderInHexFlag) {
          while ((tmpHeaderSize = tmpHeaderSize / 0x10) > 0) {
            headerSize++;
          }
          log_printf(logHandle, "%*"PRIxPTR":   ", headerSize,
                     data_p + i - offset_p);
        }
        else {
          while ((tmpHeaderSize = tmpHeaderSize / 10) > 0) {
            headerSize++;
          }
          log_printf(logHandle, "%*"PRIdPTR":   ", headerSize, 
                     data_p + i - offset_p);
        }
      }
    }
    
    /* Print the byte of the data. */
    log_printf(logHandle, "%02x ", data_p[i]);

    if (true == lineFooterFlag) {
      /* Build the string */
      if ((0 == isprint(data_p[i])) && (0 != lineSize)) { 
        string[i % lineSize] = '.'; 
      }
      else if (0 != lineSize) { 
        string[i % lineSize] = data_p[i]; 
      }
    } /* build the string */
      
    /* Print the string at the end of the line. */
    if ((0 != lineSize) && (((0 == ((i + 1) % lineSize)) && (0 != i)))) { 
      log_printf(logHandle, "    %s\n", string); 
    }
  }

  /* Handle the last (possibly incomplete) line. */
  if ((0 != lineSize) && (0 != (i % lineSize))) {
    string[i % lineSize] = 0;
    for (;0 != (i % lineSize);i++) { log_printf(logHandle, "   "); }
    if (true == lineFooterFlag) { 
      log_printf(logHandle, "    %s\n", string); 
    }
    else { log_printf(logHandle, "\n"); }
  }

} /* mem_memory_dump */







