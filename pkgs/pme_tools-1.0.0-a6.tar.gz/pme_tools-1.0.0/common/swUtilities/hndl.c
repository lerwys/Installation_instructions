/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : hndl.c
 *
 *   This file contains the implementation of a simple HaNDLe (HNDL) module.
 *
 ****************************************************************************/




/*--------------------- Include Files --------------------------------------*/

#include <string.h>


#include <generic_types.h>
#include <hndl.h>
#include <log.h>
#include <mem.h>








/*--------------------- Macro Definitions-----------------------------------*/

/* This macro defines the HNDL table signature. */
#define _HNDL_TABLE_SIGNATURE                 0xa3b4d97f
#define _HNDL_NULL_SIGNATURE                  0








/*--------------------- Type Definitions------------------------------------*/

/* This type defines the HNDL table structure. */
typedef struct {
  uint32_t   tableSignature;             /* identifies a handle table */
  char       name_s[HNDL_NAME_MAX_SIZE]; /* handle table name */
  uint32_t   initialTableSize;           /* initial table size */
  bool       expandFlag;                 /* expansion allowed flag */
  uint32_t   expansionsNum;              /* # of table expansions */
  uint32_t   tableSize;                  /* current table size */
  uint32_t   allocatedHandlesNum;        /* # of used entries in table */
  uint32_t   nextToTryHandle;            /* next handle to try */
  void     **entries_p;                  /* pointer to table entries */
} _hndl_table_t;





  



/*--------------------- Global Data Definitions ----------------------------*/

/* This variable defines the HNDL error string table. */
static const char *const _hndl_error_code_strings_cg[] = {
  /* hndl_ok_e */
  "HNDL: Operation successful.", 
 
  /* hndl_error_e */
  "HNDL: Operation failed.",

  /* hndl_invalid_handle_e */
  "HNDL: Invalid HNDL handle.",

  /* hndl_out_of_memory_e */
  "HNDL: Ran out of memory.",

  /* hndl_null_ptr_parameter_e */
  "HNDL: NULL pointer parameter.",

  /* hndl_too_few_error_strings_e */
  "HNDL: Internal error: more error codes than strings are defined.",

  /* hndl_too_many_error_strings_e */
  "HNDL: Internal error: more error strings than codes are defined.",

  /* hndl_handle_table_full_e */
  "HNDL: Handle table is full.",

  /* hndl_zero_initial_table_size_e */
  "HNDL: Zero initial table size is invalid.",
};







/*--------------------- Static Function Definitions ------------------------*/

/*
 * Try to expand the number of handle entries in the passed in table.
 * The function tries to add the initialTableSize of entries to the
 * indicated table.
 *
 * param tableId  ID of the handle table to expand.
 * return value   hndl_ok_e upon success;  An error code otherwise.
 */
static hndl_status_t
_hndl_table_expand(
  hndl_table_id_t  tableId
  )
{
  _hndl_table_t *table_p   = tableId;
  size_t         size      = 0;
  size_t         delta     = 1;
  void         **entries_p = NULL;
  

  /* Determine the expansion size.  For now it is the initial table
   * size.  Note that the initial table size must not be 0. */
  delta = table_p->initialTableSize;
    

  size = (table_p->tableSize + delta) * sizeof(void *);
  LOG_STRING(LOG_MEMORY, HNDL_MODULE_NAME, "Allocating %Zd bytes of memory "
             "for the entries in an expanded %s table with name \"%s\".",
             size, HNDL_MODULE_NAME, table_p->name_s);
  entries_p = mem_calloc(1, size);
  if (NULL == entries_p) {
    LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "Failed to allocate %Zd "
               "bytes of memory for the expanded entry table in the %s "
               "table with name \"%s\".", size, HNDL_MODULE_NAME, 
               table_p->name_s);
    return hndl_out_of_memory_e;
  }
  
  /* Copy the existing entries into the new entries. */
  memcpy(entries_p, table_p->entries_p, table_p->tableSize* sizeof(void *));

  /* Install the expanded table in place of the old table. */
  mem_free(table_p->entries_p);
  table_p->entries_p  = entries_p;
  table_p->nextToTryHandle = table_p->tableSize;
  table_p->tableSize += delta;
  table_p->expansionsNum++;
  
  return hndl_ok_e;
} /* _hndl_table_expand */


/*
 * Validate the passed in handle table Id.
 *
 * param tableId     Table ID to be validated.
 * param logFlag     Log/(do not log) messages if this flag is true/false.
 * return value      true if the validation passed; false otherwise.
 */
static bool
_hndl_table_id_validate(
  hndl_table_id_t  tableId,
  bool             logFlag
  )
{
  if (NULL == tableId) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "NULL table ID.");
    }
    return false;
  }
  _hndl_table_t *table_p = (_hndl_table_t *)tableId;

  /* Check the signature of the table. */
  if (_HNDL_TABLE_SIGNATURE != table_p->tableSignature) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "Table ID %p is not a valid "
                 "handle table ID.", table_p);
    }
    return false;
  }
  
  return true;
} /* _hndl_table_id_validate */


/*
 * Validate the passed in handle.  The function also validates the
 * passed in table ID.
 *
 * param tableId     Table ID to use.
 * param handle      Handle to be validated.
 * param logFlag     Log/(do not log) messages if this flag is true/false.
 * return value      true if the validation passed; false otherwise.
 */
static bool
_hndl_handle_validate(
  hndl_table_id_t  tableId,
  unsigned int     handle,
  bool             logFlag
  )
{
  /* Validate the passed in table ID. */
  if (false == _hndl_table_id_validate(tableId, logFlag)) { 
    return false;
  }
  _hndl_table_t *table_p = tableId;


  /* Validate the passed in handle. */
  if (handle > table_p->tableSize) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "Handle value of %u is "
                 "too big;  there are only %u entries in the handle table.",
                 handle, table_p->tableSize);
    }
    return false;
  }

  return true;
} /* _hndl_handle_validate */









/*--------------------- Public Function Definitions ------------------------*/

/*
 * Initialize the HNDL module.
 */
hndl_status_t
hndl_module_init(void)
{
  LOG_STRING(LOG_TEST, HNDL_MODULE_NAME, "Entering %s(void).", __func__);

  /* Check if the error code string table has been fully initialized. */
  const uint32_t  currentSize = sizeof(_hndl_error_code_strings_cg);
  const uint32_t  desiredSize = sizeof(char *) * hndl_last_error_code_e;
  if (currentSize < desiredSize) {
    LOG_STRING(LOG_ERROR, HNDL_MODULE_NAME,
               "More error codes than strings are defined.");
    return hndl_too_few_error_strings_e;
  }
  if (currentSize > desiredSize) {
    LOG_STRING(LOG_ERROR, HNDL_MODULE_NAME,
               "More error strings than codes are defined.");
    return hndl_too_few_error_strings_e;
  }

  return hndl_ok_e;
} /* hndl_module_init */


/*
 * Return error string for the passed in error code.
 */
const char *
hndl_error_string_get(
  hndl_status_t errorCode
  )
{
  LOG_STRING(LOG_TEST, HNDL_MODULE_NAME, "Entering %s(errorCode=%d).",
             __func__, errorCode);

  /* Validate the parameter(s). */
  if ((errorCode < 0) || (errorCode >= hndl_last_error_code_e)) {
    LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "%d is an invalid error code; "
               "supported error codes must be >= 0 and < %d.", errorCode, 
               hndl_last_error_code_e);
    return "The passed in error code is invalid.";
  }
  
  return _hndl_error_code_strings_cg[errorCode];
} /* hndl_error_string_get */


/* 
 * Destroys the indicated handle table.
 */
hndl_status_t
hndl_table_destroy(
  hndl_table_id_t tableId
  )
{
  /* Validate the passed in handle. */
  if (false == _hndl_table_id_validate(tableId, true)) { 
    return hndl_invalid_handle_e;
  }
  _hndl_table_t *table_p = tableId;


  /* Check if there are any allocated handles in the table to be
   * destroyed. */
  if (0 != table_p->allocatedHandlesNum) {
    LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "There are %u allocated handles "
               "in the \"%s\" handle table that is about to be destroyed.", 
               table_p->allocatedHandlesNum, table_p->name_s);
  }

  /* Reset the table signature. */
  table_p->tableSignature = _HNDL_NULL_SIGNATURE;

  /* Free the memory allocated for the entries. */
  LOG_STRING(LOG_MEMORY, HNDL_MODULE_NAME, "Freeing memory of a handle "
             "table entries located at %p.", table_p->entries_p);
  mem_free(table_p->entries_p);
  LOG_STRING(LOG_MEMORY, HNDL_MODULE_NAME, "Freeing memory of a handle "
             "table located at %p.", table_p);
  mem_free(table_p);

  return hndl_ok_e;
} /* hndl_table_destroy */


/* 
 * Creates a new handle table.
 */
hndl_status_t
hndl_table_create(
  const char      *name_p,
  uint32_t         initialTableSize,
  bool             expandFlag,
  hndl_table_id_t *tableId_p
  )
{
  hndl_status_t  hndlStatus = hndl_ok_e;
  
  
  /* Validate the parameter(s). */
  if ((NULL == name_p) || (NULL == tableId_p)) {
    LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "NULL pointer parameter "
               "(name_p=%p, tableId_p=%p).", name_p, tableId_p);
    return hndl_null_ptr_parameter_e;
  }
  if (0 == initialTableSize) {
    LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "Initial table size cannot "
               "be 0.");
    return hndl_zero_initial_table_size_e;
  }


  /* Allocate a new table record. */
  size_t  size = sizeof(_hndl_table_t);
  LOG_STRING(LOG_MEMORY, HNDL_MODULE_NAME, "Allocating %Zd bytes of memory "
             "for the main structure in a new %s table with name \"%s\".",
             size, HNDL_MODULE_NAME, name_p);
  _hndl_table_t *table_p = mem_calloc(1, size);
  if (NULL == table_p) {
    LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "Failed to allocate %Zd "
               "bytes of memory for the main structure of %s the table with "
               "name  \"%s\".", size, HNDL_MODULE_NAME, name_p);
    return hndl_out_of_memory_e;
  }
  

  /* Allocate the initial number of entries in the handle table. */
  size = initialTableSize * sizeof(void *);
  LOG_STRING(LOG_MEMORY, HNDL_MODULE_NAME, "Allocating %Zd bytes of memory "
             "for the entries in a new %s table with name \"%s\".",
             size, HNDL_MODULE_NAME, name_p);
  table_p->entries_p = mem_calloc(1, size);
  if (NULL == table_p->entries_p) {
    LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "Failed to allocate %Zd "
               "bytes of memory for the entries in the %s table with name "
               "\"%s\".", size, HNDL_MODULE_NAME, name_p);
    mem_free(table_p);
    return hndl_out_of_memory_e;
  }


  /* Initialize the new handle table. */
  /* Save the name of the table. */
  strncpy(table_p->name_s, name_p, HNDL_NAME_MAX_SIZE - 1);

  /* Save the expansion allowed flag. */
  table_p->expandFlag = expandFlag;
  
  /* Save the initial number of entries in the table. */
  table_p->initialTableSize = initialTableSize;
  table_p->tableSize        = initialTableSize;


  /* Set the HNDL table signature entry. */
  table_p->tableSignature = _HNDL_TABLE_SIGNATURE;

  *tableId_p = (hndl_table_id_t)table_p;
  
  return hndlStatus;
} /* hndl_table_create */


/*
 * Show the entries in the indicated handle table structure.
 */
void
hndl_table_show(
  hndl_table_id_t  tableId
  )
{
  /* Validate the passed in handle. */
  if (false == _hndl_table_id_validate(tableId, true)) { 
    return;
  }
  _hndl_table_t *table_p = tableId;

  
  /* Display the values in the handle table. */
  log_printf(LOG_STDOUT, "  tableSignature      = %u\n",
             table_p->tableSignature);
  log_printf(LOG_STDOUT, "  name_p              = %p (name = \"%s\")\n",
             table_p->name_s, table_p->name_s);
  log_printf(LOG_STDOUT, "  initialTableSize    = %u\n",
             table_p->initialTableSize);
  log_printf(LOG_STDOUT, "  expandFlag          = %d\n",
             table_p->expandFlag);
  log_printf(LOG_STDOUT, "  expansionsNum       = %u\n",
             table_p->expansionsNum);
  log_printf(LOG_STDOUT, "  tableSize           = %u\n", table_p->tableSize);
  log_printf(LOG_STDOUT, "  allocatedHandlesNum = %u\n",
             table_p->allocatedHandlesNum);
  log_printf(LOG_STDOUT, "  nextToTryHandle     = %u\n",
             table_p->nextToTryHandle);
  log_printf(LOG_STDOUT, "  entries_p           = %p\n",
             table_p->entries_p);

  /* Display the index allocation information. */
  hndl_table_entries_show(tableId);

} /* hndl_table_show */


/*
 * Show the entries in the handle table.
 */
void
hndl_table_entries_show(
  hndl_table_id_t  tableId
  )
{
  /* Validate the passed in handle. */
  if (false == _hndl_table_id_validate(tableId, true)) { 
    return;
  }
  _hndl_table_t *table_p        = tableId;
  uint32_t       i              = 0;
  uint32_t       rangeStart     = 0;
  uint32_t       rangeSize      = 0;
  bool           entryType      = true; /* allocated = true; free = false */
  bool           rangeType      = true; /* allocated = true; free = false */
  uint32_t       totalAllocated = 0;
  uint32_t       totalFree      = 0;
  

  log_printf(LOG_STDOUT, "  Handle table entries:\n");
  
  for (i = 0;i < table_p->tableSize;) {
    rangeStart  = i;
    rangeSize   = 0;
    if (NULL == table_p->entries_p[i]) { 
      entryType = false; 
      rangeType = false; 
    }
    else { 
      entryType = true; 
      rangeType = true; 
    }
      
    while (i < table_p->tableSize) {
      if (NULL == table_p->entries_p[i]) { entryType = false; }
      else { entryType = true; }
        
      if (entryType == rangeType) {
        rangeSize++;
        i++;
      }
      else {
        break;
      }
    }
    
    if (true == rangeType) { totalAllocated += rangeSize; }
    else  { totalFree += rangeSize; }
      
      
    if (rangeSize > 1) {
      log_printf(LOG_STDOUT, "    %6u - %6u: %s\n", rangeStart, 
                 rangeStart - 1 + rangeSize, (false == rangeType)? 
                 "free" : "allocated");
    }
    else {
      log_printf(LOG_STDOUT, "    %6u         : %s\n", rangeStart, 
                 (false == rangeType)? "free" : "allocated");
    }
  }

  log_printf(LOG_STDOUT, "    Number of allocated handles: %6u\n", 
             totalAllocated);
  log_printf(LOG_STDOUT, "    Number of free handles     : %6u\n", totalFree);

} /* hndl_table_entries_show */


/*
 * Allocate a new handle.
 */
hndl_status_t
hndl_handle_allocate(
  hndl_table_id_t  tableId,
  void            *object_p,
  unsigned int    *handle_p
  )
{
  /* Validate the parameter(s). */
  if (false == _hndl_table_id_validate(tableId, true)) { 
    return hndl_invalid_handle_e;
  }
  if (NULL == handle_p) {
    LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "NULL handle_p parameter.");
    return hndl_null_ptr_parameter_e;
  }

  _hndl_table_t  *table_p    = tableId;
  uint32_t        tryHandle  = table_p->nextToTryHandle;
  uint32_t        i          = 0;
  hndl_status_t   hndlStatus = hndl_handle_table_full_e;
    

  /* First we check if there are any handles available. */
  if (table_p->allocatedHandlesNum == table_p->tableSize) {
    /* The handle table is full.  Check the tables expandFlag and try
     * to expand the table if the flag is set to true. */
    if (true == table_p->expandFlag) {
      hndlStatus = _hndl_table_expand(table_p);
      if (hndl_ok_e != hndlStatus) {
        LOG_STRING(LOG_TEST, HNDL_MODULE_NAME, "Failed to expand the \"%s\" "
                   "handle table.", table_p->name_s);
        return hndlStatus;
      }
      tryHandle = table_p->nextToTryHandle;
    }
  }
  

  for (i = 0;i < table_p->tableSize;i++) {
    if (NULL == table_p->entries_p[tryHandle]) {
      /* We found an available handle.  Mark it as used and return it. */
      table_p->entries_p[tryHandle] = object_p;
      table_p->allocatedHandlesNum++;
     
      /* Set the next index to try.  This is a form of optimizing the
       * next search for an unallocated index. */
      table_p->nextToTryHandle = (tryHandle + 1) % table_p->tableSize ;

      LOG_STRING(LOG_TEST, HNDL_MODULE_NAME, "Allocated handle %u in handle "
                 "table with ID %p; next handle to try is handle %u.", 
                 tryHandle, table_p, table_p->nextToTryHandle);
      *handle_p  = tryHandle;
      hndlStatus = hndl_ok_e;
      break;
    }

    /* Move to the next handle. */
    tryHandle = (tryHandle + 1) % table_p->tableSize;
  }
  
  return hndlStatus;
} /* hndl_handle_allocate */


/*
 * Free a handle.
 */
void
hndl_handle_free(
  hndl_table_id_t  tableId,
  unsigned int     handle
  )
{
  /* Validate the passed in handle (this validates the table ID too). */
  if (false == _hndl_handle_validate(tableId, handle, true)) {
    return;
  }
  _hndl_table_t *table_p = tableId;


  if (NULL == table_p->entries_p[handle]) {
    LOG_STRING(LOG_WARNING, HNDL_MODULE_NAME, "Attempt to free an unallocated "
               "handle of %u in handle table with name \"%s\".", handle,
               table_p->name_s);
  }
  else {
    /* Free the handle. */
    LOG_STRING(LOG_TEST, HNDL_MODULE_NAME, "Freeing handle value of %u in "
               "handle table with name \"%s\".", handle, table_p->name_s);
    table_p->entries_p[handle] = NULL;
    if (0 == table_p->allocatedHandlesNum) {
      LOG_STRING(LOG_ERROR, HNDL_MODULE_NAME, "Failed to decrement the "
                 "currently allocated handle count in handle table with "
                 "name \"%s\".  Count is already zero.", table_p->name_s);
    }
    else {
      table_p->allocatedHandlesNum--;
    }
  }

} /* hndl_handle_free */


/*
 * Get the pointer to the object associated with the given handle.
 */
void *
hndl_object_from_handle_get(
  hndl_table_id_t  tableId,
  unsigned int     handle
  )
{
  /* Validate the passed in handle (this validates the table ID too). */
  if (false == _hndl_handle_validate(tableId, handle, true)) {
    return NULL;
  }
  _hndl_table_t *table_p = tableId;
  
  return table_p->entries_p[handle];
} /* hndl_object_from_handle_get */




