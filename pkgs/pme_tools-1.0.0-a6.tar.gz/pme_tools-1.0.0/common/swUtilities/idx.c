/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : idx.c
 *
 *   This file contains the implementation of a simple InDeX (IDX)
 *   management module.
 *
 ****************************************************************************/




/*--------------------- Include Files -----------------------------*/

#include <string.h>


#include <generic_types.h>
#include <idx.h>
#include <log.h>
#include <mem.h>







/*--------------------- Macro Definitions--------------------------*/

/* This macro defines the index table signature. */
#define _IDX_TABLE_SIGNATURE                 0xadded001
#define _IDX_NULL_SIGNATURE                  0







/*--------------------- Type Definitions---------------------------*/

/* This type defines an index entry in an index table. */
typedef struct {
  struct {
    uint8_t  allocatedFlag : 1; /* "true" means the entry is allocated. */
    uint8_t  unused        : 7;
  };
} _idx_index_entry_t;


/* This type defines the index table.  Note that the 0 index entry is
 * reserved for internal use and it is never allocated. */
typedef struct {
  uint32_t            tableSignature;  /* identifies an index table */
  char                name_s[IDX_NAME_MAX_SIZE]; /* name of the table */
  _idx_index_entry_t *indexEntry_p;    /* index table entries */
  uint32_t            nextToTryIndex;  /* next index to try */
  uint32_t            idxMaxNum;       /* max. number of entries in table */
  uint32_t            allocatedIdxNum; /* numb. of currently allocated idxs */
} _idx_index_table_t;



  



/*--------------------- Global Data Definitions -------------------*/

/* This variable defines the IDX error string table. */
static const char *const _idx_error_code_strings_cg[] = {
  /* idx_ok_e */
  "IDX: Operation successful.",

  /* idx_error_e */
  "IDX: Operation failed.",

  /* idx_invalid_idx_handle_e */
  "IDX: Invalid IDX handle.",

  /* idx_too_few_error_strings_e */
  "IDX: Internal error: more error codes than strings are defined.",

  /* idx_too_many_error_strings_e */
  "IDX: Internal error: more error strings than codes are defined.",

  /* idx_invalid_max_index_e */
  "IDX: Invalid maximum index.",

  /* idx_out_of_memory_e */
  "IDX: Ran out of memory.",

  /* idx_null_ptr_parameter_e */
  "IDX: NULL pointer parameter.",

  /* idx_idx_table_is_full_e */
  "IDX: Index table is full.",
};








/*--------------------- Static Function Definitions ---------------*/

/*
 * Validate the passed in index table handle.
 */
static bool
_idx_handle_validate(
  const handle_t  handle,
  const bool      logFlag
  )
{
  if (HANDLE_NULL == handle) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "NULL table handle.");
    }
    return false;
  }
  _idx_index_table_t const* indexTable_p = (_idx_index_table_t *)handle;


  /* Check the signature of the table. */
  if (_IDX_TABLE_SIGNATURE != indexTable_p->tableSignature) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, IDX_MODULE_NAME,
                 "Handle %"PRI_HANDLE" is not a valid index "
                 "table handle.", handle);
    }
    return false;
  }
  
  return true;
} /* _idx_handle_validate */


/*
 * Validate the passed in index.
 */
static bool
_idx_index_validate(
  const handle_t  handle,
  const uint32_t  idx,
  const bool      logFlag
  )
{
  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, logFlag)) { 
    return false;
  }
  _idx_index_table_t const* indexTable_p = (_idx_index_table_t *)handle;


  /* Validate the passed in index. */
  if (0 == idx) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "Index value of 0 is invalid.");
    }
    return false;
  }
  else if (idx > indexTable_p->idxMaxNum) {
    if (true == logFlag) {
      LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "Index value of %"PRIu32" is "
                 "too big;  there are only %"PRIu32" entries in the index "
                 "table.", idx, indexTable_p->idxMaxNum);
    }
    return false;
  }

  return true;
} /* _idx_index_validate */









/*--------------------- Public Function Definitions ---------------*/

/*
 * Initialize the IDX module.
 */
idx_status_t
idx_module_init(void)
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: %s().",
             __func__);
  
  /* Check if the error code string table has been fully initialized. */
  const uint32_t  currentSize = sizeof(_idx_error_code_strings_cg);
  const uint32_t  desiredSize = sizeof(char *) * idx_last_error_code_e;
  if (currentSize < desiredSize) {
    LOG_STRING(LOG_ERROR, IDX_MODULE_NAME, "More error codes than strings are "
               "defined.");
    return idx_too_few_error_strings_e;
  }
  if (currentSize > desiredSize) {
    LOG_STRING(LOG_ERROR, IDX_MODULE_NAME, "More error strings than codes are "
               "defined.");
    return idx_too_few_error_strings_e;
  }

  return idx_ok_e;
} /* idx_module_init */


/*
 * Create a new index table.
 */
idx_status_t
idx_index_table_create(
  uint32_t    idxMaxNum,
  const char *name_p,
  handle_t   *handle_p
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function %s(idxMaxNum=%u, "
             "name_p=%p=\"%s\", handle_p=%p).", __func__, idxMaxNum, name_p,
             ((NULL == name_p)? "":name_p), handle_p);

  /* Validate the passed in parameters. */
  if (NULL == handle_p) {
    LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "NULL handle_p pointer "
               "parameter.");
    return idx_null_ptr_parameter_e;
  }
  /* Validate the passed in pointer. */
  if (NULL == name_p) {
    LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "NULL name_p pointer parameter.");
    return idx_null_ptr_parameter_e;
  }


  /* Check the passed in maximum index number. */
  if (IDX_NULL_INDEX == idxMaxNum) {
    LOG_STRING(LOG_WARNING, IDX_MODULE_NAME,
               "Maximum index number of %"PRIu32" is invalid.", idxMaxNum);
    return idx_invalid_max_index_e;
  }

  /* Allocate and clear memory for the index table. */
  LOG_STRING(LOG_MEMORY, IDX_MODULE_NAME, "Allocating %Zd bytes of memory "
             "for a new index table.", sizeof(_idx_index_table_t));
  _idx_index_table_t *indexTable_p = mem_calloc(1, sizeof(_idx_index_table_t));
  if (NULL == indexTable_p) {
    LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "Failed to allocate %Zd bytes "
               "of memory for a new index table.", 
               sizeof(_idx_index_table_t));
    return idx_out_of_memory_e;
  }

  /* Allocate memory for the index entries in the table. */
  LOG_STRING(LOG_MEMORY, IDX_MODULE_NAME, "Allocating %Zd bytes of memory "
             "for %u new index table entries.",
             (idxMaxNum + 1) * sizeof(_idx_index_entry_t), idxMaxNum + 1);
  indexTable_p->indexEntry_p = mem_calloc(idxMaxNum + 1, 
                                          sizeof(_idx_index_entry_t));
  if (NULL == indexTable_p->indexEntry_p) {
    LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "Failed to allocate %Zd bytes "
               "of memory for %"PRIu32" index entries in an index table.", 
               (idxMaxNum + 1) * sizeof(_idx_index_entry_t), idxMaxNum + 1);

    LOG_STRING(LOG_MEMORY, IDX_MODULE_NAME,
               "Freeing memory of an index table located at %p.", 
               indexTable_p);
    mem_free(indexTable_p);
    return idx_out_of_memory_e;
  }

  /* Mark the zero index as allocated.  We do not allow it to be
   * allocated by the user of the IDX module. */
  indexTable_p->indexEntry_p[0].allocatedFlag = true;

  /* Save the name of the table. */
  strncpy(indexTable_p->name_s, name_p, IDX_NAME_MAX_SIZE - 1);
  
  /* Save the maximum index value, i.e., number of index entries. */
  indexTable_p->idxMaxNum = idxMaxNum;

  /* Set the index table signature entry. */
  indexTable_p->tableSignature = _IDX_TABLE_SIGNATURE;

  *handle_p = (handle_t)indexTable_p;

  return idx_ok_e;
} /* idx_index_table_create */


/*
 * Destroy an index table.
 */
idx_status_t
idx_index_table_destroy(
  handle_t handle
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE").", __func__, handle);

  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, true)) { 
    return idx_invalid_idx_handle_e;
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;


  /* Check if there are any allocated indexes in the table to be
   * destroyed. */
  if (0 != indexTable_p->allocatedIdxNum) {
    LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "There are %u allocated indexes "
               "in the \"%s\" index table that is about to be destroyed.", 
               indexTable_p->allocatedIdxNum, indexTable_p->name_s);
  }

  /* Reset the table signature. */
  indexTable_p->tableSignature = _IDX_NULL_SIGNATURE;

  /* Free the memory allocated for the table. */
  LOG_STRING(LOG_MEMORY, IDX_MODULE_NAME,
             "Freeing memory of an index table entries "
             "located at %p.", indexTable_p->indexEntry_p);
  mem_free(indexTable_p->indexEntry_p);
  LOG_STRING(LOG_MEMORY, IDX_MODULE_NAME,
             "Freeing memory of an index table located at %p.", indexTable_p);
  mem_free(indexTable_p);

  return idx_ok_e;
} /* idx_index_table_destroy */


/*
 * Allocate a new index.
 */
uint32_t
idx_index_allocate(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE").", __func__, handle);

  /* Validate the passed in parameters. */
  if (false == _idx_handle_validate(handle, true)) { 
    return IDX_NULL_INDEX;
  }

  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;  
  uint32_t                  tryIndex     = indexTable_p->nextToTryIndex;
  uint32_t                  idxMaxNum    = indexTable_p->idxMaxNum;
  uint32_t                  i            = 0;
  

  for (i = 0;i < idxMaxNum + 1;i++) {
    if (false == indexTable_p->indexEntry_p[tryIndex].allocatedFlag) {
      /* We found an available index.  Mark it as used and return it.
       * Note that the 0 index is pre-initialized as used so we should
       * never return it. */
      indexTable_p->indexEntry_p[tryIndex].allocatedFlag = true;
      indexTable_p->allocatedIdxNum++;
     
      /* Set the next index to try.  This is a form of optimizing the
       * next search for an unallocated index. */
      indexTable_p->nextToTryIndex = (tryIndex + 1) % (idxMaxNum + 1);

      LOG_STRING(LOG_TEST, IDX_MODULE_NAME,
                 "Allocated index value of %"PRIu32" in index table "
                 "with handle %"PRI_HANDLE"; next index to try is %"PRIu32".", 
                 tryIndex, handle, indexTable_p->nextToTryIndex);
      return tryIndex;
    }

    /* Move to the next index. */
    tryIndex = (tryIndex + 1) % (idxMaxNum + 1);
  }
  
  return IDX_NULL_INDEX;
} /* idx_index_allocate */


/*
 * Free an index.
 */
void
idx_index_free(
  handle_t  handle,
  uint32_t  idx
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE", idx=%"PRIu32").", __func__, 
             handle, idx);  

  /* Validate the passed in index (this validates the handle too). */
  if (false == _idx_index_validate(handle, idx, true)) {
    return;
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;


  if (false == indexTable_p->indexEntry_p[idx].allocatedFlag) {
    LOG_STRING(LOG_TEST, IDX_MODULE_NAME,
               "Attempt to free an unallocated index of %"PRIu32" "
               "in index table with handle %"PRI_HANDLE".", idx, handle);
  }
  else {
    /* Free the index. */
    LOG_STRING(LOG_TEST, IDX_MODULE_NAME,
               "Freeing index value of %"PRIu32" in index table "
               "with handle %"PRI_HANDLE".", idx, handle);
    indexTable_p->indexEntry_p[idx].allocatedFlag = false;
    if (0 == indexTable_p->allocatedIdxNum) {
      LOG_STRING(LOG_ERROR, IDX_MODULE_NAME, "Failed to decrement the "
                 "currently allocated index count in index table with "
                 "handle %"PRI_HANDLE".  Count is already zero.", handle);
    }
    else {
      indexTable_p->allocatedIdxNum--;
    }
  }

  /* Set the next index to try.  This is a form of optimizing the next
   * search for an unallocated index. */
  if (0 == indexTable_p->allocatedIdxNum) {
    indexTable_p->nextToTryIndex = 1;      
  }
  else {
    indexTable_p->nextToTryIndex = idx;
  }
} /* idx_index_free */


/*
 * Check if the passed index is allocated.
 */
bool
idx_is_index_allocated(
  handle_t  handle,
  uint32_t  idx
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE", idx=%"PRIu32").", __func__, 
             handle, idx);  

  /* Validate the passed in index (this validates the handle too). */
  if (false == _idx_index_validate(handle, idx, true)) {
    return true;
  }
  _idx_index_table_t const* indexTable_p = (_idx_index_table_t *)handle;


  return indexTable_p->indexEntry_p[idx].allocatedFlag;
} /* idx_is_index_allocated */


/*
 * Check if the passed index is valid.
 */
bool
idx_is_index_valid(
  handle_t  handle,
  uint32_t  idx
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE", idx=%"PRIu32").", __func__, 
             handle, idx);  

  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, true)) { 
    return false;
  }

  return _idx_index_validate(handle, idx, false);
} /* idx_is_index_allocated */


/*
 * Check if the passed handle is valid.
 */
bool
idx_is_handle_valid(
  handle_t  handle
  )
{
  return _idx_handle_validate(handle, false);
} /* idx_is_handle_valid */


/*
 * Get the next allocated index.
 */
uint32_t
idx_index_next_allocated_get(
  handle_t  handle,
  uint32_t  idx
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE", idx=%"PRIu32").", __func__, 
             handle, idx);  

  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, true)) { 
    return IDX_NULL_INDEX;
  }
  /* Validate the passed in index.  Note that the IDX_NULL_INDEX index
   * is valid in this case. */
  if (IDX_NULL_INDEX != idx) {
    if (false == _idx_index_validate(handle, idx, true)) {
      return IDX_NULL_INDEX;
    }
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;  
  uint32_t                  i            = idx + 1;
  

  if (IDX_NULL_INDEX == idx) {
    /* Start the search from the beginning of the index table.
     * Remember that index 0 is not used. */
    i = 1;
  }  

  for (;i < indexTable_p->idxMaxNum + 1;i++) {
    if (true == indexTable_p->indexEntry_p[i].allocatedFlag) {
      return i;
    }
  }
  
  return IDX_NULL_INDEX;
} /* idx_index_next_allocated_get */


/*
 * Return error string for the passed in error code.
 */
const char *
idx_error_string_get(
  idx_status_t errorCode
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering %s(errorCode=%d).",
             __func__, errorCode);

  /* Validate the parameters. */
  if ((errorCode < 0) || (errorCode >= idx_last_error_code_e)) {
    LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "%d is an invalid error code; "
               "supported error codes must be >= 0 and < %d.", errorCode, 
               idx_last_error_code_e);
    return "The passed in error code is invalid.";
  }
  
  return _idx_error_code_strings_cg[errorCode];
} /* idx_error_string_get */


/*
 * Mark the indicated index as allocated.
 */
void
idx_index_allocated_set(
  handle_t  handle,
  uint32_t  idx
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE", idx=%"PRIu32").", __func__, 
             handle, idx);  

  /* Validate the passed in index (this validates the handle too). */
  if (false == _idx_index_validate(handle, idx, true)) {
    return;
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;


  if (true == indexTable_p->indexEntry_p[idx].allocatedFlag) {
    LOG_STRING(LOG_TEST, IDX_MODULE_NAME,
               "Attempt to mark an already allocated index=%u "
               "as allocated in index table with handle %"PRI_HANDLE".",
               idx, (handle_t)indexTable_p);
  }
  else {
    /* Set the index as allocated. */
    indexTable_p->indexEntry_p[idx].allocatedFlag = true;
    indexTable_p->allocatedIdxNum++;
  }
} /* idx_index_allocated_set */


/*
 * Show the entries in the main index table structure.
 */
void
idx_index_table_show(
  handle_t  handle
  )
{
  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, true)) { 
    return;
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;

  
  /* Display the values in the index table. */
  log_printf(LOG_STDOUT, "  tableSignature  = %"PRIu32"\n",
             indexTable_p->tableSignature);
  log_printf(LOG_STDOUT, "  name_p          = %p (name = \"%s\")\n",
             indexTable_p->name_s, indexTable_p->name_s);
  log_printf(LOG_STDOUT, "  indexEntry_p    = %p\n",
             indexTable_p->indexEntry_p);
  log_printf(LOG_STDOUT, "  nextToTryIndex  = %"PRIu32"\n",
             indexTable_p->nextToTryIndex);
  log_printf(LOG_STDOUT, "  idxMaxNum       = %"PRIu32"\n",
             indexTable_p->idxMaxNum);
  log_printf(LOG_STDOUT, "  allocatedIdxNum = %"PRIu32"\n",
             indexTable_p->allocatedIdxNum);

  /* Display the index allocation information. */
  idx_index_table_entries_show(handle);

} /* idx_index_table_show */


/*
 * Retrieve the number of the currently allocated indexes in the table.
 */
uint32_t
idx_allocated_idx_num_get(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE").", __func__, handle);  

  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, true)) { 
    return IDX_NULL_INDEX;
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;


  return indexTable_p->allocatedIdxNum;
} /* idx_allocated_idx_num_get */


/*
 * Retrieve the number of the entries in the table.
 */
uint32_t
idx_max_idx_num_get(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE").", __func__, handle);  

  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, true)) { 
    return IDX_NULL_INDEX;
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;


  return indexTable_p->idxMaxNum;
} /* idx_max_idx_num_get */


/*
 * Show the entries in the index table.
 */
void
idx_index_table_entries_show(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE").", __func__, handle);  

  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, true)) { 
    return;
  }
  _idx_index_table_t *const indexTable_p   = (_idx_index_table_t *)handle;
  uint32_t                  i              = 0;
  uint32_t                  rangeStart     = 0;
  uint32_t                  rangeSize      = 0;
  bool                      rangeType      = true;
  idx_status_t              idxStatus      = idx_ok_e;
  idx_stats_t               idxStats;


  log_printf(LOG_STDOUT, "  Index table entries:\n");
  
  for (i = 1;i <= indexTable_p->idxMaxNum;) {
    rangeStart = i;
    rangeSize  = 0;
    rangeType  = indexTable_p->indexEntry_p[i].allocatedFlag;

    while ((i <= indexTable_p->idxMaxNum) &&
           (rangeType == indexTable_p->indexEntry_p[i].allocatedFlag)) {
      rangeSize++;
      i++;
    }      
      
    if (rangeSize > 1) {
      log_printf(LOG_STDOUT, "    %6u - %6u: %s\n", rangeStart, 
                 rangeStart - 1 + rangeSize, rangeType? "allocated" : "free");
    }
    else {
      log_printf(LOG_STDOUT, "    %6u         : %s\n", rangeStart, 
                 rangeType? "allocated" : "free");
    }
  }


  // We could compute the number of the allocated and available
  // entries in the loop above but we'd rather use the function that
  // does just that.
  idxStatus = idx_stats_get(handle, &idxStats);
  if (idx_ok_e != idxStatus) {
    LOG_STRING(LOG_ERROR, IDX_MODULE_NAME, "Failed to retrieve statistics "
               "for the \"%s\" index table.", indexTable_p->name_s);
  }
  else {
    log_printf(LOG_STDOUT, "    Number of allocated entries: %6u\n", 
               idxStats.allocatedIdxNum);
    log_printf(LOG_STDOUT, "    Number of available entries: %6u\n", 
               idxStats.availableIdxNum);
  }
  
} /* idx_index_table_entries_show */


/*
 * Get the statistics for the indicated index table.
 */
idx_status_t
idx_stats_get(
  handle_t     handle,
  idx_stats_t *idxStats_p
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE", idxStats_p=%p).", __func__, handle,
             idxStats_p);  

  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, true)) { 
    return idx_invalid_idx_handle_e;
  }
  if (NULL == idxStats_p) {
    LOG_STRING(LOG_WARNING, IDX_MODULE_NAME, "NULL pointer parameter.");
    return idx_null_ptr_parameter_e;
  }

  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;
  
  
  strncpy(idxStats_p->name_s, indexTable_p->name_s, IDX_NAME_MAX_SIZE - 1);
  idxStats_p->idxMaxNum       = indexTable_p->idxMaxNum;
  idxStats_p->allocatedIdxNum = indexTable_p->allocatedIdxNum;
  idxStats_p->availableIdxNum = 
    indexTable_p->idxMaxNum - indexTable_p->allocatedIdxNum;
  
  return idx_ok_e;
} /* idx_stats_get */


/*
 * Allocate a block of consecutive indexes.
 *
 * The function searches the index table (starting from the
 * nextToTryIndex index) for a block of consecutive unallocated
 * indexes.  The sought block needs to have "blockSize" of indexes in
 * it.  The function also attempts to minimize the fragmentation in
 * the table.  This is achieved by trying to find a block that would
 * close a gap between already allocated indexes.  Note that this
 * calls makes the function slower.
 */
uint32_t
idx_index_block_allocate(
  handle_t  handle,
  uint32_t  blockSize,
  uint32_t  alignedToValue
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE", blockSize=%"PRIu32").", __func__, 
             handle, blockSize);  

  /* Validate the passed in parameters. */
  if (false == _idx_handle_validate(handle, true)) { 
    return IDX_NULL_INDEX;
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;  


  if ((0 == blockSize) || (blockSize > indexTable_p->idxMaxNum)) { 
    return IDX_NULL_INDEX;
  }
  
  uint32_t  tryIndex            = indexTable_p->nextToTryIndex;
  uint32_t  idxMaxNum           = indexTable_p->idxMaxNum;
  uint32_t  i                   = 0;
  uint32_t  j                   = 0;
  uint8_t   currentNeighborNum  = 0;
  uint8_t   bestNeighborNum     = 0;
  uint32_t  bestFoundIndex      = IDX_NULL_INDEX;
  uint32_t  allocatedIndexCount = 0;
  bool      found               = false;
  

  for (i = 0;i < idxMaxNum + 1;) {
    currentNeighborNum = 0;

    /* Check if a free block starts from index i. */
    for (j = 0;j < blockSize;j++, i++) {
      /* Check if we are at the end of the table. */
      if (tryIndex > idxMaxNum) {
        tryIndex = 1;
        break;
      }
      else if (true == indexTable_p->indexEntry_p[tryIndex].allocatedFlag) {
        /* This index is allocated so we have not found a block here;
         * we must move forward. */
        allocatedIndexCount++;
        tryIndex++;
        i++;
        break;
      }
      else {
        /* This index is free.  For the first index in the block and
         * if the alignedToValue is not 0, check if the index is
         * aligned on the block boundary. */
        if ((0 != alignedToValue) && (0 == j) &&
            (0 != (tryIndex % alignedToValue))) {
          tryIndex++;
          i++;
          break;
        }
        
        /* Keep checking, i.e., keep running the inner j loop, if this
         * is a free block of indexes. */
        tryIndex++;
      }
    }
    /* Check if we found an unallocated block of indexes. */
    if (blockSize == j) {
      /* We found a block. */
      found = true;
            
      /* Check if the idexes immidiately before and after of the found
       * block, i.e., the block neighors, are allocated.  Note that
       * the 0 index in the table is always allocated. */
      if (true == indexTable_p->indexEntry_p[tryIndex - blockSize - 1].
          allocatedFlag) {
        currentNeighborNum++;
      }
      if ((idxMaxNum == (tryIndex - 1)) ||
          (true      == indexTable_p->indexEntry_p[tryIndex].allocatedFlag)) {
        currentNeighborNum++;
      }
      
      if (2 == currentNeighborNum) {
        /* We consider this to be a good enough block. */
        bestFoundIndex = tryIndex - blockSize;
        break;
      }
      else {
        if ((currentNeighborNum > bestNeighborNum) || 
            (IDX_NULL_INDEX == bestFoundIndex)) {
          /* This is a better block than what we had before or the
           * first found block. */
          bestNeighborNum = currentNeighborNum;
          bestFoundIndex  = tryIndex - blockSize;
        }
      }
      
      /* Check if we have gone through all the allocated indexes.  If
       * so, there will be no batter index than what we have. */
      if (allocatedIndexCount >= indexTable_p->allocatedIdxNum) {
        break;
      }
    } /* if - we found a block of unallocated indexes. */
  } /* for - check all the entries in the index table. */
  

  if (true == found) {
    /* Set the next index to try.  This is a form of optimizing the
     * next search for an unallocated index. */
    indexTable_p->nextToTryIndex = tryIndex % (idxMaxNum + 1);
    
    /* Mark all the indexes in the found block as allocated. */
    for (j = 0;j < blockSize;j++) {
      indexTable_p->indexEntry_p[bestFoundIndex + j].allocatedFlag = true;
    }

    /* Update the count of the allocated indexes in the table. */
    indexTable_p->allocatedIdxNum += blockSize;

    LOG_STRING(LOG_TEST, IDX_MODULE_NAME,
               "Allocated a block of %u index(es) starting at index %u in "
               "index table with handle %"PRI_HANDLE"; next index to try "
               "is %u.", blockSize, bestFoundIndex, handle, 
               indexTable_p->nextToTryIndex);
    return bestFoundIndex;
  }

  return IDX_NULL_INDEX;
} /* idx_index_block_allocate */


/*
 * Free a block of indexes.
 */
void
idx_index_block_free(
  handle_t  handle,
  uint32_t  startIdx,
  uint32_t  blockSize
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE", startIdx=%u, blockSize=%"PRIu32").",
             __func__, handle, startIdx, blockSize);

  /* Validate the passed in index (this validates the handle too). */
  if (false == _idx_index_validate(handle, startIdx, true)) {
    return;
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;
  uint32_t                  i            = 0;


  if (blockSize > indexTable_p->idxMaxNum) { 
    LOG_STRING(LOG_ERROR, IDX_MODULE_NAME, "Index block size of %u is larger "
               "than the table size of %u.", blockSize, 
               indexTable_p->idxMaxNum);
    return;
  }
 

  /* Mark all the indexes in the indicated block as free. */
  for (i = 0;i < blockSize;i++) {
    if (false == indexTable_p->indexEntry_p[startIdx + i].allocatedFlag) {
      LOG_STRING(LOG_TEST, IDX_MODULE_NAME,
                 "Attempt to free an unallocated index of %"PRIu32" in "
                 "index table with handle %"PRI_HANDLE".", startIdx, handle);
    }
    else {
      LOG_STRING(LOG_TEST, IDX_MODULE_NAME,
                 "Freeing index value of %"PRIu32" in index table "
                 "with handle %"PRI_HANDLE".", startIdx + i, handle);
      indexTable_p->indexEntry_p[startIdx + i].allocatedFlag = false;
      if (0 == indexTable_p->allocatedIdxNum) {
        LOG_STRING(LOG_ERROR, IDX_MODULE_NAME, "Failed to decrement the "
                   "currently allocated index count in index table with "
                   "handle %"PRI_HANDLE".  Count is already zero.", handle);
      }
      else {
        indexTable_p->allocatedIdxNum--;
      }
    }
  }

  /* Set the next index to try.  This is a form of optimizing the next
   * search for an unallocated index. */
  if (0 == indexTable_p->allocatedIdxNum) {
    indexTable_p->nextToTryIndex = 1;      
  }
  else {
    indexTable_p->nextToTryIndex = startIdx;
  }
} /* idx_index_block_free */


/*
 * Free all the indexes.
 */
void
idx_index_all_free(
  handle_t  handle
  )
{
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Entering function: "
             "%s(handle=%"PRI_HANDLE").", __func__, handle);

  /* Validate the passed in handle. */
  if (false == _idx_handle_validate(handle, true)) { 
    return;
  }
  _idx_index_table_t *const indexTable_p = (_idx_index_table_t *)handle;
  uint32_t                  i            = 1;
  

  /* Free all the indexes. */
  LOG_STRING(LOG_TEST, IDX_MODULE_NAME, "Freeing all the indexes in index "
             "table with handle %"PRI_HANDLE".", handle);

  for (i = 1;i <= indexTable_p->idxMaxNum;i++) {
    indexTable_p->indexEntry_p[i].allocatedFlag = false;
  }
  
  /* Reset the allocated entries counter. */
  indexTable_p->allocatedIdxNum = 0;
  
  /* Set the next index to try. */
  indexTable_p->nextToTryIndex = 1;      
} /* idx_index_all_free */
