/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmci.c
 *
 * Description:
 *   This file holds the Pattern Matching Control Interface API implementation
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmci.h>
#include <pm_defs.h>
#include <pmp.h>
#include <log.h>

#include <stdlib.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>

#include <fsl_pme.h>

/**********************************************************************
 * Macros
 **********************************************************************/

/* Magic number */
#define PMCI_MAGIC_VALUE 0x33636907

/* This macro determines if the build should actually make the calls to the
 * PM driver.  Calls to the PM driver code is compiled anyways.  However,
 * when not compiling on the target, a return statement is specified thus
 * preventing the call to the PM driver.  When this macro is defined, it
 * assumes it can call the PM driver (the driver is installed).  When
 * undefined, the PMCI module simply stub out all PM driver requests by
 * echoing any requests back to the originator.
 */
#define PMCI_RUNNING_ON_TARGET

/* Commands that can't be interpreted by hardware are software commands that
 * requires particular interpretation.  Sometimes, these commands translates
 * into different hardware commands.  This macro enables the decode of these
 * hardware commands.
 */
/*#define PMCI_DECODE_HW_FROM_SW_CMD*/

/* Maximum buffer size to use when proxying */
#define PMCI_PROXY_MAX_LENGTH 65536
#define PMCI_MEM_adjustment 32
#define PMCI_MAX_MSG_SIZE 0x00ffffff
#define PMCI_CMD_SCHED_INCR 256
#define PMCI_CMD_SCHED_MEM  (sizeof(pmci_cmd_sched_t)*PMCI_CMD_SCHED_INCR)

/* Module prefix to use when invoking the logging facility */
#define _PMCI_PREFIX "pmci"

/* Macro that specifies the biggest memory dump we are willing to get */
#define _PMCI_MEM_dump_max 512

/* This macro defines the number of rule context bits that can be
 * defined in a digest session context entry. */
#define pmp_rule_num_in_session_context_entry         256

/* Defines a constant describing an unknown error code */
#define PMCI_UNKNOWN_ERROR_CODE (pmci_error_first_e - 1)

/* Defines the path to get to dma module parameters */
/* TODO unconfirmed name? */
#define PMCI_PARAM_DXE_SRE_TABLE_SIZE   "sre_max_index_size"
#define PMCI_PARAM_SRE_SESSION_CTX_NUM  "sre_session_ctx_num"
#define PMCI_PARAM_SRE_SESSION_CTX_SIZE "sre_context_size"
#define PMCI_PARAM_SRE_NUM_RULES        "sre_rule_num"

#define PMCI_STAT_STNIB "stats/stnib"
#define PMCI_STAT_STNIS "stats/stnis"
#define PMCI_STAT_STNTH1 "stats/stnth1"
#define PMCI_STAT_STNTH2 "stats/stnth2"
#define PMCI_STAT_STNTHV "stats/stnthv"
#define PMCI_STAT_STNTHS "stats/stnths"
#define PMCI_STAT_STNCH "stats/stnch"

#define PMCI_STAT_STNPM "stats/stnpm"
#define PMCI_STAT_STNS1M "stats/stns1m"
#define PMCI_STAT_STNPMR "stats/stnpmr"

#define PMCI_STAT_STNDSR "stats/stndsr"
#define PMCI_STAT_STNESR "stats/stnesr"
#define PMCI_STAT_STNS1R "stats/stns1r"
#define PMCI_STAT_STNOB "stats/stnob"

#define PMCI_ATTR_HW_REV_1              "rev1"
#define PMCI_ATTR_HW_REV_2              "rev2"
#define PMCI_ATTR_EOS_PTR               "end_of_sui_reaction_ptr"
#define PMCI_ATTR_KVLTS                 "kvlts"
#define PMCI_ATTR_MAX_CHAIN             "max_chain_length"
#define PMCI_ATTR_SW_DB                 "sw_db"
#define PMCI_ATTR_PATTERN_RANGE_INDEX   "pattern_range_counter_idx"
#define PMCI_ATTR_PATTERN_RANGE_MASK    "pattern_range_counter_mask"

#define default_pme_device_path "/sys/bus/of_platform/drivers/of-fsl-pme/%s"

static FILE *PMCI_PARAM_FILE(const char *n)
{
    char buf[256];

    sprintf(buf, default_pme_device_path, n);
    return fopen(buf, "r");
}

static FILE *PMCI_ATTR_FILE(const char *n, const char* mode)
{
    char buf[256];

    sprintf(buf, default_pme_device_path, n);
    return fopen(buf, mode);
}

static int _pmci_read_sysfs(const char *name, uint32_t* value)
{
    char str[64];
    FILE* file = PMCI_ATTR_FILE(name, "r");
    if(file == NULL)
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX,
            "Failed to open sysfs %s", name);
        return pmci_unavailable_driver_e;
    }
    str[0] = 0;
    fgets(str, 64, file);
    fclose(file);
    errno = 0;
    *value = strtol(str, NULL, 0);
    if(errno != 0)
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX,
            "Failed to read an integer from sysfs %s", name);
        return pmci_unavailable_driver_e;
    }
    return pmci_success_e;
}

static int _pmci_read_sysfs64(const char *name, uint64_t* value)
{
    char str[64];
    FILE* file = PMCI_ATTR_FILE(name, "r");
    if(file == NULL)
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX,
            "Failed to open sysfs %s", name);
        return pmci_unavailable_driver_e;
    }
    str[0] = 0;
    fgets(str, 64, file);
    fclose(file);
    errno = 0;
    *value = strtoll(str, NULL, 0);
    if(errno != 0)
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX,
            "Failed to read an integer from sysfs %s", name);
        return pmci_unavailable_driver_e;
    }
    return pmci_success_e;
}

static int _pmci_write_sysfs(const char *name, uint32_t value)
{
    int result;
    FILE* file = PMCI_ATTR_FILE(name, "w");
    if(file == NULL)
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX,
            "Failed to open sysfs %s", name);
        return pmci_unavailable_driver_e;
    }
    result = fprintf(file, "%"PRIu32, value);
    fclose(file);
    if(result <= 0)
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX,
            "Failed to write an unsigned integer to sysfs %s", name);
        return pmci_unavailable_driver_e;
    }
    return pmci_success_e;
}


/* Define the batch buffer parameters */
#define PMCI_BATCH_BUFFER_GLOW_DELTA (16*1024)

/**********************************************************************
 * Types
 **********************************************************************/

/* The proxy is used to relay information from write to read path */
typedef union
{
    struct
    {
        int producer;
        int consumer;
    };
    int pair[2];
} pmci_proxy_t;

/* Scheduling of commands */
typedef struct
{
    void *cmdPtr;
    int   cmdLen;
    bool  cmdHw;
    int   respLen;
} pmci_cmd_sched_t;

/* Handle information */
typedef struct
{
    uint32_t magic;
    pid_t pid;
    handle_t handle;
    uint32_t hwRevision;
    int pmd;
    int channel;
    int scan;
    pmci_proxy_t proxy;
    pmci_cmd_sched_t *sched;
    int schedSize;
    int schedNum;
    int timeout;
    uint32_t exclusive;
    uint32_t batch;

    uint8_t *batch_buffer_p;
    uint32_t batch_buffer_len;
    uint32_t batch_data_len;
    uint32_t batch_buffer_threshold;
    
    /* Cached value of various configurable attributes */
    uint32_t extensionBlockNum;
    bool     extensionBlockNumValid;
    uint32_t contextMaxNum;
    bool     contextMaxNumValid;
    uint32_t contextAreaSize;
    bool     contextAreaSizeValid;
    uint32_t maxRuleNum;
    bool     maxRuleNumValid;
} pmci_obj_t;

typedef struct
{
    pmci_error_t code;
    char *string;
} pmci_error_string_t;

/**********************************************************************
 * Private declaration
 **********************************************************************/
static int  _pmci_openRetry(const char* dev_name, int flags);

static pmci_obj_t *_pmci_get_object(handle_t pmci_handle);
static void _pmci_assign_handle(pmci_obj_t *pmci);
static void _pmci_release_handle(pmci_obj_t *pmci);
static int  _pmci_is_valid(pmci_obj_t *pmci, handle_t handle);
static void _pmci_report_error(pmci_obj_t *pmci, int errorNo, char *msg);

static int  _pmci_create_control_handle(void);
static int  _pmci_create_scan_handle(void);
static int  _pmci_create_proxy_handles(pmci_proxy_t *proxy);

static int  _pmci_destroy_control_handle(int pmd);
static int  _pmci_destroy_scan_handle(int scan);
static int  _pmci_destroy_proxy_handles(pmci_proxy_t *proxy);

static int  _pmci_writeSchedule(pmci_obj_t *pmci, void *cmds, int cmdsSize);
static pmci_error_t _pmci_writeExecute(pmci_obj_t *pmci);
static int  _pmci_write(pmci_obj_t *pmci, pmp_header_t *header, int length, int respLength);
static int  _pmci_writeReadMasquerade(pmci_obj_t *pmci, pmp_header_t *header);
#ifdef PMCI_RUNNING_ON_TARGET
static int  _pmci_readReadMasquerade(pmci_obj_t *pmci, pmp_msg_t *notif);
#endif /* PMCI_RUNNING_ON_TARGET */
static int  _pmci_reset_all_table(pmci_obj_t *pmci, pmp_header_t *header);
static int  _pmci_get_config_attr(pmci_obj_t *pmci, uint32_t attrId, uint32_t *valuePtr);
static int  _pmci_get_attribute(pmci_obj_t *pmci, pmp_header_t *header);
static int  _pmci_set_attribute(pmci_obj_t *pmci, pmp_header_t *header);
static int  _pmci_clear_context_by_rule_id(pmci_obj_t *pmci,
                                      pmp_ctx_by_rule_id_clear_request_msg_t *req);
static int  _pmci_clear_all_context(pmci_obj_t *pmci, pmp_header_t *header);
static int  _pmci_set_exclusivity(pmci_obj_t *pmci, bool exclusiveState);
static int  _pmci_scan_data(pmci_obj_t *pmci, pmp_data_scan_request_msg_t *cmd);
static int  _pmci_get_hw_revision(pmp_hw_revision_t *rev);
static int  _pmci_get_protocol_revision(pmp_protocol_revision_t *rev);
static int  _pmci_get_statistics(pmci_obj_t *pmci, pmp_statistics_attr_t *stats);
static int  _pmci_reset_statistics(pmci_obj_t *pmci);
static int  _pmci_batch_buffer_add(pmci_obj_t *pmci, void* data, uint32_t length);
static uint32_t _pmci_decode_batch_attr_cmd(void* cmd, bool* batch_cmd, uint32_t* batch_attr);

static void _pmci_dump_object(pmci_obj_t *pmci, log_log_Level_t level);
static void _pmci_dump_data(log_log_Level_t level, void *data, int length);
static void _pmci_decode_msg(log_log_Level_t level, pmp_header_t *header);
#ifdef PMCI_NEED_TO_DECODE_MULTIPLE_MESSAGES
static void _pmci_decode_all_msg(log_log_Level_t level, pmp_header_t *header,
                              int length);
#endif /* PMCI_NEED_TO_DECODE_MULTIPLE_MESSAGES */

int _pmci_max_index_get(pmci_obj_t *pmci, pmp_table_id_t tableId);
int _pmci_record_size_get(pmp_table_id_t tableId);

/**********************************************************************
 * Global variables
 **********************************************************************/

static pmci_error_string_t _pmci_error_strings[] = {
    { pmci_success_e                , "The operation completed with success" },
    { pmci_failure_e                , "The operation fail to complete" },
    { pmci_out_of_memory_e          , "Can't allocate memory" },
    { pmci_invalid_handle_e         , "Invalid PMCI handle specified" },
    { pmci_unavailable_option_e     , "The option is not implemented" },
    { pmci_unavailable_driver_e     , "The PM driver is unavailable" },
    { pmci_invalid_option_code_e    , "Invalid option code specified"},
    { pmci_invalid_option_value_e   , "Invalid option value specified" },
    { pmci_invalid_option_size_e    , "Invalid option size specified" },
    { pmci_not_yet_implemented_e    , "Operation not yet implemented" },
    { pmci_invalid_parameters_e     , "One or more parameters are invalid" },
    { pmci_invalid_attribute_id_e   , "Invalid attribute ID to get/set" },
    { pmci_invalid_attribute_val_e  , "Invalid attribute value" },
    { pmci_invalid_attribute_len_e  , "Invalid attribute length" },
    { pmci_lost_driver_e            , "Occurs when the driver locked out" },
    { pmci_unrecoverable_error_e    , "Unrecoverable error" },
    { pmci_invalid_channel_e        , "Invalid channel number specified" },
    { pmci_empty_read_e             , "Read operation return empty buffer" },
    { pmci_unsupported_hw_revision_e, "Unsupported HW revision" },
    { PMCI_UNKNOWN_ERROR_CODE       , "Unknown error code" }
};

/**********************************************************************
 * Implementation
 **********************************************************************/

pmci_error_t pmci_open(int channel, handle_t *handle)
{
    pmci_obj_t *pmci;   /* Holds the control interface data */
    int pmd;           /* PM driver handle */
    int scan;          /* Handle used for scanning data */
    pmci_proxy_t proxy; /* Handles to the proxy streams */
    pmp_hw_revision_t hwRev;  /* Hold the HW revision info */
    
    /* Not used in PME2 */
    channel = channel;

    if ( handle == NULL )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "NULL pointer");
        return pmci_invalid_parameters_e;
    }

    /* Initialize the handler pointer */
    *handle = HANDLE_NULL;

    /* Allocate memory for our object */
    pmci = (pmci_obj_t *)malloc(sizeof(pmci_obj_t));
    if ( pmci == NULL )
    {
        /* pmci_out_of_memory_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Out-of-memory for object");
        return pmci_out_of_memory_e;
    }

    /* Allocate memory for the command scheduling buffer */
    pmci->sched = (pmci_cmd_sched_t *)malloc(PMCI_CMD_SCHED_MEM);
    if ( pmci->sched == NULL )
    {
        /* pmci_out_of_memory_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Out-of-memory for buffer");
        free(pmci);
        return pmci_out_of_memory_e;
    }
    pmci->schedSize = PMCI_CMD_SCHED_INCR;
    pmci->schedNum = 0;

    /* Create the PM driver handle */
    pmd = _pmci_create_control_handle();
    if ( pmd < 0 )
    {
        /* pmci_unavailable_driver_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Driver unavailable");
        free(pmci->sched);
        free(pmci);
        return pmci_unavailable_driver_e;
    }

    /* Create the handle used for scanning data */
    scan = _pmci_create_scan_handle();
    if ( scan < 0 )
    {
        /* pmci_unavailable_driver_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Scan unavailable");
        _pmci_destroy_control_handle(pmd);
        free(pmci->sched);
        free(pmci);
        return pmci_unavailable_driver_e;
    }

    /* Create the proxy handles */
    if ( _pmci_create_proxy_handles(&proxy) < 0 )
    {
        /* pmci_unavailable_driver_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Proxy unavailable");
        _pmci_destroy_scan_handle(scan);
        _pmci_destroy_control_handle(pmd);
        free(pmci->sched);
        free(pmci);
        return pmci_out_of_memory_e;
    }

    /* Get HW revision */
    if( _pmci_get_hw_revision(&hwRev) != pmci_success_e )
    {
        /* pmci_unavailable_driver_e */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Unable to get HW revision");
        _pmci_destroy_scan_handle(scan);
        _pmci_destroy_control_handle(pmd);
        free(pmci->sched);
        free(pmci);
        return pmci_unavailable_driver_e;
    }
    
    /* Fill in the handle */
    if (hwRev.coreMajor == PM_HW_REVISION_V2_0_MAJOR &&
        hwRev.coreMinor == PM_HW_REVISION_V2_0_MINOR) {
      pmci->hwRevision = PM_PME_VERSION_2_0;
    }
    else {
      LOG_STRING(LOG_TEST, _PMCI_PREFIX,
        "Unsupported to HW revision: Major=0x%02x, Minor=0x%02x\n",
        hwRev.coreMajor, hwRev.coreMinor);
      return pmci_unsupported_hw_revision_e;
    }

    pmci->magic = PMCI_MAGIC_VALUE;
    pmci->pid = getpid();
    _pmci_assign_handle(pmci);
    pmci->pmd = pmd;
    pmci->channel = channel;
    pmci->scan = scan;
    pmci->proxy = proxy;
    pmci->timeout = PMCI_INFINITE;
    pmci->exclusive = 0;
    pmci->batch = 0;
    pmci->batch_buffer_p = NULL;
    pmci->batch_buffer_len = 0;
    pmci->batch_data_len = 0;
    pmci->batch_buffer_threshold = PMCI_BATCH_BUFFER_THRESHOLD_DEFAULT;
    /* Clean up the cache */
    pmci->extensionBlockNumValid = 0;
    pmci->contextMaxNumValid = 0;
    pmci->contextAreaSizeValid = 0;
    pmci->maxRuleNumValid = 0;

    /* Dump the object */
    LOG_STRING(LOG_INFO, _PMCI_PREFIX,
               "pmci_handle  = %"PRI_HANDLE, (handle_t)pmci);
    _pmci_dump_object(pmci, LOG_TEST);

    /* Succeeded */
    *handle = (handle_t)pmci;
    return pmci_success_e;
}

pmci_error_t pmci_set_option(handle_t pmci_handle, pmci_option_id_t optionId,
                             void *option, int optionSize)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    LOG_STRING(LOG_INFO, _PMCI_PREFIX,
               "pmci_handle=%"PRI_HANDLE", optionId=%d, option=%p, "
               "optionSize=%d", pmci_handle, optionId, option, optionSize);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmci_handle);
        return pmci_invalid_handle_e;
    }
    
    /* Sanitize the optionId */
    if ( optionId >= pmci_num_options_e )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Invalid option code");
        return pmci_invalid_option_code_e;
    }

    /* Process the option */
    if ( optionId == pmci_option_timeout_e )
    {
        if ( option == NULL || *(int *)option < 0 )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Bad option value");
            return pmci_invalid_parameters_e;
        }

        /* Setting the timeout value for pmci_read() */
        if ( optionSize != sizeof(int) )
        {
            return pmci_invalid_option_size_e;
        }
        
        pmci->timeout = *(int *)option;
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Timeout set to %d", pmci->timeout);
        return pmci_success_e;
    }
    else if ( optionId == pmci_option_batch_buffer_threshold_e )
    {
        if ( option == NULL || *(uint32_t *)option < PMCI_BATCH_BUFFER_THRESHOLD_MIN )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Bad option value");
            return pmci_invalid_parameters_e;
        }
        
        /* Setting the batch buffer threshold value */
        if ( optionSize != sizeof(uint32_t) )
        {
            return pmci_invalid_option_size_e;
        }
        pmci->batch_buffer_threshold = *(uint32_t *) option;
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch buffer threshold set to %"PRIu32,
                   pmci->batch_buffer_threshold);
        return pmci_success_e;
    }

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Unavailable option code");
    return pmci_unavailable_option_e;
}

pmci_error_t pmci_get_option(handle_t pmci_handle, pmci_option_id_t optionId,
                          void *option, int *optionSize)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    LOG_STRING(LOG_INFO, _PMCI_PREFIX,
               "pmci_handle=%"PRI_HANDLE", optionId=%d", pmci_handle, optionId);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }

    /* Sanitize the optionId */
    if ( optionId >= pmci_num_options_e )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Invalid option code");
        return pmci_invalid_option_code_e;
    }

    /* Process the option */
    if ( optionId == pmci_option_timeout_e )
    {
        if ( option == NULL || optionSize == NULL )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "NULL option pointer");
            return pmci_invalid_parameters_e;
        }
        /* Getting the timeout value associated to pmci_read() */
        if ( *optionSize < (int)sizeof(int) )
        {
            return pmci_invalid_option_size_e;
        }
        
        *(int *)option = pmci->timeout;
        *optionSize = sizeof(int);
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "timeout=%d", pmci->timeout);
        return pmci_success_e;
    }
    else if ( optionId == pmci_option_batch_buffer_threshold_e )
    {
        if ( option == NULL || optionSize == NULL )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "NULL option pointer");
            return pmci_invalid_parameters_e;
        }
        /* Getting the batch buffer threshold. */
        if ( *optionSize < (int)sizeof(uint32_t) )
        {
            return pmci_invalid_option_size_e;
        }
        *(uint32_t *) option = pmci->batch_buffer_threshold;
        *optionSize = sizeof(uint32_t);
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch buffer threshold set to %"PRIu32,
                   pmci->batch_buffer_threshold);
        return pmci_success_e;
    }

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Unavailable option code");
    return pmci_unavailable_option_e;
}

pmci_error_t pmci_close(handle_t pmci_handle)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);
    pmci_error_t result = pmci_success_e;

    LOG_STRING(LOG_INFO, _PMCI_PREFIX, "pmci_handle=%"PRI_HANDLE, pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }

    /* Close the PM driver handle */
    if ( _pmci_destroy_control_handle(pmci->pmd) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't destroy pmd");
        result = pmci_failure_e;
    }

    /* Close the scan handle */
    if ( _pmci_destroy_scan_handle(pmci->scan) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't destroy scan");
        result = pmci_failure_e;
    }

    /* Close the proxy handles */
    if ( _pmci_destroy_proxy_handles(&pmci->proxy) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't destroy proxy");
        result = pmci_failure_e;
    }

    /* Clear out the handle assignment */
    _pmci_release_handle(pmci);

    /* Release the PMCI scheduling memory */
    free(pmci->sched);

    /* Release the PMCI memory */
    memset(pmci, 0, sizeof(pmci_obj_t));
    free(pmci);

    return result;
}

pmci_error_t pmci_write(handle_t pmci_handle, void *cmds, int cmdsSize)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);
    pmci_error_t result = pmci_success_e;
    void *start = cmds;
    void *end = cmds + cmdsSize;
    void *batch_start = NULL;
    void *batch_end = NULL;
    void *schedCmds = NULL;
    uint32_t schedCmdsSize = 0, length = 0;
    pmp_header_t *header = NULL;
    bool batch_cmd = false;
    bool clean_batch = false;
    uint32_t batch_attr;
    
    LOG_STRING(LOG_INFO, _PMCI_PREFIX,
               "pmci_handle=%"PRI_HANDLE", cmds=%p, cmdsSize=%d",
               pmci_handle, cmds, cmdsSize);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }
    
    if ( cmds == NULL || cmdsSize <= 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Bad cmds");
        return pmci_invalid_parameters_e;
    }
    
    /* Scan for batch start & end commands.  Need to handle these PMP command
       sequence that may arrive inside one buffer:
        <cmd><cmd>...
        <batch_start>
        <batch_end>
        <batch_start><cmd><cmd>...
        <cmd><cmd>...<batch_end>
        <cmd><cmd>...<batch_end><cmd><cmd>...
        <cmd><cmd>...<batch_start>
        <cmd><cmd>...<batch_start><cmd><cmd>...
        <cmd><cmd>...<batch_start><cmd><cmd>...<batch_end><cmd><cmd>...
        <cmd><cmd>...<batch_end><cmd><cmd>...<batch_start><cmd><cmd>...
    */
    while ( start < end )
    {
        schedCmds = NULL;
        
        /* Loop through all commands for a batch start or batch end command. */
        batch_start = start;
        while ( batch_start < end )
        {
            length = _pmci_decode_batch_attr_cmd(batch_start, &batch_cmd, &batch_attr);
            if ( batch_cmd ) /* This cmd is a batch start or batch_end */
            {
                if ( batch_attr ) /* Batch start found. */
                {
                    if ( pmci->batch ) /* already have a batch start before! */
                    {
                        /* Ignores the extra batch start.  Treat it like an NOP. */
                        batch_start += length;
                        continue; /* Resume batch start or end search loop */
                    }
                    pmci->batch = batch_attr;
                    /* Search for a batch end in this cmds.  If one is found
                       then we don't need to batch the commands in between. */
                    batch_end = batch_start + length;
                    while ( batch_end < end )
                    {
                        length = _pmci_decode_batch_attr_cmd(batch_end, &batch_cmd, &batch_attr);
                        if ( batch_cmd )
                        {
                            if ( !batch_attr )
                            {
                                /* Found a batch end */
                                batch_end += length;
                                pmci->batch = batch_attr;
                                break; /* Leave batch end scan loop. */
                            }
                            /* Else ignore any other batch start. */
                        }
                        batch_end += length;
                    } /* batch end after batch start scan loop */
                    if ( pmci->batch ) /* Batch end not found in the same cmds */
                    {
                        /* <batch_start>
                           <batch_start><cmd><cmd>...
                           <cmd><cmd>...<batch_start><cmd><cmd>...
                           Need to buffer the the commands after batch start. */
                        header = (pmp_header_t *) batch_start;
                        length = ntohl(header->msgLength);

                        if ( (uint32_t)(end - (batch_start+length)) < pmci->batch_buffer_threshold )
                        {
                            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch start.  Buffering %"PRIu32" bytes",
                                       (uint32_t) (end - (batch_start+length)));
                            result = _pmci_batch_buffer_add(pmci, batch_start+length,
                                                            end - (batch_start+length));
                            if ( result != pmci_success_e ) return result;
                        }
                        else
                        {
                            /* This cmds is too big.  Don't do batch and exec all cmds instead. */
                            batch_start = end;
                        }
                        if ( start != batch_start )
                        {
                            /* <cmd><cmd>...<batch_start><cmd><cmd>...
                               Need to exec those before <batch_start> first.
                            OR
                               This cmds is too big to buffer in batch buffer.  */
                            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Pre batch start.  Sending %"PRIu32" bytes",
                                       (uint32_t) (batch_start - start));
                            schedCmds = start;
                            schedCmdsSize = batch_start - start;
                        }
                        batch_start = end;
                        start = end;
                        break; /* Leave batch cmd search loop. */
                    }
                    else /* Batch end found after batch start in the same cmds.
                            <cmd><cmd>...<batch_start><cmd><cmd>...<batch_end><cmd><cmd>...
                            Ignore this pair of batch start+end.
                            Start looking for the next batch start. */
                    {
                        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch start+end pair.  Ignored.");
                        batch_start = batch_end;
                        continue; /* Resume batch cmd search loop. */
                    }
                }
                else /* Batch end found */
                {
                    if ( pmci->batch )
                    {
                        pmci->batch = batch_attr;
                        batch_end = batch_start;
                        /* <batch_end>
                           <batch_end><cmd><cmd>...
                           <cmd><cmd>...<batch_end>
                           <cmd><cmd>...<batch_end><cmd><cmd>...
                           Put everything before batch end into batch buffer.  */
                        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch end.  Buffering %"PRIu32" bytes",
                                   (uint32_t) (batch_end - start));
                        result = _pmci_batch_buffer_add(pmci, start, batch_end-start);
                        if ( result != pmci_success_e ) return result;

                        /* Exec the batch buffer */
                        schedCmds = pmci->batch_buffer_p;
                        schedCmdsSize = pmci->batch_data_len;
                        clean_batch = true;
                        /* After exec, keep scanning for possible batch start.
                           So move start to after the batch end. */
                        start = batch_end + length;
                        break; /* Leave batch cmd search loop. */
                    }
                    /* Else if no batch start before, Treat the command as an NOP. */
                }
            } /* batch attribute check */

            /* The command wasn't a batch start or batch end.  Move to next command. */
            batch_start += length;
        } /* while ( batch_start < end ); */
        
        if ( schedCmds == NULL && batch_start >= end )
        {
            /* No batch start or end was found. */
            if ( pmci->batch ) /* In batch mode */
            {
                /* <cmds><cmds>...
                   There was a batch start in previous cmds.  So we should buffer
                   this cmds. */
                result = _pmci_batch_buffer_add(pmci, start, end-start);
                if ( result != pmci_success_e ) return result;
                
                if ( pmci->batch_data_len > pmci->batch_buffer_threshold )
                {
                    /* Batch buffer is getting too big.  Send everything in batch buffer
                       now without waiting for batch end. */
                    schedCmds = pmci->batch_buffer_p;
                    schedCmdsSize = pmci->batch_data_len;
                    clean_batch = true;
                    start = end;
                }
                else
                {
                    /* All cmds are stored in batch buffer.  We are done */
                    break;
                }
            }
            else
            {
                /* <cmds><cmds>...
                   No batch start or end was found.
                OR
                   <batch_end><cmd><cmd>...
                   <cmd><cmd>...<batch_end><cmd><cmd>...
                   And all the data before <batch_end> has been taken care of.
                   Exec the remaining cmds. */
                schedCmds = start;
                schedCmdsSize = end - start;
                start = end;
            }
        }

        /* If this happens, it is single batch end */
        if ( schedCmds == NULL || schedCmdsSize == 0) break;

        /* Schedule the commands (we do this to minimize exclusive duration) */
        if ( _pmci_writeSchedule(pmci, schedCmds, schedCmdsSize) < 0 )
        {
            LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Failed to schedule the writes");
            return pmci_failure_e;
        }

        /* Apply the commands to hardware */
        result = _pmci_writeExecute(pmci);
        if ( result != pmci_success_e )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Failed to execute the writes");
        }

        if ( clean_batch )
        {
            /* What just executed came from the batch buffer.  Now we
               have to clean it up. */
            clean_batch = false;
            if ( pmci->batch_buffer_p && pmci->batch_buffer_len > PMCI_BATCH_BUFFER_THRESHOLD_MIN)
            {
                free(pmci->batch_buffer_p);
                pmci->batch_buffer_p = NULL;
                pmci->batch_buffer_len = 0;
            }
            pmci->batch_data_len = 0;
        }
    } /* While ( start < end ) */

    return result;
}

pmci_error_t pmci_read(handle_t pmci_handle, pmp_msg_t *notif)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);
    struct timeval delay;
    struct timeval *delayPtr = NULL;
    fd_set readSet;
    int length;
    int n;

    LOG_STRING(LOG_INFO, _PMCI_PREFIX,
               "pmci_handle=%"PRI_HANDLE", notif=%p",
               pmci_handle, notif);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }
    
    if ( notif == NULL)
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "NULL pointer");
        return pmci_invalid_parameters_e;
    }

    /* Compute timeout value */
    if ( pmci->timeout != PMCI_INFINITE )
    {
        delayPtr = &delay;
        memset(&delay, 0, sizeof(delay));
        delay.tv_sec = pmci->timeout;
    }
    
    /* Compute the file descriptor set for both read and write */
    FD_ZERO(&readSet);
    FD_SET(pmci->proxy.consumer, &readSet);
    n = pmci->proxy.consumer + 1;
    
    /* Block for timeout seconds */
    if ( select(n, &readSet, NULL, NULL, delayPtr) < 0 )
    {
        return pmci_failure_e;
    }
    
    /* Check if there are some data available on our proxy */
    if ( FD_ISSET(pmci->proxy.consumer, &readSet) )
    {
        /* Read the data from the proxy consumer handle */
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Reading from proxy");

        /* Check to see if we need to interpret the data */
        length = read(pmci->proxy.consumer, notif, sizeof(pmp_header_t));
        if ( length != (sizeof(pmp_header_t)) )
        {
            if ( errno == ENODEV ) return pmci_lost_driver_e;
            return pmci_failure_e;
        }
        if ( notif->header.msgType == pmp_table_read_request_msg_type_e )
        {
            /* Need four more bytes to figure out the rest */
            length = read(pmci->proxy.consumer, notif->header.data,
                          sizeof(pmp_table_id_field_t));
            if ( length != sizeof(sizeof(pmp_table_id_field_t)) )
            {
                if ( errno == ENODEV ) return pmci_lost_driver_e;
                return pmci_failure_e;
            }
            if ( (notif->requestMsg.tableReadRequestMsg.tableId ==
                  pmp_user_defined_group_table_id_e) ||
                 (notif->requestMsg.tableReadRequestMsg.tableId ==
                  pmp_equivalence_table_id_e) )
            {
                /* In orther to keep these table consistent with the rest,
                 * we remap the read reply into an homogenous form.
                 */
                length = _pmci_readReadMasquerade(pmci_handle, notif);
                if ( length < 0 )
                {
                    if ( errno == ENODEV ) return pmci_lost_driver_e;
                    return pmci_failure_e;
                }
            }
            else
            {
                /* Normal command */
                length = read(pmci->proxy.consumer,
                              &notif->requestMsg.tableReadRequestMsg.index,
                              notif->header.msgLength - sizeof(pmp_header_t) -
                              sizeof(pmp_table_id_field_t));
                if ( length < 0 )
                {
                    if ( errno == ENODEV ) return pmci_lost_driver_e;
                    return pmci_failure_e;
                }
                length += (sizeof(pmp_header_t) + sizeof(pmp_table_id_field_t));
            }
        }
        else if ( notif->header.msgLength > (uint32_t)length )
        {
            /* Normal command */
            length = read(pmci->proxy.consumer,
                          notif->header.data,
                          notif->header.msgLength - length);
            if ( length < 0 )
            {
                if ( errno == ENODEV ) return pmci_lost_driver_e;
                return pmci_failure_e;
            }
            length += sizeof(pmp_header_t);
        }
    }
    else
    {
        /* Nothing to be retrieved */
        return pmci_empty_read_e;
    }

    /* Toggle the reply bit for each message */
    if ( notif->header.msgType != pmp_error_indication_msg_type_e )
    {
        notif->header.msgType |= PMP_REPLY_MSG_CLASS_FLAG;
    }

    /* Dump the message in the logs */
    _pmci_decode_msg(LOG_TEST, &notif->header);

    return pmci_success_e;
}

pmci_error_t pmci_flush(handle_t pmci_handle)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    LOG_STRING(LOG_INFO, _PMCI_PREFIX, "pmci_handle=%"PRI_HANDLE, pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return pmci_invalid_handle_e;
    }

    /* Nothing to do with PME2 driver. */
    
    return pmci_success_e;
}

const char *pmci_error_string ( pmci_error_t code )
{
    int codeIndex;

    /* Validate the error code */
    if ( (code < pmci_error_first_e) ||
         (code > pmci_error_last_e) )
    {
        return _pmci_error_strings[abs(PMCI_UNKNOWN_ERROR_CODE)].string;
    }

    /* Here we could either walk into the table or use the absolute value of
     * the error code as an index.  For now, we just take the absolute value.
     */
    codeIndex = abs(code);

    /* Ensure the chosen index matches with the error code */
    if ( code != _pmci_error_strings[codeIndex].code )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Error code mismatch (%d/%d)",
                   code, _pmci_error_strings[codeIndex].code);
        return _pmci_error_strings[abs(pmci_unrecoverable_error_e)].string;
    }

    /* Return the corresponding error code */
    return _pmci_error_strings[codeIndex].string;
}

void PMCI_FD_SET(handle_t pmci_handle, fd_set *fdset)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return;
    }

    /* Set all PMCI file descriptor to the specified file descriptor mask */
    FD_SET(pmci->proxy.consumer, fdset);
}

void PMCI_FD_CLR(handle_t pmci_handle, fd_set *fdset)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return;
    }

    /* Clear all PMCI file descriptor to the specified file descriptor mask */
    FD_CLR(pmci->proxy.consumer, fdset);
}

int PMCI_FD_ISSET(handle_t pmci_handle, fd_set *fdset)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return 0;
    }

    /* Test the specified file descriptor set mask against PMCI descriptors */
    return ( FD_ISSET(pmci->proxy.consumer, fdset) );
}

int PMCI_FD_GETN(handle_t pmci_handle)
{
    pmci_obj_t *pmci = _pmci_get_object(pmci_handle);

    /* Sanitize the PMCI handle */
    if ( !_pmci_is_valid(pmci, pmci_handle) )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Handle %p is invalid", pmci);
        return 0;
    }

    /* Provide the highest file descriptor used by PMCI */
    return pmci->proxy.consumer;
}

/**********************************************************************
 * Private implementation
 **********************************************************************/

static int _pmci_openRetry(const char* dev_name, int flags)
{
    /* There can be a small delay between the insmod command returns and
       the /dev/ decives become available.  To make auto boot script
       easier to make we add a retry delay for opening devices. */
    int fd = -1;
    int retry = 0;
    do {
        fd = open(dev_name, flags);
        if ( fd >= 0 ) break;
        sleep(1);
    } while ( retry++ < 4 );
    return fd;
}

static pmci_obj_t *_pmci_get_object(handle_t pmci_handle)
{
    /* If need to get fancy for the handle, I put handle to obj mapping here */
    return (pmci_obj_t *)pmci_handle;
}

static void _pmci_assign_handle(pmci_obj_t *pmci)
{
    /* If need to get fancy for the handle, I put handle assigment here */
    pmci->handle = (handle_t)pmci;
}

static void _pmci_release_handle(pmci_obj_t *pmci)
{
    /* If need to get fancy for the handle, I put handle releasing here */
    pmci->handle = 0;
}

static int _pmci_is_valid(pmci_obj_t *pmci, handle_t pmci_handle)
{
    return ( (pmci != NULL) &&
             (pmci->magic == PMCI_MAGIC_VALUE) &&
#ifdef PMCI_PID_AND_THREAD_WORKING_PROPERLY
             ( (pmci->pid == getpid()) || (pmci->pid == getppid()) ) &&
#endif /* PMCI_PID_AND_THREAD_WORKING_PROPERLY */
             (pmci->handle == pmci_handle) );
}

static void _pmci_report_error(pmci_obj_t *pmci, int errorNo, char *msg)
{
    pmp_error_indication_msg_t notif;

    if ( errno != ENODEV )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Error=%d, Msg=%s", errorNo,
                   msg);
        
        /* Build the error notification */
        notif.header.protocolVersion = PMP_CURRENT_VERSION;
        notif.header.msgType         = pmp_error_indication_msg_type_e;
        notif.header.reserved        = 0;
        notif.header.msgLength       = htonl(sizeof(notif));
        notif.header.msgId           = 0;
        notif.errorNo                = htonl((uint32_t)errorNo);
        
        /* Best effort to propagate the error back to application */
        if ( write(pmci->proxy.producer, &notif, sizeof(notif)) < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't notify error "
                       "indication");
        }
    }
}

static int _pmci_create_control_handle(void)
{
    int pmd;

#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */

    /* Grab a handle to the PM driver */
    pmd = _pmci_openRetry(PME_DEV_DB_PATH, O_RDWR);
    if ( pmd < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't open driver");
        return -1;
    }
    return pmd;
}

static int _pmci_create_scan_handle(void)
{
    int scan;

#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */
    
    /* Grab a handle to the scanner driver */
    scan = _pmci_openRetry(PME_DEV_SCAN_PATH, O_RDWR);
    if ( scan < 0 )
    {
        return -1;
    }
    return scan;
}


static int _pmci_create_proxy_handles(pmci_proxy_t *proxy)
{
    /* Create a UNIX socket pair */
    return socketpair(AF_UNIX, SOCK_STREAM, 0, proxy->pair);
}

static int _pmci_destroy_control_handle(int pmd)
{
#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */
    return close(pmd);
}

static int _pmci_destroy_scan_handle(int scan)
{
#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */
    return close(scan);
}

static int _pmci_destroy_proxy_handles(pmci_proxy_t *proxy)
{
    int result;

    /* Destroy each socket of the pair */
    result = close(proxy->producer);
    result |= close(proxy->consumer);

    return result;
}

static int  _pmci_writeSchedule(pmci_obj_t *pmci, void *cmds, int cmdsSize)
{
    void *start = cmds;
    void *end = &(((uint8_t *)cmds)[cmdsSize]);
    void *hwStart = NULL;
    pmp_attribute_set_request_msg_t *hdr1;
    pmp_attribute_set_request_msg_t *hdr2;
    pmp_header_t *header;
    int length;

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Preparing commands");

    /* Walk through every single command */
    pmci->schedNum = 0;
    while ( start < end )
    {
        header = (pmp_header_t *)start;
        length = ntohl(header->msgLength);
        /* That's a good time to decode the message */
        _pmci_decode_msg(LOG_TEST, header);

        /* Decouple hardware from software commands */
        if ( (header->msgType == pmp_table_write_request_msg_type_e) ||
             (header->msgType == pmp_ctx_by_session_id_clear_request_msg_type_e) ||
             ( (header->msgType == pmp_table_read_request_msg_type_e) &&
               (header->data[3] != pmp_user_defined_group_table_id_e) &&
               (header->data[3] != pmp_equivalence_table_id_e) ) )
        {
            if ( hwStart == NULL )
            {
                /* First hardware command */
                pmci->sched[pmci->schedNum].cmdPtr = start;
                pmci->sched[pmci->schedNum].cmdLen = length;
                pmci->sched[pmci->schedNum].cmdHw  = true;
                pmci->sched[pmci->schedNum].respLen = 0;
                pmci->schedNum++;
                hwStart = start;
            }
            else
            {
                /* Next hardware command */
                pmci->sched[pmci->schedNum-1].cmdLen += length;
            }
            /* Calcluate the HW response size */
            if(header->msgType == pmp_table_read_request_msg_type_e) {
                pmci->sched[pmci->schedNum-1].respLen += length +
                    _pmci_record_size_get(header->data[3]);
            }
        }
        else
        {
            /* Software command */
            pmci->sched[pmci->schedNum].cmdPtr = start;
            pmci->sched[pmci->schedNum].cmdLen = length;
            pmci->sched[pmci->schedNum].cmdHw  = false;
            pmci->sched[pmci->schedNum].respLen = 0;
            pmci->schedNum++;
            hwStart = NULL;
        }

        /* Increment the start of command */
        start += length;
        
        /* Ensure we've got sufficient space for the command blocks */
        if ( pmci->schedNum >= pmci->schedSize )
        {
            pmci->schedSize += PMCI_CMD_SCHED_INCR;
            pmci->sched = realloc(pmci->sched,
                                  pmci->schedSize * sizeof(pmci_cmd_sched_t));
            if ( pmci->sched == NULL )
            {
                LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Out-of-memory");
                return -1;
            }
        }
    }

    /* If we have atomic start, HW chunk and atomic end, we can skip the
     * atomic start/end message */
    if ( (pmci->schedNum == 3) && (pmci->sched[1].cmdHw == true) )
    {
        hdr1 = (pmp_attribute_set_request_msg_t *)pmci->sched[0].cmdPtr;
        hdr2 = (pmp_attribute_set_request_msg_t *)pmci->sched[2].cmdPtr;
        if ( (hdr1->header.msgType == pmp_attribute_set_request_msg_type_e) &&
             (hdr1->attributeId == pmp_atomic_attr_id_e) &&
             (hdr1->attributeValue.atomicAttr) &&
             (hdr2->header.msgType == pmp_attribute_set_request_msg_type_e) &&
             (hdr2->attributeId == pmp_atomic_attr_id_e) &&
             (hdr2->attributeValue.atomicAttr == 0) )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX,
                       "Optimize by zapping atomic operations");
            pmci->schedNum = 1;
            pmci->sched[0] = pmci->sched[1];
        }
    }

    return 0;
}

static pmci_error_t _pmci_writeExecute(pmci_obj_t *pmci)
{
    int result;
    int sindex;
    pmp_header_t *header;
    int length;
    int respLength;

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Executing commands");

    /* Walking through command to execute */
    for ( sindex=0; sindex<pmci->schedNum; sindex++ )
    {
        header = (pmp_header_t *)pmci->sched[sindex].cmdPtr;
        length = pmci->sched[sindex].cmdLen;
        respLength = pmci->sched[sindex].respLen;
        
#ifndef PMCI_RUNNING_ON_TARGET
        if ( true )
        {
            /* In this case, we don't have access to the PM driver.  Therefore,
             * we are echoing everything back to the pmci_read(...) path via
             * the proxy channel.
             */
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "No target, echoing it back");
            if ( write(pmci->proxy.producer, header, length) < 0 )
            {
                return pmci_failure_e;
            }
        }
        else
#endif /* PMCI_RUNNING_ON_TARGET */
        if ( pmci->sched[sindex].cmdHw )
        {
            /* Executing one or more hardware commands */
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Hardware (%d, %d)", length, respLength);
            result = _pmci_write(pmci, header, length, respLength);
            if ( result < 0 )
            {
                _pmci_report_error(pmci, result, "Hardware command failed");
                return result;
            }
        }
        else
        {
            /* Executing one software command */
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Software (%d)", length);

            /* Take the performance hit and implement these in software */
            if ( header->msgType == pmp_table_read_request_msg_type_e )
            {
                if ( (header->data[3] != pmp_user_defined_group_table_id_e) &&
                     (header->data[3] != pmp_equivalence_table_id_e) )
                {
                    LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Should not have "
                               "reach this code.  Read in table %d is "
                               "handled by hardware", header->data[3]);
                    _pmci_report_error(pmci, pmci_failure_e, 
                                       "Bad read command");
                    return pmci_failure_e;
                }

                result = _pmci_writeReadMasquerade(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Read masquerade failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_table_reset_request_msg_type_e )
            {
                result = _pmci_reset_all_table(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Reset all table failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_attribute_get_request_msg_type_e )
            {
                result = _pmci_get_attribute(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Get attribute failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_attribute_set_request_msg_type_e )
            {
                result = _pmci_set_attribute(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Set attribute failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_ctx_by_rule_id_clear_request_msg_type_e )
            {
                result = _pmci_clear_context_by_rule_id(
                  pmci, (pmp_ctx_by_rule_id_clear_request_msg_t *)header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Clear by ruleId failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_ctx_all_clear_request_msg_type_e )
            {
                result = _pmci_clear_all_context(pmci, header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Clear all context failed");
                    return result;
                }
            }
            else if ( header->msgType == pmp_data_scan_msg_type_e )
            {
                result = _pmci_scan_data(
                  pmci, (pmp_data_scan_request_msg_t *)header);
                if ( result < 0 )
                {
                    _pmci_report_error(pmci, result, "Scan data failed");
                    return result;
                }
            }
            else
            {
                /* This is an invalid message, drop that one */
                _pmci_report_error(pmci, pmci_failure_e, "Invalid command");
                return pmci_failure_e;
            }
        }
    }

    return 0;
}

static int _pmci_write(pmci_obj_t *pmci, pmp_header_t *header, int length, int respLength)
{
    uint8_t* respBuffer = NULL;
    struct pme_db db_op;
    int rc;
    
    if(respLength > 0)
    {
        respBuffer = calloc(1, respLength);
        if(respBuffer == NULL)
        {
            LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Failed to allocate %d bytes", respLength);
            return pmci_out_of_memory_e;
        }
    }
    /* The hardware can handle these commands as is */
    db_op.input.data = header;
    db_op.input.size = length;
    db_op.output.data = respBuffer;
    db_op.output.size = respLength;
    
    rc = ioctl(pmci->pmd, PMEIO_PMTCC, &db_op);
    if ( rc < 0 )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "ioctl PMEIO_PMTCC rc=%d, errono=%d",
                rc, errno);
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return pmci_failure_e;
    }

    /* Check for any error code from PME */
    if ( db_op.flags & (PME_DB_RESULT_UNRELIABLE | PME_DB_RESULT_TRUNCATED) )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Unexpected flag from PME: 0x%"PRIx8,
                db_op.flags);
        return pmci_failure_e;
    }
    if ( db_op.status != pme_status_ok )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Unexpected status from PME: 0x%"PRIx32,
                db_op.status);
        return pmci_failure_e;
    }

    if ( db_op.output.size != (unsigned int) respLength )
    {
        /* PMCI should be able to accurately predict the response length */
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX,
                "Mismatch response length: %"PRId32" != %"PRId32,
                db_op.output.size, respLength);
    }

    if ( db_op.output.size > 0 )
    {
        /* Copy PME response into proxy */
        write(pmci->proxy.producer, db_op.output.data, db_op.output.size);
    }

    if(respBuffer != NULL)
    {
        free(respBuffer);
    }
    return pmci_success_e;
}


/* Single read reply size for pmp_user_defined_group_table_id_e and
   pmp_equivalence_table_id_e. */
#define _PMCI_READ_REPLY_SIZE \
  (sizeof(pmp_header_t) + sizeof(pmp_table_id_t) + sizeof(pmp_index_t) + \
   sizeof(uint32_t))

static int  _pmci_writeReadMasquerade(pmci_obj_t *pmci, pmp_header_t *header)
{
    pmp_table_read_request_msg_t  *origRequest;
    pmp_table_read_request_msg_t  *microRequest;
    int                         macroLength;
    uint8_t                    *macroBuffer;
    int                         respLength;
    int                         status;
    int                         loop;

    /* This is the scenario where reading into a table is using a different
     * approach than writting.  The tables pmp_user_defined_group_table_id_e and
     * pmp_equivalence_table_id_e have asymetric reads and writes.  A write to
     * those table takes only one record containing the whole table whereas
     * the read only reads one byte at a time.  In order to hide this hardware
     * inconsistency, reading into these tables are abstracted by the PMCI
     * layer.  This way, we are exposing a consistent read and write to the
     * applications.  The abstraction takes the form of handling the read
     * request for those two tables in software.
     */

    /* Allocate memory for the proxy read */
    macroLength =
      sizeof(pmp_table_read_request_msg_t) * PMP_EQUIVALENCE_ENTRY_SIZE;
    macroBuffer = malloc(macroLength);
    if ( macroBuffer == NULL )
    {
        return pmci_out_of_memory_e;
    }
    respLength = _PMCI_READ_REPLY_SIZE * PMP_EQUIVALENCE_ENTRY_SIZE;

    /* Fill in the proxy read requests */
    origRequest  = (pmp_table_read_request_msg_t *)header;
    microRequest = (pmp_table_read_request_msg_t *)macroBuffer;
    microRequest->header.protocolVersion = origRequest->header.protocolVersion;
    microRequest->header.msgType         = origRequest->header.msgType;
    microRequest->header.reserved        = origRequest->header.reserved;
    microRequest->header.msgLength       = sizeof(pmp_table_read_request_msg_t);
    microRequest->header.msgId           = origRequest->header.msgId;
    microRequest->tableId                = origRequest->tableId;
    microRequest->index                  = PMP_EQUIVALENCE_ENTRY_SIZE - 1;
    microRequest++;
    for (loop=PMP_EQUIVALENCE_ENTRY_SIZE - 2; loop>=0; loop--)
    {
        memcpy(microRequest, &microRequest[-1],
               sizeof(pmp_table_read_request_msg_t));
        microRequest->index = loop;
        microRequest++;
    }

    /* Send the macro read request as one command */
    status = _pmci_write(pmci, (pmp_header_t *)macroBuffer, macroLength, respLength);

    /* Release the temporary memory */
    free(macroBuffer);
    return status;
}

#ifdef PMCI_RUNNING_ON_TARGET
static int _pmci_readReadMasquerade(pmci_obj_t *pmci, pmp_msg_t *notif)
{
    pmp_table_read_reply_msg_t *reply;
    uint8_t *ptr;
    int length;
    int loop;

    /* This is the case that notifs alreay holds the first 20 bytes of the
     * first read table reply.  What's left is to complete the reading of
     * that first reply, read the other replies and build the desired
     * resulting reply.
     */

    /* Complete the first reply */
    ptr = (uint8_t *)notif;
    ptr += (PMP_EQUIVALENCE_ENTRY_SIZE - 1);
    reply = (pmp_table_read_reply_msg_t *)ptr;
    length = read(pmci->proxy.consumer, &reply->indexedEntry.index, 2*sizeof(uint32_t));
    if ( length != (2*sizeof(uint32_t)) )
    {
        return pmci_failure_e;
    }

    /* Read the other replies.  Warning, this function makes a wrong
     * assumption that there are three spare bytes at the end of the
     * notifs buffer.  If the buffer is of type pmp_msg_t, there are no
     * problem because that structure is of a big enough size to
     * accomodate this little trick (the use of three extra byte at
     * the end of the read reply structure).  However, if the function
     * allows to specify precisely PMP_EQUIVALENCE_TABLE_READ_REPLY_MSG_SIZE
     * or PMP_USER_DEFINED_GROUP_ENTRY_SIZE, then this function would
     * potentially scribble the memory.  Since the above assumption is
     * correct, the code below will work without a problem.
     */
    for ( loop=PMP_EQUIVALENCE_ENTRY_SIZE-2; loop>=0; loop-- )
    {
        ptr--;
        length = read(pmci->proxy.consumer, ptr, _PMCI_READ_REPLY_SIZE);
        if ( length != _PMCI_READ_REPLY_SIZE )
        {
            return pmci_failure_e;
        }
    }
    reply = (pmp_table_read_reply_msg_t *)notif;
    
    /* Need to get rid of three unused bytes between header and data.
     * Unfortunately, the read command reads one byte into a word.
     * Therefore, three bytes are not used within that word.  The
     * result is at the end, we need to move the data left by three bytes.
     */
    memmove(&reply->indexedEntry.entry,
            &reply->indexedEntry.entry.equivalenceEntry[3],
            PMP_EQUIVALENCE_ENTRY_SIZE);

    /* Adjust the header */
    reply->header.msgLength = PMP_EQUIVALENCE_TABLE_READ_REPLY_MSG_SIZE;
    
    return reply->header.msgLength;
}
#endif /* PMCI_RUNNING_ON_TARGET */

static int _pmci_reset_all_table(pmci_obj_t *pmci, pmp_header_t *header)
{
    int min, max, cur, step;
    int min_idx, max_idx;
    int recordSize, msgSize;
    int result;
    pmp_table_reset_request_msg_t *resetReq =
        (pmp_table_reset_request_msg_t *)header;
    pmp_table_write_request_msg_t *writeReq;
    uint8_t *buf;

    /* Compute the start and end index */
    min_idx = 0;
    max_idx = _pmci_max_index_get(pmci, resetReq->tableId);
    recordSize = _pmci_record_size_get(resetReq->tableId);

    if(max_idx < 0 || recordSize <= 0)
    {
        return pmci_invalid_parameters_e;
    }
    
    step = (pmci->batch_buffer_threshold - sizeof(pmp_table_reset_request_msg_t)) /
           (recordSize + sizeof(pmp_index_t));
    /* In case the threshold is really small. */
    if(step <= 0) step = 1;
    
    min = 0;
    do {
        max = min + step - 1;
        if(max > max_idx) max = max_idx;

        msgSize = sizeof(pmp_table_reset_request_msg_t) +
            ((recordSize + sizeof(pmp_index_t)) * (max - min + 1));
        /* Allocate memory to store the write commands */
        writeReq = (pmp_table_write_request_msg_t *)malloc(msgSize);
        if ( writeReq == NULL )
        {
            return pmci_out_of_memory_e;
        }

        /* Build a generic message */
        memcpy(&writeReq->header, &resetReq->header, sizeof(pmp_header_t));
        writeReq->header.msgType = pmp_table_write_request_msg_type_e;
        writeReq->header.msgLength  = msgSize;
        writeReq->tableId = resetReq->tableId;
        buf = (uint8_t *)&writeReq->indexedEntry.index;

        /* Build a single write command for the whole table */
        for ( cur=min; cur<=max; cur++ )
        {
            *(uint32_t *)buf = cur;
            buf += sizeof(pmp_index_t);

            memset(buf, 0, recordSize);
            buf += recordSize;
        }

#ifdef PMCI_DECODE_HW_FROM_SW_CMD
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Software Command Translation");
        _pmci_decode_msg(LOG_TEST, (pmp_header_t *)writeReq);
#endif /* PMCI_DECODE_HW_FROM_SW_CMD */

        /* Apply the single message to the hardware */
        result = _pmci_write(pmci, (pmp_header_t *)writeReq, msgSize, 0);
        if ( result != pmci_success_e )
        {
            free(writeReq);
            return result;
        }
        free(writeReq);
        min += step;
    } while(max < max_idx);
    
    return pmci_success_e;
}

static int  _pmci_get_config_attr(pmci_obj_t *pmci, uint32_t attrId, uint32_t *valuePtr)
{
    /* Get the driver configured attribute values */
    int result = pmci_invalid_attribute_id_e;
    FILE *param;
    
    switch(attrId)
    {
    case pmp_extension_block_num_attr_id_e:
        if ( pmci->extensionBlockNumValid )
        {
            *valuePtr = pmci->extensionBlockNum;
            result = pmci_success_e;
        }
        else
        {
            result = pmci_failure_e;
            param = PMCI_PARAM_FILE(PMCI_PARAM_DXE_SRE_TABLE_SIZE);
            if ( param != NULL )
            {
                if ( fscanf(param, "%d", valuePtr) >= 0 )
                {
                    pmci->extensionBlockNum = *valuePtr;
                    pmci->extensionBlockNumValid = true;
                    result = pmci_success_e;
                }
                fclose(param);
            }
        }
        break;
    case pmp_context_max_num_attr_id_e:
        if ( pmci->contextMaxNumValid )
        {
            *valuePtr = pmci->contextMaxNum;
            result = pmci_success_e;
        }
        else
        {
            result = pmci_failure_e;
            param = PMCI_PARAM_FILE(PMCI_PARAM_SRE_SESSION_CTX_NUM);
            if ( param != NULL )
            {
                if ( fscanf(param, "%d", valuePtr) >= 0 )
                {
                    pmci->contextMaxNum = *valuePtr;
                    pmci->contextMaxNumValid = true;
                    result = pmci_success_e;
                }
                fclose(param);
            }
        }
        break;
    case pmp_context_area_size_attr_id_e:
        if ( pmci->contextAreaSizeValid )
        {
            *valuePtr = pmci->contextAreaSize;
            result = pmci_success_e;
        }
        else
        {
            result = pmci_failure_e;
            param = PMCI_PARAM_FILE(PMCI_PARAM_SRE_SESSION_CTX_SIZE);
            if ( param != NULL )
            {
                if ( fscanf(param, "%d", valuePtr) >= 0 )
                {
                    pmci->contextAreaSize = *valuePtr;
                    pmci->contextAreaSizeValid = true;
                    result = pmci_success_e;
                }
                fclose(param);
            }
        }
        break;
    case pmp_max_stateful_rule_num_attr_id_e:
        if ( pmci->maxRuleNumValid )
        {
            *valuePtr = pmci->maxRuleNum;
            result = pmci_success_e;
        }
        else
        {
            result = pmci_failure_e;
            param = PMCI_PARAM_FILE(PMCI_PARAM_SRE_NUM_RULES);
            if ( param != NULL )
            {
                if ( fscanf(param, "%d", valuePtr) >= 0 )
                {
                    pmci->maxRuleNum = *valuePtr;
                    pmci->maxRuleNumValid = true;
                    result = pmci_success_e;
                }
                fclose(param);
            }
        }
        break;
    default:
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid attributeId %d", attrId);
        break;
    }
    return result;
}

static int  _pmci_get_attribute(pmci_obj_t *pmci, pmp_header_t *header)
{
    pmp_attribute_get_request_msg_t *getReq =
        (pmp_attribute_get_request_msg_t *)header;
    pmp_attribute_get_reply_msg_t getReply;
    uint32_t attrId = ntohl(getReq->attributeId);
    uint32_t value = 1;
    pmp_statistics_attr_t stats;
    pmp_hw_revision_t hwRev;
    pmp_protocol_revision_t protoRev;
    int result = pmci_invalid_attribute_id_e;
    int length;
    int valueLength = sizeof(value);
    void *valuePtr = &value;

    /* Sanitize the attributeId */
    if ( attrId > pmp_last_attr_id_e )
    {
        return pmci_invalid_attribute_id_e;
    }

    /* Retrieve the attribute */
    switch(attrId)
    {
    case pmp_statistics_attr_id_e:
        result = _pmci_get_statistics(pmci, &stats);
        valueLength = sizeof(stats);
        valuePtr = &stats;
        break;
    case pmp_hardware_revision_attr_id_e:
        result = _pmci_get_hw_revision(&hwRev);
        valueLength = sizeof(hwRev);
        valuePtr = &hwRev;
        break;
    case pmp_protocol_revision_attr_id_e:
        result = _pmci_get_protocol_revision(&protoRev);
        valueLength = sizeof(protoRev);
        valuePtr = &protoRev;
        break;
    case pmp_atomic_attr_id_e:
        value = pmci->exclusive;
        result = pmci_success_e;
        break;
    case pmp_batch_attr_id_e:
        value = pmci->batch;
        result = pmci_success_e;
        break;
    case pmp_sre_end_of_sui_index_attr_id_e:
        result = _pmci_read_sysfs(PMCI_ATTR_EOS_PTR, &value);
        break;
    case pmp_variable_trigger_size_attr_id_e:
        result = _pmci_read_sysfs(PMCI_ATTR_KVLTS, &value);
        break;
    case pmp_confidence_chain_max_length_attr_id_e:
        result = _pmci_read_sysfs(PMCI_ATTR_MAX_CHAIN, &value);
        break;
    case pmp_sw_database_signature_attr_id_e:
        result = _pmci_read_sysfs(PMCI_ATTR_SW_DB,  &value);
        break;
    case pmp_drcc_selection_attr_id_e:
        result = _pmci_read_sysfs(PMCI_ATTR_PATTERN_RANGE_INDEX,  &value);
        break;
    case pmp_drcc_mask_attr_id_e:
        result = _pmci_read_sysfs(PMCI_ATTR_PATTERN_RANGE_MASK,  &value);
        break;
    case pmp_extension_block_num_attr_id_e:
    case pmp_context_max_num_attr_id_e:
    case pmp_context_area_size_attr_id_e:
    case pmp_max_stateful_rule_num_attr_id_e:
        result = _pmci_get_config_attr(pmci, attrId, &value);
        break;
    default:
        /* Due to the check at beginning, we should never get here */
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid attributeId %d", attrId);
        break;
    }

    /* Verify the operation */
    if ( result < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't retrieve attribute");
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return result;
    }

    /* Reply with the attribute value */
    length = PMP_ATTRIBUTE_GET_REPLY_MSG_SIZE(valueLength);
    memcpy(&getReply, getReq, sizeof(pmp_attribute_get_request_msg_t));
    getReply.header.msgLength = htonl(length);
    memcpy(&getReply.attributeValue, valuePtr, valueLength);
    if ( write(pmci->proxy.producer, &getReply, length) < 0 )
    {
        return pmci_failure_e;
    }

    return pmci_success_e;
}

static int  _pmci_set_attribute(pmci_obj_t *pmci, pmp_header_t *header)
{
    pmp_attribute_set_request_msg_t *setReq =
        (pmp_attribute_set_request_msg_t *)header;
    uint32_t attrId = ntohl(setReq->attributeId);
    uint32_t value;
    uint32_t valueLength = (header->msgLength -
                            PMP_ATTRIBUTE_SET_REQUEST_EMPTY_MSG_SIZE);
    int result = pmci_invalid_attribute_len_e;

    /* Compute the attribute value */
    memcpy(&value, &setReq->attributeValue, sizeof(value));

    /* Prevent compiler warning */
    if ( pmci == NULL )
    {
        return pmci_invalid_handle_e;
    }

    /* Sanitize the attributeId */
    if ( attrId > pmp_last_attr_id_e )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Invalid attributeId %d", attrId);
        return pmci_invalid_attribute_id_e;
    }

    /* Assign the attribute */
    switch(attrId)
    {
    case pmp_statistics_attr_id_e:
        if ( valueLength == 0 )
        {
            result = _pmci_reset_statistics(pmci);
        }
        break;
    case pmp_hardware_revision_attr_id_e:
        /* This act as an error since can't set hardware revision */
        result = pmci_invalid_attribute_id_e;
        break;
    case pmp_protocol_revision_attr_id_e:
        /* This act as an error since can't set protocol revision */
        result = pmci_invalid_attribute_id_e;
        break;
    case pmp_atomic_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            result = _pmci_set_exclusivity(pmci, value);
        }
        break;
    case pmp_batch_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            /* Do nothing.  pmci_write() already handled all the work for
               this attribute. */
            result = pmci_success_e;
        }
        break;
    case pmp_sre_end_of_sui_index_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            result = _pmci_write_sysfs(PMCI_ATTR_EOS_PTR, value);
        }
        break;
    case pmp_variable_trigger_size_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            result = _pmci_write_sysfs(PMCI_ATTR_KVLTS, value);
        }
        break;
    case pmp_confidence_chain_max_length_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            result = _pmci_write_sysfs(PMCI_ATTR_MAX_CHAIN, value);
        }
        break;
    case pmp_sw_database_signature_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            result = _pmci_write_sysfs(PMCI_ATTR_SW_DB, value);
        }
        break;
    case pmp_drcc_selection_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            result = _pmci_write_sysfs(PMCI_ATTR_PATTERN_RANGE_INDEX, value);
        }
        break;
    case pmp_drcc_mask_attr_id_e:
        if ( valueLength == sizeof(value) )
        {
            result = _pmci_write_sysfs(PMCI_ATTR_PATTERN_RANGE_MASK, value);
        }
        break;
    case pmp_extension_block_num_attr_id_e:
    case pmp_context_max_num_attr_id_e:
    case pmp_context_area_size_attr_id_e:
    case pmp_max_stateful_rule_num_attr_id_e:
        /* These are read-only attributes */
        result = pmci_invalid_attribute_id_e;
        break;
    default:
        /* Due to the check at beginning, we should never get here */
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid attributeId %d", attrId);
        result = pmci_invalid_attribute_id_e;
        break;
    }

    /* Verify the operation */
    if ( result < 0 )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Can't set attribute");
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return result;
    }

    return pmci_success_e;
}

static int _pmci_clear_context_by_rule_id(pmci_obj_t *pmci,
                                     pmp_ctx_by_rule_id_clear_request_msg_t *req)
{
    struct pme_db_sre_reset sreReset;
    bool resetThatCacheLine;
    int ruleIndex;
    int numRules;
    int clIndex;
    int clCap;
    int bitPos;
    uint32_t sessionCtxSize;
    uint32_t sessionNum;
    uint32_t maxRuleNum;
    
    if ( pmci == NULL )
    {
        return pmci_failure_e;
    }

    if ( _pmci_get_config_attr(pmci, pmp_context_area_size_attr_id_e, &sessionCtxSize) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get sessionCtxSize");
        return pmci_failure_e;
    }
    if ( _pmci_get_config_attr(pmci, pmp_context_max_num_attr_id_e, &sessionNum) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get sessionNum");
        return pmci_failure_e;
    }
    if ( _pmci_get_config_attr(pmci, pmp_max_stateful_rule_num_attr_id_e, &maxRuleNum) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get maxRuleNum");
        return pmci_failure_e;
    }

    /* Compute the number of rules and cache line to clear */
    numRules = (req->header.msgLength -
                sizeof(pmp_ctx_by_rule_id_clear_request_msg_t) +
                sizeof(uint32_t)) / sizeof(uint32_t);
    clCap = maxRuleNum / PMP_SESSION_CONTEXT_ENTRY_SIZE;

    /* For each session digest cache line, we clear the appropriate rules */
    for ( clIndex = 0; clIndex < clCap; clIndex ++ )
    {
        /* First, we must build the mask */
        memset(&sreReset, 0, sizeof(sreReset));
        resetThatCacheLine = false;
        for ( ruleIndex = 0; ruleIndex < numRules; ruleIndex++ )
        {
            if ( ((int)req->ruleIds[ruleIndex] /
                  pmp_rule_num_in_session_context_entry) == clIndex )
            {
                bitPos = req->ruleIds[ruleIndex] %
                  pmp_rule_num_in_session_context_entry;
                sreReset.rule_vector[bitPos/32] |= (1 << (31 - (bitPos%32)));
                resetThatCacheLine = true;
                LOG_STRING(LOG_TEST, _PMCI_PREFIX, "   ruleId %d",
                           req->ruleIds[ruleIndex]);
            }
        }

        /* Only if at least one bit is set do we reset the cache line */
        if ( resetThatCacheLine )
        {
            LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Clearing context for specific "
                       "rules between %d and %d",
                       clIndex * pmp_rule_num_in_session_context_entry,
                       ((clIndex+1) * pmp_rule_num_in_session_context_entry)
                       - 1);
            LOG_MEMORY_DUMP(LOG_TEST, _PMCI_PREFIX, sreReset.rule_vector,
                            PMP_SESSION_CONTEXT_ENTRY_SIZE);

            sreReset.rule_index            = clIndex;
            sreReset.rule_increment        = (sessionCtxSize /
                                              PMP_SESSION_CONTEXT_ENTRY_SIZE);
            // TODO rule_repetitions = 1 and loop multiple commands if: PME 2.0
            // and context size = 128k.  See bug 9255
            sreReset.rule_repetitions      = sessionNum;
            sreReset.rule_reset_interval   = PMCI_SRE_CYCLE_INTERVAL;
            sreReset.rule_reset_priority   = PMCI_SRE_CLEAR_PRIORITY;
            if ( ioctl(pmci->pmd, PMEIO_SRE_RESET, &sreReset) < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Failed to clear rules "
                           "in cache line offset %d", clIndex);
                if ( errno == ENODEV ) return pmci_lost_driver_e;
                return pmci_failure_e;
            }
        }
    }

    return pmci_success_e;
}

static int _pmci_clear_all_context(pmci_obj_t *pmci, pmp_header_t *header)
{
    int min, max, cur;
    unsigned int msgSize;
    int result;
    uint32_t sessionNum;
    pmp_header_t my_header;
    pmp_ctx_by_session_id_clear_request_msg_t *clearOne = NULL;
    pmp_ctx_by_session_id_clear_request_msg_t *clearAll = NULL;
    bool low_mem_mode = false;

    if ( _pmci_get_config_attr(pmci, pmp_context_max_num_attr_id_e, &sessionNum) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get sessionNum");
        return pmci_failure_e;
    }

    /* Compute the start and end index */
    min = 1;  /* The first session id that has a context that needs reseting. */
    max = sessionNum-1; /* The last valid session id. */
    
    if ( max < min )
    {
        /* Only possible when sessionNum is configured to be 1.  Hence only
           sessionId 0 is valid, and it don't need to be reset. */
        return pmci_success_e;
    }
    
    /* Allocate memory to store all commands */
    msgSize = sizeof(pmp_ctx_by_session_id_clear_request_msg_t) * ((max-min)+1);
    if ( msgSize <= pmci->batch_buffer_threshold )
    {
        clearAll = malloc(msgSize);
    }
    if ( msgSize > pmci->batch_buffer_threshold || clearAll == NULL )
    {
        /* May be we got millions of sessions.  Fall back to clear one session at
           a time mode. */
        LOG_STRING(LOG_INFO, _PMCI_PREFIX, "Enter low memory mode after"
                   " failed to allocate %d bytes", msgSize);
        msgSize = sizeof(pmp_ctx_by_session_id_clear_request_msg_t);
        clearAll = malloc(msgSize);
        /* Can't do anything if we can't even allocate 24 bytes. */
        if ( clearAll == NULL ) return pmci_out_of_memory_e;
        low_mem_mode = true;
    }
    clearOne = clearAll;
    memcpy(&my_header, header, sizeof(pmp_header_t));
    my_header.msgType = pmp_ctx_by_session_id_clear_request_msg_type_e;
    my_header.msgLength = sizeof(pmp_ctx_by_session_id_clear_request_msg_t);
    
    /* Build HW commands that erase each session context. */
    for ( cur=min; cur<=max; cur++ )
    {
        memcpy(&clearOne->header, &my_header, sizeof(pmp_header_t));
        clearOne->ruleCap = 0;
        clearOne->sessionId = cur;

#ifdef PMCI_DECODE_HW_FROM_SW_CMD
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Software Command Translation");
        _pmci_decode_msg(LOG_TEST, (pmp_header_t *)clearOne);
#endif /* PMCI_DECODE_HW_FROM_SW_CMD */
        
        if ( low_mem_mode )
        {
            /* Clear one session at a time */
            result = _pmci_write(pmci, (pmp_header_t *)clearOne, msgSize, 0);
            if ( result != pmci_success_e )
            {
                free(clearAll);
                return result;
            }
        }
        else
        {
            /* Command stored in the list. */
            clearOne++;
        }
    }

    if ( !low_mem_mode )
    {
        /* Send all commands in the list to hardware. */
        result = _pmci_write(pmci, (pmp_header_t *)clearAll, msgSize, 0);
        if ( result != pmci_success_e )
        {
            free(clearAll);
            return result;
        }
    }
    
    free(clearAll);
    return pmci_success_e;
}

static int _pmci_set_exclusivity(pmci_obj_t *pmci, bool exclusiveState)
{
#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */

    if ( exclusiveState )
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Setting exclusivity");
        pmci->exclusive = 1;
        if ( ioctl(pmci->pmd, PMEIO_EXL_INC) < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Failed to set exclusivity");
            if ( errno == ENODEV ) return pmci_lost_driver_e;
            return pmci_failure_e;
        }
    }
    else
    {
        LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Clearing exclusivity");
        pmci->exclusive = 0;
        if ( ioctl(pmci->pmd, PMEIO_EXL_DEC) < 0 )
        {
            LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Failed to clear "
                       "exclusivity");
            if ( errno == ENODEV ) return pmci_lost_driver_e;
            return pmci_failure_e;
        }
    }

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Done.");
    return pmci_success_e;
}

static int _pmci_scan_data(pmci_obj_t *pmci, pmp_data_scan_request_msg_t *cmd)
{
    pmp_scan_report_indication_msg_t *notif;
    struct pme_scan_params params;
    struct pme_scan scan;

#ifndef PMCI_RUNNING_ON_TARGET
    return pmci_success_e;
#endif /* PMCI_RUNNING_ON_TARGET */

    notif = malloc(PMCI_MAX_MSG_SIZE);
    if ( notif == NULL )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Out-of-memory");
        return pmci_out_of_memory_e;
    }

    /* Ensure we start filling the structure from scratch */
    memset(&params, 0, sizeof(params));
    memset(&scan, 0, sizeof(scan));

    /* Update the scanner context */
    params.flags = ( PME_SCAN_PARAMS_RESIDUE |
                     PME_SCAN_PARAMS_SRE |
                     PME_SCAN_PARAMS_PATTERN );
    params.pattern.set = cmd->set;
    params.pattern.subset = ntohl(cmd->subsetMask);
    params.sre.sessionid = ntohl(cmd->sessionId);
    params.sre.esee = 1;
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "set=%d, mask=0x%x, sessionId=0x%x, ",
               params.pattern.set, params.pattern.subset,
               params.sre.sessionid);
    if ( ioctl(pmci->scan, PMEIO_SETSCAN, &params) < 0 )
    {
        free(notif);
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return pmci_failure_e;
    }
    
    /* Send the data through the scanner */
    scan.cmd.flags = PME_SCAN_CMD_STARTRESET | PME_SCAN_CMD_END;
    scan.cmd.input.data = cmd->data;
    scan.cmd.input.size = ntohl(cmd->header.msgLength) -
                          sizeof(pmp_data_scan_request_msg_t);
    scan.cmd.output.data = notif->reports;
    scan.cmd.output.size = PMCI_MAX_MSG_SIZE -
                           sizeof(pmp_scan_report_indication_msg_t);
    if ( ioctl(pmci->scan, PMEIO_SCAN, &scan) < 0 )
    {
        free(notif);
        if ( errno == ENODEV ) return pmci_lost_driver_e;
        return pmci_failure_e;
    }

    if ( scan.result.flags != 0 )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Unexpected flag from PME: 0x%"PRIx8,
                scan.result.flags);
    }
    if ( scan.result.status != pme_status_ok )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Unexpected status from PME: 0x%"PRIx32,
                scan.result.status);
        return pmci_failure_e;
    }

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Data was:");
    LOG_MEMORY_DUMP(LOG_TEST, _PMCI_PREFIX, scan.cmd.input.data,
        scan.cmd.input.size);
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Report is:");
    LOG_MEMORY_DUMP(LOG_TEST, _PMCI_PREFIX, scan.result.output.data,
        scan.result.output.size);
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Operation status is now:");
    LOG_MEMORY_DUMP(LOG_TEST, _PMCI_PREFIX, &scan, sizeof(scan));

    /* Prepare the notification message (data is already copied) */
    memcpy(notif, cmd, sizeof(pmp_header_t));
    notif->header.msgType = pmp_scan_report_indication_msg_type_e;
    notif->header.msgLength  = sizeof(pmp_scan_report_indication_msg_t) +
        scan.result.output.size;
    notif->origOffset = 0;
    
    /* Move the report data down the proxy stream */
    if ( write(pmci->proxy.producer, notif, notif->header.msgLength) < 0 )
    {
        free(notif);
        return pmci_failure_e;
    }

    /* Report is available in the pmci_read(...) path */
    free(notif);
    return pmci_success_e;
}

static int _pmci_get_hw_revision(pmp_hw_revision_t *rev)
{
    uint32_t pme_rev_1, pme_rev_2;
    int status = pmci_success_e;
    
#ifndef PMCI_RUNNING_ON_TARGET
    
    /* Convert the result into the protocol format */
    rev->socFamily                 = 0; /* Need to compute those */
    rev->socMember                 = 0; /* Need to compute those */
    rev->coreId                    = 0;
    rev->coreMajor                 = PM_HW_REVISION_V2_0_MAJOR;
    rev->coreMinor                 = PM_HW_REVISION_V2_0_MINOR;
    rev->coreIntegrationOptions    = 0;
    rev->coreConfigurationOptions  = 0;
    rev->unused                    = 0;
    return pmci_success_e;
#endif

    status = _pmci_read_sysfs(PMCI_ATTR_HW_REV_1, &pme_rev_1);
    if(status != pmci_success_e)
    {
        return status;
    }
    status = _pmci_read_sysfs(PMCI_ATTR_HW_REV_2, &pme_rev_2);
    if(status != pmci_success_e)
    {
        return status;
    }

    /* Convert the result into the protocol format */
    rev->socFamily                 = 0; /* Need to compute those */
    rev->socMember                 = 0; /* Need to compute those */
    rev->coreId                    = (pme_rev_1 & 0xffff0000) >> 16;
    rev->coreMajor                 = (pme_rev_1 & 0xff00) >> 8;
    rev->coreMinor                 = pme_rev_1 & 0xff;
    rev->coreIntegrationOptions    = (pme_rev_2 & 0xff0000) >> 16;
    rev->coreConfigurationOptions  = pme_rev_2 & 0xff;
    rev->unused                    = 0;

    return status;
}

static int _pmci_get_protocol_revision(pmp_protocol_revision_t *rev)
{
    /* Convert the result into the protocol format */
    rev->protocolMajor             = PMP_CURRENT_VERSION;
    rev->protocolMinor             = 0;
    rev->unused                    = 0;

    return pmci_success_e;
}

static int _pmci_get_statistics(pmci_obj_t *pmci, pmp_statistics_attr_t *stats)
{
    int results = pmci_success_e;
    if ( pmci == NULL ) return pmci_invalid_handle_e;

    /* Copy the statistics over */
    results = _pmci_read_sysfs64(PMCI_STAT_STNIB, &stats->pmInputBytes);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNOB, &stats->pmOutputBytes);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNTH1, &stats->pmTriggerOneByteHits);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNTH2, &stats->pmTriggerTwoByteHits);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNTHV, &stats->pmTriggerVariableHits);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNTHS, &stats->pmTriggerSpecialHits);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNCH, &stats->pmConfidenceHits);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNPM, &stats->pmMatches);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNDSR, &stats->pmDxeExecutions);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNESR, &stats->pmEndOfSuiExecutions);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNS1M, &stats->pmSuiMatchingPatterns);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNS1R, &stats->pmSuiGeneratingReports);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNIS, &stats->pmInputSuis);
    if(results != pmci_success_e) return results;
    results = _pmci_read_sysfs64(PMCI_STAT_STNPMR, &stats->pmSelectedMatches);
    if(results != pmci_success_e) return results;

    /* Old deflate stat.  Don't apply for PME 2.x */
    stats->dfInputBytes              = 0;
    stats->dfOutputBytes             = 0;
    stats->dfDecompressions          = 0;
    
    return pmci_success_e;
}

static int  _pmci_reset_statistics(pmci_obj_t *pmci)
{
    int results = pmci_success_e;
    if ( pmci == NULL ) return pmci_invalid_handle_e;
    
    results = _pmci_write_sysfs(PMCI_STAT_STNIB, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNOB, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNTH1, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNTH2, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNTHV, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNTHS, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNCH, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNPM, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNDSR, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNESR, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNS1M, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNS1R, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNIS, 0);
    if(results != pmci_success_e) return results;
    results = _pmci_write_sysfs(PMCI_STAT_STNPMR, 0);
    if(results != pmci_success_e) return results;

    return results;
}

/* Add commands to batch buffer.  Ignores 0 length command buffer. */
static int _pmci_batch_buffer_add(pmci_obj_t *pmci, void* data, uint32_t length)
{
    int results = pmci_success_e;
    uint8_t* new_buffer_p;
    uint32_t n;
    
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "Batch add 0x%p, length=%"PRIu32, data, length);
    if ( length > 0 )
    {
        if ( pmci->batch_data_len + length > pmci->batch_buffer_len )
        {
            /* Need bigger buffer */
            n = ((pmci->batch_data_len + length - pmci->batch_buffer_len) /
                 PMCI_BATCH_BUFFER_GLOW_DELTA) + 1;
            pmci->batch_buffer_len += n * PMCI_BATCH_BUFFER_GLOW_DELTA;
            new_buffer_p = realloc(pmci->batch_buffer_p, pmci->batch_buffer_len);
            if ( new_buffer_p == NULL )
            {
                /* Can't adjust the size of the buffer */
                LOG_STRING(LOG_WARNING, _PMCI_PREFIX,
                          "Cannot grow batch buffer to %"PRIu32" bytes",
                          pmci->batch_buffer_len);
                return pmci_out_of_memory_e;
            }
            pmci->batch_buffer_p = new_buffer_p;
        }
        /* Append the new commands. */
        memcpy(pmci->batch_buffer_p + pmci->batch_data_len, data, length);
        pmci->batch_data_len += length;

        LOG_STRING(LOG_TEST, _PMCI_PREFIX,
                   "Batch buffer size = %"PRIu32"; data len = %"PRIu32,
                   pmci->batch_buffer_len, pmci->batch_data_len);
    }
    return results;
}

/* Check if the command is a set batch attribute command.  Always return the command length.
   Return true in *batch_cmd and attribute value in *batch_attr if the command is set
   batch attribute. */
static uint32_t _pmci_decode_batch_attr_cmd(void* cmd, bool* batch_cmd, uint32_t* batch_attr)
{
    uint32_t length;
    pmp_header_t *header = cmd;
    pmp_attribute_set_request_msg_t* set_req;
    *batch_cmd = false;
    
    length = ntohl(header->msgLength);

    if ( header->msgType == pmp_attribute_set_request_msg_type_e )
    {
        set_req = (pmp_attribute_set_request_msg_t *)header;
        if ( ntohl(set_req->attributeId) == pmp_batch_attr_id_e )
        {
             *batch_cmd = true;
             *batch_attr = set_req->attributeValue.batchAttr;
        }
    }
    return length;
}

static void _pmci_dump_object(pmci_obj_t *pmci, log_log_Level_t level)
{
    LOG_STRING(level, _PMCI_PREFIX, "magic       = 0x%x", pmci->magic);
    LOG_STRING(level, _PMCI_PREFIX, "pid         = %d",  pmci->pid);
    LOG_STRING(level, _PMCI_PREFIX, "handle      = %p", pmci->handle);
    LOG_STRING(level, _PMCI_PREFIX, "hwRevision  = 0x%x", pmci->hwRevision);
    LOG_STRING(level, _PMCI_PREFIX, "pmd         = %d", pmci->pmd);
    LOG_STRING(level, _PMCI_PREFIX, "channel     = %d", pmci->channel);
    LOG_STRING(level, _PMCI_PREFIX, "scan        = %d", pmci->scan);
    LOG_STRING(level, _PMCI_PREFIX, "proxy:");
    LOG_STRING(level, _PMCI_PREFIX, "  producer  = %d", pmci->proxy.producer);
    LOG_STRING(level, _PMCI_PREFIX, "  consumer  = %d", pmci->proxy.consumer);
    LOG_STRING(level, _PMCI_PREFIX, "sched       = %p", pmci->sched);
    LOG_STRING(level, _PMCI_PREFIX, "schedSize   = %d", pmci->schedSize);
    LOG_STRING(level, _PMCI_PREFIX, "schedNum    = %d", pmci->schedNum);
    if ( pmci->timeout == PMCI_INFINITE )
    {
        LOG_STRING(level, _PMCI_PREFIX, "timeout     = PMCI_INFINITE");
    }
    else
    {
        LOG_STRING(level, _PMCI_PREFIX, "timeout     = %d", pmci->timeout);
    }
    LOG_STRING(level, _PMCI_PREFIX, "exclusive   = %"PRIu32, pmci->exclusive);
    LOG_STRING(level, _PMCI_PREFIX, "batch       = %"PRIu32, pmci->batch);
    LOG_STRING(level, _PMCI_PREFIX, "batch_buffer_p   = 0x%p", pmci->batch_buffer_p);
    LOG_STRING(level, _PMCI_PREFIX, "batch_buffer_len = %"PRIu32, pmci->batch_buffer_len);
    LOG_STRING(level, _PMCI_PREFIX, "batch_data_len   = %"PRIu32, pmci->batch_data_len);
    LOG_STRING(level, _PMCI_PREFIX, "batch_buffer_threshold = %"PRIu32,
               pmci->batch_buffer_threshold);

    LOG_STRING(level, _PMCI_PREFIX, "Memory Dump:");
    LOG_MEMORY_DUMP(level, _PMCI_PREFIX, pmci, sizeof(pmci_obj_t));
}

static void _pmciDumpVersion(log_log_Level_t level, uint8_t version)
{
    if ( version == PMP_CURRENT_VERSION )
    {
        LOG_STRING(level, _PMCI_PREFIX, "   Version = pmp_current_version(%d)",
                   version);
    }
    else
    {
        LOG_STRING(level, _PMCI_PREFIX, "   Version = pmp_unknown_version(%d)",
                   version);
    }
}

static void _pmciDumpType(log_log_Level_t level, uint8_t type)
{
    switch (type)
    {
    case pmp_table_read_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_table_read_request_msg_type_e(%d)", type);
        break;
    case pmp_table_read_reply_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_table_read_reply_msg_type_e(%d)", type);
        break;
    case pmp_table_write_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_table_write_request_msg_type_e(%d)", type);
        break;
    case pmp_table_reset_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_table_reset_request_msg_type_e(%d)", type);
        break;
    case pmp_attribute_get_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_attribute_get_request_msg_type_e(%d)", type);
        break;
    case pmp_attribute_get_reply_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_attribute_get_reply_msg_type_e(%d)", type);
        break;
    case pmp_attribute_set_request_msg_type_e:
        LOG_STRING(level,
                   _PMCI_PREFIX,
                   "   Type    = pmp_attribute_set_request_msg_type_e(%d)",
                   type);
        break;
    case pmp_ctx_by_session_id_clear_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_ctx_by_session_id_clear_request_msg_type_e(%d)",
                   type);
        break;
    case pmp_ctx_by_rule_id_clear_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_ctx_by_rule_id_clear_request_msg_type_e(%d)",
                   type);
        break;
    case pmp_ctx_all_clear_request_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_ctx_all_clear_request_msg_type_e(%d)", type);
        break;
    case pmp_error_indication_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_error_indication_msg_type_e(%d)", type);
        break;
    case pmp_data_scan_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_data_scan_msg_type_e(%d)", type);
        break;
    case pmp_scan_report_indication_msg_type_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   Type    = pmp_scan_report_indication_msg_type_e(%d)", type);
        break;
    default:
        LOG_STRING(level, _PMCI_PREFIX, "   Type    = pmp_null_msg_type_e(%d)",
                   type);
        break;
    }
}

static void _pmciDumpLength(log_log_Level_t level, uint32_t length)
{
    LOG_STRING(level, _PMCI_PREFIX, "   Length  = %d (0x%x)",
               (int)length, (int)length);
}

static void _pmciDumpMsgId(log_log_Level_t level, uint64_t msgId)
{
    LOG_STRING(level, _PMCI_PREFIX, "   MsgId   = 0x%"PRIx64, msgId);
}

static void _pmciDumpTableId(log_log_Level_t level, uint32_t tableId)
{
    switch(tableId)
    {
    case pmp_one_byte_trigger_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_one_byte_trigger"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_two_byte_trigger_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_two_byte_trigger"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_variable_trigger_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_variable_trigger"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_confidence_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_confidence_table_id_e"
                   "(%d)", tableId);
        break;
    case pmp_confirmation_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_confirmation"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_user_defined_group_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_user_defined_group"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_equivalence_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_equivalence_table_id_e"
                   "(%d)", tableId);
        break;
    case pmp_session_context_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_session_context"
                   "TableId_e(%d)", tableId);
        break;
    case pmp_special_trigger_table_id_e:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_special_trigger"
                   "TableId_e(%d)", tableId);
        break;
    default:
        LOG_STRING(level, _PMCI_PREFIX, "   TableId = pmp_null_table_id_e"
                   "(%d)", tableId);
        break;
    }
}

static void _pmci_dump_data(log_log_Level_t level, void *data, int length)
{
    LOG_STRING(level, _PMCI_PREFIX, "   Data    = (%d bytes follow)", length);
    if ( length > 512 )
    {
        LOG_MEMORY_DUMP(level, _PMCI_PREFIX, data, 512);
        LOG_STRING(level, _PMCI_PREFIX, "   Data truncated at 512B");
    }
    else
    {
        LOG_MEMORY_DUMP(level, _PMCI_PREFIX, data, length);
    }
}

static void _pmciDumpAttrId(log_log_Level_t level, uint32_t attrId)
{
    switch(attrId)
    {
    case pmp_statistics_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_statistics_attr_id_e(%d)", attrId);
        break;
    case pmp_hardware_revision_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_hardware_revision_attr_id_e(%d)", attrId);
        break;
    case pmp_protocol_revision_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_protocol_revision_attr_id_e(%d)", attrId);
        break;
    case pmp_atomic_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_atomic_attr_id_e(%d)", attrId);
        break;
    case pmp_batch_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_batch_attr_id_e(%d)", attrId);
        break;
    case pmp_sre_end_of_sui_index_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_sre_end_of_sui_index_attr_id_e(%d)",
                   attrId);
        break;
    case pmp_variable_trigger_size_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_variable_trigger_size_attr_id_e(%d)", attrId);
        break;
    case pmp_confidence_chain_max_length_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_confidence_chain_max_length_attr_id_e(%d)",
                   attrId);
        break;
    case pmp_sw_database_signature_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_sw_database_signature_attr_id_e(%d)", attrId);
        break;
    case pmp_drcc_selection_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_drcc_selection_attr_id_e(%d)", attrId);
        break;
    case pmp_extension_block_num_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_extension_block_num_attr_id_e(%d)",
                   attrId);
        break;
    case pmp_context_max_num_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_context_max_num_attr_id_e(%d)",
                   attrId);
        break;
    case pmp_context_area_size_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_context_area_size_attr_id_e(%d)",
                   attrId);
        break;
    case pmp_max_stateful_rule_num_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = pmp_max_stateful_rule_num_attr_id_e(%d)",
                   attrId);
        break;
    case pmp_drcc_mask_attr_id_e:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId pmp_drcc_mask_attr_id_e = (%d)",
                   attrId);
        break;
    default:
        LOG_STRING(level, _PMCI_PREFIX,
                   "   AttrId  = UNKNOWN(%d)", attrId);
        break;
    }
}

static void _pmci_decode_msg(log_log_Level_t level, pmp_header_t *header)
{
    pmp_table_read_reply_msg_t *readReq;
    pmp_table_write_request_msg_t *writeReq;
    pmp_table_reset_request_msg_t *resetReq;
    pmp_attribute_set_request_msg_t *setReq;
    pmp_attribute_get_request_msg_t *getReq;
    pmp_ctx_by_session_id_clear_request_msg_t *clearBySession;
    pmp_ctx_by_rule_id_clear_request_msg_t *clearByRule;
    
    /* Waste less time */
    if ( !log_is_log_level_enabled(level) ) return;

    LOG_STRING(level, _PMCI_PREFIX, "Command Decode");

    /* Dump the common header and next eight bytes as raw data */
    if ( header->msgLength > 128 )
    {
        LOG_MEMORY_DUMP(level, _PMCI_PREFIX, header, 128);
    }
    else
    {
        LOG_MEMORY_DUMP(level, _PMCI_PREFIX, header, header->msgLength);
    }

    /* Dump the common header */
    _pmciDumpVersion(level, header->protocolVersion);
    _pmciDumpType(level, header->msgType);
    _pmciDumpLength(level, header->msgLength);
    _pmciDumpMsgId(level, header->msgId);

    /* The rest of the message is specific for each command type */
    switch(header->msgType)
    {
    case pmp_table_read_request_msg_type_e:
    case pmp_table_read_reply_msg_type_e:
        readReq = (pmp_table_read_reply_msg_t *)header;
        _pmciDumpTableId(level, readReq->tableId);
        LOG_STRING(level, _PMCI_PREFIX, "   Index   = 0x%x",
                   readReq->indexedEntry.index);
        if ( readReq->header.msgLength > sizeof(pmp_table_read_request_msg_t) )
        {
          LOG_STRING(level, _PMCI_PREFIX, "   Data    =");
          LOG_MEMORY_DUMP(level, _PMCI_PREFIX, &readReq->indexedEntry.entry,
                          header->msgLength -
                          sizeof(pmp_table_read_request_msg_t));
        }
        break;
    case pmp_table_write_request_msg_type_e:
        writeReq = (pmp_table_write_request_msg_t *)header;
        _pmciDumpTableId(level, writeReq->tableId);
        LOG_STRING(level, _PMCI_PREFIX, "   Index   = 0x%x",
                   writeReq->indexedEntry.index);
        _pmci_dump_data(level, &writeReq->indexedEntry.entry,
                      writeReq->header.msgLength +
                      sizeof(pmp_table_entry_t) -
                      sizeof(pmp_table_write_request_msg_t));
        break;
    case pmp_table_reset_request_msg_type_e:
        resetReq = (pmp_table_reset_request_msg_t *)header;
        _pmciDumpTableId(level, resetReq->tableId);
        break;
    case pmp_attribute_get_request_msg_type_e:
    case pmp_attribute_get_reply_msg_type_e:
        getReq = (pmp_attribute_get_request_msg_t *)header;
        _pmciDumpAttrId(level, getReq->attributeId);
        break;
    case pmp_attribute_set_request_msg_type_e:
        setReq = (pmp_attribute_set_request_msg_t *)header;
        _pmciDumpAttrId(level, setReq->attributeId);
        LOG_STRING(level, _PMCI_PREFIX, "   AttrVal = 0x%x",
                   *(int *)&setReq->attributeValue);
        break;
    case pmp_ctx_by_session_id_clear_request_msg_type_e:
        clearBySession = (pmp_ctx_by_session_id_clear_request_msg_t *)header;
        LOG_STRING(level, _PMCI_PREFIX, "   Session = 0x%x (%d)",
                   clearBySession->sessionId,
                   clearBySession->sessionId);
        LOG_STRING(level, _PMCI_PREFIX, "   RuleCap = %d",
                   clearBySession->ruleCap);
        break;
    case pmp_ctx_by_rule_id_clear_request_msg_type_e:
        clearByRule = (pmp_ctx_by_rule_id_clear_request_msg_t *)header;
        LOG_STRING(level, _PMCI_PREFIX, "   FirstSes= 0x%x",
                   clearByRule->firstSessionId);
        LOG_STRING(level, _PMCI_PREFIX, "   Depth   = %d",
                   clearByRule->sessionDepth);
        LOG_STRING(level, _PMCI_PREFIX, "   NumSes  = %d",
                   clearByRule->numberOfSession);
        LOG_STRING(level, _PMCI_PREFIX, "   Rules   =");
        _pmci_dump_data(level, clearByRule->ruleIds,
                      clearByRule->header.msgLength -
                      sizeof(pmp_ctx_by_rule_id_clear_request_msg_t) -
                      sizeof(uint32_t));
        break;
    /* We may omit the following case statements as these all revert to
     * the default case.
     *
    case pmp_ctx_all_clear_msg_type_e:
    case pmp_error_indication_msg_type_e:
    case pmp_data_scan_msg_type_e:
    case pmp_scan_report_indication_msg_type_e:
     */
    default:
        if ( header->msgLength > sizeof(pmp_header_t) )
        {
            LOG_STRING(level, _PMCI_PREFIX, "   Data    =");
            LOG_MEMORY_DUMP(level, _PMCI_PREFIX, header->data,
                            header->msgLength - sizeof(pmp_header_t));
        }
        break;
    }
}

#ifdef PMCI_NEED_TO_DECODE_MULTIPLE_MESSAGES
static void _pmci_decode_all_msg(log_log_Level_t level, pmp_header_t *header,
                              int length)
{
    pmp_header_t *msg;
    void *start = header;
    void *end = start + length;

    /**********************************************************************
     * WARNING WARNING WARNING WARNING WARNING WARNING WARNING WARNING
     * For performance, we might want to skip this as it is time consuming
     * not necessary for the proper functioning of the control interface.
     **********************************************************************/

    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "***** START OF DECODE *****");
    while (start < end)
    {
        msg = (pmp_header_t *)start;
        _pmci_decode_msg(level, msg);
        start += ntohl(msg->msgLength);
    }
    LOG_STRING(LOG_TEST, _PMCI_PREFIX, "****** END OF DECODE ******");

}
#endif /* PMCI_NEED_TO_DECODE_MULTIPLE_MESSAGES */

/**********************************************************************
 * Description:
 *    This function provides the highest valid index for a given table
 *
 * Parameters:
 *    pmci    - pmci object
 *    tableId - Table identifier for which to compute the maximum index value
 *
 * Return:
 *    Maximum index value that is valid for the specified table identifier
 **********************************************************************/
int _pmci_max_index_get(pmci_obj_t *pmci, pmp_table_id_t tableId)
{
    uint32_t value;
    switch (pmci->hwRevision)
    {
    case PM_PME_VERSION_1_1:
        switch (tableId)
        {
        case pmp_two_byte_trigger_table_id_e:
            return PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V1 - 1;
        case pmp_variable_trigger_table_id_e:
            return PMP_VARIABLE_TRIGGER_ENTRY_NUM_V1 - 1;
        case pmp_confidence_table_id_e:
            return PMP_CONFIDENCE_ENTRY_NUM_V1 - 1;
        default:
            break;
        }
        break;
    case PM_PME_VERSION_2_0:
        switch (tableId)
        {
        case pmp_two_byte_trigger_table_id_e:
            return PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V2_0 - 1;
        case pmp_variable_trigger_table_id_e:
            return PMP_VARIABLE_TRIGGER_ENTRY_NUM_V2_0 - 1;
        case pmp_confidence_table_id_e:
            return PMP_CONFIDENCE_ENTRY_NUM_V2_0 - 1;
        default:
            break;
        }
        break;
    case PM_PME_VERSION_2_1:
        switch (tableId)
        {
        case pmp_two_byte_trigger_table_id_e:
            return PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V2_1 - 1;
        case pmp_variable_trigger_table_id_e:
            return PMP_VARIABLE_TRIGGER_ENTRY_NUM_V2_1 - 1;
        case pmp_confidence_table_id_e:
            return PMP_CONFIDENCE_ENTRY_NUM_V2_1 - 1;
        default:
            break;
        }
        break;
    default:
        /* 0 will be returned for unsupported HW revision */
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Unsupported HW revision 0x%x", pmci->hwRevision);
        return 0;
    }
    
    switch (tableId)
    {
    case pmp_one_byte_trigger_table_id_e:
        return PMP_ONE_BYTE_TRIGGER_ENTRY_NUM - 1;
        break;
    case pmp_confirmation_table_id_e:
        if ( _pmci_get_config_attr(pmci, pmp_extension_block_num_attr_id_e,
                                   &value) != pmci_success_e )
        {
            LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Failed to get "
                       "extensionBlockNum");
            return 0;
        }
        /* ConfirmationEntryMaxIndex = ConfirmationEntryNum - 1 */
        return ((int)value - 1);
        break;
    case pmp_user_defined_group_table_id_e:
        return PMP_USER_DEFINED_GROUP_ENTRY_NUM - 1;
        break;
    case pmp_equivalence_table_id_e:
        return PMP_EQUIVALENCE_ENTRY_NUM - 1;
        break;
    case pmp_session_context_table_id_e:
        if ( _pmci_get_config_attr(pmci, pmp_context_max_num_attr_id_e, &value) !=
             pmci_success_e )
        {
            LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Failed to get sessionNum");
            return 0;
        }
        /* SessionContextEntryMaxIndex = SessionEntryNum - 1 */
        return ((int)value - 1);
        break;
    case pmp_special_trigger_table_id_e:
        return PMP_SPECIAL_TRIGGER_ENTRY_NUM - 1;
        break;
    default:
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid tableId %d", tableId);
        return 0;
        break;
    } /* switch */

    return 0;
} /* pmciMaxIndexGet */

/**********************************************************************
 * Description:
 *    This function provides the record size to use in the message
 *    protocol for a given table identifier.  The returned value
 *    represent the size of the data portion of the message that is
 *    sent to the PM hardware.
 *
 * Parameters:
 *    tableId - Table identifier for which to compute the record size value
 *
 * Return:
 *    Record size associated to the specified table identifier.
 **********************************************************************/
int _pmci_record_size_get(pmp_table_id_t tableId)
{
    switch (tableId)
    {
    case pmp_one_byte_trigger_table_id_e:
        return PMP_ONE_BYTE_TRIGGER_ENTRY_SIZE;
        break;
    case pmp_two_byte_trigger_table_id_e:
        return PMP_TWO_BYTE_TRIGGER_ENTRY_SIZE;
        break;
    case pmp_variable_trigger_table_id_e:
        return PMP_VARIABLE_TRIGGER_ENTRY_SIZE;
        break;
    case pmp_confidence_table_id_e:
        return PMP_CONFIDENCE_ENTRY_SIZE;
        break;
    case pmp_confirmation_table_id_e:
        return PMP_CONFIRMATION_ENTRY_SIZE;
        break;
    case pmp_user_defined_group_table_id_e:
        return PMP_USER_DEFINED_GROUP_ENTRY_SIZE;
        break;
    case pmp_equivalence_table_id_e:
        return PMP_EQUIVALENCE_ENTRY_SIZE;
        break;
    case pmp_session_context_table_id_e:
        /* The session contexts are read by cache line offset */
        return PMP_SESSION_CONTEXT_ENTRY_SIZE;
        break;
    case pmp_special_trigger_table_id_e:
        return PMP_SPECIAL_TRIGGER_ENTRY_SIZE;
        break;
    default:
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Invalid tableId %d", tableId);
        return 0;
        break;
    } /* switch */

    return 0;
} /* pmciRecordSizeGet */

int pmci_context_clear_by_session_id(uint32_t sessionId)
{
    handle_t pmci_handle;
    pmp_ctx_by_session_id_clear_request_msg_t clearReq;
    pmci_error_t status;
    int channel = PMCI_DEFAULT_CHANNEL;
    uint32_t sessionNum;

    /* Verify access to PMCI and PMD modules */
    status = pmci_open(channel, &pmci_handle);
    if ( status != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't access PMCI module "
                   "(%d:%s)", status, pmci_error_string(status));
        return pmci_unavailable_driver_e;
    }
    
    if ( _pmci_get_config_attr(pmci_handle, pmp_context_max_num_attr_id_e, &sessionNum) !=
         pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't get sessionNum");
        pmci_close(pmci_handle);
        return pmci_failure_e;
    }

    /* Verify that the specified sessionId is valid */
    if ( (sessionId == 0) || (sessionId >= sessionNum) )
    {
        LOG_STRING(LOG_ERROR, _PMCI_PREFIX, "Session 0x%x is invalid",
                   (int)sessionId);
        pmci_close(pmci_handle);
        return pmci_invalid_parameters_e;
    }

    /* Prepare the message to clear the context */
    memset(&clearReq, 0, sizeof(clearReq));
    clearReq.header.protocolVersion = PMP_CURRENT_VERSION;
    clearReq.header.msgType         = pmp_ctx_by_session_id_clear_request_msg_type_e;
    clearReq.header.reserved        = 0;
    clearReq.header.msgLength       = htonl(sizeof(clearReq));
    clearReq.header.msgId           = (uintptr_t)pmci_handle;
    clearReq.sessionId              = htonl(sessionId);
    clearReq.ruleCap                = 0;

    /* Send the request */
    status = pmci_write(pmci_handle, &clearReq, sizeof(clearReq));
    if ( status != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't send clear request "
                   "(%d:%s)", status, pmci_error_string(status));
        pmci_close(pmci_handle);
        return status;
    }

    /* Wait until the request has been completed */
    status = pmci_flush(pmci_handle);
    if ( status != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't complete clear request "
                   "(%d:%s)", status, pmci_error_string(status));
        pmci_close(pmci_handle);
        return status;
    }
    
    status = pmci_close(pmci_handle);
    if ( status != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMCI_PREFIX, "Can't close pmci handle "
                   "(%d:%s)", status, pmci_error_string(status));
        return status;
    }
    return pmci_success_e;
}
