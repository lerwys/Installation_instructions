/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmlaTgApi.c
 *
 * Description:
 *   This file implements the Pattern Matching Loader Agent API specifically 
 *   for the TransGen verification tool.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmla.h>
#include <pm_defs.h>
#include <pmp.h>
#include <stdio.h>
#include <string.h>

/**********************************************************************
 * Private types
 **********************************************************************/
#define maxFilenameLen_d 50
#define maxPmlaTgObj 1
#define defaultOutFile "pmlaCtrlMsg.txt"

#define PMLA_TG_MODE_NORMAL 0
#define PMLA_TG_MODE_ZERO_RESET 1

/* Loader Agent object */
typedef struct
{
    char outFilename[maxFilenameLen_d];
    FILE* outFile;
    int allocated;
    int connected;
    int mode;
} PmlaTgObj_t;

/**********************************************************************
 * Global variabls
 **********************************************************************/

/**********************************************************************
 * Internal function Implementation
 **********************************************************************/

/*
 * This rouine dump the data in 32bit hex dump, byte order preserved.
 */
static int binPrint(FILE* file, uint8_t* buf, int length)
{
    int i, j, seg_len;
    for(i=0; i < length ; i+= 4)
    {
        if(length - i >= 4) seg_len = 4;
        else seg_len = length - i;
        for(j=0; j < seg_len; j++)
        {
            if(fprintf(file, "%02X", buf[i+j]) < 0)
                return 0;
        }
        if(fprintf(file, " ") < 0) return 0;
    }
    return 1;
}

/* This routine is a modifed version of _pmci_max_index_get in pmci.c */
static int _pmlaTgMaxIndexGet(pmp_table_id_t tableId)
{
    switch (tableId)
    {
#ifdef PME_1_1
    case pmp_two_byte_trigger_table_id_e:
        return PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V1 - 1;
    case pmp_variable_trigger_table_id_e:
        return PMP_VARIABLE_TRIGGER_ENTRY_NUM_V1 - 1;
    case pmp_confidence_table_id_e:
        return PMP_CONFIDENCE_ENTRY_NUM_V1 - 1;
    case pmp_confirmation_table_id_e:
        return 65536 - 1;
        
#endif
#ifdef PME_2_0
    case pmp_two_byte_trigger_table_id_e:
        return PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V2_0 - 1;
    case pmp_variable_trigger_table_id_e:
        return PMP_VARIABLE_TRIGGER_ENTRY_NUM_V2_0 - 1;
    case pmp_confidence_table_id_e:
        return PMP_CONFIDENCE_ENTRY_NUM_V2_0 - 1;
    case pmp_confirmation_table_id_e:
        return (65536*4) - 1;
#endif
#ifdef PME_2_1
    case pmp_two_byte_trigger_table_id_e:
        return PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V2_1 - 1;
    case pmp_variable_trigger_table_id_e:
        return PMP_VARIABLE_TRIGGER_ENTRY_NUM_V2_1 - 1;
    case pmp_confidence_table_id_e:
        return PMP_CONFIDENCE_ENTRY_NUM_V2_1 - 1;
    case pmp_confirmation_table_id_e:
        return (65536*4) - 1;
#endif
    case pmp_one_byte_trigger_table_id_e:
        return PMP_ONE_BYTE_TRIGGER_ENTRY_NUM - 1;
        break;
    case pmp_user_defined_group_table_id_e:
        return PMP_USER_DEFINED_GROUP_ENTRY_NUM - 1;
        break;
    case pmp_equivalence_table_id_e:
        return PMP_EQUIVALENCE_ENTRY_NUM - 1;
        break;
    case pmp_session_context_table_id_e:
        //return PMP_SESSION_NUM - 1;
        return 1023;
        break;
    case pmp_special_trigger_table_id_e:
        return PMP_SPECIAL_TRIGGER_ENTRY_NUM - 1;
        break;

    default:
        return 0;
        break;
    } /* switch */

    return 0;
} /* pmciMaxIndexGet */

/* This routine is a modifed version of _pmci_record_size_get in pmci.c */
static int _pmlaTgRecordSizeGet(pmp_table_id_t tableId)
{
    switch (tableId)
    {
    case pmp_one_byte_trigger_table_id_e:
        return PMP_ONE_BYTE_TRIGGER_ENTRY_SIZE;
        break;
    case pmp_two_byte_trigger_table_id_e:
        return PMP_TWO_BYTE_TRIGGER_ENTRY_SIZE;
        break;
    case pmp_variable_trigger_table_id_e:
        return PMP_VARIABLE_TRIGGER_ENTRY_SIZE;
        break;
    case pmp_confidence_table_id_e:
        return PMP_CONFIDENCE_ENTRY_SIZE;
        break;
    case pmp_confirmation_table_id_e:
        return PMP_CONFIRMATION_ENTRY_SIZE;
        break;
    case pmp_user_defined_group_table_id_e:
        return PMP_USER_DEFINED_GROUP_ENTRY_SIZE;
        break;
    case pmp_equivalence_table_id_e:
        return PMP_EQUIVALENCE_ENTRY_SIZE;
        break;
    case pmp_session_context_table_id_e:
        return PMP_SESSION_CONTEXT_ENTRY_SIZE;
        break;
    case pmp_special_trigger_table_id_e:
        return PMP_SPECIAL_TRIGGER_ENTRY_SIZE;
        break;

    default:
        return 0;
        break;
    } /* switch */

    return 0;
} /* pmciRecordSizeGet */

//This routine is a modifed version of _pmci_reset_all_table in pmci.c
static int _pmlaTgwriteResetTableMsg(FILE* outFile, pmp_header_t* header, int mode)
{
    int min, max, cur;
    int recordSize, msgSize;
    pmp_table_reset_request_msg_t *resetReq = 
        (pmp_table_reset_request_msg_t *)header;
    pmp_table_write_request_msg_t *writeReq;
    uint8_t *buf;

    /* Compute the start and end index */
    min = 0;
    max = _pmlaTgMaxIndexGet(ntohl(resetReq->tableId));
    recordSize = _pmlaTgRecordSizeGet(ntohl(resetReq->tableId));
    msgSize = sizeof(pmp_table_reset_request_msg_t) + 
        ((recordSize + sizeof(uint32_t)) * (max+1));

    if(mode == PMLA_TG_MODE_ZERO_RESET && ntohl(resetReq->tableId) != pmp_one_byte_trigger_table_id_e)
    {
        // Do a comment type message instead, for SRAM write
        // Except one byte table - they are registers
        msgSize = (max+1) * recordSize;
        buf = calloc(msgSize, 1);
        
        if( fprintf(outFile, "#TableReset Tid%d %08X ", ntohl(resetReq->tableId), msgSize) < 0 ||
            !binPrint(outFile, buf, msgSize) || fprintf(outFile, "\n") < 0)
        {
            free(buf);
            return pmlaLostConnectivity_c;
        }
        
        free(buf);
        return pmlaSuccess_c;
    }
    
    /* Allocate memory to store the write commands */
    writeReq = (pmp_table_write_request_msg_t *)malloc(msgSize);
    if ( writeReq == NULL )
    {
        return pmlaOutOfMemory_c;
    }
    
    //const int cmd_size_limit = 8*1024;
    const int cmd_size_limit = 1024*1024*1024; // no limit
    int segmentSize = 0;
    int totalSize = 0;
    //while(totalSize < (msgSize - sizeof(pmp_table_reset_request_msg_t)))
    cur = 0;
    while(cur <= max)
    {
        /* Build a generic message */
        memcpy(&writeReq->header, &resetReq->header, sizeof(pmp_header_t));
        writeReq->header.msgType = pmp_table_write_request_msg_type_e;
        //writeReq->header.msgLength = ntohl(msgSize);
        writeReq->tableId = resetReq->tableId;
        buf = (uint8_t *)&writeReq->indexedEntry.index;

        segmentSize = sizeof(pmp_table_reset_request_msg_t);
        /* Build a single write command for the whole table */
        for ( cur=min; cur<=max; cur++ )
        {
            *(uint32_t *)buf = ntohl(cur);
            buf += sizeof(uint32_t);

            memset(buf, 0, recordSize);
            buf += recordSize;

            segmentSize += sizeof(uint32_t) + recordSize;
            if(segmentSize >= cmd_size_limit) break;
        }
        min = cur + 1;
        totalSize += segmentSize - sizeof(pmp_table_reset_request_msg_t);
        writeReq->header.msgLength = ntohl(segmentSize);
        /* Apply the single message to the hardware */
        if(fprintf(outFile, "%08X ", segmentSize) < 0 ||
           !binPrint(outFile, (uint8_t*) writeReq, segmentSize) ||
           fprintf(outFile, "\n") < 0) 
        {
            free(writeReq);
            return pmlaLostConnectivity_c;
        }
    }
    free(writeReq);
    return pmlaSuccess_c;
}

/**********************************************************************
 * API Implementation
 **********************************************************************/

PmlaError_t pmlaOpen ( PmlaTarget_t *target, handle_t *handle )
{
    PmlaTgObj_t *obj;

    /* In the case of TransGen, the target should either be NULL or 
     * representing some kind of file name or file descriptor.
     */

    /* Initialize the handle to null */
    *handle = HANDLE_NULL;
    
    /* Just to work around the compiler warning */
    if ( target == NULL ) {}

    /* Allocating a Loader Agent handle */
    obj = (PmlaTgObj_t *)malloc(sizeof(PmlaTgObj_t));
    if(obj == NULL) return pmlaOutOfMemory_c;

    strcpy(obj->outFilename, defaultOutFile);
    obj->outFile = NULL;
    obj->allocated = 1;
    obj->connected = 0;
    obj->mode = PMLA_TG_MODE_NORMAL;
    
    if(target != NULL)
    {
        struct sockaddr_in *inetAddr_p = (struct sockaddr_in *)&(target->addr);
        if(inetAddr_p->sin_addr.s_addr == 0) // ip 0.0.0.0
            obj->mode = PMLA_TG_MODE_ZERO_RESET;
    }
    
    /* Return the handle as an integer */
    *handle = (handle_t)obj;
    return pmlaSuccess_c;
}

PmlaError_t pmlaSetOption ( handle_t pmlaHandle,
                    int optionId,
                    void *option,
                    int optionSize )
{
    PmlaTgObj_t *obj;
    
    /* You choose whether you want to support any options */
    /* Be consistent with pmlaGetOption though! */

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    /* Sanitize the optionId */
    if ( (optionId < 0) || (optionId > pmlaMaxOptions_c) )
    {
        return pmlaInvalidOptionCode_c;
    }
    if ( option == NULL )
    {
        return pmlaInvalidOptionValue_c;
    }
    if ( optionSize < (int)sizeof(int) )
    {
        return pmlaInvalidOptionSize_c;
    }

    /* TODO:  Handle the options you want to support here */
    //return pmlaInvalidOptionValue_c; /* When option value is out-of-range */
    //return pmlaInvalidOptionSize_c; /* When option size does not match */
    //return pmlaSuccess_c; /* When option successfully processed */
    
    return pmlaSuccess_c;
}

PmlaError_t pmlaGetOption ( handle_t pmlaHandle,
                            int optionId,
                            void *option,
                            int *optionSize )
{
    PmlaTgObj_t *obj;

    /* You choose whether you want to support any options */
    /* Be consistent with pmlaSetOption though! */

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    /* Sanitize the optionId */
    if ( (optionId < 0) || (optionId > pmlaMaxOptions_c) )
    {
        return pmlaInvalidOptionCode_c;
    }
    if ( option == NULL )
    {
        return pmlaInvalidOptionValue_c;
    }
    if ( (optionSize == NULL) || (*optionSize < (int)sizeof(int)) )
    {
        return pmlaInvalidOptionSize_c;
    }

    /* TODO:  Handle the options you want to support here */
    //return pmlaInvalidOptionValue_c; /* When option value is out-of-range */
    //return pmlaInvalidOptionSize_c; /* When option size does not match */
    //return pmlaSuccess_c; /* When option successfully processed */
    
    return pmlaSuccess_c;
}

PmlaError_t pmlaClose ( handle_t pmlaHandle )
{
    PmlaTgObj_t *obj;

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    if(obj->connected) pmlaDisconnect(pmlaHandle);

    /* Destroying the handle */
    memset(obj, 0, sizeof(PmlaTgObj_t));

    free(obj);
    return pmlaSuccess_c;
}

PmlaError_t pmlaConnect ( handle_t pmlaHandle )
{
    PmlaTgObj_t *obj;

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    if(obj->connected) return pmlaAlreadyConnected_c;

    obj->outFile = fopen(obj->outFilename,"w");
    if(obj->outFile == NULL) return pmlaConnectFailure_c;

    obj->connected = 1;
    return pmlaSuccess_c;
}

PmlaError_t pmlaDisconnect ( handle_t pmlaHandle )
{
    PmlaTgObj_t *obj;

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    if(!obj->connected || obj->outFile == NULL) return pmlaNotConnected_c;
   
    if(fclose(obj->outFile) != 0) return pmlaLostConnectivity_c;
    
    obj->outFile = NULL;
    obj->connected = 0;
    return pmlaSuccess_c;
}

PmlaError_t pmlaSendBulkBegin ( handle_t pmlaHandle )
{
    PmlaTgObj_t *obj;

    /* You may totally ignore bulk hint function.  This is normally used when
     * you send data across a network and want to optimize how this data is 
     * conveyed.
     */

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    /* TODO:  Check against double begin here if you want to get fancy */
    //return pmlaBulkInProgress_c;

    return pmlaSuccess_c;
}

PmlaError_t pmlaSendBulkEnd ( handle_t pmlaHandle )
{
    PmlaTgObj_t *obj;

    /* You may totally ignore bulk hint function.  This is normally used when
     * you send data across a network and want to optimize how this data is 
     * conveyed.
     */

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    if(fprintf(obj->outFile, "#BulkEnd\n") < 0)
        return pmlaLostConnectivity_c;
    /* TODO:  Check against double end here if you want to get fancy */
    //return pmlaNotInBulkState_c;

    return pmlaSuccess_c;
}

PmlaError_t pmlaSend ( handle_t pmlaHandle,
                       pmp_msg_t *cmd )
{
    PmlaTgObj_t *obj;
    int rc;
    uint32_t cmdSize = ntohl(cmd->header.msgLength);
    /* That's probably one of the most important function for you.  That's 
     * where you hook your transmit function.  This is all yours to hook 
     * to any file I/O or socket based data exchange as you want.
     */

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    /* Sanitize the command */
    if ( cmd == NULL )
    {
        return pmlaNoBufferProvided_c;
    }
    if(cmdSize <= 0) return pmlaBufferSizeError_c;

    if(!obj->connected || obj->outFile == NULL)
        return pmlaNotConnected_c;

    // We need to filter out message that is mean for pmla server instead of 
    // hardware.  We will skip the read commands too since they don't work 
    // in Transgen.  
    // pmp_table_reset_request_msg_t *resetReq = 
    //                                   &cmd->requestMsg.tableResetRequestMsg;
    // printf("*** %d %d %d\n", cmd->header.protocolVersion, 
    //        cmd->header.msgType, ntohl(resetReq->tableId));
    if(cmd->header.protocolVersion != PMP_CURRENT_VERSION)
        return pmlaInvalidCommand_c;
    // We will need to expand the reset commands like the real pmla server.
    if(cmd->header.msgType == pmp_table_reset_request_msg_type_e)
    {
        rc = _pmlaTgwriteResetTableMsg(obj->outFile, &cmd->header, obj->mode);
        if(rc != pmlaSuccess_c) return pmlaUnrecoverableError_c;
        return pmlaSuccess_c;
    }
    
    if(cmd->header.msgType == pmp_attribute_set_request_msg_type_e)
    {
        pmp_attribute_set_request_msg_t* setAttrReq = 
                    &cmd->requestMsg.attributeSetRequestMsg;    
        if(ntohl(setAttrReq->attributeId) == pmp_sre_end_of_sui_index_attr_id_e)
        {
            uint32_t tmp = ntohl(setAttrReq->attributeValue.sreEndOfSuiIndexAttr);
            if(fprintf(obj->outFile, "#setAttrSreEndOfSuiReactionPtr %08X\n", 
                 tmp) < 0)
                return pmlaLostConnectivity_c;
        }
        return pmlaSuccess_c;
    }
    
    
    if(cmd->header.msgType != pmp_table_write_request_msg_type_e && 
       cmd->header.msgType != pmp_ctx_by_session_id_clear_request_msg_type_e) 
      return pmlaSuccess_c;
    
    if(fprintf(obj->outFile, "%08X ", cmdSize) < 0)
        return pmlaLostConnectivity_c;

    if(!binPrint(obj->outFile, (uint8_t *)cmd, cmdSize)) 
    {
        return pmlaLostConnectivity_c;
    }
    if(fprintf(obj->outFile, "\n") < 0) return pmlaLostConnectivity_c;
    
    return pmlaSuccess_c;
}

PmlaError_t pmlaRecv ( handle_t  pmlaHandle,
                       pmp_msg_t *notif )
{
    PmlaTgObj_t *obj;
    int len;
    
    /* That's probably one of the most important function for you.  That's 
     * where you hook your receive function.  This is all yours to hook 
     * to any file I/O or socket based data exchange as you want.
     */

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    /* Sanitize the result notification buffer */
    if ( notif == NULL )
    {
        return pmlaNoBufferProvided_c;
    }

    //return pmlaBufferSizeError_c;

    /* TODO:  Your I/O operation goes here (don't forget the timeout) */
    len = 0;
    //return pmlaLostConnectivity_c; /* I/O operation failed */
    //return 0; /* A Timeout occured */
    //return pmlaBufferSizeError_c; /* Received buffer exceeds buffer size */

    /* Return the handle as an integer (Hopefully, you sent all bytes) */
    //return pmlaSuccess_c;
    printf("\n====================================================\n");
    printf("  Unable to simulate receive operation in TransGen\n");
    printf("  mode.  Please run pmm with \"--hwsim\" option.\n");
    printf("  Aborting operation.");
    printf("\n====================================================\n");
    
    return pmlaLostConnectivity_c;
}

PmlaError_t pmlaFlush ( handle_t pmlaHandle )
{
    PmlaTgObj_t *obj;
    //int res;

    /* That's a function to figure out when all written data has been sent to
     * the pattern matching hardware and thereof flush out any pending 
     * operation.  I was thinking of implementing this functions as if we
     * send an echo request command.  But if you have a better way,
     * be my guest ;).
     */

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaTgObj_t *)pmlaHandle;
    if ( obj == NULL )
    {
        return pmlaInvalidHandle_c;
    }

    if(!obj->connected || obj->outFile == NULL)
        return pmlaNotConnected_c;

    if(fflush(obj->outFile)) return pmlaLostConnectivity_c;
    return pmlaSuccess_c;
}
