/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmlaTgEmpty.c
 *
 * Description:
 *   The TransGen verification tool does not require the use of a Loader
 *   Agent back-end.  As a result, this empty file is provided to create the
 *   a server-side library.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include "pmla.h"
#include <stdio.h>

/**********************************************************************
 * Empty
 **********************************************************************/

