/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmlaSrmServer.c
 *
 * Description:
 *   The Simple Remotely Managed reference implementation has two modules.
 *   The server module is implemented by this file.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmlaSrmServer.h>
#include <log.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>

/**********************************************************************
 * Implementation
 **********************************************************************/

PmlaSrmServerObj_t *pmlaSrmServerCreate(struct sockaddr *sa)
{
    PmlaSrmServerObj_t *handle;
    int sock;
    int saLen = 0;

    PMLA_LOG_SOCKADDR(LOG_TEST, sa);

    /* Create some memory to hold client specific information */
    handle = (PmlaSrmServerObj_t *)malloc(sizeof(PmlaSrmServerObj_t));
    if ( handle == NULL )
    {
        /* Can't allocate memory */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Out-of-memory");
        return NULL;
    }

    /* Fill in the client object */
    memset(handle, 0, sizeof(PmlaSrmServerObj_t));

    /* Create the listen socket */
    sock = socket(sa->sa_family, SOCK_STREAM, 0);
    if ( sock < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot create socket");
        free(handle);
        return NULL;
    }

    /* Bind and listen on appropriate address/port */
    if ( sa->sa_family == AF_INET )
    {
        saLen = sizeof(struct sockaddr_in);
    }
    else if ( sa->sa_family == AF_UNIX )
    {
        saLen = SUN_LEN(((struct sockaddr_un *)sa));
    }
    else
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Unknown type of connection");
        close(sock);
        free(handle);
        return NULL;
    }
    if ( bind(sock, sa, saLen) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot bind");
        close(sock);
        free(handle);
        return NULL;
    }
    if ( listen(sock, 128) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot listen");
        close(sock);
        free(handle);
        return NULL;
    }

    /* Store the create listen socket */
    handle->server = sock;
    
    return handle;
}

int pmlaSrmServerAccept(PmlaSrmServerObj_t *handle, uint32_t *channel)
{
    struct sockaddr_in sa;
    socklen_t saLen = sizeof(sa);
    int client;
    struct timeval delay;
    fd_set readSet;
    int n;
    PmlaSrmChannelMsg_t prefix;
    struct linger linger = { 1, 0 };

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "server=%p", handle);

    /* Block on accept */
    client = accept(handle->server, (struct sockaddr *)&sa, &saLen);
    if ( client < 0 )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "accept() failed (%d:%s)",
                   errno, strerror(errno));
        return -1;
    }

    /* Expecting the channel information */
    memset(&delay, 0, sizeof(delay));
    delay.tv_sec = 1;
    FD_ZERO(&readSet);
    FD_SET(client, &readSet);
    n = client+1;
    if ( select(n, &readSet, NULL, NULL, &delay) < 0 )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "select() failed (%d:%s)",
                   errno, strerror(errno));
        setsockopt(client, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger));
        close(client);
        return -1;
    }
    if ( !FD_ISSET(client, &readSet) )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "No channel information");
        setsockopt(client, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger));
        close(client);
        return -1;
    }

    /* Extract channel information */
    n = recv(client, &prefix, sizeof(prefix), 0);
    if ( n < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX,"Failed to get channel information");
        setsockopt(client, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger));
        close(client);
        return -1;
    }
    if ( n != sizeof(prefix) )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Error in channel information");
        setsockopt(client, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger));
        close(client);
        return -1;
    }
    if ( (prefix.hdr.type != pmlaSrmClientChannel_c) ||
         (ntohl(prefix.hdr.length) != sizeof(uint32_t)) )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Unexpected message type");
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_PREFIX, &prefix, sizeof(prefix));
        setsockopt(client, SOL_SOCKET, SO_LINGER, &linger, sizeof(linger));
        close(client);
        return -1;
    }
    *channel = ntohl(prefix.channel);

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client=%d, channel=%d",client,*channel);
    return client;
}

int pmlaSrmServerSendData(int client, void *buf, int bufSize)
{
    PmlaSrmOverhead_t prefix;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client=%d, buf=%p, bufSize=%d",
               client, buf, bufSize);

    /* Send the prefix first */
    prefix.type = pmlaSrmClientData_c;
    prefix.length = bufSize;
    prefix.word = htonl(prefix.word);
    if ( send(client, &prefix, sizeof(prefix), 0) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot send prefix");
        return -1;
    }

    /* Send the actual data */
    return send(client, buf, bufSize, 0);
}

int pmlaSrmServerSendControl(int client, void *buf, int bufSize)
{
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client=%d, buf=%p, bufSize=%d",
               client, buf, bufSize);

    /* The buffer argument must point to a valid prefix */
    if ( bufSize > 8 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Wrong prefix size");
        return -1;
    }

    /* Send the prefix first */
    if ( send(client, buf, bufSize, 0) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot send control prefix");
        return -1;
    }

    /* For now, the control do not need more data than the prefix */
    return 0;
}

int pmlaSrmServerRecv(int client, void *arg, 
                      PmlaSrmServerHandler_t data,
                      PmlaSrmServerHandler_t control)
{
    PmlaSrmOverhead_t prefix;
    int result;
    int length;
    int fragSize;
    char *buffer;
    char *ptr;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client=%d", client);

    /* Extract the prefix first */
    length = recv(client, &prefix, sizeof(prefix), 0);
    if ( length == 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Shutting down");
        return -1;
    }
    if ( length != sizeof(prefix) )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot handle partial prefix (%d)",
                   length);
        return -1;
    }
    prefix.word = ntohl(prefix.word);

    /* Demux data from control */
    if ( prefix.type == pmlaSrmClientData_c )
    {
        /* Allocate buffer for the incoming message */
        length = prefix.length;
        buffer = malloc(length);
        if ( buffer == NULL )
        {
            LOG_STRING(LOG_ERROR, _PMLA_PREFIX, 
                       "Can't allocate %d of memory", length);
            return -1;
        }
        ptr = buffer;

        /* Got a data request */
        while(length > 0)
        {
            fragSize = recv(client, ptr, length, 0);
            if ( fragSize < 0 )
            {
                LOG_STRING(LOG_TEST, _PMLA_PREFIX, 
                           "Cannot receive data fragment");
                free(buffer);
                return -1;
            }
            
            ptr += fragSize;
            length -= fragSize;
        }

        /* Process the data then release memory */
        result = (data)(arg, buffer, prefix.length);
        free(buffer);
        return result;
    }
    else
    {
        /* Got a control request */
        return (control)(arg, &prefix, sizeof(prefix));
    } 

    return 0;
}

int pmlaSrmServerDestroy(PmlaSrmServerObj_t *handle)
{
    struct sockaddr_un sa;
    socklen_t saLen = sizeof(sa);

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "server=%p", handle);

    /* Retrieve socket information before closing it */
    getsockname(handle->server, (struct sockaddr *)&sa, &saLen);

    /* Close the listen socket */
    close(handle->server);

    /* Release the memory */
    free(handle);

    /* In case of UNIX socket, we must also remove the file */
    if ( (sa.sun_family == AF_UNIX) && (strlen(sa.sun_path) > 0) )
    {
        remove(sa.sun_path);
    }

    return 0;
}

int pmlaSrmServerGetFd(PmlaSrmServerObj_t *handle)
{
    return handle->server;
}
