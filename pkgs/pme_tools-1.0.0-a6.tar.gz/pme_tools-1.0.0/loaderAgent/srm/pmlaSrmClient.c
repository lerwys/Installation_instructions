/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmlaSrmClient.c
 *
 * Description:
 *   The Simple Remotely Managed reference implementation has two modules.
 *   The front-end module is implemented by this file.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmlaSrmClient.h>
#include <generic_types.h>
#include <log.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>
#include <signal.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <sys/ioctl.h>
#include <unistd.h>

/**********************************************************************
 * Private declaration
 **********************************************************************/

static int _pmlaSrmClientDisconnect(PmlaSrmClientObj_t *handle);
static int _pmlaSrmClientSetKeepalive(PmlaSrmClientObj_t *handle);
static int _pmlaSrmClientGetKeepalive(PmlaSrmClientObj_t *handle);
static bool _pmlaSrmClientIsConnected(PmlaSrmClientObj_t *handle);
static void *_consumerThread(void *arg);

/**********************************************************************
 * Implementation
 **********************************************************************/

PmlaSrmClientObj_t *pmlaSrmClientCreate(void)
{
    PmlaSrmClientObj_t *handle;

    /* Create some memory to hold client specific information */
    handle = (PmlaSrmClientObj_t *)malloc(sizeof(PmlaSrmClientObj_t));
    if ( handle == NULL )
    {
        /* Can't allocate memory */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Out-of-memory");
        return NULL;
    }

    /* Fill in the client object */
    memset(handle, 0, sizeof(PmlaSrmClientObj_t));
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p", handle);

    return handle;
}

int pmlaSrmClientSetKeepalive(PmlaSrmClientObj_t *handle, int probeDelay)
{
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p, keepAlive=%d",
               handle, probeDelay);

    /* Cache the option value */
    handle->probeDelay = probeDelay;

    /* Determine if it should be propagated down */
    if ( _pmlaSrmClientIsConnected(handle) )
    {
        /* Socket is connected, we can attempt to propagate the option down */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Propagating down to socket");
        return _pmlaSrmClientSetKeepalive(handle);
    }

    return 0;
}

int pmlaSrmClientGetKeepalive(PmlaSrmClientObj_t *handle)
{
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p", handle);

    /* Quick and dirty sanity checking */
    if ( handle->probeDelay && _pmlaSrmClientIsConnected(handle) )
    {
        if ( handle->probeDelay != _pmlaSrmClientGetKeepalive(handle) )
        {
            /* Simply log it for tracking purposes */
        }
    }

    /* Here, there's really no need to query the socket layer */
    return handle->probeDelay;
}

int pmlaSrmClientSend(PmlaSrmClientObj_t *handle, void *buf, int bufSize)
{
    PmlaSrmOverhead_t prefix;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p, buf=%p, bufSize=%d",
               handle, buf, bufSize);

    /* Straight socket send */
    prefix.type = pmlaSrmClientData_c;
    prefix.length = bufSize;
    prefix.word = htonl(prefix.word);
    if ( (send(handle->server, &prefix, sizeof(prefix), 0) < 0) ||
         (send(handle->server, buf, bufSize, 0) < 0) )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Send operation failed");
        return -1;
    }

    return 0;
}

int pmlaSrmClientRecv(PmlaSrmClientObj_t *handle, void *buf, int bufSize, 
                      int timeout)
{
    int sock = handle->data.consumer;
    int res;
    struct timeval option;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p, buf=%p, bufSize=%d, "
               "timeout=%d", handle, buf, bufSize, timeout);

    /* Set the timeout value (remember, zero means infinite) */
    option.tv_sec = timeout;
    option.tv_usec = 0;
    res = setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &option, sizeof(option));
    if ( res < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "setsockopt failed");
        return -1;
    }

    /* Straight socket call */
    res = recv(sock, buf, bufSize, 0);
    if ( res < 0 )
    {
        /* Catch the case where we timed out */
        if ( errno == EWOULDBLOCK )
        {
            return 0;
        }

        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "recv failed");
    }

    return res;
}

int pmlaSrmClientFlush(PmlaSrmClientObj_t *handle)
{
    PmlaSrmOverhead_t prefix;
    int length;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p", handle);

    /* Reset the pending flag */
    handle->pending = false;

    /* Sending the flush prefix command */
    prefix.type = pmlaSrmClientCtrlFlush_c;
    prefix.length = 0;
    prefix.word = htonl(prefix.word);
    if ( send(handle->server, &prefix, sizeof(prefix), 0) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Can't send flush");
        return -1;
    }

    /* Wait forever on the completion */
    prefix.word = 0;
    length = recv(handle->ctrl.consumer, &prefix, sizeof(prefix), 0);
    if ( length != sizeof(prefix) )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, 
                   "Can't receive flush notification (%d)", length);
        return -1;
    }

    /* This time, it came in right endianess */
    if ( prefix.type != pmlaSrmClientCtrlFlush_c )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Wrong flush notification");
        return -1;
    }

    /* Check for pending data */
    if ( handle->pending == true )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Pending data");
        return 1;
    }

    return 0;
}

static int _pmlaSrmClientSetChannel(int server,
                                    uint32_t channel)
{
    PmlaSrmChannelMsg_t prefix;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, 
               "Setting the server %d to channel %d", server, channel);

    /* Sending the channel prefix command */
    prefix.hdr.type = pmlaSrmClientChannel_c;
    prefix.hdr.length = sizeof(channel);
    prefix.hdr.word = htonl(prefix.hdr.word);
    prefix.channel = htonl(channel);
    if ( send(server, &prefix, sizeof(prefix), 0) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Can't send channel information");
        return -1;
    }

    return 0;
}

int pmlaSrmClientConnect(PmlaSrmClientObj_t *handle, struct sockaddr *dest,
                         uint32_t channel, int timeout)
{
    int s;
    int sockSize;
    struct timeval to;
    fd_set set;
    int nonBlocking;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p", handle);
    PMLA_LOG_SOCKADDR(LOG_TEST, dest);

    /* Create the server socket (this allows set options to occur) */
    s = socket(dest->sa_family, SOCK_STREAM, 0);
    if ( s < 0 )
    {
        /* Can't create server socket */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Can't create socket");
        return -1;
    }
    handle->server = s;

    /* Apply options to socket */
    if ( dest->sa_family == AF_INET )
    {
        _pmlaSrmClientSetKeepalive(handle);
    }

    /* Compute the socket address size */
    if ( dest->sa_family == AF_INET ) 
    {
        sockSize = sizeof(struct sockaddr_in);
    }
    else if ( dest->sa_family == AF_UNIX )
    {
        sockSize = SUN_LEN(((struct sockaddr_un *)dest));
    }
    else 
    {
        close(s);
        return -1;
    }

    /* Note that specifying a timeout of zero seconds cause this 
     * function to expose the TCP connect latency.
     */

    /* Switch to non-blocking mode */
    if ( timeout > 0 )
    {
        nonBlocking = 1;
        if ( ioctl(s, FIONBIO, &nonBlocking) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Can't switch to non-blocking");
            close(s);
            return -1;
        }
    }
    else
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Exposing TCP connect latency");
    }

    /* Connect to target */
    if ( connect(s, dest, sockSize) < 0 )
    {
        if ( errno == EINPROGRESS )
        {
            /* Connect not completed; wait until we time out */
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Connect in progress.");
            FD_ZERO(&set);
            FD_SET(s, &set);
            memset(&to, 0, sizeof(to));
            to.tv_sec = timeout;
            if ( select(s+1, NULL, &set, NULL, &to) < 0 )
            {
                LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Non-blocking connect "
                           "failed (%d:%s)", errno, strerror(errno));
                close(s);
                return -1;
            }
            if ( !FD_ISSET(s, &set) )
            {
                LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Timed out");
                close(s);
                return -1;
            }
        }
        else
        {
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot connect");
            close(s);
            return -1;
        }
    }

    /* Switch back to blocking mode */
    if ( timeout > 0 )
    {
        nonBlocking = 0;
        if ( ioctl(s, FIONBIO, &nonBlocking) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Can't switch to blocking");
            close(s);
            return -1;
        }
    }

    /* Setting the channel */
    if ( _pmlaSrmClientSetChannel(s, channel) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot set channel");
        close(s);
        return -1;
    }

    /* Connection established */
    handle->server = s;

    /* Create the proxy sockets */
    if ( socketpair(AF_UNIX, SOCK_STREAM, 0, handle->data.pair) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot create data proxy");
        close(handle->server);
        return -1;
    }
    if ( socketpair(AF_UNIX, SOCK_STREAM, 0, handle->ctrl.pair) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot create control proxy");
        close(handle->server);
        close(handle->data.producer);
        close(handle->data.consumer);
        return -1;
    }
    
    /* Start the receive thread */
    if ( pthread_create(&handle->consumerTid, NULL, _consumerThread, handle) )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot create consumer thread");
        close(handle->server);
        close(handle->data.producer);
        close(handle->data.consumer);
        close(handle->ctrl.producer);
        close(handle->ctrl.consumer);
        return -1;
    }

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Connection completed successfully.");

    return 0;
}

int pmlaSrmClientGetErrorCode(PmlaSrmClientObj_t *handle)
{
    PmlaSrmErrorCodeMsg_t msg;
    int length = 0;
    int res;
    uint8_t *buf = (uint8_t *)&msg;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p", handle);

    /* Extract the error code message off the control */
    while ( length < (int)sizeof(msg) )
    {
        res = recv(handle->ctrl.consumer, &buf[length], sizeof(msg)-length, 0);
        if ( res <= 0 )
        {
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, 
                       "Can't receive error code (%d)", length);
            return pmlaTransportError_c;
        }
        length += res;
    }

    /* Only the error code is expected */
    return (int)msg.code;
}

int pmlaSrmClientDisconnect(PmlaSrmClientObj_t *handle)
{
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p", handle);

    /* Terminate the consumer thread */
    if ( pthread_cancel(handle->consumerTid) )
    {
        /* Can't cancel the thread but the show must go on */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot cancel consumer thread");
        return -1;
    }

    /* Clean up the rest */
    return _pmlaSrmClientDisconnect(handle);
}

int pmlaSrmClientDestroy(PmlaSrmClientObj_t *handle)
{
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p", handle);

    /* If the socket is still connected, must destroy it first */
    if ( _pmlaSrmClientIsConnected(handle) )
    {
        pmlaSrmClientDisconnect(handle);
    }

    /* Wipe out the memory */
    memset(handle, 0, sizeof(PmlaSrmClientObj_t));

    /* Release the memory */
    free(handle);

    return 0;
}

/**********************************************************************
 * Private Implementation
 **********************************************************************/

static void *_consumerThread(void *arg)
{
    PmlaSrmClientObj_t *handle = (PmlaSrmClientObj_t *)arg;
    PmlaSrmOverhead_t prefix;
    uint32_t code;
    static char buffer[PMLA_SRM_MAX_FRAGMENT_SIZE];
    int length;
    int fragSize;

    /* Initialize the thread behavior */
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
    pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

    /* Craig is using screen for running the pmm application.  It just 
     * happen that screen generates a SIGWINCH signal if the the user (Craig)
     * connects from a different terminal.  Since this thread does not care
     * about SIGWINCH neither screen behavior, we can safely ignore this
     * particual signal.  This signal will also makes its way to the main
     * thread where the screen application handles properly anyways.  If we
     * receive other kind of interruptions, we may have to ignore more 
     * signals.
     */
    signal(SIGWINCH, SIG_IGN);

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Starting consumer thread");

    while (1)
    {
        /* Block on receive */
        length = recv(handle->server, &prefix, sizeof(prefix), 0);
        if ( length < 0 )
        {
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Error receiving prefix");
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "error=%d, errno=%d (%s)", 
                       length, errno, strerror(errno));
            _pmlaSrmClientDisconnect(handle);
            return NULL;
        }
        else if ( length == 0 )
        {
            /* Since we're blocking, we might have received a signal that
             * kicked ourselelf out of the receive.  Ignoring this scneario
             * and retry.
             */
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Empty receive");
            if ( ++(handle->retry) >= PMLA_SRM_CLIENT_RETRY_MAX )
            {
                _pmlaSrmClientDisconnect(handle);
                return NULL;
            }
            continue;
        }
        else if ( length != sizeof(prefix) )
        {
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Invalid prefix length (%d)", 
                       length);
            _pmlaSrmClientDisconnect(handle);
            return NULL;
        }

        /* Reset the retry counter */
        handle->retry = 0;

        /* Oops, formating the right byte order */
        prefix.word = ntohl(prefix.word);

        /* Check for type of fragment */
        if ( prefix.type == pmlaSrmClientData_c )
        {
            /* Processing data */
            handle->pending = true;
            length = prefix.length;
            while(length > 0)
            {
                /* Getting all data fragments */
                fragSize = recv(handle->server, buffer, 
                                length>PMLA_SRM_MAX_FRAGMENT_SIZE?
                                PMLA_SRM_MAX_FRAGMENT_SIZE:length, 0);
                if ( fragSize < 0 )
                {
                    LOG_STRING(LOG_TEST, _PMLA_PREFIX, 
                               "Error while receiving data fragment");
                    LOG_STRING(LOG_TEST, _PMLA_PREFIX,
                               "error=%d, errno=%d (%s)", length, errno,
                               strerror(errno));
                    _pmlaSrmClientDisconnect(handle);
                    return NULL;
                }

                /* Move the fragment to data stream */
                if ( send(handle->data.producer, buffer, fragSize, 0) < 0 )
                {
                    LOG_STRING(LOG_TEST, _PMLA_PREFIX, 
                               "Cannot move to data proxy");
                    _pmlaSrmClientDisconnect(handle);
                    return NULL;
                }

                /* Adjust overall data to move */
                length -= fragSize;
            }
        }
        else if ( prefix.type == pmlaSrmClientCtrlFlush_c )
        {
            /* Move flush fragment to control stream */
            if ( send(handle->ctrl.producer, &prefix, sizeof(prefix), 0) < 0 )
            {
                LOG_STRING(LOG_TEST, _PMLA_PREFIX,
                           "Cannot move to control proxy");
                _pmlaSrmClientDisconnect(handle);
                return NULL;
            }
        }
        else if ( prefix.type == pmlaSrmClientErrorCode_c )
        {
            /* Extract the error code */
            fragSize = recv(handle->server, &code, sizeof(code), 0);
            if ( fragSize < 0 )
            {
                LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Can't read error code");
                return NULL;
            }

            /* Move the error code onto the control stream */
            if ( send(handle->ctrl.producer, &prefix, sizeof(prefix), 0) < 0 )
            {
                LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Can't push prefix");
                _pmlaSrmClientDisconnect(handle);
                return NULL;
            }
            code = ntohl(code); /* Such that endianess isn't causing trouble */
            if ( send(handle->ctrl.producer, &code, sizeof(code), 0) < 0 )
            {
                LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Can't push prefix");
                _pmlaSrmClientDisconnect(handle);
                return NULL;
            }
        }
        else
        {
            /* Not expecting this type of fragment */
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Unexpected prefix type");
            LOG_MEMORY_DUMP(LOG_TEST, _PMLA_PREFIX, &prefix, sizeof(prefix));
            _pmlaSrmClientDisconnect(handle);
            return NULL;
        }
    }

    return NULL;
}

static int _pmlaSrmClientSetKeepalive(PmlaSrmClientObj_t *handle)
{
    int option;
    int sock = handle->server;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p", handle);

    /* This function causes the keep alive feature to be enabled or disable */
    if ( handle->probeDelay )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Enabling keep-alive");

        /* Enable the keep alive feature */
        option = 1;
        setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &option, sizeof(option));

        /* Adjust the idle period before generating probes */
        option = handle->probeDelay;
        setsockopt(sock, SOL_TCP, TCP_KEEPIDLE, &option, sizeof(option));

        /* Adjust retry interval to 2 seconds in case probe ACK is missing */
        option = 2;
        setsockopt(sock, SOL_TCP, TCP_KEEPINTVL, &option, sizeof(option));

        /* Set number of unacked probes to 10 before tearing down connection */
        option = 10;
        setsockopt(sock, SOL_TCP, TCP_KEEPCNT, &option, sizeof(option));
    }
    else
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Disabling keep-alive");

        /* Disable the keep alive feature */
        option = 0;
        setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &option, sizeof(option));
    }

    return 0;
}

static int _pmlaSrmClientGetKeepalive(PmlaSrmClientObj_t *handle)
{
    int option;
    socklen_t optionLen = sizeof(option);
    int sock = handle->server;
    int keepAliveValue = 0;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "client_p=%p", handle);

    /* Check to see if keep alive is enable */
    getsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &option, &optionLen);
    if ( option )
    {
        /* Keep alive is enabled, check the idle timeout value */
        optionLen = sizeof(option);
        getsockopt(sock, SOL_TCP, TCP_KEEPIDLE, &option, &optionLen);
        keepAliveValue = option;
    }
    
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Keep-alive is %d", keepAliveValue);
    return keepAliveValue;
}

static bool _pmlaSrmClientIsConnected(PmlaSrmClientObj_t *handle)
{
    struct sockaddr_in sa;
    socklen_t saLen = sizeof(sa);

    /* Use the socket properties and verify if it has a peer connected to it */
    if ( getpeername(handle->server, (struct sockaddr *)&sa, &saLen) >= 0 )
    {
        return true;
    }
    return false;
}

static int _pmlaSrmClientDisconnect(PmlaSrmClientObj_t *handle)
{
    int gotAnError = 0;

    /* Close proxy sockets */
    if ( close(handle->ctrl.consumer) < 0 )
    {
        /* Can't close the consoumer control proxy but the show must go on */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot close control proxy (C)");
        gotAnError = 1;
    }        
    if ( close(handle->ctrl.producer) < 0 )
    {
        /* Can't close the producer control proxy but the show must go on */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot close control proxy (P)");
        gotAnError = 1;
    }        
    if ( close(handle->data.consumer) < 0 )
    {
        /* Can't close the consoumer data proxy but the show must go on */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot close data proxy (C)");
        gotAnError = 1;
    }        
    if ( close(handle->data.producer) < 0 )
    {
        /* Can't close the producer data proxy but the show must go on */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot close data proxy (P)");
        gotAnError = 1;
    }        

    /* Close the server socket */
    if ( close(handle->server) < 0 )
    {
        /* Can't close the server socket but the show must go on */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot close medium");
        gotAnError = 1;
    }

    /* No need to wipe out the object structure */

    /* Flags any error that occured during the teardown */
    if ( gotAnError )
    {
        return -1;
    }

    return 0;
}



