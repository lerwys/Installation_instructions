/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmlaSrmApi.c
 *
 * Description:
 *   This file implements the Pattern Matching Loader Agent API specifically 
 *   for the Simple Remotely Managed reference implementation.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmla.h>
#include <pmlaSrmClient.h>
#include <log.h>
#include <string.h>
#include <generic_types.h>
#include <unistd.h>

/**********************************************************************
 * Private types
 **********************************************************************/

/* Loader Agent bulk information */
typedef struct
{
    uint8_t *buf_p;
    uint8_t *cur_p;
    uint8_t *last_p;
    int bufSize;
} PmlaSrmBulkInfo_t;

/* Loader Agent object */
typedef struct
{
    /* Cheap protection mechanism */
    int magic;

    /* Need to store the whole target structure */
    PmlaTarget_t target;

    /* Client handles */
    PmlaSrmClientObj_t *client_p;

    /* Connect state */
    bool connected;

    /* Bulk state */
    bool bulked;

    /* Process identifier */
    pid_t pid;

    /* Bulk information */
    PmlaSrmBulkInfo_t bulkInfo;

    /* Timeout value to use for receiving messages */
    int timeout;

} PmlaSrmObj_t;

/* Magic number for cheap protection mechanism */
#define PMLA_SRM_MAGIC_VALUE 0x506d6c61

/* Bulk memory grow factor */
#define PMLA_SRM_BULK_GROW_INCREMENT 4096

/* Define a log level for API entry functions */
#define PMLA_INFO LOG_TEST

/**********************************************************************
 * Global variables
 **********************************************************************/

/**********************************************************************
 * Private Implementation
 **********************************************************************/

static inline int pmlaSrmValid ( PmlaSrmObj_t *obj )
{
    return ( (obj != NULL) && 
#ifdef PMLA_PID_AND_THREAD_WORKING_PROPERLY
             (obj->pid == getpid()) &&
#endif /* PMLA_PID_AND_THREAD_WORKING_PROPERLY */
             (obj->magic == PMLA_SRM_MAGIC_VALUE) );
}

static inline int pmlaSrmStubout ( PmlaSrmObj_t *obj )
{
    return (obj->target.channel == -1);
}

static void _pmlaDumpObject(PmlaSrmObj_t *obj, log_log_Level_t level)
{
    struct sockaddr_in *inetAddr;
    struct sockaddr_un *unixAddr;

    LOG_STRING(level, _PMLA_PREFIX, "magic       = 0x%x", obj->magic);
    LOG_STRING(level, _PMLA_PREFIX, "target:");
    LOG_STRING(level, _PMLA_PREFIX, "    channel = %d", obj->target.channel);
    if ( obj->target.addr.sa_family == AF_UNIX )
    {
        unixAddr = (struct sockaddr_un *)&obj->target.addr;
        LOG_STRING(level, _PMLA_PREFIX, "    family  = AF_UNIX");
        LOG_STRING(level, _PMLA_PREFIX, "    path    = %s", 
                   unixAddr->sun_path);
    }
    else if ( obj->target.addr.sa_family == AF_INET )
    {
        inetAddr = (struct sockaddr_in *)&obj->target.addr;
        LOG_STRING(level, _PMLA_PREFIX, "    family  = AF_INET");
        LOG_STRING(level, _PMLA_PREFIX, "    port    = %d",
                   ntohs(inetAddr->sin_port));
        LOG_STRING(level, _PMLA_PREFIX, "    address = %s",
                   inet_ntoa(inetAddr->sin_addr));
    }
    else
    {
        LOG_STRING(level, _PMLA_PREFIX, "    family  = Unspecified");
    }
    LOG_STRING(level, _PMLA_PREFIX, "client_p    = %p", obj->client_p);
    LOG_STRING(level, _PMLA_PREFIX, "connected   = %s",
               obj->connected?"true":"false");
    LOG_STRING(level, _PMLA_PREFIX, "bulked      = %s",
               obj->bulked?"true":"false");
    LOG_STRING(level, _PMLA_PREFIX, "pid         = %d", obj->pid);
    LOG_STRING(level, _PMLA_PREFIX, "bulkInfo:");
    LOG_STRING(level, _PMLA_PREFIX, "    buf_p   = %p", obj->bulkInfo.buf_p);
    LOG_STRING(level, _PMLA_PREFIX, "    cur_p   = %p", obj->bulkInfo.cur_p);
    LOG_STRING(level, _PMLA_PREFIX, "    last_p  = %p", obj->bulkInfo.last_p);
    LOG_STRING(level, _PMLA_PREFIX, "    bufSize = %d", obj->bulkInfo.bufSize);
    LOG_STRING(level, _PMLA_PREFIX, "Memory Dump:");
    LOG_MEMORY_DUMP(level, _PMLA_PREFIX, obj, sizeof(PmlaSrmObj_t));
}

static int _pmlaBulkInit(PmlaSrmBulkInfo_t *bi)
{
    /* Allocate memory and initializing information */
    bi->buf_p = (uint8_t *)malloc(PMLA_SRM_BULK_GROW_INCREMENT);
    if ( bi->buf_p == NULL )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Cannot create bulk buffer");
        return pmlaOutOfMemory_c;
    }
    bi->cur_p = NULL; /* _pmlaBulkStart(...) will set it to bi->buf_p */
    bi->last_p = bi->cur_p + PMLA_SRM_BULK_GROW_INCREMENT;
    bi->bufSize = PMLA_SRM_BULK_GROW_INCREMENT;

    return pmlaSuccess_c;
}

static int _pmlaBulkStart(PmlaSrmBulkInfo_t *bi)
{
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Start");

    /* Set the starting point to the beginning of the buffer */
    bi->cur_p = bi->buf_p;

    return pmlaSuccess_c;
}

static int _pmlaBulkEnd(PmlaSrmBulkInfo_t *bi, PmlaSrmClientObj_t *client)
{
    int result;
    int length;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "End");

    /* Ensure we do not overload the client */
    length = (bi->cur_p - bi->buf_p);
    if ( length > PMLA_MAX_MSG_SIZE )
    {
        /* Well, we should not get here since _pmlaBulkCumulate(...) should
         * have protected us agains this error condition.
         */
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Holding %d bytes", length);
        return pmlaBufferSizeError_c;
    }

    /* Send the cumulated data */
    result = pmlaSrmClientSend(client, bi->buf_p, length);
    if ( result < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Lost connectivity");

        /* Here, we would normally return an error.  However, in order to 
         * keep bulk end aligned with bulk start, we don't return the error
         * here but rather on next PMLA call.
         */
        /*
        return pmlaLostConnectivity_c;
        */
    }
    
    /* Normally, we would reset bi->cur_p.  Since no other bulk operation
     * can take place without a bulk start, we keep bi->cur_p as is.  This
     * is helpful for debugging purposes.  The bi->cur_p will be reset by
     * _pmlaBulkStart(...) anyways.
     */

    return pmlaSuccess_c;
}

static PmlaError_t _pmlaBulkCumulate(PmlaSrmBulkInfo_t *bi, void *src, 
                                     int srcLen)
{
    uint8_t *newBuf_p;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "src=%p, srcLen=%d", src, srcLen);

    /* We shall not cumulate more data than the maximum message size */
    if ( ((bi->cur_p - bi->buf_p) + srcLen) > PMLA_MAX_MSG_SIZE )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Cannot cumulate %Zd bytes", 
                   (bi->cur_p - bi->buf_p) + srcLen);
        return pmlaBufferSizeError_c;
    }

    /* Grow the buffer such that we can hold that new data */
    while ((bi->last_p - bi->cur_p) < srcLen)
    {
        /* Allocate memory */
        bi->bufSize += PMLA_SRM_BULK_GROW_INCREMENT;
        newBuf_p = (uint8_t *)realloc(bi->buf_p, bi->bufSize);
        if ( newBuf_p == NULL )
        {
            /* Can't adjust the size of the buffer */
            LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Cannot grow bulk buffer");
            return pmlaOutOfMemory_c;
        }

        /* Adjust bulk information */
        bi->last_p = newBuf_p + bi->bufSize;
        bi->cur_p = newBuf_p + (bi->cur_p - bi->buf_p);
        bi->buf_p = newBuf_p;
    }

    /* Copy the data onto the buffer */
    memcpy(bi->cur_p, src, srcLen);
    bi->cur_p += srcLen;

    return pmlaSuccess_c;
}

static int _pmlaBulkCleanup(PmlaSrmBulkInfo_t *bi)
{
    /* Release the buffer */
    free(bi->buf_p);

    /* Ensure no one else will use it */
    bi->buf_p = NULL;
    bi->cur_p = NULL;
    bi->last_p = NULL;
    bi->bufSize = 0;

    return pmlaSuccess_c;
}

/**********************************************************************
 * API Implementation
 **********************************************************************/

PmlaError_t pmlaOpen ( PmlaTarget_t *target, handle_t *handle )
{
    PmlaSrmObj_t *obj;
    struct sockaddr_in *inetAddr;
    struct sockaddr_un *unixAddr;

    /* Initialize the resulted handle to null */
    *handle = HANDLE_NULL;

    /* Sanitize the target argument */
    if ( target == NULL )
    {
        /* Target not present */
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "No target specified");
        return pmlaInvalidTarget_c;
    }
    if ( handle == NULL )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Null handle specified");        
        return pmlaNoBufferProvided_c;
    }

    if ( target->addr.sa_family == AF_INET )
    {
        inetAddr = (struct sockaddr_in *)&target->addr;
        if ( (inetAddr->sin_port == 0) ||
             (inetAddr->sin_addr.s_addr == 0) )
        {
            /* Target badly initialized */
            LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Bad AF_INET target");
            return pmlaInvalidTarget_c;
        }
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "AF_INET target");
    }
    else if ( target->addr.sa_family == AF_UNIX )
    {
        unixAddr = (struct sockaddr_un *)&target->addr;

        /* Is there some invalid file name? */
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "AF_UNIX target");
    }
    else if ( target->addr.sa_family == AF_UNSPEC )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "AF_UNSPEC target");
    }
    else
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Invalid target");
        return pmlaInvalidTarget_c;
    }

    /* Allocating a Loader Agent handle */
    obj = (PmlaSrmObj_t *)malloc(sizeof(PmlaSrmObj_t));
    if ( obj == NULL )
    {
        /* Failed to allocate memory to hold the PMLA handle */
        return pmlaOutOfMemory_c;
    }
    
    /* Create the client resource */
    memset(obj, 0, sizeof(PmlaSrmObj_t));
    memcpy(&obj->target, target, sizeof(PmlaTarget_t));
    obj->magic = PMLA_SRM_MAGIC_VALUE;
    obj->connected = false;
    obj->bulked = false;
    obj->pid = getpid();
    obj->timeout = PMLA_INFINITE;
    if ( _pmlaBulkInit(&obj->bulkInfo) < 0 )
    {
        /* Failed to initialize bulk information */
        free(obj);
        return pmlaUnrecoverableError_c;
    }
    if ( obj->target.channel != -1 )
    {
        obj->client_p = pmlaSrmClientCreate();
        if ( obj->client_p == NULL )
        {
            /* Failed to create client data resources, free up memory first */
            free(obj);
            _pmlaBulkCleanup(&obj->bulkInfo);
            return pmlaOutOfMemory_c;
        }
    }

    /* Dump the object */
    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, 
               "pmlaHandle  = %"PRI_HANDLE, (handle_t)obj);
    _pmlaDumpObject(obj, LOG_TEST);

    /* Return the handle */
    *handle = (handle_t)obj;
    return pmlaSuccess_c;
}

PmlaError_t pmlaSetOption ( handle_t pmlaHandle,
                            int optionId,
                            void *option,
                            int optionSize )
{
    PmlaSrmObj_t *obj;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, 
               "pmlaHandle=%"PRI_HANDLE", optionId=%d", pmlaHandle, optionId);

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;    
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Sanitize the optionId */
    if ( (optionId < 0) || (optionId > pmlaMaxOptions_c) )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Invalid option code");
        return pmlaInvalidOptionCode_c;
    }
    if ( option == NULL )
    {
        return pmlaInvalidOptionValue_c;
    }

    /* Process keep alive option */
    if ( optionId == pmlaOptionKeepAlive_c )
    {
        /* Ensure time to probe is withinn a valid range */
        if ( optionSize != sizeof(int) )
        {
            return pmlaInvalidOptionSize_c;
        }
        if ( (*(int *)option < 0) || 
             (*(int *)option > PMLA_MAX_KEEPALIVE) )
        {
            return pmlaInvalidOptionValue_c;
        }

        /* Set keep alive value down to client */
        if ( (obj->target.addr.sa_family != AF_INET) ||
             (pmlaSrmClientSetKeepalive(obj->client_p, *(int *)option) < 0) )
        {
            return pmlaUnavailableOption_c;
        }

        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Keep alive set to %d seconds", 
                   *(int *)option);
        return pmlaSuccess_c;
    }
    /* Process timeout option */
    else if ( optionId == pmlaOptionTimeout_c )
    {
        if ( optionSize != sizeof(int) )
        {
            return pmlaInvalidOptionSize_c;
        }
        if ( *(int *)option < 0 )
        {
            return pmlaInvalidOptionValue_c;
        }
        obj->timeout = *(int *)option;

        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Timeout set to %d seconds", 
                   *(int *)option);
        return pmlaSuccess_c;
    }
    
    /* Reaching here when the option is not available at this time */
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Unavailable option code");
    return pmlaUnavailableOption_c;
}

PmlaError_t pmlaGetOption ( handle_t pmlaHandle,
                            int optionId,
                            void *option,
                            int *optionSize )
{
    PmlaSrmObj_t *obj;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, 
               "pmlaHandle=%"PRI_HANDLE", optionId=%d", pmlaHandle, optionId);

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Sanitize the optionId */
    if ( (optionId < 0) || (optionId > pmlaMaxOptions_c) )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Invalid option code");
        return pmlaInvalidOptionCode_c;
    }
    if ( option == NULL || optionSize == NULL)
    {
        return pmlaInvalidOptionValue_c;
    }

    /* Process keep alive option */
    if ( optionId == pmlaOptionKeepAlive_c )
    {
        /* Ensure time to probe is withinn a valid range */
        if ( obj->target.addr.sa_family != AF_INET )
        {
            return pmlaUnavailableOption_c;
        }
        if ( *optionSize < (int)sizeof(int) )
        {
            return pmlaInvalidOptionSize_c;
        }
        *(int *)option = pmlaSrmClientGetKeepalive(obj->client_p);
        if ( *(int *)option < 0 )
        {
            return pmlaUnavailableOption_c;
        }
        *optionSize = sizeof(int);

        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Keep alive of %d retrieved", 
                   *(int *)option);
        return pmlaSuccess_c;
    }
    /* Process timeout option */
    else if ( optionId == pmlaOptionTimeout_c )
    {
        if ( *optionSize < (int)sizeof(int) )
        {
            return pmlaInvalidOptionSize_c;
        }
        *(int *)option = obj->timeout;
        *optionSize = sizeof(int);

        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Timeout of %d retrieved", 
                   *(int *)option);
        return pmlaSuccess_c;
    }
    
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Unavailable option code");
    return pmlaUnavailableOption_c;
}

PmlaError_t pmlaClose ( handle_t pmlaHandle )
{
    PmlaSrmObj_t *obj;
    int res;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Disconnect if currently connected */
    if ( obj->connected )
    {
        res = pmlaDisconnect(pmlaHandle);
        if ( res < 0 ) return res;
    }

    /* Destroying the client resources */
    if ( pmlaSrmClientDestroy(obj->client_p) < 0 )
    {
        return pmlaCantDestroy_c;
    }

    /* Cleanup the bulk information */
    if ( _pmlaBulkCleanup(&obj->bulkInfo) < 0 )
    {
        return pmlaCantDestroy_c;
    }

    /* Destroying the handle */
    memset(obj, 0, sizeof(PmlaSrmObj_t));
    free(obj);

    return pmlaSuccess_c;
}

PmlaError_t pmlaConnect ( handle_t pmlaHandle )
{
    PmlaSrmObj_t *obj;
    int timeout;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Avoid connect duplicate */
    if ( obj->connected )
    {
        return pmlaAlreadyConnected_c;
    }

    /* Compute desired timeout for connect */
    timeout = obj->timeout;
    if ( timeout == PMLA_INFINITE )
    {
        timeout = 0;
    }

    /* Connect to target */
    if ( pmlaSrmClientConnect(obj->client_p, &obj->target.addr, 
                              obj->target.channel, obj->timeout) < 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Could not connect");
        return pmlaConnectFailure_c;
    }

    /* Mark the handle as connected */
    obj->connected = true;

    return pmlaSrmClientGetErrorCode(obj->client_p);
}

PmlaError_t pmlaDisconnect ( handle_t pmlaHandle )
{
    PmlaSrmObj_t *obj;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Avoid erroneous disconnects */
    if ( !obj->connected )
    {
        return pmlaNotConnected_c;
    }

    /* Disconnect from target */
    if ( pmlaSrmClientDisconnect(obj->client_p) < 0 )
    {
        return pmlaLostConnectivity_c;
    }

    /* Mark the handle as not connected */
    obj->connected = false;

    return pmlaSuccess_c;
}

PmlaError_t pmlaSendBulkBegin ( handle_t pmlaHandle )
{
    PmlaSrmObj_t *obj;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Avoid bulk begin duplicate */
    if ( obj->bulked )
    {
        return pmlaBulkInProgress_c;
    }

    /* Go in bulked mode */
    obj->bulked = true;

    /* Verify bulk information */
    return _pmlaBulkStart(&obj->bulkInfo);
}

PmlaError_t pmlaSendBulkEnd ( handle_t pmlaHandle )
{
    PmlaSrmObj_t *obj;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Avoid erroneous bulk end */
    if ( !obj->bulked )
    {
        return pmlaNotInBulkState_c;
    }

    /* Go in normal mode */
    obj->bulked = false;

    /* Send all cumulated data now */
    return _pmlaBulkEnd(&obj->bulkInfo, obj->client_p);
}

PmlaError_t pmlaSend ( handle_t pmlaHandle,
                       pmp_msg_t *cmd )
{
    PmlaSrmObj_t *obj;
    int res;
    uint32_t cmdSize = ntohl(cmd->header.msgLength);

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE", cmd=%p, "
               "cmdSize=%d", pmlaHandle, cmd, cmdSize);

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Ensure we're connected in order to send anything */
    if ( !obj->connected )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is not "
                   "connected", pmlaHandle);
        return pmlaNotConnected_c;
    }

    /* Sanitize the command */
    if ( cmd == NULL )
    {
        return pmlaNoBufferProvided_c;
    }
    if ( cmd->header.protocolVersion != PMP_CURRENT_VERSION )
    {
        return pmlaInvalidCommand_c;
    }

    /* Sanitize the command size */
    if ( cmdSize > PMLA_MAX_MSG_SIZE )
    {
        return pmlaBufferSizeError_c;
    }

    /* Handle bulked operation */
    if ( obj->bulked )
    {
        return _pmlaBulkCumulate(&obj->bulkInfo, cmd, cmdSize);
    }

    /* Send the command to target */
    res = pmlaSrmClientSend(obj->client_p, cmd, cmdSize);
    if ( res < 0 )
    {
        return pmlaLostConnectivity_c;
    }

    /* Return the handle as an integer (Hopefully, you sent all bytes) */
    return pmlaSuccess_c;
}

PmlaError_t pmlaRecv ( handle_t pmlaHandle,
                       pmp_msg_t *notif )
{
    PmlaSrmObj_t *obj;
    int len;
    uint32_t notifSize;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE", notif=%p",
               pmlaHandle, notif);

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    /* Ensure we're connected in order to receive anything */
    if ( !obj->connected )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is not "
                   "connected", pmlaHandle);
        return pmlaNotConnected_c;
    }

    /* Sanitize the result notification buffer */
    if ( notif == NULL )
    {
        return pmlaNoBufferProvided_c;
    }

    /* Perform the I/O receive operation for notification header */
    len = pmlaSrmClientRecv(obj->client_p, notif, 
                            sizeof(notif->header), obj->timeout);
    if ( len < 0 )
    {
        /* Lost communication with target */
        return pmlaLostConnectivity_c;
    }
    else if ( len == 0 )
    {
        /* No data were received in the past timeout */
        LOG_STRING(LOG_INFO, _PMLA_PREFIX, "Timed out");
        return pmlaTimedOut_c;
    }
    else if ( len != sizeof(notif->header) )
    {
        /* Notification header is wrong size */
        return pmlaBufferSizeError_c;
    }

    /* Quick sanity of the header */
    if ( notif->header.protocolVersion != PMP_CURRENT_VERSION )
    {
        return pmlaInvalidNotification_c;
    }
    notifSize = ntohl(notif->header.msgLength);
    if ( notifSize > sizeof(pmp_msg_t) )
    {
        return pmlaBufferSizeError_c;
    }

    /* Perform the I/O receive operation for remainder of notification.
     * Since we only deal with complete message, the remaining should all be 
     * available and therefore, we should not have to wait for it.
     */
    if ( notifSize > sizeof(notif->header) )
    {
        len = pmlaSrmClientRecv(obj->client_p, notif->header.data,
                                notifSize - sizeof(notif->header), 0);
        if ( len < 0 )
        {
            /* Lost communication with target */
            return pmlaLostConnectivity_c;
        }
        else if ( len == 0 )
        {
            /* No data were received in the past timeout */
            LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "No data available");
            return pmlaTransportError_c;
        }
        else if ( (uint32_t)len != (notifSize - sizeof(notif->header)) )
        {
            /* Notification header is wrong size */
            return pmlaBufferSizeError_c;
        }
    }

    /* Return the handle as an integer (Hopefully, you sent all bytes) */
    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Got %d bytes", notifSize);
    return pmlaSuccess_c;
}

PmlaError_t pmlaFlush ( handle_t pmlaHandle )
{
    PmlaSrmObj_t *obj;
    int status;

    LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "pmlaHandle=%"PRI_HANDLE, pmlaHandle);

    /* That's a function to figure out when all written data has been sent to
     * the pattern matching hardware and thereof flush out any pending 
     * operation.
     */

    /* Sanitize the handle (you may add magic number checking if you want) */
    obj = (PmlaSrmObj_t *)pmlaHandle;
    if ( !pmlaSrmValid(obj) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Handle %"PRI_HANDLE" is "
                   "invalid", pmlaHandle);
        return pmlaInvalidHandle_c;
    }
    if ( pmlaSrmStubout(obj) )
    {
        LOG_STRING(PMLA_INFO, _PMLA_PREFIX, "Stubing out");
        return pmlaSuccess_c;
    }

    status = pmlaSrmClientFlush(obj->client_p);
    if ( status < 0 )
    {
        /* An error prevented us from flushing previous commands */
        return pmlaTransportError_c;
    }
    if ( status > 0 )
    {
        /* No error occured, however, receive data is pending */
        return pmlaBufferPending_c;
    }

    return pmlaSuccess_c;
}

