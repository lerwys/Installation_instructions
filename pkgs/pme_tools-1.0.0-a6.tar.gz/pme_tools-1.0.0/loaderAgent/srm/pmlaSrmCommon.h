/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef __pmlaSrmCommon_h__
#define __pmlaSrmCommon_h__

/**********************************************************************
 * File:  pmlaSrmCommon.h
 *
 * Description:
 *   The Simple Remotely Managed reference implementation has commonality
 *   between its front-end and back-end.  This file identifies the common
 *   declaration between the two module.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmla.h>
#include <endian.h>
#include <arpa/inet.h>

/* Verify we can properly build structures based on byte order */
#ifndef __BYTE_ORDER
#error "Byte ordering is unspecified."
#endif /* __BYTE_ORDER */

/* Do this check here so we don't have to repeat this code everywhere */
#if (__BYTE_ORDER != __LITTLE_ENDIAN) && (__BYTE_ORDER != __BIG_ENDIAN)
#error "Byte ordering is unknown."
#endif /* __BYTE_ORDER */

/**********************************************************************
 * Types
 **********************************************************************/

/* Loader Agent Overhead */
typedef union
{
    struct
    {
#if (__BYTE_ORDER == __BIG_ENDIAN)
        uint32_t   type :    8;
        uint32_t   length : 24;
#else /* Above is __BIG_ENDIAN, below is __LITTLE_ENDIAN */
        uint32_t   length : 24;
        uint32_t   type :    8;
#endif /* __BYTE_ORDER */
    };
    uint32_t word;
} PmlaSrmOverhead_t;

/* Loader Agent Error Code Message */
typedef struct
{
    PmlaSrmOverhead_t hdr;
    uint32_t code;
} PmlaSrmErrorCodeMsg_t;

/* Loader Agent Channel Message */
typedef struct
{
    PmlaSrmOverhead_t hdr;
    uint32_t channel;
} PmlaSrmChannelMsg_t;

/* Loader Agent constants */
typedef enum
{
    pmlaSrmClientData_c       = 0x00,
    pmlaSrmClientCtrlFlush_c  = 0x01,
    pmlaSrmClientErrorCode_c  = 0x02,
    pmlaSrmClientChannel_c    = 0x03,
} PmlaSrmOverheadType_t;

/* Fragment size */
#define PMLA_SRM_MAX_FRAGMENT_SIZE  4096

/* Module prefix when using the logging facility */
#define _PMLA_PREFIX "pmla"

/* Macro that logs a socket address */
#define PMLA_LOG_SOCKADDR(level, sockAddr)                                    \
    if ( (sockAddr)->sa_family == AF_INET ) {                                 \
        LOG_STRING(level, _PMLA_PREFIX,                                       \
                   "family=AF_INET, port=%d, address=%s",                     \
                   ntohs(((struct sockaddr_in *)(sockAddr))->sin_port),       \
                   inet_ntoa(((struct sockaddr_in *)(sockAddr))->sin_addr));  \
    } else if ( (sockAddr)->sa_family == AF_UNIX ) {                          \
        LOG_STRING(level, _PMLA_PREFIX, "family=AF_UNIX, path=%s",            \
                   ((struct sockaddr_un *)(sockAddr))->sun_path);             \
    } else {                                                                  \
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "family=Unknown(%d)",              \
                   (sockAddr)->sa_family);                                    \
    }


#endif /* __pmlaSrmCommon_h__ */
