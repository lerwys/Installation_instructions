/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmlaSrmDaemon.c
 *
 * Description:
 *   On the Loader Agent back-end, there is a daemon listening for TCP 
 *   connections.  This deamon is implemented by this file.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmp.h>
#include <pmci.h>
#include <pmlaSrmServer.h>
#include <pmapp.h>
#include <log.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <ctype.h>
#include <sched.h>
#include <errno.h>

#include <sys/ioctl.h>
#include <fcntl.h>
#define RENAME_PM2PME
#include <fsl_pme.h>

/**********************************************************************
 * Macros
 **********************************************************************/

/* Compute a dynamic version for debugging purposes */
#define PMLA_SRMD_VERSION ("v1.1, built on " __DATE__ ", " __TIME__ \
                           " for Freescale")

/* Specify the maximum buffer sizes needed for requests and replies */
#define PMLA_SRMD_BUF_MAX (PMLA_MAX_MSG_SIZE)
#define PMLA_SRMD_REPLY_SIZE_MAX (64*1024)

/* Indicate the maximum file name length for the logging argument */
#define PMLA_MAX_LOG_FNAME_SIZE 80

/* Arguments list and formats */
#define PMLAD_ARG_TCP              "--tcp"
#define PMLAD_ARG_TCP_FORMAT       "[<serverIp>:]<serverPort>"
#define PMLAD_ARG_UNIX             "--unix"
#define PMLAD_ARG_UNIX_FORMAT      "<serverFile>"
#define PMLAD_ARG_DEBUG            "--debug"
#define PMLAD_ARG_INFO             "--info"
#define PMLAD_ARG_VERSION          "--version"
#define PMLAD_ARG_DCD              "--dcd"
#define PMLAD_ARG_CHANNEL          "--channel"
#define PMLAD_ARG_CHANNEL_AUTO     "auto"
#define PMLAD_ARG_CHANNEL_FORMAT   "<channelId>|" PMLAD_ARG_CHANNEL_AUTO
#define PMLAD_ARG_LOGFILE          "--log-file"
#define PMLAD_ARG_LOGFILE_FORMAT   "[<fileName>]"
#define PMLAD_ARG_LEVEL            "--log-level"
#define PMLAD_ARG_LEVEL_FORMAT     "<logLevel>"
#define PMLAD_ARG_STDOUT           "--log-stdout"
#define PMLAD_ARG_HELP             "--help"
#define PMLAD_ARG_PRIORITY         "--priority"
#define PMLAD_ARG_PRIORITY_LOW     "low"
#define PMLAD_ARG_PRIORITY_MED     "med"
#define PMLAD_ARG_PRIORITY_HIGH    "high"
#define PMLAD_ARG_PRIORITY_FORMAT  ( PMLAD_ARG_PRIORITY_LOW "|" \
                                     PMLAD_ARG_PRIORITY_MED "|" \
                                     PMLAD_ARG_PRIORITY_HIGH )
#define PMLAD_ARG_NTP              "--ntp"
#define PMLAD_ARG_NTP_FORMAT       "<ntpServerIp>"

/* To help scope the memory requirements, we limit the number of concurent
 * clients.  This number can be scaled down or up based on the available
 * memory and desired behavior.
 */
#define PMLAD_MAX_CLIENTS 8

/* Defines the macro for computing the channel automatically */
#define PMLAD_CHANNEL_AUTO 0x7fffffff

/* Defines the desired PMCI timeout value */
#define PMLAD_PMCI_TIMEOUT 1

/**********************************************************************
 * Types
 **********************************************************************/

/* Specifies the daemon context */
typedef struct
{
    /* Contains the server binding address (TCP or UNIX) */
    union
    {
        struct sockaddr generic;
        struct sockaddr_in tcp;
        struct sockaddr_un sys;
    };

    /* Holds the PMLA server-side handle */
    PmlaSrmServerObj_t *server;

    /* Holds miscenallenous values derived from calling arguments */
    bool dontCheckForDriver;
    int channel;
    bool logOnFile;
    int priority;

    /* In a multi-threaded application, it is unsafe to malloc() in one thread
     * and to free() the same memory in another thread.  To ensure the daemon
     * is not vulnerable to such scenario, client threads deffer the releasing
     * of memory along with closing any handles and cancelling any threads to 
     * the main thread.  The same one that actually did resources allocation.
     * The mechanism used to deffer such work is through UNIX socket while
     * calling the socketpair() function to create the file descriptors.  To 
     * help following and maintaining the code, we use this structure to 
     * clearly state which handle is the producer and which one is the consumer
     * of the socket pair.  We call the overall structure variable 'release' as
     * this is used to release the resources.
     */
    union
    {
        struct
        {
            int producer;
            int consumer;
        };
        int pair[2];
    } release;

    /* Parent pid */
    int parent;

    /* Tearing down state */
    volatile bool tearingDown;

    /* Address for accessing an NTP server */
    struct sockaddr_in ntp;
} PmlaSrmDaemonObj_t;

/* Specifies the client context */
typedef struct _PmlaSrmDaemonClientObj_tag
{
    /* Poins back to the master daemon context */
    PmlaSrmDaemonObj_t *handle;

    /* Client file descriptor returned from accept on server-side PMLA */
    int transport;

    /* Handle to the PMCI object */
    volatile handle_t controlIf;

    /* Handle to the client's thread */
    pthread_t tid;

    /* Pointer used for memory management (allocation/deallocation) */
    struct _PmlaSrmDaemonClientObj_tag *next;

    /* Little helper to figure out if client is allocated or not */
    bool allocated;

    /* Channel used by this client */
    int channel;
} PmlaSrmDaemonClientObj_t;

/**********************************************************************
 * Private declaration
 **********************************************************************/

static int _help(char *cmd, char *text, bool full);
static int _computeTcpArgs(char *addressPort, struct in_addr *address, 
                           unsigned short *port);
static int _processArguments(PmlaSrmDaemonObj_t *obj, int argn, char *args[]);
static int _checkForDriver(PmlaSrmDaemonObj_t *obj);
#ifdef _PMLAD_MONITOR_ERROR
static void *_monitorHwError(void *arg);
#endif /* _PMLAD_MONITOR_ERROR */
static int  _processLaData(void *arg, void *buf, int bufSize);
static int  _processLaControl(void *arg, void *buf, int bufSize);
static int  _handlePmciRequest(PmlaSrmDaemonClientObj_t *client);
static void *_processRequests(void *args);
static void _destroyClientObject(PmlaSrmDaemonClientObj_t *client);
static void _signalKillHandler(int sigNum);
static void _writeErrorCode(PmlaSrmDaemonClientObj_t *client,
                            PmlaError_t code);
static int _recoverPmDriver(PmlaSrmDaemonClientObj_t *client);
static int _initializeClients(void);
static PmlaSrmDaemonClientObj_t *_allocClient(void);
static void _freeClient(PmlaSrmDaemonClientObj_t *c);
static int _initializeRelease(PmlaSrmDaemonObj_t *obj);
static void _releaseClientObject(PmlaSrmDaemonClientObj_t *client);
static void _destroyAllClientObjects(void);
static void _cleanupClientObject(PmlaSrmDaemonObj_t *obj);
static void _kickoffClientObject(PmlaSrmDaemonObj_t *obj);
static int  _retrieveTimeOfDay(struct timeval *tv, struct timezone *tz);

/**********************************************************************
 * Global Variables
 **********************************************************************/

static PmlaSrmDaemonObj_t _obj;
static PmlaSrmDaemonClientObj_t *_clients;
static PmlaSrmDaemonClientObj_t *_head;
static PmlaSrmDaemonClientObj_t *_tail;
static pthread_mutex_t _mutex;

#ifdef _PMLAD_MONITOR_ERROR
static pthread_t _monitorThread;
#endif /* _PMLAD_MONITOR_ERROR */

/**********************************************************************
 * Implementation
 **********************************************************************/

int main ( int argn, char *args[] )
{
    struct sched_param param;
    struct timeval delay;
    fd_set readSet;
    int n;

    /* Sanitize and process the arguments */
    memset(&_obj, 0, sizeof(_obj));
    if ( _processArguments(&_obj, argn, args) < 0 )
    {
        return _help(args[0], "Bad arguments", false);
    }

    /* Check the presense of the driver */
    if ( _checkForDriver(&_obj) < 0 )
    {
        return _help(args[0], "Driver not loaded", false);
    }

    /* Configure the daemon */
    _obj.server = pmlaSrmServerCreate(&_obj.generic);
    if ( _obj.server == NULL )
    {
        return _help(args[0], "Can't instanciate the server object", false);
    }

    /* Create release pipe and clients memory */
    if ( _initializeRelease(&_obj) < 0 )
    {
        return _help(args[0], "Can't initialize release pipe", false);
    }
    if ( _initializeClients() < 0 )
    {
        return _help(args[0], "Can't initialize clients", false);
    }

    /* It's time to detach ourselves from controlling terminal */
    if ( daemon(!_obj.logOnFile, !_obj.logOnFile) < 0 )
    {
        return _help(args[0], "Can't detach from terminal", false);
    }

    /* Set the daemon's process priority */
    memset(&param, 0, sizeof(param));
    param.__sched_priority = _obj.priority;
    if ( _obj.priority )
    {
        if ( sched_setscheduler(0, SCHED_FIFO, &param) < 0 )
        {
            LOG_STRING(LOG_INFO, _PMLA_PREFIX, "Can't change priority");
        }
    }

    /* Hold on the parent process idenfier */
    _obj.parent = getpid();

    /* Hook to the various signals */
    signal(SIGINT, _signalKillHandler);
    signal(SIGSTOP, _signalKillHandler);
    signal(SIGTERM, _signalKillHandler);
    signal(SIGKILL, _signalKillHandler);
    signal(SIGPIPE, SIG_IGN);

    LOG_STRING(LOG_INFO, _PMLA_PREFIX, "Starting PMLA daemon");

#ifdef _PMLAD_MONITOR_ERROR
    /* Monitor for major hardware error */
    if ( pthread_create(&_monitorThread, NULL, _monitorHwError, &_obj) )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Can't start monitoring thread");
        exit(-1);
    }
#endif /* _PMLAD_MONITOR_ERROR */

    /* Process requests */
    while (1)
    {
        /* Figure out what to do */
        memset(&delay, 0, sizeof(delay));
        delay.tv_sec = PMCI_INFINITE;
        FD_ZERO(&readSet);
        FD_SET(_obj.release.consumer, &readSet);
        FD_SET(pmlaSrmServerGetFd(_obj.server), &readSet);
        n = pmlaSrmServerGetFd(_obj.server);
        if ( _obj.release.consumer > n )
        {
            n = _obj.release.consumer;
        }
        n++;
        if ( select(n, &readSet, NULL, NULL, &delay) < 0 )
        {
            LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "select() failed");
            return -1;
        }
        if ( FD_ISSET(_obj.release.consumer, &readSet) )
        {
            /* We're cleaning up one client */
            LOG_STRING(LOG_INFO, _PMLA_PREFIX, "Cleaning up one client");
            _cleanupClientObject(&_obj);
        }
        if ( FD_ISSET(pmlaSrmServerGetFd(_obj.server), &readSet) )
        {
            /* We're accepting a new client */
            LOG_STRING(LOG_INFO, _PMLA_PREFIX, "Accepting a new client");
            _kickoffClientObject(&_obj);
        }
    }

    /* Should never get here */
    LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Can't reach this poing");

    return 0;
}

/**********************************************************************
 * Private Implementation
 **********************************************************************/

static int _help ( char *cmd, char *text, bool full )
{
    if ( text )
    {
        printf("Error:   %s\n", text);
    }
    printf("Syntax:  %s {%s %s | %s %s}\n"
           "         [%s] [%s] [%s] [%s] [%s %s]\n"
           "         [%s %s] [%s %s] [%s]\n"
           "         [%s %s] [%s %s] [%s]\n",
           cmd,
           PMLAD_ARG_TCP, PMLAD_ARG_TCP_FORMAT,
           PMLAD_ARG_UNIX, PMLAD_ARG_UNIX_FORMAT,
           PMLAD_ARG_DEBUG,
           PMLAD_ARG_INFO,
           PMLAD_ARG_VERSION,
           PMLAD_ARG_DCD,
           PMLAD_ARG_CHANNEL, PMLAD_ARG_CHANNEL_FORMAT,
           PMLAD_ARG_LOGFILE, PMLAD_ARG_LOGFILE_FORMAT,
           PMLAD_ARG_LEVEL, PMLAD_ARG_LEVEL_FORMAT,
           PMLAD_ARG_STDOUT,
           PMLAD_ARG_PRIORITY, PMLAD_ARG_PRIORITY_FORMAT,
           PMLAD_ARG_NTP, PMLAD_ARG_NTP_FORMAT,
           PMLAD_ARG_HELP);
    printf("Options:\n");
    if ( full )
    {
    printf("    %s %s\n", PMLAD_ARG_TCP, PMLAD_ARG_TCP_FORMAT);
    printf("         Instruct the PMLA daemon to use TCP as the transport\n");
    printf("         mechanism.  The binding information must also be\n");
    printf("         provided.  Such information includes the IP address\n");
    printf("         and the TCP port number of the server.  The IP\n");
    printf("         address of the server may be omitted.  In which case\n");
    printf("         any IP addresses managed by the server may be used to\n");
    printf("         connect to PMLA daemon.  Note that the PMLA module\n");
    printf("         only support TCP and UNIX.  One of the two mechanisms\n");
    printf("         must be used.\n");
    printf("    %s %s\n", PMLAD_ARG_UNIX, PMLAD_ARG_UNIX_FORMAT);
    printf("         Instruct the PMLA daemon to use UNIX local socket as\n");
    printf("         the transport mechanism.  The local file used for the\n");
    printf("         communication scheme must also be specified.  Note\n");
    printf("         that the PMLA module only support TCP and UNIX.  One\n");
    printf("         of the mechanisms must be used.\n");
    printf("    %s\n", PMLAD_ARG_DEBUG);
    printf("         Optional argument that enable all log levels.  It is\n");
    printf("         equivalent of using --log-level -1 argument.\n");
    printf("    %s\n", PMLAD_ARG_INFO);
    printf("         Optional argument that enable %s log levels.\n",
           "LOG_INFO");
    printf("         It is equivalent of using --log-level 0x%x argument.\n",
           LOG_INFO);
    printf("    %s\n", PMLAD_ARG_VERSION);
    printf("         Optional argument that display the version of this\n");
    printf("         executable daemon.  Using this argument will not\n");
    printf("         spawn off the PMLA daemon but simply echo the version\n");
    printf("    %s\n", PMLAD_ARG_DCD);
    printf("         During starting up, the PMLA daemon do verify that\n");
    printf("         all required Pattern Matching drivers are loaded and\n");
    printf("         available.  It also hang on to those driver in order\n");
    printf("         prevent any users from removing them during real-time\n");
    printf("         This optional argument means \"Don't Check Driver\"\n");
    printf("         which skip the verifying and holding stage.\n");
    printf("    %s %s\n", PMLAD_ARG_CHANNEL, PMLAD_ARG_CHANNEL_FORMAT);
    printf("         By default, the PMLA daemon determines the DMA\n");
    printf("         channel to use automatically.  This optional argument\n");
    printf("         instructs the PMLA daemon to restricts the desired\n");
    printf("         DMA channel to the specified value.  Note that\n");
    printf("         specifying the value \"%s\" forces the channel to\n",
           PMLAD_ARG_CHANNEL_AUTO);
    printf("         determined automatically as the default.  See the\n");
    printf("         Pattern Matching driver for more details about DMA\n");
    printf("         channels.\n");
    printf("    %s %s\n", PMLAD_ARG_LOGFILE, PMLAD_ARG_LOGFILE_FORMAT);
    printf("         By default, the PMLA daemon redirect all logs to a\n");
    printf("         temporary file named /tmp/pmla.<pid>.log.  This\n");
    printf("         optional argument specifies an alternate file name.\n");
    printf("         Note that not specifying a file name would cause \n");
    printf("         the daemon to revert to /tmp/pmla.<pid>.log.\n");
    printf("    %s %s\n", PMLAD_ARG_LEVEL, PMLAD_ARG_LEVEL_FORMAT);
    printf("         This optional argument specifies the log level.\n");
    printf("    %s\n", PMLAD_ARG_STDOUT);
    printf("         By defaults, all log output get redirected to a file.\n");
    printf("         This optional argument instructs the PMLA daemon to\n");
    printf("         dump the logs on standard output (aka stdout).  Note\n");
    printf("         however that by dumping the logs on stdout, the\n");
    printf("         daemon cannot fully detach itself from the calling\n");
    printf("         shell.  When using this option, exiting from the\n");
    printf("         calling shell will hang until the daemon terminates.\n");
    printf("    %s %s\n", PMLAD_ARG_PRIORITY, PMLAD_ARG_PRIORITY_FORMAT);
    printf("         This optional argument provides the ability to change\n");
    printf("         the process priority for the PMLA daemon. By default,\n");
    printf("         the 'low' priority is used.\n");
    printf("    %s %s\n", PMLAD_ARG_NTP, PMLAD_ARG_NTP_FORMAT);
    printf("         This optional argument provides the ability to use \n");
    printf("         the time retrieved from an NTP server for the purpose\n");
    printf("         of logging.  This option is particularly useful when\n");
    printf("         the clock drift of the running system is such that it\n");
    printf("         cannot be used reliably (i.e. in cosim environment)\n");
    printf("    %s\n", PMLAD_ARG_HELP);
    printf("         Display this screen but not spawn off the daemon.\n");
    }
    else
    {
    printf("    Use %s for more information\n", PMLAD_ARG_HELP);
    }

    return 0;
}

static int _computeTcpArgs(char *addressPort, struct in_addr *address, 
                           unsigned short *port)
{
    size_t i;
    int portPos = 0;

    /* Search for the column optional separator */
    for ( i=0; i<strlen(addressPort); i++ )
    {
        if ( addressPort[i] == ':' )
        {
            portPos = i+1;
            break;
        }
    }

    /* Validate IP address */
    if ( portPos )
    {
        addressPort[portPos-1] = 0;
        if ( inet_aton(addressPort, address) == 0 )
        {
            printf("Invalid IP address (%s)\n", addressPort);
            return -1;
        }
    }
    else
    {
        address->s_addr = htonl(INADDR_ANY);
    }

    /* Validate TCP port */
    *port = htons(atoi(&addressPort[portPos]));
    if ( *port == 0 )
    {
        printf("Invalid TCP port (%s)\n", &addressPort[portPos]);
        return -1;
    }

    return 0;
}

static int _processArguments(PmlaSrmDaemonObj_t *obj, int argn, char *args[])
{
    int i = 1;
    bool gotSocketInfo = false;
    bool useStdout = false;
    char logFile[PMLA_MAX_LOG_FNAME_SIZE];
    int level = PMAPP_DefaultLogLevel_d;

    /* Set non-zero default values */
    sprintf(logFile, "/tmp/pmla.%d.log", getpid());
    obj->channel = PMLAD_CHANNEL_AUTO;

    while ( i < argn )
    {
        /* Process the arguments */
        if ( strcmp(args[i], PMLAD_ARG_TCP) == 0 )
        {
            /* Ensure next argument is present */
            if ( (i+1) >= argn )
            {
                printf("No value for %s\n", args[i]);
                return -1;
            }

            /* Move index to actual argument */
            i++;

            /* Filling in the tcp structure */
            obj->tcp.sin_family = AF_INET;
            if ( _computeTcpArgs(args[i], 
                                 &obj->tcp.sin_addr, 
                                 &obj->tcp.sin_port) < 0 )
            {
                return -1;
            }
            gotSocketInfo = true;
        }
        else if ( strcmp(args[i], PMLAD_ARG_UNIX) == 0 )
        {
            /* Ensure next argument is present */
            if ( (i+1) >= argn )
            {
                printf("No value for %s\n", args[i]);
                return -1;
            }

            /* Move index to actual argument */
            i++;

            /* Filling in the unix structure */
            obj->sys.sun_family = AF_UNIX;
            strcpy(obj->sys.sun_path, args[i]);
            gotSocketInfo = true;
        }
        else if ( strcmp(args[i], PMLAD_ARG_DEBUG) == 0 )
        {
            /* We want debugging */
            level = LOG_ALL;
        }
        else if ( strcmp(args[i], PMLAD_ARG_INFO) == 0 )
        {
            /* We want debugging */
            level |= LOG_INFO;
        }
        else if ( strcmp(args[i], PMLAD_ARG_VERSION) == 0 )
        {
            printf("%s\n", PMLA_SRMD_VERSION);
            exit(0);
        }
        else if ( strcmp(args[i], PMLAD_ARG_DCD) == 0 )
        {
            /* Dont check the presence of the driver */
            obj->dontCheckForDriver = true;
        }
        else if ( strcmp(args[i], PMLAD_ARG_CHANNEL) == 0 )
        {
            /* Ensure next argument is present */
            if ( (i+1) >= argn )
            {
                printf("No value for %s\n", args[i]);
                return -1;
            }

            /* Move index to actual argument */
            i++;

            /* Computing the channel number */
            if ( strcmp(args[i], PMLAD_ARG_CHANNEL_AUTO) == 0 )
            {
                obj->channel = PMLAD_CHANNEL_AUTO;
            }
            else
            {
                sscanf(args[i], "%d", &obj->channel);
            }
        }
        else if ( strcmp(args[i], PMLAD_ARG_LOGFILE) == 0 )
        {
            /* Log file name is optional */

            useStdout = false;

            /* Check to see if there is a file name specified */
            if ( ((i+1) < argn) &&
                 (args[i+1] != NULL) &&
                 (args[i+1][0] != '-') &&
                 (args[i+1][1] != '-') &&
                 (strlen(args[i+1]) < (PMLA_MAX_LOG_FNAME_SIZE-1)) )
            {
                i++;
                sprintf(logFile, "%s", args[i]);
            }
        }
        else if ( strcmp(args[i], PMLAD_ARG_LEVEL) == 0 )
        {
            /* Ensure next argument is present */
            if ( (i+1) >= argn )
            {
                printf("No value for %s\n", args[i]);
                return -1;
            }

            /* Move index to actual argument */
            i++;

            /* Check for a valid log level */
            if ( (args[i][0] == '0') &&
                 (args[i][1] == 'x') )
            {
                if ( (!isxdigit(args[i][2])) ||
                     (strlen(args[i]) <= 2) )
                {
                    printf("Invalid hex log level %s\n", args[i]);
                    return -1;
                }

                /* Hex log level */
                sscanf(&args[i][2], "%x", &level);
            }
            else if ( (isdigit(args[i][0])) ||
                      ((args[i][0] == '-') && (isdigit(args[i][1]))) )
            {
                /* Dec log level */
                sscanf(args[i], "%d", &level);
            }
            else
            {
                /* Invalid log level */
                printf ("Invalid log level %s\n", args[i]);
                return -1;
            }
        }
        else if ( strcmp(args[i], PMLAD_ARG_STDOUT) == 0 )
        {
            /* Forces all output to stdout */
            useStdout = true;
        }
        else if ( strcmp(args[i], PMLAD_ARG_PRIORITY) == 0 )
        {
            /* Ensure next argument is present */
            if ( (i+1) >= argn )
            {
                printf("No priority specified for %s\n", args[i]);
                return -1;
            }

            /* Move index to actual argument */
            i++;
            if ( strcmp(args[i], PMLAD_ARG_PRIORITY_LOW) == 0 )
            {
                obj->priority = 0;
            }
            else if ( strcmp(args[i], PMLAD_ARG_PRIORITY_MED) == 0 )
            {
                obj->priority = 45;
            }
            else if ( strcmp(args[i], PMLAD_ARG_PRIORITY_HIGH) == 0 )
            {
                obj->priority = 90;
            }
            else
            {
                printf ("Invalid priority %s\n", args[i]);
                return -1;
            }
        }
        else if ( strcmp(args[i], PMLAD_ARG_NTP) == 0 )
        {
            /* Ensure next argument is log_mask_setpresent */
            if ( (i+1) >= argn )
            {
                printf("No value for %s\n", args[i]);
                return -1;
            }

            /* Move index to actual argument */
            i++;

            /* Filling in the socket address structure */
            obj->ntp.sin_family = AF_INET;
            obj->ntp.sin_port = htons(123);
            if ( inet_aton(args[i], &obj->ntp.sin_addr) == 0 )
            {
                printf("Invalid IP address (%s)\n", args[i]);
                return -1;
            }

            /* Switch the clock source to our NTP client */
            log_clock_source_set(_retrieveTimeOfDay);
        }
        else if ( strcmp(args[i], PMLAD_ARG_HELP) == 0 )
        {
            _help(args[0], NULL, true);
            exit(0);
        }
        else if ( strcmp(args[i], "--file") == 0 )
        {
            printf ("The option --file is deprecated.  Use --log-file next "
                    "time.\n");
            useStdout = false;
        }
        else
        {
            /* Unrecognize argument */
            printf("Unknown argument %s\n", args[i]);
            return -1;
        }

        /* Move on the next argument */
        i++;
    }

    /* Set the desired log level */
    log_mask_set(level);

    /* Set the log output location */
    if ( useStdout )
    {
        obj->logOnFile = false;
    }
    else
    {
        if ( log_log_to_file(logFile) == HANDLE_NULL )
        {
            printf ("Warning, cannot write to %s.  Redirecting to stdout.\n",
                    logFile);
            log_handle_set(stdout);
            obj->logOnFile = false;
        }
        else
        {
            obj->logOnFile = true;
        }
    }

    /* Ensure the critical arguments has been provided */
    if ( !gotSocketInfo )
    {
        /* Missing socket information --tcp or --unix */
        printf("No transport mechanism specified (use %s or %s)\n",
               PMLAD_ARG_TCP, PMLAD_ARG_UNIX);
        return -1;
    }

    return 0;
}

static int _checkForDriver(PmlaSrmDaemonObj_t *obj)
{
    static char fname[80];
    static char *driver[] = {
        PME_DEV_DB_PATH,
        PME_DEV_SCAN_PATH,
        NULL
    };
    int i = 0;
    int fd;
    bool driverMissing = false;

    if ( !obj->dontCheckForDriver )
    {
        /* Check for the presense of the driver */
        while ( driver[i] != NULL )
        {
            if ( driver[i][strlen(driver[i])-2] == '%' )
            {
                /* If channel is computed automatically, skip this checking */
                if ( obj->channel == PMLAD_CHANNEL_AUTO )
                {
                    i++;
                    continue;
                }
                sprintf (fname, driver[i], obj->channel);
            }
            else
            {
                strcpy (fname, driver[i]);
            }

            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Checking \"%s\"...", fname);
            if ( (fd = open(fname, O_RDWR)) < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Driver \"%s\" missing",
                           fname);
                driverMissing = true;
            }
            else
            {
                close(fd);
            }
            i++;
        }
    }
    
    if ( driverMissing ) return -1;
    else return 0;
}

#ifdef _PMLAD_MONITOR_ERROR
static void *_monitorHwError(void *arg)
{
    PmlaSrmDaemonObj_t *obj = (PmlaSrmDaemonObj_t *)arg;
    struct pm_channel_monitor monitorParam;
    char monitorFn[256];
    int monitorFd;
    int result;
    int mask = 0;

    /* Ensure the thread is cancellable */
    pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
    pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);

    /* Acquire a file descriptor to monitor the channel */
#ifdef PMLAD_MONITOR_ERROR_FROM_CHANNEL
    sprintf(monitorFn, PM_CHANNEL_PATH, obj->channel);
#else
    if ( obj == NULL ) {} /* Eliminate compiler warning */
    sprintf(monitorFn, PM_CTRL_PATH);
#endif /* PMLAD_MONITOR_ERROR_FROM_CHANNEL */
    monitorFd = open(monitorFn, O_RDONLY);
    if ( monitorFd < 0 )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Can't acquire handle");
        return NULL;
    }

    while(1)
    {
        /* Initialize the monitor parameter */
        memset(&monitorParam, 0, sizeof(monitorParam));
        monitorParam.monitor.block = 1;
        monitorParam.monitor.ignore_mask = mask;

        /* Wait for an error code */
#ifdef PMLAD_MONITOR_ERROR_FROM_CHANNEL
        result = ioctl(monitorFd, PM_CHANNEL_IOCTL_MONITOR, &monitorParam);
#else
        result = ioctl(monitorFd, PM_CTRL_IOCTL_MONITOR, 
                       &monitorParam.monitor);
#endif /* PMLAD_MONITOR_ERROR_FROM_CHANNEL */
        if ( result <= 0 )
        {
            LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Unexpected result");
        }
        else
        {
            /* Analyze the status code coming back */
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Status = 0x%x", 
                       monitorParam.monitor.status);
            if ( monitorParam.monitor.status == 0 )
            {
                LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Encountered global error "
                           "0x%x", monitorParam.monitor.status);
                exit(-1);
            }
        }

        mask = monitorParam.monitor.status;
    }
}
#endif /* _PMLAD_MONITOR_ERROR */

static int _processLaData(void *arg, void *buf, int bufSize)
{
    PmlaSrmDaemonClientObj_t *client = (PmlaSrmDaemonClientObj_t *)arg;
    pmci_error_t result;

    /* Write to the PMCI handle */
    result = pmci_write(client->controlIf, buf, bufSize);

    /* Check the result code */
    if ( result != pmci_success_e )
    {
        /* Log the error somehow */
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "ERROR=%d:%s", 
                   result, pmci_error_string(result));
    }

    return 0;
}

static int _processLaControl(void *arg, void *buf, int bufSize)
{
    PmlaSrmDaemonClientObj_t *client = (PmlaSrmDaemonClientObj_t *)arg;
    PmlaSrmOverhead_t prefix;
    pmci_error_t status;

    /* Ensure we've got at least four bytes */
    if ( bufSize < (int)sizeof(int) )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Buffer cannot hold a prefix");
        return -1;
    }

    /* Parse the control request */
    prefix.word = *(uint32_t *)buf;
    if ( prefix.type == pmlaSrmClientCtrlFlush_c )
    {
        /* Block until the whole pipe if flushed out */
        status = pmci_flush(client->controlIf);
        if ( status != pmci_success_e )
        {
            LOG_STRING(LOG_INFO, _PMLA_PREFIX, "ERROR=%d (%d:%s)",
                       status, errno, strerror(errno));
        }
        
        /* Notify the remote client we're done */
        prefix.word = htonl(prefix.word);
        if ( pmlaSrmServerSendControl(client->transport, 
                                      &prefix, sizeof(prefix)) < 0 )
        {
            LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Lost connectivity");
            return -1;
        }
    }
    else
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "ERROR=0x%x", prefix.word);
        return -1;
    }

    return 0;
}

static int _handlePmciRequest(PmlaSrmDaemonClientObj_t *client)
{
    pmp_msg_t *notif;
    pmci_error_t result;

    /* Allocate memory to store the buffer */
    notif = malloc(sizeof(pmp_msg_t));
    if ( notif == NULL )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Can't allocate %Zd bytes of memory",
                   sizeof(pmp_msg_t));
        return -1;
    }

    /* There should be a reply pending.  In not, might need to recover */
    do
    {
        result = pmci_read(client->controlIf, notif);
        if ( result == pmci_lost_driver_e )
        {
            LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Lost driver access, now "
                       "trying to recover...");
            
            if ( _recoverPmDriver(client) < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Failed to recover");
                free(notif);
                return -1;
            }
        }
    } while (result == pmci_lost_driver_e);
    
    /* Don't process further if no data was provided */
    if ( result == pmci_empty_read_e  )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "No data process");
        free(notif);
        return 0;
    }
    if ( result != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
                   "Can't access the control interface and/or driver (%d)",
                   result);
        free(notif);
        return -1;
    }

    /* Ensure that the data provided by the control interface is valid */
    if ( notif->header.protocolVersion != PMP_CURRENT_VERSION )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Invalid protocol version "
                   "(bufSize=%d)", notif->header.msgLength);
        LOG_MEMORY_DUMP(LOG_WARNING, _PMLA_PREFIX, notif, 
                        notif->header.msgLength);
        free(notif);
        return -1;
    }

    /* Injecting this data back up */
    if (pmlaSrmServerSendData(client->transport, notif, 
                              notif->header.msgLength) < 0)
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Lost connectivity");
        free(notif);
        return -1;
    }

    free(notif);
    return 0;
}

static void *_processRequests(void *arg)
{
    PmlaSrmDaemonClientObj_t *client = (PmlaSrmDaemonClientObj_t *)arg;
    fd_set readSet;
    int result;
    int n;

    /* Initialize the thread */
    client->tid = pthread_self();

    /* Process requests forever */
    while (1)
    {
        /* Requests may come from either the PMLA or PMCI side */
        FD_ZERO(&readSet);
        PMCI_FD_SET(client->controlIf, &readSet);
        n = PMCI_FD_GETN(client->controlIf);
        FD_SET(client->transport, &readSet);
        if ( client->transport > n ) n = client->transport;
        n++;
        if ( select(n, &readSet, NULL, NULL, NULL) < 0 )
        {
            /* Check if main thread is tearing down all client threads */
            if ( client->handle->tearingDown )
            {
                return NULL;
            }

            /* Continue if this error is a result of interrupt system call */
            if ( errno == EINTR )
            {
                LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Got a system call");
                FD_ZERO(&readSet);
                continue;
            }

            /* If neither tearing down or interrupted, that's an error */
            LOG_STRING(LOG_INFO, _PMLA_PREFIX, "select() failed with %d:%s",
                       errno, strerror(errno));
            break;
        }

        /* Process request from PMCI */
        if ( PMCI_FD_ISSET(client->controlIf, &readSet) )
        {
            result = _handlePmciRequest(client);
            if ( result < 0 )
            {
                LOG_STRING(LOG_TEST, _PMLA_PREFIX,
                           "Can't process from PMCI (%d)", result);
                break;
            }
        }

        /* Process request from PMLA */
        if ( FD_ISSET(client->transport, &readSet) )
        {
            result = pmlaSrmServerRecv(client->transport, 
                                       arg, _processLaData, _processLaControl);
            
            if ( result < 0 )
            {
                if ( errno != 0 )
                {
                    LOG_STRING(LOG_TEST, _PMLA_PREFIX, 
                               "Can't process from PMLA (%d: %d=%s)",
                               result, errno, strerror(errno));
                }
                break;
            }
        }
    }

    /* We're terminating or we've got an error */
    _destroyClientObject(client);

    return NULL;
}

static void _destroyClientObject(PmlaSrmDaemonClientObj_t *client)
{
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Postponing release of %p", client);

    if ( send(_obj.release.producer, &client, sizeof(client), 0) < 0 )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Can't release %p", client);
    }
}

static void _writeErrorCode(PmlaSrmDaemonClientObj_t *client,
                            PmlaError_t code)
{
    PmlaSrmErrorCodeMsg_t prefix;

    /* Write a control message back to the client */
    prefix.hdr.type = pmlaSrmClientErrorCode_c;
    prefix.hdr.length = sizeof(prefix.code);
    prefix.hdr.word = htonl(prefix.hdr.word);
    prefix.code = htonl(code);
    if ( pmlaSrmServerSendControl(client->transport, 
                                  &prefix, sizeof(prefix)) < 0 )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX,
                   "Could not send error code back to client");
    }
}

static void _signalKillHandler(int sigNum)
{
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, 
               "Interrupted PID %d abruptly signal number %d.", 
               getpid(), sigNum);

    if ( _obj.parent == getpid() )
    {
        /* Indicate to everyone that we're being teardown */
        if ( _obj.tearingDown )
        {
            LOG_STRING(LOG_ERROR, _PMLA_PREFIX, 
                       "Not supporting nested signals");
            return;
        }
        _obj.tearingDown = true;

#ifdef _PMLAD_MONITOR_ERROR
        /* Stop the monitoring thread */
        if ( pthread_cancel(_monitorThread) != 0 )
        {
            LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Can't cancel monitor "
                       "thread");
        }
#endif /* _PMLAD_MONITOR_ERROR */
        
        /* Destroy all pending clients and its memory */
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Destroying all clients");
        _destroyAllClientObjects();
        free(_clients);

        /* Do our best to gracefully shutdown the daemon */
        pmlaSrmServerDestroy(_obj.server);
        
        /* Deregistering the signal */
        signal(SIGINT, SIG_DFL);
        signal(SIGSTOP, SIG_DFL);
        signal(SIGTERM, SIG_DFL);
        signal(SIGKILL, SIG_DFL);
        
        LOG_STRING(LOG_INFO, _PMLA_PREFIX, "Stopping PMLA daemon");
        
        /* We're gone */
        exit(0);
    }
    else
    {
        LOG_STRING(LOG_INFO, _PMLA_PREFIX, 
                   "Ignoring signals on client's threads");
    }
}

static int _recoverPmDriver(PmlaSrmDaemonClientObj_t *client)
{
    handle_t handle;
    int retry = 60;
    int timeout = PMLAD_PMCI_TIMEOUT;
    pmci_error_t status;

    /* Tear down all existing driver handle */
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Closing PMCI handle");
    if ( pmci_close(client->controlIf) != pmci_success_e )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Failed to close PMCI handle");
    }
    client->controlIf = HANDLE_NULL;

    /* Reopen the driver */
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Reopen PMCI handle");
    do 
    {
        sleep(2);
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Retrying...");
        status = pmci_open(client->channel, &handle);
        if ( status != pmci_success_e )
        {
            if ( retry-- < 0 )
            {
                return -1;
            }
        }
    } while (handle == HANDLE_NULL);

    /* Recovered a driver handle, adjusting timeout value */
    if ( pmci_set_option(handle, pmci_option_timeout_e, 
                       &timeout, sizeof(timeout)) != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
                   "Could not set PMCI timeout value to %d", timeout);
    }

    /* Make the newly open handle available */
    LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
               "Recovered using handle %p in %d retries", handle, 61-retry);
    client->controlIf = handle;

    return 0;
}

static int _initializeClients(void)
{
    int i;

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Initializing client memory");

    /* Allocating a huge memory chunk */
    _clients = malloc(PMLAD_MAX_CLIENTS * sizeof(PmlaSrmDaemonClientObj_t));
    if ( _clients == NULL )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Failed to allocate memory");
        return -1;
    }

    /* Set the head and tail */
    _head = &_clients[0];
    _tail = &_clients[PMLAD_MAX_CLIENTS-1];

    /* Link all blocks together and clear memory */
    for ( i=0; i<(PMLAD_MAX_CLIENTS-1); i++ )
    {
        memset(&_clients[i], 0, 128);
        _clients[i].next = &_clients[i+1];
        _clients[i].allocated = false;
    }
    _clients[PMLAD_MAX_CLIENTS-1].next = NULL;
    _clients[PMLAD_MAX_CLIENTS-1].allocated = false;

    /* Initialize the mutex */
    if ( pthread_mutex_init(&_mutex, NULL) < 0 )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Can't initialize mutex");
        return -1;
    }

    return 0;
}

static PmlaSrmDaemonClientObj_t *_allocClient(void)
{
    PmlaSrmDaemonClientObj_t *client;

    /* Ensure we're the only one accessing these resources */
    if ( pthread_mutex_lock(&_mutex) != 0 )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Can't lock mutex");
        return NULL;
    }

    /* Return NULL if there is no more client memory available.  Indeed, that's
     * wasting one client memory but it certainly simplyfies the management of 
     * memory by quite a bit.
     */
    if ( _head == _tail )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Out of client memory");
        client = NULL;
    }
    else
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Handing out %p", _head);
        
        /* Allocate one client memory */
        client = _head;
        _head = _head->next;
        client->next = NULL;
        client->allocated = true;
    }

    /* Ok, we're done */
    if ( pthread_mutex_unlock(&_mutex) != 0 )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Can't unlock mutex");
    }

    return client;
}

static void _freeClient(PmlaSrmDaemonClientObj_t *c)
{
    /* Ensure we're the only one accessing these resources */
    if ( pthread_mutex_lock(&_mutex) != 0 )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Can't lock mutex");
        return;
    }

    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Taking back %p", c);

    /* Release the client memory */
    c->allocated = false;
    _tail->next = c;
    c->next = NULL;
    _tail = c;

    /* Ok, we're done */
    if ( pthread_mutex_unlock(&_mutex) != 0 )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "Can't unlock mutex");
    }
}

static int _initializeRelease(PmlaSrmDaemonObj_t *obj)
{
    if ( socketpair(AF_UNIX, SOCK_DGRAM, 0, obj->release.pair) < 0 )
    {
        return -1;
    }
    return 0;
}

static void _releaseClientObject(PmlaSrmDaemonClientObj_t *client)
{
    LOG_STRING(LOG_TEST, _PMLA_PREFIX, "Releasing %p", client);

    /* Close the transport handle */
    if ( close(client->transport) < 0 )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
                   "Could not close loader agent handle properly");
    }

    /* Close the control interface handle */
    if ( pmci_close(client->controlIf) != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
                   "Could not close control interface properly");
    }

    /* By now, this thread should be in a canceled state */
    if ( pthread_join(client->tid, NULL) != 0 )
    {
        LOG_STRING(LOG_TEST, _PMLA_PREFIX,
                   "Could not cleanup the thread properly");
    }

    /* Release the memory for that client */
    _freeClient(client);
}

static void _destroyAllClientObjects(void)
{
    int i;
    struct linger linger = { 1, 0 };

    for (i=0; i<PMLAD_MAX_CLIENTS; i++ )
    {
        if ( _clients[i].allocated == true )
        {
            /* Change option on the transport socket to cause an abort */
            if ( setsockopt(_clients[i].transport, 
                            SOL_SOCKET, SO_LINGER, 
                            &linger, sizeof(linger)) < 0 )
            {
                LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Can't set SO_LINGER");
            }

            /* Release the client */
            _releaseClientObject(&_clients[i]);
        }
    }
}

static void _cleanupClientObject(PmlaSrmDaemonObj_t *obj)
{
    PmlaSrmDaemonClientObj_t *client;

    if ( recv(obj->release.consumer, &client, sizeof(client), 0) < 0 )
    {
        LOG_STRING(LOG_ERROR, _PMLA_PREFIX, "recv() failed");
        return;
    }

    _releaseClientObject(client);
}

static void _kickoffClientObject(PmlaSrmDaemonObj_t *obj)
{
    PmlaSrmDaemonClientObj_t *client;
    pthread_t tid;
    int sock;
    uint32_t channel;
    int timeout = PMLAD_PMCI_TIMEOUT;
    pmci_error_t status;
    int tstatus;

    /* Waiting for a new connection */
    sock = pmlaSrmServerAccept(obj->server, &channel);
    if ( sock < 0 )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX,"Can't accept connections!");
        return;
    }
    
    /* Allocate memory for a potential connection */
    client = _allocClient();
    if ( client == NULL )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "Can't allocate client");

        /* Write an error code and destroy the client */
        close(sock);
        return;
    }

    /* Determine the channel to use */
    if ( obj->channel != PMLAD_CHANNEL_AUTO )
    {
        LOG_STRING(LOG_INFO, _PMLA_PREFIX, "Client requested channel %d, "
                   "server overwrote it with %d", channel, obj->channel);
        channel = obj->channel;
    }
    
    /* Create the control interface underlying handle */
    client->channel = channel;
    client->handle = obj;
    client->transport = sock;
    status = pmci_open(channel, (handle_t *)&client->controlIf);
    if ( status != pmci_success_e )
    {
        LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
                   "Can't create a control interface handle (%d:%s)",
                   status, pmci_error_string(status));
        
        /* Write an error code and destroy the client */
        _writeErrorCode(client, pmlaTargetHwFailure_c);
        _destroyClientObject(client);
    }
    else
    {
        /* Associate the handle with right timeout value for pmci_read() */
        status = pmci_set_option(client->controlIf, pmci_option_timeout_e, 
                               &timeout, sizeof(timeout));
        if ( status != pmci_success_e )
        {
            LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
                       "Could not set PMCI timeout value to %d (%d:%s)",
                       timeout, status, pmci_error_string(status));
        }

        
        /* Kick start the associated threads */
        tstatus = pthread_create(&tid, NULL, _processRequests, client);
        if ( tstatus )
        {
            LOG_STRING(LOG_WARNING, _PMLA_PREFIX, "No thread! (%d:%s)",
                       tstatus, strerror(tstatus));
            _writeErrorCode(client, pmlaTargetSwFailure_c);
            _destroyClientObject(client);
        }
        else
        {
            /* Write a successful error code back to client */
            _writeErrorCode(client, pmlaSuccess_c);
        }
    }
}

/**********************************************************************
 * The code below should be moved to a shared library later.  For now,
 * since we are just establishing a proof of concept, we keep it here
 * temporarily.
 */

/* The include files we need to retrieved time from external server */
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <time.h>

/* NTP time stamp represents seconds since January 1st 1900 whereas
 * Linux/Unix time stamp represents seconds since January 1st 1970.  RFC868
 * highlights this differences and the macro below reflects this offset.
 */
#define RFC868_1900_1970 (0x83AA7E80)

/* The fraction portion of the NTP time stamp is a little tricky.  Each unit
 * in that field represents 1/2^32 seconds.  That's 1/4294967296.  Since we're
 * interesting in micro-seconds, we use 1/4295.  That not the most precise
 * convertion but that should be adequate for our goals.
 */
#define RFC1305_FRAC_FACTOR (4295)

/* An NTP timestamp is composed of seconds and fraction of a second */
typedef struct
{
    unsigned sec;
    unsigned usec;
} NtpTimeStamp_t;

/* An NTP packet is defined as below.  See RFC4330 for details on SNTP. */
typedef union
{
    unsigned int words[0];

    struct
    {
#if __BYTE_ORDER == __LITTLE_ENDIAN
        unsigned int   precision : 8;
        unsigned int   poll      : 8;
        unsigned int   stratum   : 8;
        unsigned int   mode      : 3;
        unsigned int   vn        : 3;
        unsigned int   li        : 2;
#else
        unsigned int   li        : 2;
        unsigned int   vn        : 3;
        unsigned int   mode      : 3;
        unsigned int   stratum   : 8;
        unsigned int   poll      : 8;
        unsigned int   precision : 8;
#endif /* __BYTE_ORDER */

        unsigned int   rootDelay;
        unsigned int   rootDisp;
        unsigned int   refId;

        NtpTimeStamp_t ref;
        NtpTimeStamp_t orig;
        NtpTimeStamp_t rx;
        NtpTimeStamp_t tx;

        unsigned int   keyId;

        /* The field below is not used by SNTP */
        /* unsigned char digest[128]; */
    };
} NtpPacket_t;        

typedef struct
{
    int                sock;
    struct sockaddr_in sin;
    socklen_t          sinLen;
    NtpPacket_t        pkt;
    char               dateStr[256];
} SntpClientContext_t;

static int _retrieveTimeOfDay(struct timeval *tv, struct timezone *tz)
{
    int result;
    struct timeval option;
    SntpClientContext_t *ctx;
    static int numFailure = 0;

    /* Allocate some memory to operation as an SNTP client */
    ctx = malloc(sizeof(SntpClientContext_t));
    if ( ctx == NULL )
    {
        /* Can't allocate memory */
        return -1;
    }

    /* Not using time zone for now */
    memset(tz, 0, sizeof(struct timezone));

    /* Prepare the message and the context */
    memset(ctx, 0, sizeof(SntpClientContext_t));
    ctx->pkt.vn = 4;   /* Use NTP version 4 messages */
    ctx->pkt.mode = 3; /* Operate as a client */
    ctx->pkt.words[0] = htonl(ctx->pkt.words[0]);

    /* Open a UDP socket */
    ctx->sock = socket(PF_INET, SOCK_DGRAM, 0);
    if ( ctx->sock < 0 )
    {
        /* Can't create UDP socket */
        free(ctx);
        return -1;
    }

    /* Set a receive timeout of 2 seconds */
    option.tv_sec = 2;
    option.tv_usec = 0;
    result = setsockopt(ctx->sock, SOL_SOCKET, SO_RCVTIMEO, 
                        &option, sizeof(option));
    if ( result < 0 )
    {
        /* Can't set timeout of 2 seconds */
        close(ctx->sock);
        free(ctx);
        return -1;
    }
    
    /* Send the request */
    result = sendto(ctx->sock, &ctx->pkt, sizeof(ctx->pkt), 0, 
                    (struct sockaddr *)&_obj.ntp, sizeof(_obj.ntp));
    if ( result < 0 )
    {
        /* Can't send SNTP request */
        close(ctx->sock);
        free(ctx);
        return -1;
    }

    /* Retrieve the response */
    memset(&ctx->sin, 0, sizeof(ctx->sin));
    ctx->sinLen = sizeof(ctx->sin);
    result = recvfrom(ctx->sock, &ctx->pkt, sizeof(ctx->pkt), 0, 
                      (struct sockaddr *)&ctx->sin, &ctx->sinLen);
    if ( result != sizeof(ctx->pkt) )
    {
        if ( ++numFailure >= 3 )
        {
            /* Our NTP timestamp mechanism isn't working, rolling back to 
             * the default mechanism.
             */
            log_clock_source_set(gettimeofday);
            LOG_STRING(LOG_WARNING, _PMLA_PREFIX, 
                       "NTP Timestamping isn't working; disabling it");
            close(ctx->sock);
            free(ctx);
            return gettimeofday(tv, tz);
        }
        close(ctx->sock);
        free(ctx);
        return -1;
    }
    numFailure = 0;

    /* Interpret the result */
    tv->tv_sec =  (uint32_t)(ntohl(ctx->pkt.rx.sec)) - RFC868_1900_1970;
    tv->tv_usec = (uint32_t)(ntohl(ctx->pkt.rx.usec)) / RFC1305_FRAC_FACTOR;
    
    close(ctx->sock);
    free(ctx);
    return 0;
}
