/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef __pmlaSrmClient_h__
#define __pmlaSrmClient_h__

/**********************************************************************
 * File:  pmlaSrmClient.h
 *
 * Description:
 *   The Simple Remotely Managed reference implementation has two modules.
 *   The client module is implemented by this file.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <generic_types.h>
#include <pmlaSrmCommon.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <pthread.h>

/**********************************************************************
 * Macros
 **********************************************************************/

#define PMLA_SRM_CLIENT_RETRY_MAX 16

/**********************************************************************
 * Types
 **********************************************************************/

typedef union
{
    struct
    {
        int producer;
        int consumer;
    };
    int pair[2];
} PmlaSrmProxy_t;

typedef struct
{
    int server;
    PmlaSrmProxy_t data;
    PmlaSrmProxy_t ctrl;
    pthread_t consumerTid;
    int probeDelay;
    int retry;
    volatile bool pending;
} PmlaSrmClientObj_t;

/**********************************************************************
 * Interface
 **********************************************************************/

PmlaSrmClientObj_t *pmlaSrmClientCreate(void);
int pmlaSrmClientSetKeepalive(PmlaSrmClientObj_t *handle, int probeDelay);
int pmlaSrmClientGetKeepalive(PmlaSrmClientObj_t *handle);
int pmlaSrmClientSend(PmlaSrmClientObj_t *handle, void *buf, int bufSize);
int pmlaSrmClientRecv(PmlaSrmClientObj_t *handle, void *buf, int bufSize, 
                      int timeout);
int pmlaSrmClientFlush(PmlaSrmClientObj_t *handle);
int pmlaSrmClientConnect(PmlaSrmClientObj_t *handle, struct sockaddr *dest, 
                         uint32_t channel, int timeout);
int pmlaSrmClientGetErrorCode(PmlaSrmClientObj_t *handle);
int pmlaSrmClientDisconnect(PmlaSrmClientObj_t *handle);
int pmlaSrmClientDestroy(PmlaSrmClientObj_t *handle);

#endif /* __pmlaSrmClient_h__ */
