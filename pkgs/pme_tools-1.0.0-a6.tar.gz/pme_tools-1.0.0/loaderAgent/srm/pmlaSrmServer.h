/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef __pmlaSrmServer_h__
#define __pmlaSrmServer_h__

/**********************************************************************
 * File:  pmlaSrmServer.h
 *
 * Description:
 *   The Simple Remotely Managed reference implementation has two modules.
 *   The server module is declared by this file.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <generic_types.h>
#include <pmlaSrmCommon.h>
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <pthread.h>
#include <sys/un.h>

/**********************************************************************
 * Types
 **********************************************************************/

typedef struct
{
    int server;
} PmlaSrmServerObj_t;

typedef int (*PmlaSrmServerHandler_t)(void *arg, void *buf, int bufSize);

/**********************************************************************
 * Interface
 **********************************************************************/

PmlaSrmServerObj_t *pmlaSrmServerCreate(struct sockaddr *sa);
int pmlaSrmServerAccept(PmlaSrmServerObj_t *handle, uint32_t *channel);
int pmlaSrmServerSendData(int client, void *buf, int bufSize);
int pmlaSrmServerSendControl(int client, void *buf, int bufSize);
int pmlaSrmServerRecv(int client, void *arg, 
                      PmlaSrmServerHandler_t data,
                      PmlaSrmServerHandler_t control);
int pmlaSrmServerDestroy(PmlaSrmServerObj_t *handle);
int pmlaSrmServerGetFd(PmlaSrmServerObj_t *handle);

#endif /* pmlaSrmServer_h__ */
