/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmlaSlmClientTest.c
 *
 * Description:
 *   This file represent a unit test utility to excercise the Simple
 *   Remotely Managed Loader Agent client library.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <pmla.h>
#include <pmp.h>
#include <pmci.h>
#include <pmapp.h>
#include <log.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>

/**********************************************************************
 * Types
 **********************************************************************/

#define PMLA_SRM_HIGHLIGHT_RED   "\033[1;37;41m"
#define PMLA_SRM_HIGHLIGHT_GREEN "\033[1;37;42m"
#define PMLA_SRM_HIGHLIGHT_OFF   "\033[0m"

#define PMLA_SRM_CLIENT_TEST_DATA_SIZE 20
#define PMLA_SRM_CLIENT_TEST_SIZE 65536

#define _PMLA_TEST "test"

#define _PMLA_TEST_LOG(testObj, format, ...)                                  \
    do {                                                                      \
        if ( (testObj)->level == LOG_TMP ) {                                  \
            LOG_STRING((testObj)->level, _PMLA_TEST, format, ##__VA_ARGS__);  \
        } else {                                                              \
            printf(format "\n", ##__VA_ARGS__);                               \
        }                                                                     \
    } while(0)

typedef struct
{
    PmlaTarget_t target;
    handle_t handle;
    bool regress;
    bool sanitize;
    bool skipLongTests;
    log_log_Level_t level;
    int firstTid;
    int lastTid;
    int skipTid;
    bool crash;
    bool runOnTarget;
    bool hideHighlights;
    bool local;

    int numRules;
    int numSession;
    int ctxSize;
} PmlaSrmClientTestObj_t;

#define PMLA_SRM_CLIENT_TEST_PATTERN1 "Bonjour la police!"
#define PMLA_SRM_CLIENT_TEST_PATTERN2 "AAAABBBBCCCCDDDDzzzzyyyyxxxxwwww"

/**********************************************************************
 * Private declaration
 **********************************************************************/

extern int _pmci_max_index_get(pmp_table_id_t tableId);
extern int _pmci_record_size_get(pmp_table_id_t tableId);

static int _help(char *cmd, char *text );
static int _computeTcpArgs(char *addressPort, struct in_addr *address, 
                           unsigned short *port);
static int _processArguments(PmlaSrmClientTestObj_t *obj, 
                             int argn, char *args[]);

static int _clearAllEntries(PmlaSrmClientTestObj_t *obj, 
                            pmp_table_id_t tableId);
static int _writeEntry(PmlaSrmClientTestObj_t *obj, pmp_table_id_t tableId,
                       uint32_t tindex, void *data);
static int _readEntry(PmlaSrmClientTestObj_t *obj, pmp_table_id_t tableId,
                      uint32_t tindex, void *data);
static int _scanData(PmlaSrmClientTestObj_t *obj, 
                     uint8_t set, uint16_t subset,
                     uint32_t sessionId, void *data, int dataLen,
                     bool expectMatch);

static int _testMultiEntry(PmlaSrmClientTestObj_t *obj, pmp_table_id_t tableId,
                           uint32_t tindex);
static int _testSingleEntry(PmlaSrmClientTestObj_t *obj, 
                            pmp_table_id_t tableId);
static int _testBasicSanity(PmlaSrmClientTestObj_t *obj);
static int _testErrorCode(PmlaSrmClientTestObj_t *obj);
static int _testReadWriteTable(PmlaSrmClientTestObj_t *obj);
static int _testPartialWriteTable(PmlaSrmClientTestObj_t *obj);
static int _testResetTable(PmlaSrmClientTestObj_t *obj);
static int _testAttributes(PmlaSrmClientTestObj_t *obj);
static int _testClearContextBySessionId(PmlaSrmClientTestObj_t *obj);
static int _testClearContextByRuleId(PmlaSrmClientTestObj_t *obj);
static int _testClearAllContext(PmlaSrmClientTestObj_t *obj);
static int _testEmptyAtomicity(PmlaSrmClientTestObj_t *obj);
static int _testAtomicity(PmlaSrmClientTestObj_t *obj);
static int _testScanData(PmlaSrmClientTestObj_t *obj);
static int _testBulk(PmlaSrmClientTestObj_t *obj);
static int _testDataAppClearBySessionId(PmlaSrmClientTestObj_t *obj);
static int _testOpenCloseRepetition(PmlaSrmClientTestObj_t *obj);
static int _testOpenCloseCapacity(PmlaSrmClientTestObj_t *obj);
static int _testDone(PmlaSrmClientTestObj_t *obj, int numErrors);
static void _signalHandler(int signum);
static void _quit(PmlaSrmClientTestObj_t *obj);
static int _getCommonParameters(PmlaSrmClientTestObj_t *obj);
static int _firstSessionCl(PmlaSrmClientTestObj_t *obj, int sessionId); 
/**********************************************************************
 * Unit Test
 **********************************************************************/

static struct timespec _t1, _t2, _tx;
static PmlaSrmClientTestObj_t _obj;

int main ( int argn, char *args[] )
{
    int errorCount = 0;
    PmlaError_t code;
    /* Register to the various signal */

    signal(SIGINT, _signalHandler);
    signal(SIGQUIT, _signalHandler);
    signal(SIGSTOP, _signalHandler);
    signal(SIGTERM, _signalHandler);
    signal(SIGKILL, _signalHandler);
    signal(SIGURG, _signalHandler); 
    signal(SIGSYS, _signalHandler);
    /* Take a snapshot of the time */
    if ( clock_gettime(CLOCK_REALTIME, &_t1) != 0 )
    {
        _PMLA_TEST_LOG(&_obj, "Can't get time");
        return -1;
    }
    _tx = _t1;

    /* Sanitize and process the arguments */
    if ( _processArguments(&_obj, argn, args) < 0 )
    {
        return _help(args[0], "Bad arguments");
    }

    /* Instanciate a PMLA handle */
    code = pmlaOpen(&_obj.target, &_obj.handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(&_obj, "Can't create PMLA handle (%d:%s)",
                       code, pmlaErrorString(code));
        return -1;
    }

    /* Connect to target */
    code = pmlaConnect(_obj.handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(&_obj, "Can't connect to target (%d:%s)", 
                       code, pmlaErrorString(code));
        return -1;
    }
    if(_getCommonParameters(&_obj))
    {
        _PMLA_TEST_LOG(&_obj, "Can't get all common attributes\n");
        return -1;
    }

    /* Run the tests */
    system("date");
    printf("======================================================"
           "================\n");
    if ( _obj.sanitize )
    {
        _PMLA_TEST_LOG(&_obj, "SUITE:  Sanity");
        errorCount += _testBasicSanity(&_obj);
    }
    if ( _obj.regress )
    {
        _PMLA_TEST_LOG(&_obj, "SUITE:  Regression");
        errorCount += _testErrorCode(&_obj);
        errorCount += _testReadWriteTable(&_obj);
        errorCount += _testPartialWriteTable(&_obj);
        errorCount += _testResetTable(&_obj);
        errorCount += _testAttributes(&_obj);
        errorCount += _testClearContextBySessionId(&_obj);
        if(0 == 1) {
            // TODO Don't run this until figure out what it is suppose to do.
            errorCount += _testClearContextByRuleId(&_obj);
        }
        errorCount += _testClearAllContext(&_obj);
        errorCount += _testEmptyAtomicity(&_obj);
        if(!_obj.local)
        {
            // Can't work unless we have timeout for pmciWrite.
            errorCount += _testAtomicity(&_obj);
        }
        errorCount += _testScanData(&_obj);
        errorCount += _testOpenCloseRepetition(&_obj);
        
        if(!_obj.local)
        {
            // Not implemented nor needed in local PMLA
            errorCount += _testBulk(&_obj);
            errorCount += _testOpenCloseCapacity(&_obj);
        }
    }
    if ( _obj.crash )
    {
        _PMLA_TEST_LOG(&_obj, "SUITE:  Special case");
        errorCount += _testReadWriteTable(&_obj);
    }
    if ( _obj.runOnTarget )
    {
        _PMLA_TEST_LOG(&_obj, "SUITE:  Target specific tests");
        errorCount += _testDataAppClearBySessionId(&_obj);
    }

    printf("======================================================"
           "================\n");

    /* Flush out everyting before disconnecting */
    code = pmlaFlush(_obj.handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(&_obj, "Can't flush (%d:%s)",
                       code, pmlaErrorString(code));
    }

    _PMLA_TEST_LOG(&_obj, "Tests completed with %d errors", errorCount);

    _quit(&_obj);
    
    if(errorCount) return 2;
    return 0;
}

/**********************************************************************
 * Private Implementation
 **********************************************************************/

static int _help ( char *cmd, char *text )
{
    printf ("%s\n", text);
    printf ("Syntax:  %s {--tcp <serverIp>:<serverPort> | "
            "--unix <serverFile>}\n", cmd);
    printf ("            [--sanitize] [--regress] [--debug] [--skiplong]\n");
    printf ("            [--tid <tableId>] [--notid <tableId>] [--crash]\n");
    printf ("            [--nohighlights] [--channel <channelNo>] [--local]\n");

    return 1;
}

static int _computeTcpArgs(char *addressPort, struct in_addr *address, 
                           unsigned short *port)
{
    size_t i;
    int portPos = 0;

    /* Search for the column optional separator */
    for ( i=0; i<strlen(addressPort); i++ )
    {
        if ( addressPort[i] == ':' )
        {
            portPos = i+1;
            break;
        }
    }

    /* Validate IP address */
    if ( portPos )
    {
        addressPort[portPos-1] = 0;
        if ( inet_aton(addressPort, address) == 0 )
        {
            return -1;
        }
    }
    else
    {
        /* Hey, no IP address provided */
        return -1;
    }

    /* Validate TCP port */
    *port = htons(atoi(&addressPort[portPos]));
    if ( *port == 0 )
    {
        return -1;
    }

    return 0;
}

static int _processArguments ( PmlaSrmClientTestObj_t *obj, 
                               int argn, char *args[] )
{
    int i = 1;
    struct sockaddr_in *inetAddr = (struct sockaddr_in *)&obj->target.addr;
    struct sockaddr_un *unixAddr = (struct sockaddr_un *)&obj->target.addr;

    if ( argn < 2 ) return -1;

    memset(obj, 0, sizeof(PmlaSrmClientTestObj_t));
    obj->level = LOG_TEST;
    log_mask_set(LOG_ERROR | LOG_WARNING);
    obj->firstTid = pmp_table_id_first_table_id_e;
    obj->lastTid = pmp_table_id_last_table_id_e;
    obj->skipTid = pmp_table_id_last_table_id_e + 1;

    while ( i < argn )
    {
        /* Process the arguments */
        if ( strcmp(args[i], "--tcp") == 0 )
        {
            /* Move index to actual argument */
            i++;

            /* Filling in the tcp structure */
            inetAddr->sin_family = AF_INET;
            if ( _computeTcpArgs(args[i], 
                                 &inetAddr->sin_addr, 
                                 &inetAddr->sin_port) < 0 )
            {
                return -1;
            }
        }
        else if ( strcmp(args[i], "--unix") == 0 )
        {
            /* Move index to actual argument */
            i++;

            /* Filling in the unix structure */
            unixAddr->sun_family = AF_UNIX;
            strcpy(unixAddr->sun_path, args[i]);
        }
        else if ( strcmp(args[i], "--channel") == 0 )
        {
            /* Move index to actual argument */
            i++;

            /* Setting the channel */
            sscanf(args[i], "%d", &obj->target.channel);
        }
        else if ( strcmp(args[i], "--sanitize") == 0 )
        {
            /* We want sanity */
            obj->sanitize = true;
        }
        else if ( strcmp(args[i], "--regress") == 0 )
        {
            /* We want regression */
            obj->regress = true;
        }
        else if ( strcmp(args[i], "--debug") == 0 )
        {
            /* We want full debugging */
            obj->level = LOG_TMP;
            log_mask_set(LOG_ALL);
            log_handle_set(stdout);
        }
        else if ( strcmp(args[i], "--skiplong") == 0 )
        {
            /* Don't execute long tests */
            obj->skipLongTests = true;
        }
        else if ( strcmp(args[i], "--tid") == 0 )
        {
            i++;
            sscanf(args[i], "%d", &obj->firstTid);
            obj->lastTid = obj->firstTid;
        }
        else if ( strcmp(args[i], "--notid") == 0 )
        {
            i++;
            sscanf(args[i], "%d", &obj->skipTid);
        }
        else if ( strcmp(args[i], "--crash") == 0 )
        {
            obj->crash = true;
        }
        else if ( strcmp(args[i], "--target") == 0 )
        {
            obj->runOnTarget = true;
        }
        else if ( strcmp(args[i], "--nohighlights") == 0 )
        {
            obj->hideHighlights = true;
        }
        else if ( strcmp(args[i], "--local") == 0 )
        {
            obj->local = true;
        }

        else
        {
            /* Unrecognize argument */
            return -1;
        }

        /* Move on the next argument */
        i++;
    }

    if ( !obj->regress && !obj->sanitize && !obj->crash && !obj->runOnTarget )
    {
        return _help(args[0], "Did you forget to sepcify an action?");
    }

    return 0;
}

static int _getCommonParameters(PmlaSrmClientTestObj_t *obj)
{
    pmp_attribute_get_request_msg_t getReq;
    pmp_attribute_get_reply_msg_t getReply;
    int code;

    /* Get the number of session */    
    getReq.header.protocolVersion = PMP_CURRENT_VERSION;
    getReq.header.msgType         = pmp_attribute_get_request_msg_type_e;
    getReq.header.reserved        = 0;
    getReq.header.msgLength       = htonl(PMP_ATTRIBUTE_GET_REQUEST_MSG_SIZE);
    getReq.header.msgId           = (uintptr_t) obj->handle;
    getReq.attributeId            = htonl(pmp_context_max_num_attr_id_e);
    code = pmlaSend(obj->handle, (pmp_msg_t *)&getReq);
    if(code != pmci_success_e)
    {
        _PMLA_TEST_LOG(obj, "   Fail to send get request (%d)\n",
                            code);
        return 1;
    }
    memset(&getReply, 0, sizeof(getReply));
    code = pmlaRecv(obj->handle, (pmp_msg_t *)&getReply);
    if (code != pmci_success_e)
    {
        _PMLA_TEST_LOG(obj, "   Fail to receive anything (%d)\n",
                    code);
        return -1;
    }
    memcpy(&obj->numSession, &getReply.attributeValue, sizeof(obj->numSession));
    obj->numSession = ntohl(obj->numSession);

    /* Get the max rules */
    getReq.header.protocolVersion = PMP_CURRENT_VERSION;
    getReq.header.msgType         = pmp_attribute_get_request_msg_type_e;
    getReq.header.reserved        = 0;
    getReq.header.msgLength       = htonl(PMP_ATTRIBUTE_GET_REQUEST_MSG_SIZE);
    getReq.header.msgId           = (uintptr_t) obj->handle;
    getReq.attributeId            = htonl(pmp_max_stateful_rule_num_attr_id_e);
    code = pmlaSend(obj->handle, (pmp_msg_t *)&getReq);
    if(code != pmci_success_e)
    {
        _PMLA_TEST_LOG(obj, "   Fail to send get request (%d)\n",
                            code);
        return 1;
    }
    memset(&getReply, 0, sizeof(getReply));
    code = pmlaRecv(obj->handle, (pmp_msg_t *)&getReply);
    if (code != pmci_success_e)
    {
        _PMLA_TEST_LOG(obj, "   Fail to receive anything (%d)\n",
                    code);
        return -1;
    }
    memcpy(&obj->numRules, &getReply.attributeValue, sizeof(obj->numRules));
    obj->numRules = ntohl(obj->numRules);

    /* Get the context size */
    getReq.header.protocolVersion = PMP_CURRENT_VERSION;
    getReq.header.msgType         = pmp_attribute_get_request_msg_type_e;
    getReq.header.reserved        = 0;
    getReq.header.msgLength       = htonl(PMP_ATTRIBUTE_GET_REQUEST_MSG_SIZE);
    getReq.header.msgId           = (uintptr_t) obj->handle;
    getReq.attributeId            = htonl(pmp_context_area_size_attr_id_e);
    code = pmlaSend(obj->handle, (pmp_msg_t *)&getReq);
    if(code != pmci_success_e)
    {
        _PMLA_TEST_LOG(obj, "   Fail to send get request (%d)\n",
                            code);
        return 1;
    }
    memset(&getReply, 0, sizeof(getReply));
    code = pmlaRecv(obj->handle, (pmp_msg_t *)&getReply);
    if (code != pmci_success_e)
    {
        _PMLA_TEST_LOG(obj, "   Fail to receive anything (%d)\n",
                    code);
        return -1;
    }
    memcpy(&obj->ctxSize, &getReply.attributeValue, sizeof(obj->ctxSize));
    obj->ctxSize = ntohl(obj->ctxSize);

    return 0;
}

static int _clearAllEntries(PmlaSrmClientTestObj_t *obj, pmp_table_id_t tableId)
{
    pmp_table_reset_request_msg_t resetReq;
    PmlaError_t code;
    
    /* Build the reset message */
    resetReq.header.protocolVersion = PMP_CURRENT_VERSION;
    resetReq.header.msgType         = pmp_table_reset_request_msg_type_e;
    resetReq.header.reserved        = 0;
    resetReq.header.msgLength       = htonl(sizeof(resetReq));
    resetReq.header.msgId           = (uintptr_t)obj->handle;
    resetReq.tableId                = htonl(tableId);
    
    /* Send the reset message */
    code = pmlaSend(obj->handle, (pmp_msg_t *)&resetReq);
    if ( code != pmlaSuccess_c ) return -1;
    return 0;
}

static int _writeEntry(PmlaSrmClientTestObj_t *obj, pmp_table_id_t tableId,
                       uint32_t tindex, void *data)
{
    static pmp_table_write_request_msg_t *writeReq = NULL;
    int bufferSize = PMLA_SRM_CLIENT_TEST_SIZE;
    int entrySize = _pmci_record_size_get(tableId);
    PmlaError_t code;

    /* Allocate buffer to read from three different table */
    if ( writeReq == NULL )
    {
        writeReq = (pmp_table_write_request_msg_t *)malloc(bufferSize);
    }
    if ( !writeReq )
    {
        _PMLA_TEST_LOG(obj, "Out-of-memory");
        return 1;
    }
    
    /* Write into the table */
    memset(writeReq, 0, sizeof(pmp_table_read_request_msg_t));
    writeReq->header.protocolVersion = PMP_CURRENT_VERSION;
    writeReq->header.msgType         = pmp_table_write_request_msg_type_e;
    writeReq->header.reserved        = 0;
    writeReq->header.msgLength       = 
      htonl(sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + 
            entrySize);
    writeReq->header.msgId           = (uintptr_t)obj->handle;
    writeReq->tableId                = htonl(tableId);
    writeReq->indexedEntry.index     = htonl(tindex);
    memcpy(&writeReq->indexedEntry.entry, data, entrySize);
    code = pmlaSend(obj->handle, (pmp_msg_t *)writeReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "Fail to send request (%d:%s)",
                       code, pmlaErrorString(code));
        return 1;
    }

    LOG_STRING(LOG_TEST, _PMLA_TEST, "Write Request:");
    LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, writeReq,
                    ntohl(writeReq->header.msgLength));

    return 0;
}

static int _readEntry(PmlaSrmClientTestObj_t *obj, pmp_table_id_t tableId,
                      uint32_t tindex, void *data)
{
    static pmp_table_read_request_msg_t *readReq = NULL;
    static pmp_table_read_reply_msg_t *readReply = NULL;
    int bufferSize = PMLA_SRM_CLIENT_TEST_SIZE;
    int entrySize = _pmci_record_size_get(tableId);
    int timeout;
    PmlaError_t code;

    /* Allocate buffer to read from three different table */
    if ( readReq == NULL )
    {
        readReq=(pmp_table_read_request_msg_t *)
          malloc(sizeof(pmp_table_read_request_msg_t));
    }
    if ( readReply == NULL )
    {
        readReply = (pmp_table_read_reply_msg_t *)malloc(bufferSize);
    }
    if ( !readReq || !readReply )
    {
        _PMLA_TEST_LOG(obj, "Out-of-memory");
        return 1;
    }
    
    /* Read from the specified table */
    memset(readReq, 0, sizeof(pmp_table_read_request_msg_t));
    memset(readReply, 0, bufferSize);
    readReq->header.protocolVersion = PMP_CURRENT_VERSION;
    readReq->header.msgType         = pmp_table_read_request_msg_type_e;
    readReq->header.reserved        = 0;
    readReq->header.msgLength       = htonl(sizeof(pmp_table_read_request_msg_t));
    readReq->header.msgId           = (uintptr_t)obj->handle;
    readReq->tableId                = htonl(tableId);
    readReq->index                  = htonl(tindex);
    code = pmlaSend(obj->handle, (pmp_msg_t *)readReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to send request (%d:%s)",
                       code, pmlaErrorString(code));
        return 1;
    }
    timeout = 60;
    code = pmlaSetOption(obj->handle, pmlaOptionTimeout_c, 
                         &timeout, sizeof(timeout));
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't set timeout value %d (%d:%s)", 
                       timeout, code, pmlaErrorString(code));
        return 1;
    }
    bufferSize = (sizeof(pmp_table_read_reply_msg_t) -
                  sizeof(pmp_table_entry_t) + entrySize);
    code = pmlaRecv(obj->handle, (pmp_msg_t *)readReply);
    if ( code == pmlaTimedOut_c )
    {
        _PMLA_TEST_LOG(obj, "   Timed out");
        return 1;
    }
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to receive reply (%d:%s)",
                       code, pmlaErrorString(code));
        return 1;
    }

    LOG_STRING(LOG_TEST, _PMLA_TEST, "Read Response:");
    /* Here, we're dumping more than needed. TODO - Frederic. */
    LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, readReply,
                    sizeof(pmp_table_read_reply_msg_t));

    /* Sanitizing the reply overhead */
    if ( readReply->header.protocolVersion != PMP_CURRENT_VERSION )
    {
        _PMLA_TEST_LOG(obj, "   Bad protocol version (%d/%d)", 
                       readReply->header.protocolVersion, PMP_CURRENT_VERSION);
    }
    if ( readReply->header.msgType != pmp_table_read_reply_msg_type_e )
    {
        _PMLA_TEST_LOG(obj, "   Bad type (%d/%d)", 
                       readReply->header.msgType, 
                       pmp_table_read_request_msg_type_e);
    }
    if ( readReply->header.reserved != 0 )
    {
        _PMLA_TEST_LOG(obj, "   Bad reserved (%d/%d)", 
                       readReply->header.reserved, 0);
    }
    if ( ntohl(readReply->header.msgLength) != (uint32_t)bufferSize )
    {
        _PMLA_TEST_LOG(obj, "   Bad length (%d/%d)", 
                       ntohl(readReply->header.msgLength), bufferSize);
    }
    if ( readReply->header.msgId != readReq->header.msgId )
    {
        _PMLA_TEST_LOG(obj, "   Bad msgId (0x%"PRIx64"/0x%"PRIx64")", 
                       readReply->header.msgId, readReq->header.msgId);
    }
    if ( ntohl(readReply->tableId) != tableId )
    {
        _PMLA_TEST_LOG(obj, "   Bad tableId (%d/%d)", 
                       ntohl(readReply->tableId), tableId);
    }
    if ( ntohl(readReply->indexedEntry.index) != tindex )
    {
        /* We let that one go for user-defined group and equivalence tables */
        if ( (tableId != pmp_user_defined_group_table_id_e) &&
             (tableId != pmp_equivalence_table_id_e) )
        {
            _PMLA_TEST_LOG(obj, "   Bad tindex (0x%"PRIx32"/0x%"PRIx32")",
                           ntohl(readReply->indexedEntry.index), tindex);
        }
    }

    /* Copy the memory over */
    memcpy(data, &readReply->indexedEntry.entry, entrySize);

    return 0;
}

static int _scanData(PmlaSrmClientTestObj_t *obj, 
                     uint8_t set, uint16_t subset,
                     uint32_t sessionId, void *data, int dataLen,
                     bool expectMatch)
{
    static pmp_data_scan_request_msg_t *scanReq = NULL;
    static pmp_scan_report_indication_msg_t *rptNotif = NULL;
    int scanReqLen = sizeof(pmp_data_scan_request_msg_t) + dataLen;
    int rptNotifLen = PMLA_SRM_CLIENT_TEST_SIZE;
    int errorCount = 0;
    int timeout;
    PmlaError_t code;

    /* Allocate memory */
    if ( scanReq == NULL )
    {
        scanReq = 
          (pmp_data_scan_request_msg_t *)malloc(PMLA_SRM_CLIENT_TEST_SIZE);
    }
    if ( rptNotif == NULL )
    {
        rptNotif = (pmp_scan_report_indication_msg_t *)
            malloc(PMLA_SRM_CLIENT_TEST_SIZE);
    }
    if ( !scanReq || !rptNotif )
    {
        _PMLA_TEST_LOG(obj, "   Out-of-memory");
        return ++errorCount;
    }

    /* Build the scan request message */
    memset(scanReq, 0, PMLA_SRM_CLIENT_TEST_SIZE);
    memset(rptNotif, 0, PMLA_SRM_CLIENT_TEST_SIZE);
    scanReq->header.protocolVersion = PMP_CURRENT_VERSION;
    scanReq->header.msgType         = pmp_data_scan_msg_type_e;
    scanReq->header.reserved        = 0;
    scanReq->header.msgLength       = htonl(scanReqLen);
    scanReq->header.msgId           = (uintptr_t)obj->handle;
    scanReq->set                    = set;
    scanReq->subsetMask             = htonl(subset);
    scanReq->sessionId              = htonl(sessionId);
    memcpy(scanReq->data, data, dataLen);
    code = pmlaSend(obj->handle, (pmp_msg_t *)scanReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to send request (%d:%s)",
                       code, pmlaErrorString(code));
        return ++errorCount;
    }

    /* Wait for the reqport */
    timeout = 60;
    code = pmlaSetOption(obj->handle, pmlaOptionTimeout_c, 
                         &timeout, sizeof(timeout));
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't set timeout value %d (%d:%s)", 
                       timeout, code, pmlaErrorString(code));
        return 1;
    }
    rptNotifLen = sizeof(pmp_scan_report_indication_msg_t) + 5;
    if ( expectMatch )
    {
        rptNotifLen += 16;
    }
    code = pmlaRecv(obj->handle, (pmp_msg_t *)rptNotif);
    if ( code == pmlaTimedOut_c )
    {
        _PMLA_TEST_LOG(obj, "   Timed out");
        return ++errorCount;
    }
    else if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to receive report (%d:%s)",
                       code, pmlaErrorString(code));
        return ++errorCount;
    }
    else
    {
        _PMLA_TEST_LOG(
            obj, "   Report: %d (%d/%d)", 
            rptNotifLen, (int)sizeof(pmp_scan_report_indication_msg_t),
            rptNotifLen - (int)sizeof(pmp_scan_report_indication_msg_t));
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, rptNotif, rptNotifLen);
        if ( (int)ntohl(rptNotif->header.msgLength) != rptNotifLen )
        {
            errorCount++;
            if ( expectMatch )
            {
                _PMLA_TEST_LOG(obj, "   No match");
            }
            else
            {
                _PMLA_TEST_LOG(obj, "   Unexpected match");
            }
        }
    }

    return errorCount;
}

static int _testMultiEntry(PmlaSrmClientTestObj_t *obj, pmp_table_id_t tableId,
                           uint32_t tindex)
{
    static uint8_t pattern1[PMLA_SRM_CLIENT_TEST_SIZE];
    static uint8_t pattern2[PMLA_SRM_CLIENT_TEST_SIZE];
    static uint8_t results1[PMLA_SRM_CLIENT_TEST_SIZE];
    static uint8_t results2[PMLA_SRM_CLIENT_TEST_SIZE];
    static uint8_t mask[] = { 0x00, 0x00, 0x00, 0x0f, 0xff, 0xff, 0xff, 0xff };
    int bufPos;
    int entrySize;
    int errorCount = 0;

    /* Build pattern1 */
    for ( bufPos = 0; 
          bufPos < PMLA_SRM_CLIENT_TEST_SIZE;
          bufPos += strlen(PMLA_SRM_CLIENT_TEST_PATTERN1) )
    {
        strcpy((char*) &pattern1[bufPos], PMLA_SRM_CLIENT_TEST_PATTERN1);
    }

    /* Build pattern2 */
    for ( bufPos = 0; 
          bufPos < PMLA_SRM_CLIENT_TEST_SIZE;
          bufPos += strlen(PMLA_SRM_CLIENT_TEST_PATTERN2) )
    {
        strcpy((char*) &pattern2[bufPos], PMLA_SRM_CLIENT_TEST_PATTERN2);
    }

    /* Compute entry size */
    entrySize = _pmci_record_size_get(tableId);

    /* Adjust patterns for partial fields */
    if ( (tableId == pmp_two_byte_trigger_table_id_e) ||
         (tableId == pmp_variable_trigger_table_id_e) )
    {
        for ( bufPos = 0; bufPos < entrySize; bufPos++ )
        {
            pattern1[bufPos] &= mask[bufPos%entrySize];
            pattern2[bufPos] &= mask[bufPos%entrySize];
        }
    }

    /* Ensure results buffer are empty */
    memset(results1, 0, entrySize);
    memset(results2, 0, entrySize);
    
    /* Write some data */
    errorCount += _writeEntry(obj, tableId, tindex, pattern1);
    errorCount += _writeEntry(obj, tableId, tindex+1, pattern2);
    
    /* Read the data back */
    errorCount += _readEntry(obj, tableId, tindex, results1);
    errorCount += _readEntry(obj, tableId, tindex+1, results2);
    
    /* Compare the data */
    if ( memcmp(pattern1, results1, entrySize) != 0 )
    {
        LOG_STRING(LOG_WARNING, _PMLA_TEST,
                   "   Mismatch on table %d, index %d", tableId, tindex);
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory written:");
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, pattern1, entrySize);
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory read:");
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, results1, entrySize);
        errorCount++;
    }
    if ( memcmp(pattern2, results2, entrySize) != 0 )
    {
        LOG_STRING(LOG_WARNING, _PMLA_TEST,
                   "   Mismatch on table %d, index %d", tableId,tindex+1);
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory written:");
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, pattern2, entrySize);
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory read:");
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, results2, entrySize);
        errorCount++;
    }

    return errorCount;
}

static int _testSingleEntry(PmlaSrmClientTestObj_t *obj, pmp_table_id_t tableId)
{
    static uint8_t pattern1[PMLA_SRM_CLIENT_TEST_SIZE];
    static uint8_t results1[PMLA_SRM_CLIENT_TEST_SIZE];
    int bufPos;
    int entrySize;
    int tindex;
    uint8_t mask = 0xff;
    int errorCount = 0;

    if ( tableId == pmp_user_defined_group_table_id_e ) mask = 0x7;

    /* Build the pattern buffer */
    for ( bufPos=0; bufPos<PMLA_SRM_CLIENT_TEST_SIZE; bufPos++ )
    {
        /* Just use one bit for now */
        pattern1[bufPos] = bufPos & mask;
    }

    /* Compute entry size */
    entrySize = _pmci_record_size_get(tableId);

    /* Write some data */
    errorCount += _writeEntry(obj, tableId, 0, pattern1);
    
    for ( tindex=0; tindex<3; tindex++ )
    {
        /* Ensure results buffer are empty */
        memset(results1, 0, entrySize);
    
        /* Read the data back */
        errorCount += _readEntry(obj, tableId, tindex, results1);
        
        /* Compare the data */
        if ( tableId == pmp_special_trigger_table_id_e )
        {
            if ( pattern1[entrySize-1] != results1[entrySize-1] )
            {
                _PMLA_TEST_LOG(obj, "   Mismatch on special trigger index %d", 
                               tindex);
                LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory written:");
                LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, pattern1, entrySize);
                LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory read:");
                LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, results1, entrySize);
                errorCount++;
            }
        }
        else
        {
            if ( memcmp(pattern1, results1, entrySize) != 0 )
            {
                _PMLA_TEST_LOG(obj, "   Mismatch on table %d, index %d", 
                               tableId, tindex);
                LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory written:");
                LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, pattern1, entrySize);
                LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory read:");
                LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, results1, entrySize);
                errorCount++;
            }
        }
    }

    return errorCount;
}

static int _testBasicSanity(PmlaSrmClientTestObj_t *obj)
{
    PmlaError_t code;

    _PMLA_TEST_LOG(obj, "TEST:  pmlaFlush()");

    /* Flush the pipe */
    _PMLA_TEST_LOG(obj, "   Flushing the loader agent pipe");
    code = pmlaFlush(obj->handle);
    if ( (code != pmlaSuccess_c) && (code != pmlaBufferPending_c) )
    {
        _PMLA_TEST_LOG(obj, "   Can't flush (%d:%s)", 
                       code, pmlaErrorString(code));
        return _testDone(obj, 1);
    }

    return _testDone(obj, 0);
}

static int _testErrorCode(PmlaSrmClientTestObj_t *obj)
{
    PmlaError_t code;

    _PMLA_TEST_LOG(obj, "TEST:  pmlaErrorString(...)");

    /* Loop through all error codes and see what spits out */
    for ( code=(pmlaErrorFirst_c-1); code<=(pmlaErrorLast_c+1); code++ )
    {
        _PMLA_TEST_LOG(obj, "   %3d : %s", code, pmlaErrorString(code));
    }

    return _testDone(obj, 0);
}

static int _testReadWriteTable(PmlaSrmClientTestObj_t *obj)
{
    int tableId;
    int tindex;
    int firstIndex = 13;
    int lastIndex = 20;
    int errorCount = 0;

    _PMLA_TEST_LOG(obj, "TEST:  pmp_table_read_request_msg_type_e/"
                   "pmp_table_write_request_msg_type_e");

    /* Loop through out all of the tables */
    for ( tableId = obj->firstTid; tableId <= obj->lastTid; tableId++ )
    {
        if ( tableId == obj->skipTid )
        {
            _PMLA_TEST_LOG(obj, "   Skipping table %d (as requested)",tableId);
            continue;
        }

        if ( obj->skipLongTests && (
                 (tableId == pmp_special_trigger_table_id_e) ) )
        {
            _PMLA_TEST_LOG(obj, "   Skipping table %d (long test)", tableId);
        }
        else
        {
            _PMLA_TEST_LOG(obj, "   Testing  table %d", tableId);
            
            switch (tableId)
            {
            case pmp_user_defined_group_table_id_e:
            case pmp_equivalence_table_id_e:
            case pmp_one_byte_trigger_table_id_e:
            case pmp_special_trigger_table_id_e:
                /* Single entry in and out */
                errorCount += _testSingleEntry(obj, tableId);
                break;
            case pmp_two_byte_trigger_table_id_e:
            case pmp_variable_trigger_table_id_e:
            case pmp_confidence_table_id_e:
            case pmp_confirmation_table_id_e:
            case pmp_session_context_table_id_e:
                /* Multi entry table */
                for ( tindex = firstIndex; tindex <= lastIndex; tindex += 2 )
                {
                    errorCount += _testMultiEntry(obj, tableId, tindex);
                }
                break;
            default:
                /* Bad table */
                break;
            }
        }
    }

    return _testDone(obj, errorCount);
}

static int _testPartialWriteTable(PmlaSrmClientTestObj_t *obj)
{
    int tableId = pmp_confirmation_table_id_e;
    int tindex = 0x4803;
    static uint8_t pattern1[PMP_CONFIRMATION_ENTRY_SIZE];
    static uint8_t results1[PMP_CONFIRMATION_ENTRY_SIZE];
    int entrySize = PMP_CONFIRMATION_ENTRY_SIZE;
    static pmp_table_write_request_msg_t *writeReq = NULL;
    int partialSizes[] = { 32, 64, 96, -1 };
    int i;
    int errorCount = 0;
    PmlaError_t code;

    _PMLA_TEST_LOG(obj, "TEST:  pmp_table_write_request_msg_type_e on partial "
                   "record");

    /* For now, we only run this test on the confirmation table */

    /* Allocate buffer to read from three different table */
    if ( writeReq == NULL )
    {
        writeReq = (pmp_table_write_request_msg_t *)
            malloc(PMP_CONFIRMATION_TABLE_READ_REPLY_MSG_SIZE);
    }
    if ( !writeReq )
    {
        _PMLA_TEST_LOG(obj, "   Out-of-memory");
        return _testDone(obj, ++errorCount);
    }
    
    /* Initialize the entry to all ones and wait for it to complete */
    memset(pattern1, 0xff, entrySize);
    errorCount += _writeEntry(obj, tableId, tindex, pattern1);

    /* Read it back to make sure we've got the right data */
    memset(results1, 0x00, entrySize);
    errorCount += _readEntry(obj, tableId, tindex, results1);

    /* Compare the results */
    if ( memcmp(pattern1, results1, entrySize) != 0 )
    {
        _PMLA_TEST_LOG(obj, "   Mismatch on table %d", tableId);
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory written:");
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, pattern1, entrySize);
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory read:");
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, results1, entrySize);
        return _testDone(obj, ++errorCount);
    }

    /* Loop through all of the different cache line boundary */
    i = 0;
    while(partialSizes[i] > 0)
    {
        _PMLA_TEST_LOG(obj, "   Testing %dB or partial data", partialSizes[i]);

        /* Modify the first cache line of pattern */
        memset(&pattern1[partialSizes[i]-32], partialSizes[i], 32);
        
        /* Apply it to the hardware */
        memset(writeReq, 0, sizeof(pmp_table_read_request_msg_t));
        writeReq->header.protocolVersion = PMP_CURRENT_VERSION;
        writeReq->header.msgType         = pmp_table_write_request_msg_type_e;
        writeReq->header.reserved        = 0;
        writeReq->header.msgLength       = 
          htonl(sizeof(pmp_table_write_request_msg_t) - 
                sizeof(pmp_table_entry_t) + partialSizes[i]);
        writeReq->header.msgId           = (uintptr_t)obj->handle;
        writeReq->tableId                = htonl(tableId);
        writeReq->indexedEntry.index     = htonl(tindex);
        memcpy(&writeReq->indexedEntry.entry, pattern1, partialSizes[i]);
        code = pmlaSend(obj->handle, (pmp_msg_t *)writeReq);
        if ( code != pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   Fail to send request (%d:%s)",
                           code, pmlaErrorString(code));
            return _testDone(obj, ++errorCount);
        }
        
        /* Read it back to make sure we've got the right data */
        memset(results1, 0x00, entrySize);
        errorCount += _readEntry(obj, tableId, tindex, results1);
        
        /* Compare the results */
        if ( memcmp(pattern1, results1, entrySize) != 0 )
        {
            _PMLA_TEST_LOG(obj, "   Mismatch on table %d", tableId);
            LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory written:");
            LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, pattern1, entrySize);
            LOG_STRING(LOG_TEST, _PMLA_TEST, "Memory read:");
            LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, results1, entrySize);
            return _testDone(obj, ++errorCount);
        }

        /* Move onto the next test */
        i++;
    }

    return _testDone(obj, errorCount);
}

static int _testResetTable(PmlaSrmClientTestObj_t *obj)
{
    int tableId;
    int errorCount = 0;
    PmlaError_t code;
    
    _PMLA_TEST_LOG(obj, "TEST:  pmp_table_reset_request_msg_type_e");

    /* Teset the reset for all tables */
    for ( tableId=obj->firstTid; tableId<=obj->lastTid; tableId++ )
    {
        if ( tableId == obj->skipTid )
        {
            _PMLA_TEST_LOG(obj, "   Skipping table %d (as requested)",tableId);
            continue;
        }

        if ( ( (tableId == pmp_confirmation_table_id_e) ||
               (tableId == pmp_session_context_table_id_e) ) &&
             (obj->skipLongTests) )
        {
            _PMLA_TEST_LOG(obj, "   Skipping table %d (takes too long time)", 
                           tableId);
        }
        else
        {
            _PMLA_TEST_LOG(obj, "   Testing  table %d", tableId);
            
            if ( _clearAllEntries(obj, tableId) < 0 )
            {
                _PMLA_TEST_LOG(obj, "   Cannot send the reset table request");
                errorCount++;
            }

            /* For debugging purposes, we flush after each command to provide
             * better feeling of the progress.
             */
            code = pmlaFlush(obj->handle);
            if ( code != pmlaSuccess_c )
            {
                _PMLA_TEST_LOG(obj, "   Can't flush (%d:%s)",
                               code, pmlaErrorString(code));
                errorCount++;
            }
        }
    }

    return _testDone(obj, errorCount);
}

typedef struct
{
    char *name;
    int size;
    bool readable;
    bool writable;
} _PmlaSrmClientTestAttrSpec_t;

static int _testOneAttribute(PmlaSrmClientTestObj_t *obj, uint32_t attrId,
                             bool expectSuccess, 
                             _PmlaSrmClientTestAttrSpec_t *spec)
{
    pmp_attribute_get_request_msg_t getReq;
    pmp_attribute_get_reply_msg_t getReply;
    pmp_attribute_set_request_msg_t setReq;
    pmp_error_indication_msg_t errorNotif;
    PmlaError_t code;
    uint32_t value;
    uint32_t old_value;
    
    int length;
    int timeout;

    /* Compute the value to use */
    value = htonl(13);
    if ( spec->size > 4 )
    {
        length = PMP_ATTRIBUTE_SET_REQUEST_EMPTY_MSG_SIZE;
    }
    else
    {
        length = PMP_ATTRIBUTE_SET_REQUEST_MSG_SIZE(spec->size);
    }

    /* Send the set request */
    if ( spec->writable )
    {
        if(spec->size <= 4) {
            // save the old_value
            /* Send the get request */
            getReq.header.protocolVersion = PMP_CURRENT_VERSION;
            getReq.header.msgType         = pmp_attribute_get_request_msg_type_e;
            getReq.header.reserved        = 0;
            getReq.header.msgLength       = htonl(PMP_ATTRIBUTE_GET_REQUEST_MSG_SIZE);
            getReq.header.msgId           = (uintptr_t) obj->handle;
            getReq.attributeId            = htonl(attrId);
            code = pmlaSend(obj->handle, (pmp_msg_t *)&getReq);
            if ( code != pmci_success_e )
            {
                _PMLA_TEST_LOG(obj, "   Fail to send get request (%d)",
                            code);
                return -1;
            }
            memset(&getReply, 0, sizeof(getReply));
            code = pmlaRecv(obj->handle, (pmp_msg_t *)&getReply);
            if (code != pmci_success_e)
            {
                _PMLA_TEST_LOG(obj, "   Fail to receive anything (%d)",
                            code);
                return -1;
            }
            memcpy(&old_value, &getReply.attributeValue, sizeof(old_value));
            _PMLA_TEST_LOG(obj, "   32bit old value %u", ntohl(old_value));
        }
        // Write the new value.
        setReq.header.protocolVersion = PMP_CURRENT_VERSION;
        setReq.header.msgType         = pmp_attribute_set_request_msg_type_e;
        setReq.header.reserved        = 0;
        setReq.header.msgLength       = htonl(length);
        setReq.header.msgId           = (uintptr_t)obj->handle;
        setReq.attributeId            = htonl(attrId);
        memcpy(&setReq.attributeValue, &value, sizeof(value));
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, &setReq, sizeof(setReq));
        code = pmlaSend(obj->handle, (pmp_msg_t *)&setReq);
        if ( code != pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   Fail to send set request (%d:%s)",
                           code, pmlaErrorString(code));
            return -1;
        }
    }

    /* Set the timeout value for the duration of this test */
    
    timeout = 10;
    if(obj->local) timeout = 1;
    
    code = pmlaSetOption(obj->handle, pmlaOptionTimeout_c, 
                         &timeout, sizeof(timeout));
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't set timeout value %d (%d:%s)", 
                       timeout, code, pmlaErrorString(code));
        return 1;
    }

    /* Check for potential notification */
    length = sizeof(errorNotif);
    memset(&errorNotif, 0, length);
    code = pmlaRecv(obj->handle, (pmp_msg_t *)&errorNotif);
    if ( (code != pmlaSuccess_c) && (code != pmlaTimedOut_c) )
    {
        _PMLA_TEST_LOG(obj, "   Fail to receive anything (%d:%s)",
                       code, pmlaErrorString(code));
        return -1;
    }
    if ( expectSuccess )
    {
        /* No notification is expected */
        if ( code == pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   Unexpected notification (%d/%d)", 
                           ntohl(errorNotif.header.msgLength),
                           ntohl(errorNotif.errorNo));
            return -1;
        }
    }
    else
    {
        /* A notification is expected */
        if ( code == pmlaTimedOut_c )
        {
            _PMLA_TEST_LOG(obj, "   Missing notification (%d)", length);
            return -1;
        }
        
        /* Sanitize the notification */
        if ( (errorNotif.header.protocolVersion != PMP_CURRENT_VERSION) ||
             (errorNotif.header.msgType != pmp_error_indication_msg_type_e) ||
             (errorNotif.header.reserved != 0 ) ||
             (errorNotif.header.msgLength != (uint32_t)htonl(length)) ||
             (errorNotif.header.msgLength != 
              htonl(sizeof(pmp_error_indication_msg_t)))||
             (errorNotif.header.msgId != 0) ||
             (errorNotif.errorNo != (uint32_t)htonl(pmci_invalid_attribute_id_e)))
        {
            _PMLA_TEST_LOG(obj, "   Malformed notification");
            LOG_MEMORY_DUMP(LOG_TMP, _PMLA_TEST, 
                            &errorNotif, sizeof(errorNotif));
            return -1;
        }
    }

    /* Send the get request */
    getReq.header.protocolVersion = PMP_CURRENT_VERSION;
    getReq.header.msgType         = pmp_attribute_get_request_msg_type_e;
    getReq.header.reserved        = 0;
    getReq.header.msgLength       = htonl(PMP_ATTRIBUTE_GET_REQUEST_MSG_SIZE);
    getReq.header.msgId           = (uintptr_t)obj->handle;
    getReq.attributeId            = htonl(attrId);
    code = pmlaSend(obj->handle, (pmp_msg_t *)&getReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to send set request (%d:%s)",
                       code, pmlaErrorString(code));
        return -1;
    }

    /* Receive the message header first */
    memset(&getReply, 0, sizeof(getReply));
    code = pmlaRecv(obj->handle, (pmp_msg_t *)&getReply);
    if ( (code != pmlaSuccess_c) && (code != pmlaTimedOut_c) )
    {
        _PMLA_TEST_LOG(obj, "   Fail to receive anything (%d:%s)",
                       code, pmlaErrorString(code));
        return -1;
    }

    length = ntohl(getReply.header.msgLength) - sizeof(pmp_header_t);
    length -= sizeof(pmp_attribute_id_t); // Take attributeId off the length
    if ( length != spec->size )
    {
        _PMLA_TEST_LOG(obj, "   Amount mismatch; expected %d but got %d",
                       spec->size, length);
        return -1;
    }
    if ( (code != pmlaSuccess_c) && (code != pmlaTimedOut_c) )
    {
        _PMLA_TEST_LOG(obj, "   Fail to receive anything (%d:%s)",
                       code, pmlaErrorString(code));
        return -1;
    }

    /* Expect some reply */
    if ( code == pmlaTimedOut_c )
    {
        _PMLA_TEST_LOG(obj, "   Missing get reply");
        return -1;
    }
    if ( expectSuccess )
    {
        /* Expect a valid get reply */
        length = PMP_ATTRIBUTE_GET_REPLY_MSG_SIZE(spec->size);
        if ( (getReply.header.protocolVersion != PMP_CURRENT_VERSION) ||
             (getReply.header.msgType != pmp_attribute_get_reply_msg_type_e) ||
             (getReply.header.reserved != 0) ||
             (getReply.header.msgLength != (uint32_t)htonl(length)) ||
             (getReply.header.msgId != (uintptr_t)obj->handle) ||
             (getReply.attributeId != htonl(attrId)) ||
             ((spec->writable) &&
              (spec->size <= 8) && 
              (memcmp(&getReply.attributeValue, &value, sizeof(value) != 0))) )
        {
            _PMLA_TEST_LOG(obj, "   Malformed get reply");
            LOG_MEMORY_DUMP(LOG_TMP, _PMLA_TEST, 
                            &getReply, sizeof(getReply));
            return -1;
        }
        else
        {
            if(spec->size <= 4){
                uint32_t v1;
                memcpy(&v1, &getReply.attributeValue, sizeof(uint32_t));
                _PMLA_TEST_LOG(obj, "   32bit Reply value %u", ntohl(v1));
            }
        }

        // Reset to the old_value
        if ( spec->size > 4 )
        {
            length = PMP_ATTRIBUTE_SET_REQUEST_EMPTY_MSG_SIZE;
        }
        else
        {
            length = PMP_ATTRIBUTE_SET_REQUEST_MSG_SIZE(spec->size);
        }

        /* Send the set request of the old value */
        if ( spec->writable && spec->size <= 4)
        {
            // Write the new value.
            setReq.header.protocolVersion = PMP_CURRENT_VERSION;
            setReq.header.msgType         = pmp_attribute_set_request_msg_type_e;
            setReq.header.reserved        = 0;
            setReq.header.msgLength       = htonl(length);
            setReq.header.msgId           = (uintptr_t) obj->handle;
            setReq.attributeId            = htonl(attrId);
            memcpy(&setReq.attributeValue, &old_value, sizeof(old_value));
            //LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, &setReq, sizeof(setReq));
            code = pmlaSend(obj->handle, (pmp_msg_t *)&setReq);
            if ( code != pmci_success_e )
            {
                _PMLA_TEST_LOG(obj, "   Fail to send set request (%d)\n",
                            code);
                return -1;
            }
        }
    }
    else
    {
        /* Expect an error notification */
        length = sizeof(pmp_error_indication_msg_t);
        if ( (getReply.header.protocolVersion != PMP_CURRENT_VERSION) ||
             (getReply.header.msgType != pmp_error_indication_msg_type_e) ||
             (getReply.header.reserved != 0 ) ||
             (getReply.header.msgLength != 
              htonl(sizeof(pmp_error_indication_msg_t)))||
             (getReply.header.msgId != 0) ||
             (getReply.attributeId != 
              (uint32_t)htonl(pmci_invalid_attribute_id_e)) )
        {
            _PMLA_TEST_LOG(obj, "   Malformed error notification");
            LOG_MEMORY_DUMP(LOG_TMP, _PMLA_TEST, 
                            &getReply, sizeof(pmp_error_indication_msg_t));
            return -1;
        }
    }
    return 0;
}

static _PmlaSrmClientTestAttrSpec_t _attrSpec[] = {
    /* name                                    size  read   write */
    { "pmp_statistics_attr_id_e",               136, true,  true  }, /* 0x00 */
    { "pmp_hardware_revision_attr_id_e",         12, true,  false }, /* 0x01 */
    { "pmp_protocol_revision_attr_id_e",          4, true,  false }, /* 0x02 */
    { "pmp_atomic_attr_id_e",                     4, false, false }, /* 0x03 */
    { "pmp_batch_attr_id_e",                      4, false, false }, /* 0x04 */
    { "pmp_sre_end_of_sui_reaction_ptr_attr_id_e",4, true,  true  }, /* 0x05 */
    { "pmp_variable_trigger_size_attr_id_e",      4, true,  true  }, /* 0x06 */
    { "pmp_confidence_chain_max_length_attr_id_e",4, true,  true  }, /* 0x07 */
    { "pmp_sw_database_signature_attr_id_e",      4, true,  true  }, /* 0x08 */
    { "pmp_drcc_selection_attr_id_e",             4, true,  true  }, /* 0x09 */
    { "pmp_extension_block_num_attr_id_e",        4, true,  false }, /* 0x0a */
    { "pmp_context_max_num_attr_id_e",            4, true,  false }, /* 0x0b */
    { "pmp_context_area_size_attr_id_e",          4, true,  false }, /* 0x0c */
    { "pmp_max_stateful_rule_num_attr_id_e",      4, true,  false }, /* 0x0d */
    { "INVALID",                                  0, true,  true  }  /* XXXX */
};

static int _testAttributes(PmlaSrmClientTestObj_t *obj)
{
    int attrId;
    int errorCount = 0;

    _PMLA_TEST_LOG(obj, "TEST:  pmp_attribute_get_request_msg_type_e/"
                   "pmp_attribute_set_request_msg_type_e");

    /* Test all valid attributes */
    for ( attrId = pmp_first_attr_id_e; attrId <= pmp_last_attr_id_e; attrId++ )
    {
        _PMLA_TEST_LOG(obj, "   Testing attribute %s(%d)",
                       _attrSpec[attrId].name, attrId);
        if ( _testOneAttribute(obj, attrId, true, &_attrSpec[attrId]) < 0 ) 
        {
            errorCount++;
        }
    }

    if(!obj->local) {
    /* Test an invalid attribute */
        attrId = pmp_last_attr_id_e + 1;
        _PMLA_TEST_LOG(obj, "   Testing attribute %s(%d)",
                    _attrSpec[attrId].name, attrId);
        if ( _testOneAttribute(obj, attrId, false, &_attrSpec[attrId]) < 0 )
        {
            errorCount++;
        }
    }
    return _testDone(obj, errorCount);
}

static int _testClearContextBySessionId(PmlaSrmClientTestObj_t *obj)
{
    pmp_ctx_by_session_id_clear_request_msg_t clearReq;
    static const int _firstSessionId = 3;
    int _numSessionBlocks = obj->numSession - _firstSessionId;
    
    // Will need to read this from driver...
//#define Default_SessionContextSize_d 32768
//#define _firstSessionCl(sessionId)   (sessionId) *                            
//                                     Default_SessionContextSize_d /               
//                                     PMP_SESSION_CONTEXT_ENTRY_SIZE
    
    //static uint8_t pattern1[_numSessionBlocks][Default_SessionContextSize_d];
    //static uint8_t results1[_numSessionBlocks][Default_SessionContextSize_d];
    //static uint8_t allZero1[Default_SessionContextSize_d];
    
    //static uint8_t *pattern1[_numSessionBlocks];
    //static uint8_t *results1[_numSessionBlocks];
    static uint8_t **pattern1;
    static uint8_t **results1;
    static uint8_t *allZero1;

    uint8_t *cl;
    int blockId;
    int clId;
    int numCls = obj->ctxSize / PMP_SESSION_CONTEXT_ENTRY_SIZE;
    int numCompares = obj->ctxSize;
    int digestSize = 1024;
    int errorCount = 0;
    PmlaError_t code;
    int i;

    pattern1 = calloc(sizeof(uint8_t*), _numSessionBlocks);
    results1 = calloc(sizeof(uint8_t*), _numSessionBlocks);
    for(i =0; i < _numSessionBlocks; i++)
    {
        pattern1[i] = calloc(sizeof(uint8_t), 32768);//obj->ctxSize);
        results1[i] = calloc(sizeof(uint8_t), 32768);//obj->ctxSize);
    }
    allZero1 = calloc(sizeof(uint8_t), obj->ctxSize);
    
    /* The objective here is to pick three consecutive session block and
     * write non-zero data to each of them.  Then use the clear context
     * by session id command to clear the middle session block.  By reading
     * the three session blocks back, only the middle one should have been
     * zeroed.  The first and last block should be intact.
     */

    _PMLA_TEST_LOG(obj, "TEST:  pmp_ctx_by_session_id_clear_request_msg_type_e");

    /* When skipping long test, just use 10 cache line per sessions */
    if ( obj->skipLongTests )
    {
        numCls = 32;
        numCompares = PMP_SESSION_CONTEXT_ENTRY_SIZE * numCls;
    }
    if ( numCompares < digestSize )
    {
        digestSize = numCompares;
    }

    /* Building the pattern array */
    for ( blockId=0; blockId<_numSessionBlocks; blockId++ )
    {
        /* Patterns */
        cl = pattern1[blockId];
        for ( clId=0; clId<numCls; clId++ )
        {
            memset(cl, (blockId << 4) | 0x08 | (clId & 0x07), 
                   PMP_SESSION_CONTEXT_ENTRY_SIZE);
            cl += PMP_SESSION_CONTEXT_ENTRY_SIZE;
        }

        /* Results */
        memset(results1[blockId], 0xaa, obj->ctxSize);
    }
    memset(allZero1, 0x00, obj->ctxSize);

    /* Writing data onto the three choosen session context blocks */
    _PMLA_TEST_LOG(obj, "   Writing non-zero values to session table");
    for ( blockId=0; blockId<_numSessionBlocks; blockId++ )
    {
        cl = pattern1[blockId];
        for ( clId=0; clId<numCls; clId++ )
        {
            errorCount += _writeEntry(obj, pmp_session_context_table_id_e, 
                                      _firstSessionCl(obj, _firstSessionId+blockId)+
                                      clId, cl);
            cl += PMP_SESSION_CONTEXT_ENTRY_SIZE;
        }
    }

    /* Wait until all writes are done */
    code = pmlaFlush(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to complete all the writes (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Use the command to implement the context clear by session id */
    _PMLA_TEST_LOG(obj, "   Clear context using sessionId %d", 
                   _firstSessionId+1);
    memset(&clearReq, 0, sizeof(clearReq));
    clearReq.header.protocolVersion = PMP_CURRENT_VERSION;
    clearReq.header.msgType         = pmp_ctx_by_session_id_clear_request_msg_type_e;
    clearReq.header.reserved        = 0;
    clearReq.header.msgLength       = htonl(sizeof(clearReq));
    clearReq.header.msgId           = (uintptr_t)obj->handle;
    clearReq.sessionId              = htonl(_firstSessionId+1);
    clearReq.ruleCap                = 0;
    code = pmlaSend(obj->handle, (pmp_msg_t *)&clearReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to send clear request (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* This command can take a long time, waiting for completion */
    code = pmlaFlush(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to complete the clear request (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Read the three session context blocks back */
    _PMLA_TEST_LOG(obj, "   Reading session data");
    for ( blockId=0; blockId<_numSessionBlocks; blockId++ )
    {
        cl = results1[blockId];
        for ( clId=0; clId<numCls; clId++ )
        {
            errorCount += _readEntry(obj, pmp_session_context_table_id_e, 
                                     _firstSessionCl(obj, _firstSessionId+blockId) +
                                     clId, cl);
            cl += PMP_SESSION_CONTEXT_ENTRY_SIZE;
        }
    }

    /* Compare the results */
    _PMLA_TEST_LOG(obj, "   Verifying the results");
    if ( memcmp(pattern1[0], results1[0], numCompares) != 0 )
    {
        _PMLA_TEST_LOG(obj, "   First session got affected");
        errorCount++;
    }
    if ( memcmp(pattern1[1], results1[1], numCompares) == 0 )
    {
        _PMLA_TEST_LOG(obj, "   No effect on cleared session");
        errorCount++;
    }
    if ( memcmp(allZero1,    results1[1], digestSize) != 0 )
    {
        _PMLA_TEST_LOG(obj, "   Session not cleared properly");
        LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, results1[1], 256);
        errorCount++;
    }
    if ( memcmp(pattern1[2], results1[2], numCompares) != 0 )
    {
        _PMLA_TEST_LOG(obj, "   Last session got affected");
        errorCount++;
    }

    _PMLA_TEST_LOG(obj, "   Completed.");
    
    for(i =0; i < _numSessionBlocks; i++)
    {
        free(pattern1[i]);
        free(results1[i]);
    }
    free(allZero1);
    free(pattern1);
    free(results1);

    return _testDone(obj, errorCount);
}

static int _testClearContextByRuleId(PmlaSrmClientTestObj_t *obj)
{
    /* There is a bug righ here */
    static pmp_ctx_by_rule_id_clear_request_msg_t *clearReq = NULL;
    static const int _firstSessionId = 3;
    
    //int _numSessionBlocks = obj->numSession - _firstSessionId;
    const int _numSessionBlocks = 3;
    
//#define _firstSessionCl(sessionId)   (sessionId) *                            
//                                     Default_SessionContextSize_d /               
//                                     PMP_SESSION_CONTEXT_ENTRY_SIZE
#define _zeroSessionId 88
    //static uint8_t pattern1[_numSessionBlocks][Default_SessionContextSize_d];
    //static uint8_t results1[_numSessionBlocks][Default_SessionContextSize_d];
    //static uint8_t allZero1[Default_SessionContextSize_d];

    //static uint8_t *pattern1[_numSessionBlocks];
    //static uint8_t *results1[_numSessionBlocks];
    static uint8_t **pattern1;
    static uint8_t **results1;
    static uint8_t *allZero1;

    uint8_t *cl;
    int blockId;
    int clId;
    int numCls = obj->ctxSize/PMP_SESSION_CONTEXT_ENTRY_SIZE;
    int numCompares = obj->ctxSize;
    int ruleIds[] = { 15, 3, 456, 7, 258, 111, -1 };
    int ruleIndex;
    int length;
    int errorCount = 0;
    PmlaError_t code;
    int i;

    pattern1 = calloc(sizeof(uint8_t*), _numSessionBlocks);
    results1 = calloc(sizeof(uint8_t*), _numSessionBlocks);

    for(i =0; i < _numSessionBlocks; i++)
    {
        pattern1[i] = calloc(sizeof(uint8_t), 32768);//obj->ctxSize*2);
        results1[i] = calloc(sizeof(uint8_t), 32768);//obj->ctxSize*2);
    }
    allZero1 = calloc(sizeof(uint8_t), 32768); //obj->ctxSize*2);

    /* The objective here is to pick three consecutive session block and
     * write non-zero data to each of them.  Then use the clear context
     * by rule id command to clear four rules in all session block.  By reading
     * the three session blocks back, only the specific bits should be 
     * zeroed.
     */

    _PMLA_TEST_LOG(obj, "TEST:  pmp_ctx_by_rule_id_clear_request_msg_type_e");

    /* Ensure we've got memory */
    if ( clearReq == NULL )
    {
        clearReq = malloc(sizeof(pmp_ctx_by_rule_id_clear_request_msg_t) + 32);
    }

    /* When skipping long test, just use 10 cache line per sessions */
    if ( obj->skipLongTests )
    {
        numCls = 2;
        numCompares = PMP_SESSION_CONTEXT_ENTRY_SIZE * numCls;
    }

    /* Building the pattern array */
    for ( blockId=0; blockId<_numSessionBlocks; blockId++ )
    {
        memset(pattern1[blockId], 0xff, obj->ctxSize);
        memset(results1[blockId], 0xaa, obj->ctxSize);
    }
    memset(allZero1, 0x00, obj->ctxSize);

    /* Writing data onto the three choosen session context blocks */
    _PMLA_TEST_LOG(obj, "   Writing non-zero values to session table");
    for ( blockId=0; blockId<_numSessionBlocks; blockId++ )
    {
        cl = pattern1[blockId];
        for ( clId=0; clId<numCls; clId++ )
        {
            errorCount += _writeEntry(obj, pmp_session_context_table_id_e, 
                                      _firstSessionCl(obj, _firstSessionId+blockId)+
                                      clId, cl);
            cl += PMP_SESSION_CONTEXT_ENTRY_SIZE;
        }
    }
    _PMLA_TEST_LOG(obj, "   Writing zero values to session table");
    cl = allZero1;
    for ( clId=0; clId<numCls; clId++ )
    {
        errorCount += _writeEntry(obj, pmp_session_context_table_id_e, 
                                  _firstSessionCl(obj, _zeroSessionId) + clId, cl);
        cl += PMP_SESSION_CONTEXT_ENTRY_SIZE;
    }

    /* Wait until all writes are done */
    code = pmlaFlush(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to complete all the writes (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Use the command to implement the context clear by rule id */
    _PMLA_TEST_LOG(obj, "   Clear context using ruleId %d", ruleIds[0]);
    length = sizeof(pmp_ctx_by_rule_id_clear_request_msg_t);
    memset(clearReq, 0, length);
    clearReq->header.protocolVersion = PMP_CURRENT_VERSION;
    clearReq->header.msgType         = pmp_ctx_by_rule_id_clear_request_msg_type_e;
    clearReq->header.reserved        = 0;
    clearReq->header.msgLength       = htonl(length);
    clearReq->header.msgId           = (uintptr_t)obj->handle;
    clearReq->firstSessionId         = 0;
    clearReq->sessionDepth           = 0;
    clearReq->numberOfSession        = 0;
    clearReq->ruleIds[0]             = htonl(ruleIds[0]);
    code = pmlaSend(obj->handle, (pmp_msg_t *)clearReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to send clear request (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Repeat the command but with multiple ruleIds in it */
    _PMLA_TEST_LOG(obj, "   Clear multiple context using rule:");
    length = sizeof(pmp_ctx_by_rule_id_clear_request_msg_t) - sizeof(uint32_t);
    memset(clearReq, 0, length);
    clearReq->header.protocolVersion = PMP_CURRENT_VERSION;
    clearReq->header.msgType         = pmp_ctx_by_rule_id_clear_request_msg_type_e;
    clearReq->header.reserved        = 0;
    clearReq->header.msgLength       = htonl(length);
    clearReq->header.msgId           = (uintptr_t)obj->handle;
    clearReq->firstSessionId         = 0;
    clearReq->sessionDepth           = 0;
    clearReq->numberOfSession        = 0;
    ruleIndex = 1;
    while ( ruleIds[ruleIndex] != -1 )
    {
        if(ruleIds[ruleIndex] < obj->numRules) {
            _PMLA_TEST_LOG(obj, "      ruleId=%d", ruleIds[ruleIndex]);
            length += sizeof(uint32_t);
            clearReq->ruleIds[ruleIndex-1] = htonl(ruleIds[ruleIndex]);
            clearReq->header.msgLength = htonl(length);
        }
        ruleIndex++;
    }
    LOG_STRING(LOG_TEST, _PMLA_TEST, "About to send the request");
    code = pmlaSend(obj->handle, (pmp_msg_t *)clearReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to send multi clear request (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* This command can take a long time, waiting for completion */
    code = pmlaFlush(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to complete the clear request (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Read the three session context blocks back */
    _PMLA_TEST_LOG(obj, "   Reading session data");
    for ( blockId=0; blockId<_numSessionBlocks; blockId++ )
    {
        cl = results1[blockId];
        for ( clId=0; clId<numCls; clId++ )
        {
            errorCount += _readEntry(obj, pmp_session_context_table_id_e, 
                                     _firstSessionCl(obj, _firstSessionId+blockId) +
                                     clId, cl);
            cl += PMP_SESSION_CONTEXT_ENTRY_SIZE;
        }
    }

    /* Alter the patterns to reflect the expected reset state */
    ruleIndex = 0;
    while ( ruleIds[ruleIndex] != -1 )
    {
        if(ruleIds[ruleIndex] < obj->numRules) {
            for ( blockId=0; blockId<_numSessionBlocks; blockId++ )
            {
                pattern1[blockId][ruleIds[ruleIndex] / 8] &= 
                    ~(1 << (7 - (ruleIds[ruleIndex]%8)));
            }
        }
        ruleIndex++;
    }

    /* Compare the results */
    _PMLA_TEST_LOG(obj, "   Verifying the results");
    for ( blockId=0; blockId<_numSessionBlocks; blockId++ )
    {
        if ( memcmp(pattern1[blockId], results1[blockId], numCompares) != 0 )
        {
            _PMLA_TEST_LOG(obj, "   Session %d not cleared properly", 
                           _firstSessionId+blockId);
            _PMLA_TEST_LOG(obj, "   Got the following:");
            LOG_MEMORY_DUMP(LOG_TMP, _PMLA_TEST, results1[blockId], 64);
            _PMLA_TEST_LOG(obj, "   Was expecting:");
            LOG_MEMORY_DUMP(LOG_TMP, _PMLA_TEST, pattern1[blockId], 64);
            errorCount++;
        }
    }

    /* Read the zeroed session context block back */
    _PMLA_TEST_LOG(obj, "   Reading zeroed session data");
    cl = results1[0];
    for ( clId=0; clId<numCls; clId++ )
    {
        errorCount += _readEntry(obj, pmp_session_context_table_id_e, 
                                 _firstSessionCl(obj, _zeroSessionId) + clId, cl);
        cl += PMP_SESSION_CONTEXT_ENTRY_SIZE;
    }

    /* Compare the results */
    _PMLA_TEST_LOG(obj, "   Verifying the zeroed result");
    if ( memcmp(allZero1, results1[0], numCompares) != 0 )
    {
        _PMLA_TEST_LOG(obj, "   Session %d not cleared properly", 
                       _zeroSessionId);
        _PMLA_TEST_LOG(obj, "   Got the following:");
        LOG_MEMORY_DUMP(LOG_TMP, _PMLA_TEST, results1[0], 64);
        _PMLA_TEST_LOG(obj, "   Was expecting:");
        LOG_MEMORY_DUMP(LOG_TMP, _PMLA_TEST, allZero1, 64);
        errorCount++;
    }
    
    _PMLA_TEST_LOG(obj, "   Completed.");
    
    for(i =0; i < _numSessionBlocks; i++)
    {
        free(pattern1[i]);
        free(results1[i]);
    }
    free(allZero1);
    free(pattern1);
    free(results1);
    
    return _testDone(obj, errorCount);
}

static int _testClearAllContext(PmlaSrmClientTestObj_t *obj)
{
    static uint8_t pattern1[PMP_SESSION_CONTEXT_ENTRY_SIZE];
    static uint8_t results1[PMP_SESSION_CONTEXT_ENTRY_SIZE];
    static uint8_t allZero1[PMP_SESSION_CONTEXT_ENTRY_SIZE];
    pmp_ctx_all_clear_request_msg_t clearReq;
    int sessions[] = { 1, 2, 3, 100, 259, 1013, -1 };
    int num256Rules = 2;
    int session;
    int ruleBlock;
    int clId;
    bool isToldAboutReset;
    bool isToldAboutUnchange;
    int errorCount = 0;
    int warningCount = 0;
    PmlaError_t code;   
    int maxSession;
    
    _PMLA_TEST_LOG(obj, "TEST:  pmp_ctx_all_clear_request_msg_type_e");
    
    maxSession = obj->numSession;
    
    num256Rules = obj->numRules >> 8; // Each rule take one bit in digest.

    _PMLA_TEST_LOG(obj, "   maxSession=%d maxRule/256=%d", maxSession, num256Rules);
    /* Fill in the buffers */
    memset(pattern1, 0xff, PMP_SESSION_CONTEXT_ENTRY_SIZE);
    memset(results1, 0x00, PMP_SESSION_CONTEXT_ENTRY_SIZE);
    memset(allZero1, 0x00, PMP_SESSION_CONTEXT_ENTRY_SIZE);

    /* Set digests of a few sessions */
    _PMLA_TEST_LOG(obj, "   Fake some rule contexts");
    session = 0;
    while (sessions[session] >= 0 && sessions[session] <= maxSession)
    {
        for ( ruleBlock=0; ruleBlock<num256Rules; ruleBlock++ )
        {
            clId = (sessions[session] * 
                    obj->ctxSize /
                    PMP_SESSION_CONTEXT_ENTRY_SIZE) + ruleBlock;
            errorCount += _writeEntry(obj, pmp_session_context_table_id_e, clId, 
                                      pattern1);
        }
        session++;
    }

    /* Clear all session */
    _PMLA_TEST_LOG(obj, "   Clear all contexts");
    memset(&clearReq, 0, sizeof(clearReq));
    clearReq.header.protocolVersion = PMP_CURRENT_VERSION;
    clearReq.header.msgType         = pmp_ctx_all_clear_request_msg_type_e;
    clearReq.header.reserved        = 0;
    clearReq.header.msgLength       = htonl(sizeof(clearReq));
    clearReq.header.msgId           = (uintptr_t)obj->handle;
    code = pmlaSend(obj->handle, (pmp_msg_t *)&clearReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to send clear request (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Wait for the completion of the command */
    code = pmlaFlush(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Fail to wait for completion (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Read the digest back */
    _PMLA_TEST_LOG(obj, "   Verify some digest");
    session = 0;
    while (sessions[session] >= 0)
    {
        if(sessions[session] >= maxSession) { session++; continue; }
        
        isToldAboutReset = false;
        isToldAboutUnchange = false;
        for ( ruleBlock=0; ruleBlock<num256Rules; ruleBlock++ )
        {
            clId = (sessions[session] * 
                    obj->ctxSize /
                    PMP_SESSION_CONTEXT_ENTRY_SIZE) + ruleBlock;
            errorCount += _readEntry(obj, pmp_session_context_table_id_e, clId, 
                                     results1);

            if ( memcmp(results1, allZero1, PMP_SESSION_CONTEXT_ENTRY_SIZE) 
                 != 0 )
            {
                if ( sessions[session] > 3 ) warningCount++;
                else errorCount++;
                if ( !isToldAboutReset )
                {
                    _PMLA_TEST_LOG(obj, "   SessionId %d not reset (%d)", 
                                   sessions[session], ruleBlock);
                    isToldAboutReset = true;
                }
            }
            if ( memcmp(results1, pattern1, PMP_SESSION_CONTEXT_ENTRY_SIZE) 
                 == 0 )
            {
                if ( sessions[session] > 3 ) warningCount++;
                else errorCount++;
                if ( !isToldAboutUnchange )
                {
                    _PMLA_TEST_LOG(obj, "   SessionId %d is unchanged (%d)", 
                               sessions[session], ruleBlock);
                    isToldAboutUnchange = true;
                }
            }
        }

        session++;
    }

    if ( warningCount )
    {
        /* In co-simulation, we are limiting the number of sessionId.  This has
         * the implication that not all session context are cleared by this
         * function.  We spitted out a note to track it down but don't fail the
         * test because of that.
         */
        _PMLA_TEST_LOG(obj, "Note:  %d warnings were observed", warningCount);
    }

    return _testDone(obj, errorCount);
}

static int _testEmptyAtomicity(PmlaSrmClientTestObj_t *obj)
{
    pmp_attribute_set_request_msg_t atomReq;
    int errorCount = 0;
    PmlaError_t code;
    int length;

    _PMLA_TEST_LOG(obj, "TEST:  pmp_atomic_attr_id_e (short)");

    /* Request for atomicity on the master handle */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Starting atomicity");
    length = PMP_ATTRIBUTE_SET_REQUEST_MSG_SIZE(sizeof(pmp_atomic_attr_t));
    memset(&atomReq, 0, sizeof(atomReq));
    atomReq.header.protocolVersion = PMP_CURRENT_VERSION;
    atomReq.header.msgType         = pmp_attribute_set_request_msg_type_e;
    atomReq.header.reserved        = 0;
    atomReq.header.msgLength       = htonl(length);
    atomReq.header.msgId           = (uintptr_t)obj->handle;
    atomReq.attributeId            = htonl(pmp_atomic_attr_id_e);
    atomReq.attributeValue.atomicAttr = htonl(1);
    code = pmlaSend(obj->handle, (pmp_msg_t *)&atomReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't start atomicity (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Wait for five seconds */
    sleep(5);

    /* Stop atomicity */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Ending atomicity");
    atomReq.attributeValue.atomicAttr = htonl(0);
    code = pmlaSend(obj->handle, (pmp_msg_t *)&atomReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't stop atomicity (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    return _testDone(obj, errorCount);
}

static int _testAtomicity(PmlaSrmClientTestObj_t *obj)
{
    PmlaTarget_t target2;
    handle_t pmla2;
    pmp_attribute_set_request_msg_t atomReq;
    pmp_table_read_request_msg_t readReq;
    uint8_t reply[PMLA_SRM_CLIENT_TEST_SIZE];
    pmp_table_read_reply_msg_t *readReply = (pmp_table_read_reply_msg_t *)reply;
    int readReplyLen;
    int errorCount = 0;
    int timeout;
    PmlaError_t code;
    int length;

    _PMLA_TEST_LOG(obj, "TEST:  pmp_atomic_attr_id_e (long)");

    /* Give the target a few seconds to settles down (i.e. to prevent logging
     * collisions).
     */
    sleep(5);

    /* Need another PMLA handle to test this one */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Opening an additional handle");
    memcpy(&target2, &obj->target, sizeof(PmlaTarget_t));
    code = pmlaOpen(&target2, &pmla2);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't create second PMLA handle (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Connecting to target");
    code = pmlaConnect(pmla2);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Second PMLA can't connect (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Build a read request message */
    memset(&readReq, 0, sizeof(readReq));
    memset(readReply, 0, PMLA_SRM_CLIENT_TEST_SIZE);
    readReq.header.protocolVersion = PMP_CURRENT_VERSION;
    readReq.header.msgType         = pmp_table_read_request_msg_type_e;
    readReq.header.reserved        = 0;
    readReq.header.msgLength       = htonl(sizeof(pmp_table_read_request_msg_t));
    readReq.header.msgId           = (uintptr_t)pmla2;
    readReq.tableId                = htonl(pmp_confidence_table_id_e);
    readReq.index                  = htonl(0);

    /* Set the timeout value for the duration of this test */
    timeout = 10;
    code = pmlaSetOption(obj->handle, pmlaOptionTimeout_c, 
                         &timeout, sizeof(timeout));
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't set timeout %d on primary (%d:%s)", 
                       timeout, code, pmlaErrorString(code));
        return 1;
    }
    code = pmlaSetOption(pmla2, pmlaOptionTimeout_c, 
                         &timeout, sizeof(timeout));
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't set timeout %d on secondary (%d:%s)",
                       timeout, code, pmlaErrorString(code));
        return 1;
    }

    /* Ensure the second PMLA can read data */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Sending first read request");
    code = pmlaSend(pmla2, (pmp_msg_t *)&readReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't request first read (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Waiting for first read request");
    readReplyLen = PMP_CONFIDENCE_TABLE_READ_REPLY_MSG_SIZE;
    code = pmlaRecv(pmla2, (pmp_msg_t *)readReply);
    if ( code == pmlaTimedOut_c )
    {
        _PMLA_TEST_LOG(obj, "   Unexpected timeout");
        return _testDone(obj, ++errorCount);
    }
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't get the first reply (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Request for atomicity on the master handle */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Starting atomicity");
    length = PMP_ATTRIBUTE_SET_REQUEST_MSG_SIZE(sizeof(pmp_atomic_attr_t));
    memset(&atomReq, 0, sizeof(atomReq));
    atomReq.header.protocolVersion = PMP_CURRENT_VERSION;
    atomReq.header.msgType         = pmp_attribute_set_request_msg_type_e;
    atomReq.header.reserved        = 0;
    atomReq.header.msgLength       = htonl(length);
    atomReq.header.msgId           = (uintptr_t)obj->handle;
    atomReq.attributeId            = htonl(pmp_atomic_attr_id_e);
    atomReq.attributeValue.atomicAttr = htonl(1);
    code = pmlaSend(obj->handle, (pmp_msg_t *)&atomReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't start atomicity (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }
    code = pmlaFlush(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't complete start of atomicity (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Repeat the read request but this time, we should time out */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Sending second read request");
    code = pmlaSend(pmla2, (pmp_msg_t *)&readReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't request second read (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Waiting for second read request");
    readReplyLen = PMP_CONFIDENCE_TABLE_READ_REPLY_MSG_SIZE;
    code = pmlaRecv(pmla2, (pmp_msg_t *)readReply);
    if ( code != pmlaTimedOut_c )
    {
        _PMLA_TEST_LOG(obj, "   Test failed, expected time out here (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Stop atomicity */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Ending atomicity");
    atomReq.attributeValue.atomicAttr = htonl(0);
    code = pmlaSend(obj->handle, (pmp_msg_t *)&atomReq);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't end atomicity (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }
    code = pmlaFlush(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't complete end of atomicity (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* This time around, the second read request should come back */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Waiting for second read request");
    readReplyLen = PMP_CONFIDENCE_TABLE_READ_REPLY_MSG_SIZE;
    code = pmlaRecv(pmla2, (pmp_msg_t *)readReply);
    if ( (code != pmlaSuccess_c) && (code != pmlaTimedOut_c) )
    {
        _PMLA_TEST_LOG(obj, "   Can't get second reply from second attempt");
        return _testDone(obj, ++errorCount);
    }
    if ( code == pmlaTimedOut_c )
    {
        _PMLA_TEST_LOG(obj, "   Test failed, we expected the result here");
        return _testDone(obj, ++errorCount);
    }

    /* Kill the second PMLA handle */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Closing secondary PMLA handle");
    code = pmlaClose(pmla2);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't close secondary PMLA handle (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    return _testDone(obj, errorCount);
}

static int _testScanData(PmlaSrmClientTestObj_t *obj)
{
    int i;
    uint8_t equivalence[PMP_EQUIVALENCE_ENTRY_SIZE];
    uint32_t stIndex = 0x148;
    uint8_t stData[] = { 0x00, 0x00, 0x00, 0x00, 0x11, 0x83, 0x06, 0x0C };
    uint32_t cdIndex = 0x4520;
    uint8_t cdData[] = { 0x40, 0x40, 0x10, 0xC5 };
    uint32_t cmIndex = 0x4520;
    uint8_t cmData[] = { 0xFC, 0x81, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF,
                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                         0x00, 0x80, 0x00, 0x01, 0x01, 0x1F, 0xAA, 0x00,
                         0x41, 0x42, 0x43, 0x44, 0x00, 0x00, 0x00, 0x00,
                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                         0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                         0x60, 0x53, 0x01, 0x40, 0x20, 0x45, 0x00, 0x00, 
                         0x40, 0x40, 0x10, 0xc5, 0x20, 0x45, 0x00, 0x00, 
                         0x00, 0x00, 0x00, 0x00, 0x11, 0x83, 0x06, 0x0c, 
                         0x00, 0x00, 0x00, 0x00, 0x48, 0x01, 0x00, 0x00, 
                         0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 
                         0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 
                         0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 
                         0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f };
    char matchedData[] = "Mon alphabet is ABCDEFG...";
    char unmatchedData[] = "Bonjour la police!";
    int errorCount = 0;
    PmlaError_t code;

    _PMLA_TEST_LOG(obj, "TEST:  pmp_data_scan_request_msg_type_e");

    /* Reset all the trigger tables */
    _clearAllEntries(obj, pmp_one_byte_trigger_table_id_e);
    _clearAllEntries(obj, pmp_two_byte_trigger_table_id_e);
    _clearAllEntries(obj, pmp_variable_trigger_table_id_e);

    /* Configure the equivalence table */
    for ( i=0; i<PMP_EQUIVALENCE_ENTRY_SIZE; i++ )
    {
        if ( (i >= 'a') && (i <= 'z') )
        {
            equivalence[i] = i - 'a' + 'A';
        }
        else
        {
            equivalence[i] = i;
        }
    }
    errorCount += _writeEntry(obj, pmp_equivalence_table_id_e, 0, equivalence);

    /* Configure the short trigger entry */
    errorCount += _writeEntry(obj, pmp_two_byte_trigger_table_id_e,stIndex,stData);

    /* Configure the confidence entry */
    errorCount += _writeEntry(obj, pmp_confidence_table_id_e, cdIndex, cdData);

    /* Configure the confirmation entry */
    errorCount += _writeEntry(obj, pmp_confirmation_table_id_e,cmIndex,cmData);

    /* Wait for the command to be flushed out */
    code = pmlaFlush(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't flush the write commands (%d:%s)",
                       code, pmlaErrorString(code));
        errorCount++;
    }

    /* Scan twice, once positively, once negatively */
    errorCount += _scanData(obj, 0, 0xffff, 0, matchedData, 
                            strlen(matchedData), true);
    errorCount += _scanData(obj, 0, 0xffff, 0, unmatchedData, 
                            strlen(unmatchedData), false);

    return _testDone(obj, errorCount);
}

static int _testBulk(PmlaSrmClientTestObj_t *obj)
{
    pmp_table_read_request_msg_t readReq;
    uint8_t reply[PMLA_SRM_CLIENT_TEST_SIZE];
    pmp_table_read_reply_msg_t *readReply = (pmp_table_read_reply_msg_t *)reply;
    int readReplyLen;
    int iter;
    int errorCount = 0;
    int timeout;
    PmlaError_t code;

    _PMLA_TEST_LOG(obj, "TEST:  pmlaSendBulkBegin(...)/pmlaSendBulkEnd(...)");

    /* Start a bulk operation */
    code = pmlaSendBulkBegin(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Failed to begin bulk operation (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Set the timeout value for the duration of this test */
    timeout = 30;
    code = pmlaSetOption(obj->handle, pmlaOptionTimeout_c, 
                         &timeout, sizeof(timeout));
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't set timeout value %d (%d:%s)",
                       timeout, code, pmlaErrorString(code));
        return 1;
    }

    /* Send three read request message */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Sending the read request");
    memset(&readReq, 0, sizeof(readReq));
    memset(readReply, 0, PMLA_SRM_CLIENT_TEST_SIZE);
    readReq.header.protocolVersion = PMP_CURRENT_VERSION;
    readReq.header.msgType         = pmp_table_read_request_msg_type_e;
    readReq.header.reserved        = 0;
    readReq.header.msgLength       = htonl(sizeof(pmp_table_read_request_msg_t));
    readReq.header.msgId           = (uintptr_t)obj->handle;
    readReq.tableId                = htonl(pmp_confidence_table_id_e);
    readReq.index                  = htonl(0);
    for ( iter=0; iter<3; iter++ )
    {
        _PMLA_TEST_LOG(obj, "   Request index %d", iter);
        readReq.index = htonl(iter);
        code = pmlaSend(obj->handle, (pmp_msg_t *)&readReq);
        if ( code != pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   Can't request read (%d:%s)",
                           code, pmlaErrorString(code));
            return _testDone(obj, ++errorCount);
        }
    }

    /* Ensure we are not getting any reply yet */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Checking unexpected reply");
    readReplyLen = PMP_CONFIDENCE_TABLE_READ_REPLY_MSG_SIZE;
    code = pmlaRecv(obj->handle, (pmp_msg_t *)readReply);
    if ( (code != pmlaSuccess_c) && (code != pmlaTimedOut_c) )
    {
        _PMLA_TEST_LOG(obj, "   Can't wait for a reply (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }
    if ( code == pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Unexpected reply");
        return _testDone(obj, ++errorCount);
    }

    /* End the bulk operation */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Ending bulk operation");
    code = pmlaSendBulkEnd(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "   Can't end bulk operation (%d:%s)",
                       code, pmlaErrorString(code));
        return _testDone(obj, ++errorCount);
    }

    /* Now the three replies should come back */
    LOG_STRING(LOG_TEST, _PMLA_TEST, "Retrieving read replies");
    for ( iter=0; iter<3; iter++ )
    {
        _PMLA_TEST_LOG(obj, "   Reply for index %d", iter);
        readReplyLen = PMP_CONFIDENCE_TABLE_READ_REPLY_MSG_SIZE;
        code = pmlaRecv(obj->handle, (pmp_msg_t *)readReply);
        if ( (code != pmlaSuccess_c) && (code != pmlaTimedOut_c) )
        {
            _PMLA_TEST_LOG(obj, "Can't get the reply %d (%d:%s)", 
                           iter, code, pmlaErrorString(code));
            return _testDone(obj, ++errorCount);
        }
        if ( code == pmlaTimedOut_c )
        {
            _PMLA_TEST_LOG(obj, "   Unexpected timeout");
            return _testDone(obj, ++errorCount);
        }
        if ( (int)ntohl(readReply->indexedEntry.index) != iter )
        {
            _PMLA_TEST_LOG(obj, "   Message out-of-sequence");
            LOG_MEMORY_DUMP(LOG_TEST, _PMLA_TEST, readReply, readReplyLen);
            return _testDone(obj, ++errorCount);
        }
    }

    return _testDone(obj, errorCount);
}

static int _testDataAppClearBySessionId(PmlaSrmClientTestObj_t *obj)
{
    int status;
    uint32_t sessionId = 3;

    _PMLA_TEST_LOG(obj, "TEST:  pmci_context_clear_by_session_id(...)");

    status = pmci_context_clear_by_session_id(sessionId);
    if ( status < 0 )
    {
        _PMLA_TEST_LOG(obj, "Failed.");
    }
    else
    {
        _PMLA_TEST_LOG(obj, "Passed.");
    }

    return 0;
}

static int _testOpenCloseRepetition(PmlaSrmClientTestObj_t *obj)
{
    PmlaTarget_t target;
    handle_t pmla;
    int repeat = 400;
    int errorCount = 0;
    PmlaError_t code;

    _PMLA_TEST_LOG(obj, "TEST:  pmlaOpen(...)/pmlaClose(...) repetition");

    if ( obj->skipLongTests ) repeat = 10;

    _PMLA_TEST_LOG(obj, "   Testing %d iterations", repeat);

    while(repeat--)
    {
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Testing PMLA handle %d", repeat);

        /* Open a pmla handle */
        memcpy(&target, &obj->target, sizeof(PmlaTarget_t));
        code = pmlaOpen(&target, &pmla);
        if ( code != pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   Can't create PMLA handle %d (%d:%s)",
                           repeat, code, pmlaErrorString(code));
            return _testDone(obj, ++errorCount);
        }
        code = pmlaConnect(pmla);
        if ( code != pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   PMLA can't connect %d (%d:%s)",
                           repeat, code, pmlaErrorString(code));
            return _testDone(obj, ++errorCount);
        }

        /* Just flush the handle to get something through */
        code = pmlaFlush(pmla);
        if ( code != pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   Can't flush the PMLA handle (%d:%s)",
                           code, pmlaErrorString(code));
            errorCount++;
        }

        /* Close the handle */
        code = pmlaClose(pmla);
        if ( code != pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   Can't close the PMLA handle (%d:%s)",
                           code, pmlaErrorString(code));
            errorCount++;
        }

        if(!obj->local)
        {
            /* Co-simulation target can't handle fast request properly */
            LOG_STRING(LOG_TEST, _PMLA_TEST, "Give the target a break");
            sleep(7);
        }
    }

    if(!obj->local)
    {
        _PMLA_TEST_LOG(obj, "   Waiting a bit");
        sleep(10);
    }

    return _testDone(obj, errorCount);
}

static int _testOpenCloseCapacity(PmlaSrmClientTestObj_t *obj)
{
    PmlaTarget_t target;
    int errorCount = 0;
    int capacity = 7;
    int loop;
    handle_t *handles;
    PmlaError_t code;

    _PMLA_TEST_LOG(obj, "TEST:  pmlaOpen(...)/pmlaClose(...) capacity");

    _PMLA_TEST_LOG(obj, "   Opening %d concurent handles", capacity);

    handles = malloc(capacity*sizeof(handle_t));
    if ( handles == NULL )
    {
        _PMLA_TEST_LOG(obj, "   Cannot allocate memory");
        return ++errorCount;
    }

    for ( loop=0; loop<capacity; loop++ )
    {
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Testing PMLA handle %d", loop);

        /* Open a pmla handle */
        memcpy(&target, &obj->target, sizeof(PmlaTarget_t));
        code = pmlaOpen(&target, &handles[loop]);
        if ( code != pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   Can't create PMLA handle (%d:%s)",
                           code, pmlaErrorString(code));
            errorCount++;
        }
        else
        {
            /* Connect to the target */
            code = pmlaConnect(handles[loop]);
            if ( loop < (capacity-1) )
            {
                if ( code != pmlaSuccess_c )
                {
                    _PMLA_TEST_LOG(obj, "   PMLA can't connect (%d:%s)",
                                   code, pmlaErrorString(code));
                    errorCount++;
                }
                else
                {
                    /* Just flush the handle to get something through */
                    code = pmlaFlush(handles[loop]);
                    if ( code != pmlaSuccess_c )
                    {
                        _PMLA_TEST_LOG(obj, "   Can't flush the PMLA handle "
                                       "(%d:%s)", code, pmlaErrorString(code));
                        errorCount++;
                    }
                }
            }
            else
            {
                if ( code == pmlaSuccess_c )
                {
                    _PMLA_TEST_LOG(obj, "   PMLA wasn't supposed to connect");
                    errorCount++;
                }
                if ( code != pmlaTransportError_c )
                {
                    _PMLA_TEST_LOG(obj, "   Wrong expected code (%d:%s)",
                                   code, pmlaErrorString(code));
                    errorCount++;
                }
            }
        }

        /* Co-simulation target can't handle fast request properly */
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Give the target a break");
        sleep(2);
    }

    _PMLA_TEST_LOG(obj, "   Closing all handles");

    for ( loop=0; loop<(capacity-1); loop++ )
    {
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Closing PMLA handle %d", loop);

        /* Close the handle */
        code = pmlaClose(handles[loop]);
        if ( code != pmlaSuccess_c )
        {
            _PMLA_TEST_LOG(obj, "   Can't close the PMLA handle (%d:%s)",
                           code, pmlaErrorString(code));
            errorCount++;
        }

        /* Co-simulation target can't handle fast request properly */
        LOG_STRING(LOG_TEST, _PMLA_TEST, "Give the target a break");
        sleep(2);
    }

    _PMLA_TEST_LOG(obj, "   Waiting a bit");
    sleep(10);

    return _testDone(obj, errorCount);
}

static int _testDone(PmlaSrmClientTestObj_t *obj, int numErrors)
{
    int s;

    /* Measure time it took to execute this test */
    if ( clock_gettime(CLOCK_REALTIME, &_t2) != 0 )
    {
        _PMLA_TEST_LOG(obj, "   Can't get time");
        s = 0;
    }
    else
    {
        s = _t2.tv_sec - _tx.tv_sec;
        _tx = _t2;
    }

    /* Display result message with elapsed time */
    if ( obj->hideHighlights )
    {
        if ( numErrors )
        {
            _PMLA_TEST_LOG(obj, "Failed.  (%d errors, %d seconds)", 
                           numErrors, s);
        }
        else
        {
            _PMLA_TEST_LOG(obj, "Passed.  (%d seconds)", s);
        }
    }
    else
    {
        if ( numErrors )
        {
            _PMLA_TEST_LOG(obj, "%sFailed.  (%d errors, %d seconds)%s", 
                           PMLA_SRM_HIGHLIGHT_RED, numErrors, s,
                           PMLA_SRM_HIGHLIGHT_OFF);
        }
        else
        {
            _PMLA_TEST_LOG(obj, "%sPassed.  (%d seconds)%s", 
                           PMLA_SRM_HIGHLIGHT_GREEN, s, 
                           PMLA_SRM_HIGHLIGHT_OFF);
        }
    }
    return numErrors;
}

static void _signalHandler(int signum)
{
    _PMLA_TEST_LOG(&_obj, "Interrupted by signal %d", signum);
    _quit(&_obj);
    exit(0);
}

static void _quit(PmlaSrmClientTestObj_t *obj)
{
    int sec;
    PmlaError_t code;

    /* Take another snapshot and report execution time */
    if ( clock_gettime(CLOCK_REALTIME, &_t2) != 0 )
    {
        _PMLA_TEST_LOG(obj, "Can't get time");
        return;
    }
    sec = _t2.tv_sec - _t1.tv_sec;
    if ( sec > 3600 )
    {
        _PMLA_TEST_LOG(obj, "Execution completed in %d hours, %d minutes, "
                       "%d seconds", sec/3600, (sec%3600)/60, (sec%3600)%60);
    }
    else if ( sec > 60 )
    {
        _PMLA_TEST_LOG(obj, "Execution completed in %d minutes, %d seconds", 
                       sec/60, sec%60);
    }
    else
    {
        _PMLA_TEST_LOG(obj, "Execution completed in %d seconds", sec);
    }

    /* Disconnect the PMLA */
    _PMLA_TEST_LOG(obj, "Disconnecting from the server");
    code = pmlaDisconnect(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "Can't disconnect (%d:%s)",
                       code, pmlaErrorString(code));
        return;
    }

    /* Close the handle */
    _PMLA_TEST_LOG(obj, "Closing the loader agent handle");
    code = pmlaClose(obj->handle);
    if ( code != pmlaSuccess_c )
    {
        _PMLA_TEST_LOG(obj, "Can't close (%d:%s)",
                       code, pmlaErrorString(code));
        return;
    }
    
    _PMLA_TEST_LOG(obj, "Goodbye!");

}

int _firstSessionCl(PmlaSrmClientTestObj_t* obj, int sessionId)
{
    return (sessionId) * obj->ctxSize / PMP_SESSION_CONTEXT_ENTRY_SIZE;
}
    

