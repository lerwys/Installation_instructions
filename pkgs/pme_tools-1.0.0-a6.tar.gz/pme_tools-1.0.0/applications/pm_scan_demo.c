/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : pm_scan_demo.c
 *
 *   This file contains the implementation of the Pattern Matching
 *   Scan Demo application.
 *
 ****************************************************************************/

/* 
 * Platform Header files
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>

/*
 * Freescale PM Header files
 */
#include <fsl_pme.h>
#include <pmp.h>
#include <pmci.h>
#include <dll.h>

/*
 * Program constants
 */
#define PMSCAN_DEFAULT_CHANNEL 0
#define PMSCAN_DEFAULT_SET 0
#define PMSCAN_DEFAULT_SUBSET 0xffff
#define PMSCAN_DEFAULT_SESSION 1

/* Return code for long options */
enum {
    pmscan_option_help_e=128,
    pmscan_option_str_e,
    pmscan_option_file_e,
    pmscan_option_mode_e,
    pmscan_option_set_e,
    pmscan_option_subset_e,
    pmscan_option_verbose_e,
    pmscan_option_residue_e,
    pmscan_option_session_e,
    pmscan_option_silent_e,
    pmscan_option_detail_e
};

/* Error codes */
enum {
    pmscan_ok_e = 0,
    pmscan_error_bad_option_e  = 1,
    pmscan_error_malloc_e      = 2,
    pmscan_error_exception_e   = 3,
    pmscan_error_driver_e      = 4,
    pmscan_error_file_io_e     = 5,
    pmscan_error_unsupported_e = 6,
    pmscan_error_unknown       = 7
};


/* 
 * Internal types
 */

/* Buffer list type.  Used for list of scan buffer. */
typedef struct {
    dll_node_t  dllNode;
    uint32_t len;
    uint8_t buf[0];
} pmscan_buf_t;

// TODO use pre-allocated buffer untill BMan buffer available from driver.
#define REPORT_BUF_SIZE (2*1024*1024)
static uint8_t report_buf_g[REPORT_BUF_SIZE];

/*
 * Internal functions
 */

/****************************************************************************************
   Free all allocated buffer in the list.
   
    parameter: the list that will be freed and emptied.
    return value: none.
 ****************************************************************************************/
static void _pmscan_free_buffer_list(dll_list_t* buf_list_p)
{
    pmscan_buf_t* buf_p = NULL;
    pmscan_buf_t* next_buf_p = NULL;
    
    buf_p = DLL_STRUCT_FROM_NODE_GET(dll_get_first(buf_list_p), 
                                     pmscan_buf_t, dllNode);
    /* Free all allocated buffers.  There is not need to remove them from the DLL list. */
    while (buf_p != NULL) {
        next_buf_p = DLL_STRUCT_FROM_NODE_GET(dll_get_next_node(buf_list_p, &buf_p->dllNode ),
                                              pmscan_buf_t, dllNode);
        free(buf_p);
        buf_p = next_buf_p;
    }
    /* Initialize the head of the list. */
    dll_list_init(buf_list_p);
}


/****************************************************************************************
   A simple routine is needed to convert the value 6 byte array back into 
   processable 64bit value.  It came from the language limitation that there is
   no simple type that can represent the 48 bit unit offset $N from HW. 
   Note: This routine only works in big-endian machine.
   
    parameter: buffer containing 6 bytes, big-endian order.
    return value: big-endian uint64_t value of the 48bit data.
 ****************************************************************************************/
static inline uint64_t _pmscan_get_unit_offset(uint8_t* buf)
{
    uint64_t rc = 0;
    memcpy(((uint8_t*)&rc) + (sizeof(uint64_t) - PMP_REPORT_WORK_UNIT_OFFSET_SIZE), 
           buf, PMP_REPORT_WORK_UNIT_OFFSET_SIZE);
    return rc;
}

/****************************************************************************************
   Simple string to integer converter that can handle NN or 0xNN.  An expended version
   of atoi().
   
    parameter: input string.
    return value: converted integer value.
 ****************************************************************************************/
static int _pmscan_string_to_int(char* str)
{
    int len = strlen(str);
    int rc = 0;
    const int min_size_hex_str = 3;
    
    if (len >= min_size_hex_str && str[0] == '0' && (str[1] == 'x' || str[1] == 'X')) {
        sscanf(str+2, "%x", &rc);
        return rc;
    }
    else return atoi(str);
}

/****************************************************************************************
   Covert hex string e.g. "AB" into 0xAB, "01" into 0x01.
   Has basic error checking.  "H2" will be converted into 0x00.
   
    parameter: two byte string.
    return value: converted uint8_t value.
 ****************************************************************************************/
static uint8_t _pmscan_two_char_to_hex(char* hex_char)
{
    uint8_t value = 0;
    int i = 0;
    uint8_t c;
    
    for (i = 0; i < 2; i++) {
        value <<= 4;
        c = hex_char[i];
        if (c >= '0' && c <= '9') value |= c - '0';
        else if (c >= 'a' && c <= 'f') value |= c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') value |= c - 'A' + 10;
        else return 0;
    }
    return value;
}

/****************************************************************************************
   Calculate the size needed to store the coverted meta string.  
   e.g. "\x00" will return 1
        "abc" will return 3 
        "ab\x00\xffcd" will return 6
        
    parameter: The user input string.
    return value: String length of the decoded meta string.
 ****************************************************************************************/
static int _pmscan_meta_strlen(char* str)
{
    int len = 0;
    int i = 0;
    int end = strlen(str);
    /* 4 == strlen("\\xNN") */
    const int size_of_meta_str = 4;
    
    while (i < end) {
        if (str[i] == '\\' &&
            end - i >= size_of_meta_str && /* Still have room for \xNN */
            (str[i+1] == 'x' || str[i+1] == 'X') ) {
            i += size_of_meta_str;
            len++;
        } else {
            i++;
            len++;
        }
    }
    return len;
}

/****************************************************************************************
   Convert a meta string into what it represents in binary.
   e.g. For str = "ab\x05", target will have {0x61, 0x62, 0x05} 
        For str = "\x00\xff", target will have {0x01, 0xff}
   Note: No support for incomplete hex representation, e.g.
        For str = "a\x3", target will have {0x61, 0x5c, 0x78, 0x33}
   Returned target buffer may contain non-printable bytes and not null terminated.
   
    parameter: target buffer of converted string, original null terminated string, 
               target buffer size.
    return value: Number of bytes copied into the target buffer.
 ****************************************************************************************/
static int _pmscan_meta_strcpy(uint8_t* target, char* str, int target_size)
{
    int cpy_len = 0;
    int i = 0;
    int end = strlen(str);
    /* strlen("\\xNN") == 4 */
    const int size_of_meta_str = 4;
    
    while (cpy_len < target_size) {
        if (str[i] == '\\' &&
            end - i >= size_of_meta_str &&
            (str[i+1] == 'x' || str[i+1] == 'X')) {
            target[cpy_len] = _pmscan_two_char_to_hex(str+i+2);
            i += size_of_meta_str;
            cpy_len++;
        } else {
            target[cpy_len] = str[i];
            i++;
            cpy_len++;
        }
        if (str[i] == '\0') break;
    }
    return cpy_len;
}

/* A note on the match report

   After a scan operation, a report buffer is returned by hardware.  A report buffer may 
   contains multiple types of records, such as match report record, rule report record 
   and end-of-report record.

   For example:
   [ simple match report  (16 bytes)
     simple match report  (16 bytes)
     rule report          (variable size)
     simple match report  (16 bytes)
     end-of-report        (5 bytes)
   ]
   or
   [ rule report          (variable size)
     verbose match report (40 bytes)
     rule report          (variable size)
     rule report          (variable size)
     verbose match report (40 bytes)
     end-of-report        (5 bytes)
   ]
   or
   [ end-of-report        (5 bytes)
   ]
   
   Depends on the device parameter, simple or verbose match reports will be generated.

   Rule reports are generated by stateful/stateless rules, if the reaction has a 
   report {...} command.  The length and content of the report will depends on
   the report {...} command.
   
   End-of-report is optional and can be turned off by a pm_base module parameter.
   End-of-report contains the number of byte scanned in the unit.

   Examples on how to decode the match report buffer are covered by these functions:
    _pmscan_count_match_in_report()
    _pmscan_print_match_in_report()
    _pmscan_dump_match()
 */

/****************************************************************************************
   This routine dumps the scan data and show which bytes are covered by reported matches. 
   Requires ANSI/VT-100 complient terminal to display the ANSI colours properly.
   
    parameters: scan data buffer, scan data length, report buffer, report buffer length.
    return value: pmscan_ok_e, or error code.
 ****************************************************************************************/
static int _pmscan_dump_match(uint8_t* data_buf, uint32_t data_len, 
                              uint8_t* report_buf, uint32_t report_len)
{
    uint8_t* marker_p = NULL;
    uint8_t* inc_marker_p = NULL;
    
    /* first_byte_offset is signed because the match begin offset calculation may returns 
       a negative value. */
    int first_byte_offet = 0, last_byte_offset = 0;
    
    bool hex_mode = false;
    int i = 0, loop_limit = 0;
    int line_width = 0, colour = 0, last_colour = 0;
    
    uint32_t offset = 0;
    uint32_t match_length = 0;
    pmp_rep_rec_type_t type = 0;
    pmp_report_simple_match_record_t* match_record_p = NULL;
    pmp_report_extended_match_record_t* extended_match_record_p = NULL;
    pmp_report_rule_record_t* rule_record_p = NULL;
    
    /* ANSI/VT100 colour:  Reset,     White-on-Green,  White-on-Blue,   Black-on-Yellow */
    char* term_colour[] = {"\033[0m", "\033[1;37;42m", "\033[1;37;44m", "\033[1;30;43m"};
    enum {
        max_colour = 2,
        inc_colour = 3
    };

    /* Nothing to print if we have no data or empty match report. */
    if (data_len == 0 || report_len == 0) return pmscan_ok_e;

    /* Check if we should use hex dump.  Use hex dump if some characters are not printable. */
    while (offset < data_len) {
        if (!isprint(data_buf[offset]) && 
            data_buf[offset] != '\r' && data_buf[offset] != '\n') {
            hex_mode = true;
            break;
        }
        offset++;
    }
    
    /* Mark the bytes that have matches by using a marker table that has the 
       same size as the data. */
    marker_p = calloc(data_len, 1);
    if (marker_p == NULL) {
        printf ("ERROR: Failed to allocate %d bytes\n", data_len);
        return pmscan_error_malloc_e;
    }
    /* Also mark the bytes that have inconclusive matches. */
    inc_marker_p = calloc(data_len, 1);
    if (inc_marker_p == NULL) {
        printf ("ERROR: Failed to allocate %d bytes\n", data_len);
        return pmscan_error_malloc_e;
    }

    offset = 0;
    /* Loop through the whole report to mark all the bytes */
    while (offset < report_len) {
        type = report_buf[offset];
        
        /* Reached the end-of-SUI report */
        if (type == pmp_end_of_report_type_e) break;
        
        if (type == pmp_rule_report_type_e) {
            /* We don't do anything for rule report here.  Just advance to the next record. */
            /* For rule report, the length of the whole record is inside the header. */
            rule_record_p = (pmp_report_rule_record_t*) (report_buf + offset);
            offset += rule_record_p->length;
            continue;
        }
        
        if ((type & pmp_record_type_mask) == pmp_simple_match_type_e ||
           (type & pmp_record_type_mask) == pmp_verbose_match_type_e) {
            /* Both simple and verbose report has a simple report at the beginning. */
            match_record_p = (pmp_report_simple_match_record_t*) (report_buf + offset);
            
            /* matchByteOffset from HW points to the last byte of the match and it starts at 1 
               for the first byte, hence for software address calculation we need to minus 1. */
            last_byte_offset = match_record_p->matchByteOffset - 1;

            match_length = match_record_p->matchLength;
            /*  Extended match report - This is generated by special stateful rules
                that allows reporting of matches long than 255 bytes. */
            if (match_length == pmp_extended_match_report_code_e)
            {
                extended_match_record_p = (pmp_report_extended_match_record_t*) match_record_p;
                match_length = extended_match_record_p->matchLength;
            }
            
            /* The first byte of the match is at matchByteOffset - match_length. */
            first_byte_offet = match_record_p->matchByteOffset - match_length;
            
            /* It is possible to have a match that covers bytes ahead of the current scan 
               unit, if residue feature is enabled and the match covers some residue bytes from 
               the previous scan unit. */
            if (first_byte_offet < 0) first_byte_offet = 0;
            
            /* A match is inconclusive if either inconclusive bit is 1 and
               the full match bit is 0 */
            if ((type & (pmp_inconclusive_left_record_type_class | 
                         pmp_inconclusive_right_record_type_class)) &&
                !(type & pmp_full_match_record_type_class)) {
                /* Mark all the bytes that is covered by this inconclusive match record.  */
                for (i = first_byte_offet; i <= last_byte_offset; i++) {
                    inc_marker_p[i] = 1;
                }
            } else {
                /* Mark all the bytes that is covered by this match record.  */
                for (i = first_byte_offet; i <= last_byte_offset; i++) {
                    if (marker_p[i] < max_colour) marker_p[i]++;
                }
            }
            /* Advance to the next record */
            if ((type & pmp_record_type_mask) == pmp_simple_match_type_e) {
                offset += sizeof(pmp_report_simple_match_record_t);
            }
            else {
                offset += sizeof(pmp_report_verbose_match_record_t);
            }
            continue;
        }
        /* Unsupported type */
        free(marker_p);
        free(inc_marker_p);
        return pmscan_error_unsupported_e;
    }

    /* Print all bytes, with marked bytes covered by ANSI colour.  */
    offset = 0;
    if (hex_mode) line_width = 16;
    else line_width = 80;
    last_colour = colour = 0;
    printf("(1 match:%sX%s | >=2 match:%sX%s | inconclusive only:%sX%s)\n",
          term_colour[1], term_colour[0], term_colour[2], term_colour[0],
          term_colour[inc_colour], term_colour[0]);
    
    /* Loop through each byte of scan data. */
    while ( offset  <  data_len ) {
        if (hex_mode) printf("%04x: ", offset);

        if (data_len - offset >= (uint32_t) line_width) loop_limit = line_width;
        else loop_limit = data_len - offset;
        
        /* Loop for one printing line */
        for (i = 0; i < loop_limit; i++) {
            if (hex_mode) {
                if (last_colour == 0) putchar(' ');
                if (i == line_width / 2) putchar(' ');
            }
            colour = marker_p[offset+i];
            if (colour > max_colour) colour = max_colour;
            if (colour == 0 && inc_marker_p[offset+i]) colour = inc_colour;
            if (colour != last_colour) {
                printf(term_colour[colour]);
            }
            if (hex_mode && last_colour != 0) putchar(' ');
            last_colour = colour;
            
            if (hex_mode) {
                printf("%02hhx", data_buf[offset+i]);
            }
            else { /* ASCII mode */
                if (data_buf[offset+i] == '\r' || data_buf[offset+i] == '\n') {
                    i++;
                    break; /* Leave the line loop. */
                }
                putchar(data_buf[offset+i]);
            }
        }
        if (colour) printf(term_colour[0]);
        last_colour = colour = 0;
        
        if (hex_mode) {
            /* Print the ASCII column */
            if (loop_limit != line_width) { /* Last line need to fill the space */
                if (i-1 < line_width / 2) putchar(' ');
                while (i++ < line_width) {
                    printf("   ");
                }
            }
            printf("  |");
            for (i = 0; i < loop_limit; i++) {
                colour = marker_p[offset+i];
                if (colour > max_colour) colour = max_colour;
                if (colour == 0 && inc_marker_p[offset+i]) colour = inc_colour;
                if (colour != last_colour) {
                    printf(term_colour[colour]);
                    last_colour = colour;
                }
                if (isprint(data_buf[offset+i])) {
                    putchar(data_buf[offset+i]);
                } else putchar('.');
            }
            if (colour) printf(term_colour[0]);
            last_colour = colour = 0;
            putchar('|');
        }
        /* Done line print loop.  print line-feed. */
        printf("\n");
        offset += i;
    }
    printf("%s", term_colour[0]);

    free(marker_p);
    free(inc_marker_p);
    return pmscan_ok_e;
}

/****************************************************************************************
   This routine prints the various details from a match report.
   
    parameters: report buffer, report buffer length.
    return value: pmscan_ok_e, or error code.
 ****************************************************************************************/
static int _pmscan_print_match_in_report(uint8_t* report_buf, uint32_t report_len)
{
    uint32_t offset = 0;
    uint32_t i = 0, l = 0;
    const uint32_t hex_dump_line_max = 32;
    uint64_t unit_offset = 0;
    int line_count = 0;
    pmp_rep_rec_type_t type = 0;
    pmp_report_simple_match_record_t* match_record_p = NULL;
    pmp_report_extended_match_record_t* extended_match_record_p = NULL;
    pmp_report_verbose_match_record_t* verbose_record_p = NULL;
    pmp_report_rule_record_t* rule_record_p = NULL;
    
    while (offset < report_len) {
        type = report_buf[offset];

        /* Reached the end-of-SUI record */
        if (type == pmp_end_of_report_type_e) break;
        
        if (type == pmp_rule_report_type_e) {
            /* For rule report, the length of the whole report is inside the header */
            rule_record_p = (pmp_report_rule_record_t*) (report_buf + offset);
            printf("rule (0x%02hhx): len=0x%02x\n", type, rule_record_p->length);
            line_count++;            
            /* Hex dump the data reported by the rule */
            i = l = 0;
            while (i < rule_record_p->length - sizeof(pmp_report_rule_record_t)) {
                if (l == 0) printf("  ");
                printf("%02hhx ", report_buf[offset + sizeof(pmp_report_rule_record_t) + i]);
                if (l++ > hex_dump_line_max) { 
                    printf("\n");
                    line_count++;
                    l = 0;
                }
                i++;
            }
            if (l > 0) { printf("\n"); line_count++; }
            offset += rule_record_p->length;
            continue;
        }
        
        if ((type & pmp_record_type_mask) == pmp_simple_match_type_e ||
            (type & pmp_record_type_mask) == pmp_verbose_match_type_e) {
            /* Both simple and verbose report has a simple report at the beginning. */
            match_record_p = (pmp_report_simple_match_record_t*) (report_buf + offset);
            if (match_record_p->matchLength == pmp_extended_match_report_code_e)
            {
                /*  Extended match report - This is generated by special stateful rules
                    that allows reporting of matches long than 255 bytes. */
                extended_match_record_p = (pmp_report_extended_match_record_t*) match_record_p;
                printf("match(0x%02hhx): {0x%02hhx} len=0x%04"PRIx16" offset=0x%08x"
                        ":%08x tag=0x%08x\n",
                        type, extended_match_record_p->oldMatchLength, 
                        extended_match_record_p->matchLength, extended_match_record_p->unitOffset,
                        extended_match_record_p->matchByteOffset, extended_match_record_p->expTag);
            }
            else
            {
                unit_offset = _pmscan_get_unit_offset(match_record_p->unitOffset);
                printf("match(0x%02hhx): len=0x%02hhx offset=0x%012"PRIx64":%08x tag=0x%08x\n",
                        type, match_record_p->matchLength, unit_offset, 
                        match_record_p->matchByteOffset, match_record_p->expTag);
            }
            line_count++;
            
            if ((type & pmp_record_type_mask) == pmp_simple_match_type_e) 
                offset += sizeof(pmp_report_simple_match_record_t);
            else {
                /* Print the extra details from the verbose report */
                verbose_record_p = (pmp_report_verbose_match_record_t*) (report_buf + offset);
                printf( "    \\n=0x%08x ext=0x%08x FM=%u incL=%u incR=%u\n",
                        verbose_record_p->lastLineBreak, verbose_record_p->lastExtChar,
                        verbose_record_p->inconclusive.fullMatch,
                        verbose_record_p->inconclusive.left, 
                        verbose_record_p->inconclusive.right);
                line_count++;
                
                if (verbose_record_p->capturedXSize > 0) {
                    printf("    $X=0x%016"PRIx64" (%d bytes)\n",
                            verbose_record_p->capturedX, verbose_record_p->capturedXSize);
                    line_count++;
                }
                if (verbose_record_p->capturedYSize > 0) {
                    printf("    $Y=0x%016"PRIx64" (%d bytes)\n",
                            verbose_record_p->capturedY, verbose_record_p->capturedYSize);
                    line_count++;
                }
                offset += sizeof(pmp_report_verbose_match_record_t);
            }
            continue;
        }
        
        printf("Unsupported type 0x%02hhx\n", type);
        return pmscan_error_unsupported_e;
    }
    if (line_count == 0) printf("( No match or rule reported. )\n");
    return pmscan_ok_e;
}


/****************************************************************************************
   This routine count the number of matches and rules from one match report.
    
    parameters: report buffer, report buffer length, 
                location to store the number full match,
                location to store the number of inconclusive match, 
                location to store the number of rule.
    return value: pmscan_ok_e, or error code.
 ****************************************************************************************/
static int _pmscan_count_match_in_report(uint8_t* report_buf, uint32_t report_len, 
                                         int* num_full_match_p, int* num_inclusive_match_p, 
                                         int* num_rule_p)
{
    uint32_t offset = 0;
    pmp_rep_rec_type_t type = 0;
    pmp_report_rule_record_t* rule_record_p = NULL;
    
    (*num_full_match_p) = 0;
    (*num_inclusive_match_p) = 0;
    (*num_rule_p) = 0;
    
    while (offset < report_len)
    {
        type = report_buf[offset];

        /* Reached the end-of-SUI report */
        if (type == pmp_end_of_report_type_e) break;

        if (type == pmp_rule_report_type_e) {
            /* For rule report, the length of the whole report is inside the header */
            (*num_rule_p)++;
            rule_record_p = (pmp_report_rule_record_t*) (report_buf + offset);
            offset += rule_record_p->length;
            continue;
        }
        
        if ((type & pmp_record_type_mask) == pmp_simple_match_type_e ||
            (type & pmp_record_type_mask) == pmp_verbose_match_type_e) {
            
            /* A match is inconclusive if either inconclusive bit is 1 and 
               the full match bit is 0 */
            if ((type & (pmp_inconclusive_left_record_type_class |
                        pmp_inconclusive_right_record_type_class)) &&
               !(type & pmp_full_match_record_type_class)) {
                (*num_inclusive_match_p)++;
            } else {
                (*num_full_match_p)++;
            }

            if ((type & pmp_record_type_mask) == pmp_simple_match_type_e) 
                offset += sizeof(pmp_report_simple_match_record_t);
            else
                offset += sizeof(pmp_report_verbose_match_record_t);
            continue;
        }

        /* Unsupported type in the report */
        printf("Unsupported type 0x%02hhx\n", type);
        return pmscan_error_unsupported_e;
    }
    return pmscan_ok_e;
}

/****************************************************************************************
   This routine scan the input data and process the results.
   The data buffer prepared in the scan list will be scanned in sequence.
   If the scan data list is empty, it will prompt for strings from stdin 
   and scan them.
    
    parameters: openned and configured pme_scanner device file descriptor,
                list of scan data, print detail level.
    return value: pmscan_ok_e, or error code.
 ****************************************************************************************/
static int _pmscan_scan_buffer_list(int scan_fd, dll_list_t* scan_buf_list_p, 
                                    int print_detail)
{
    pmscan_buf_t* scan_buf_p = NULL;

    int num_full_match = 0, num_inconclusive_match = 0, num_rule = 0, num_scan = 0;
    int num_full_match_delta = 0, num_inconclusive_match_delta = 0, num_rule_delta = 0;
    bool interactive = false;
    int rc = pmscan_ok_e;
    const int interactive_buf_len = 1024;
    
    /* This structre is used to pass location of size of scan data into the scanner device.
       After the operation, the result of the scan such as match report buffer length and 
       error flags will be stored in members of the same stucture. */
    struct pme_scan pme_oper;
    
    /* Get the first scan buffer.  Entered data will be scanned in original order. */
    scan_buf_p = DLL_STRUCT_FROM_NODE_GET(dll_get_first(scan_buf_list_p),
                                          pmscan_buf_t, dllNode);
    if (scan_buf_p == NULL) {
        /* Enable interactive mode if the user did not specify any scan data using parameters. 
           We will keep using the same buffer in this mode. */
        printf( "\nInteractive mode: Enter string to be scanned."
                "  To exit, enter \"quit\"\n\n");
        interactive = true;
        scan_buf_p = malloc(sizeof(pmscan_buf_t) + interactive_buf_len);
        if (scan_buf_p == NULL) {
            printf("ERROR: malloc failed to allocate %d bytes\n", 
                   (int) sizeof(pmscan_buf_t) + interactive_buf_len);
            return pmscan_error_malloc_e;
        }
        scan_buf_p->len = interactive_buf_len;
    }
    
    /* Scan through the scan buffer list. */
    while (scan_buf_p != NULL) {
        if (interactive) {
            /* Interactive mode: keep scanning string from stdin until the user enter "quit". */
            printf("> ");
            if(fgets((char*) scan_buf_p->buf, interactive_buf_len, stdin) == NULL) break;
            /* The string will have an extra \n because of the Enter key.  Remove it. */
            if (scan_buf_p->buf[strlen((char*)scan_buf_p->buf)-1] == '\n') {
                scan_buf_p->buf[strlen((char*)scan_buf_p->buf)-1] = '\0';
            }
            /* if the entered string starts with "quit", leave the scanning loop. */
            if (strstr((char*) scan_buf_p->buf, "quit") == (char*) scan_buf_p->buf) break;
            
            scan_buf_p->len = _pmscan_meta_strlen((char*) scan_buf_p->buf);
            /* No string.  Return to the prompt. */
            if (scan_buf_p->len <= 0) continue;
            
            /* Prepare the entered string for scanning. */
            _pmscan_meta_strcpy(scan_buf_p->buf, (char*) scan_buf_p->buf, scan_buf_p->len);
        }
        
        if (print_detail) printf("#%02d: Scanning %d bytes.\n", num_scan, scan_buf_p->len);
        
        /* Set all pointers and length to 0.  BMan buffer will be used to return 
           scan report. 
           
           Note: Depends on the application, pre-allocated buffer may be more appropiate.
           Scanning with pre-allocated buffer will be faster since there will be no allocate 
           and free operations on the fly.  The disadvantage is it's difficult to predict how 
           much buffer space is sufficient until the scan is finish.  If the 
           pre-allocated buffer is not big enough to hold the match reports the the TRUNCATED
           flag for that buffer will be set in the result.flags.
         */
        memset(&pme_oper, 0, sizeof(pme_oper));
        // TODO Use pre-allocated buffer for now.
        //pme_oper.cmd.flags = PME_SCAN_CMD_RES_BMAN;

        if (!interactive && dll_is_node_at_back(scan_buf_list_p, 
                                                &scan_buf_p->dllNode)) {
            /* If it is the last buffer, set the end-of-stream flag. */
            pme_oper.cmd.flags |= PME_SCAN_CMD_END;
        }
        
        /* Setup the pointers to point to the data buffer we want to scan. */
        pme_oper.cmd.input.size = scan_buf_p->len;
        pme_oper.cmd.input.data = scan_buf_p->buf;

        // TODO Use pre-allocated buffer for now.
        pme_oper.cmd.output.size = REPORT_BUF_SIZE;
        pme_oper.cmd.output.data = report_buf_g;

        /* Perform the scan. */
        rc = ioctl(scan_fd, PMEIO_SCAN, &pme_oper);
        if (rc < 0) {
            /* Possible reasons for returning an error here: 
               Incorrect configuration, bad parameters */
            perror("ioctl scan");
            rc = pmscan_error_driver_e;
            break;
        }

        /* Check for any exception or error. */
        if (pme_oper.result.status != pme_status_ok) {
            /* Exception codes are error code reported by hardware. See the block guide 
               for the meaning of each exception code. 
               
               Note: Some exception codes are normal and should be handled appropriately
               depends on the application.  Exception handling is beyond the scope of 
               this program, so we will just quit the scan loop. */
            printf("ERROR: Exception code after scan, report: 0x%02x\n", 
                   pme_oper.result.status);
            rc = pmscan_error_exception_e;
            break;
        }
        if (pme_oper.result.flags & ~(PME_SCAN_RESULT_BMAN)) {
            /* Result flags contain conditions or errors returned by the driver.
               
               We only expect result.flag to indicate BMan buffer(s) was returned.
               If we are using pre-allocated buffer then we need to deal with the truncated 
               flags appropriately. */
            printf("ERROR: Unexpected result flags, report: 0x%"PRIx8"\n", 
                   pme_oper.result.flags);
            rc = pmscan_error_driver_e;
            break;
        }
        
        if (pme_oper.result.output.data != NULL)
        {
            /* Process the match report */
            rc = _pmscan_count_match_in_report(pme_oper.result.output.data,
                                               pme_oper.result.output.size, 
                                               &num_full_match_delta, 
                                               &num_inconclusive_match_delta,
                                               &num_rule_delta);
            if (rc != pmscan_ok_e) break;
            
            num_full_match += num_full_match_delta;
            num_inconclusive_match += num_inconclusive_match_delta;
            num_rule += num_rule_delta;
            
            if (print_detail > 0) {
                _pmscan_print_match_in_report(pme_oper.result.output.data, 
                                              pme_oper.result.output.size);
            }
            
            if (print_detail > 1 && (num_full_match_delta + num_inconclusive_match_delta) > 0) {
                /* Only print the extra detail if there are reported matches. */
                printf("Match detail in scan data:  ");
                _pmscan_dump_match(scan_buf_p->buf, scan_buf_p->len, 
                                    pme_oper.result.output.data,
                                    pme_oper.result.output.size);
            }
        }
        
        /* BMan buffer should be released after we are done with them. */
        if (pme_oper.result.output.data != NULL &&
            pme_oper.result.flags & PME_SCAN_RESULT_BMAN) {
            ioctl(scan_fd, PMEIO_RELEASE_BUFS, &pme_oper.result.output.data);
        }

        num_scan++;
        
        if (!interactive) {
            /* Get the next scan buffer. */
            scan_buf_p = DLL_STRUCT_FROM_NODE_GET(dll_get_next_node(scan_buf_list_p, 
                                                  &scan_buf_p->dllNode ), 
                                                  pmscan_buf_t, dllNode);
        }
        if (print_detail) printf("\n");
    }
    
    if (interactive && scan_buf_p != NULL) free(scan_buf_p);
    
    printf("Number of successful scan:    %d\n", num_scan);
    printf("Number of full match:         %d\n", num_full_match);
    printf("Number of inconclusive match: %d\n", num_inconclusive_match);
    printf("Number of rule report:        %d\n", num_rule);
    
    return rc;
}

/****************************************************************************************
   This routine print the help message.

    parameter: none.
    return value: none.
 ****************************************************************************************/
static void _pmscan_print_help(void)
{
    printf( "Usage: \n"
            "        pm_scan_demo [<options>]\n\n"
            );
    printf( "Description:\n"
            "        A sample application that scans user entered string or file, and\n"
            "        prints the reported matches.\n\n"
            );
    printf( "Options:\n"
            "  -s, --str <string>\n"
            "        Scan a string.\n"
            "        May use \\xNN to represent a byte in hexidecimal.\n\n"
            
            "  -f, --file <filename>\n"
            "        Scan the binary content of a file as a single scan unit\n\n"
            
            "        Multiple strings and files may be scanned sequentially as \n"
            "        separate scan units by repeating the -s, and -f options.\n\n"
                        
            "  -r, --residue\n"
            "        Enable residue feature.\n\n"
            
            "  --set <num>\n"
            "        Expression set to scan against.  Default = %d.\n\n"
            
            "  --subset <num>\n"
            "        Expression subset-mask to scan against.  Default = 0x%04x.\n\n"
            
            "  --session <num>\n"
            "        Stateful rule session id number.  Default = %d.\n\n"
            
            "  --verbose\n"
            "        Enable verbose report.  HW will report more data per match.\n\n"
            
            "  --silent\n"
            "        Disable printing of match report.\n\n"
            
            "  --detail\n"
            "        Shows scan data covered by matches. Requires ANSI/VT100 terminal.\n\n",
            PMSCAN_DEFAULT_SET, PMSCAN_DEFAULT_SUBSET, PMSCAN_DEFAULT_SESSION
            );
    printf( "Example:\n"
            "        pm_scan_demo -s abcd -s defg --residue --detail\n\n"
            );
}

/****************************************************************************************
   The main() decode the command line parameters, create the scan buffer list, 
   and setup the scanner device.
   
    parameters: command line parameters.
    return value: pmscan_ok_e, or error code.
 ****************************************************************************************/
int main(int argc, char *argv[])
{
    int option = 0;
    
    dll_list_t scan_buf_list;
    
    pmscan_buf_t* scan_buf_p = 0;
    int rc = pmscan_ok_e, len = 0, read_len = 0;
    bool scanning_string = false;
    int scan_fd = 0, file_fd = 0;

    /* Various parameter that can be set by command line options.
       See the parameter setup section below for more details of each parameters. */
    uint32_t set = PMSCAN_DEFAULT_SET, subset = PMSCAN_DEFAULT_SUBSET,
             session = PMSCAN_DEFAULT_SESSION, print_detail = 1;
    
    bool     verbose = false, residue = false;
    
    /* This struct is used for setting up the scan device parameters */
    struct pme_scan_params scanner_params;
    
    static struct option longOptions[] = {
        {"help",    no_argument,       NULL, pmscan_option_help_e},
        {"str",     required_argument, NULL, pmscan_option_str_e},
        {"file",    required_argument, NULL, pmscan_option_file_e},
        {"residue", no_argument,       NULL, pmscan_option_residue_e},
        {"set",     required_argument, NULL, pmscan_option_set_e},
        {"subset",  required_argument, NULL, pmscan_option_subset_e},
        {"verbose", no_argument,       NULL, pmscan_option_verbose_e},
        {"session", required_argument, NULL, pmscan_option_session_e},
        {"silent",  no_argument,       NULL, pmscan_option_silent_e},
        {"detail",  no_argument,       NULL, pmscan_option_detail_e},
        {NULL, no_argument, NULL, no_argument}
    };
    
    /* scan_buf_list contain the all the scan data.  They will be sent to hardware for
       scanning in sequence. */
    dll_list_init(&scan_buf_list);
    
    /* Decode the parameters */
    while (true) {
        option = getopt_long(argc, argv, "-rhs:f:m:", longOptions, NULL);

        if ( option <= 0 ) break;

        switch(option) {
            case 1:
                /* Get 1 when one of the parameters is not defined.  It is not well documented 
                   in getopt_long man page. */
                printf("Unknown option \"%s\"\n",optarg);
                return pmscan_error_bad_option_e;
                
            case '?':
                /* getopt_long already printed an error msg. */
                return pmscan_error_bad_option_e;
            
            case pmscan_option_help_e:
            case 'h':
                _pmscan_print_help();
                return pmscan_ok_e;
                
            case pmscan_option_str_e:
            case 's':
                /* Store the string and add it as a scan unit into the scan list. */
                scanning_string = true;
                len = _pmscan_meta_strlen(optarg);
                scan_buf_p = malloc(sizeof(pmscan_buf_t) + len);
                if (scan_buf_p == NULL) {
                    printf("ERROR: malloc failed to allocate %d bytes\n",
                           (int) sizeof(pmscan_buf_t) + len);
                    return pmscan_error_malloc_e;
                }
                scan_buf_p->len = len;
                _pmscan_meta_strcpy(scan_buf_p->buf, optarg, len);
                dll_add_to_back(&scan_buf_list, &scan_buf_p->dllNode);
                break;

            case pmscan_option_file_e:
            case 'f':
                /* Store the content of the file and add it as a scan unit into the scan list.
                   The file's content will be scanned as a single unit no matter now big it is. */
                file_fd = open(optarg, O_RDONLY);
                if (file_fd < 0) {
                    printf("Error: Unable to open %s\n", optarg);
                    perror("");
                    return pmscan_error_file_io_e;
                }
                /* Find the size of the file. */
                len = lseek(file_fd, 0, SEEK_END);
                if (len >= 0) {
                    scan_buf_p = malloc(sizeof(pmscan_buf_t) + len);
                    if (scan_buf_p == NULL) {
                        printf("ERROR: malloc failed\n");
                        printf("File %s (%d bytes) is too large to read into memory\n", 
                               optarg, len);
                        return pmscan_error_malloc_e;
                    }
                    scan_buf_p->len = len;
                    lseek(file_fd, 0, SEEK_SET);
                    read_len = 0;
                    while (read_len < len) {
                        rc = read(file_fd, scan_buf_p->buf + read_len, len - read_len);
                        if (rc < 0) {
                            printf("Error: Failed to read %s\n", optarg);
                            perror("");
                            return pmscan_error_file_io_e;
                        }
                        read_len += rc;
                    }
                    dll_add_to_back(&scan_buf_list, &scan_buf_p->dllNode);
                }
                else {
                    printf("Ignoring file \"%s\" which has unknown size.\n", optarg);
                }
                close(file_fd);
                break;

            case pmscan_option_set_e:
                set = _pmscan_string_to_int(optarg);
                break;

            case pmscan_option_subset_e:
                subset = _pmscan_string_to_int(optarg);
                break;

            case pmscan_option_verbose_e:
                verbose = true;
                break;

            case pmscan_option_residue_e:
            case 'r':
                residue = true;
                break;
                
            case pmscan_option_session_e:
                session = _pmscan_string_to_int(optarg);
                break;

            case pmscan_option_silent_e:
                print_detail = 0;
                break;
                
            case pmscan_option_detail_e:
                print_detail = 2;
                break;

            default:
                break;
        }
    }
        
    /* Open a Pattern Matching scanner device. */
    scan_fd = open(PME_DEV_SCAN_PATH, O_RDONLY);
    if (scan_fd < 0)
    {
        perror(PME_DEV_SCAN_PATH);
        return pmscan_error_driver_e;
    }
    
    /* Setup the scanner device to use the desired parameters. 
       Cannot start the scan operation until this step is done. */
    memset(&scanner_params, 0 , sizeof(scanner_params));

    /* Residue feature: Last 128 bytes (number configurable by driver TODO PME2?) of scan data
       are stored in memory.  They will be prepended to the next scan data in the stream.
       This feature is useful for scanning data stream where logically related data may 
       appears in different scan unit.  */
    if (residue) scanner_params.residue.enable = 1;
        
    /* Set: HW will only returns matches which the pattern's set inside the 
       database and the scan stream's set is identical. */
    scanner_params.pattern.set = set;
    
    /* Subset: HW will only returns matches which the pattern's subset inside 
       the database and the scan stream's subset have overlapping bit. */
    scanner_params.pattern.subset = subset;
    
    /* Session id: Only applied for stateful rules.  Multiple scan stream with
       the same session id will share the session context. */
    scanner_params.sre.sessionid = session;

    /* Clear the context session of this particular session id.  It is not necessary to clear 
       the session context, for example if there is no stateful rule in the database.  */
    rc = pmci_context_clear_by_session_id(session);
    if (rc != pmci_success_e)
    {
        /* Possible reason for this error: 
           pme_ctrl device driver is not loaded.
           Use a session id that is bigger than the configured maximum value. */
        printf("Failed to clear context of session %d: %s\n", session, pmci_error_string(rc));
        return pmscan_error_driver_e;
    }
    
    /* esee: This flag enable the end-of-SUI event for 
       stateful/stateless rules that use such event. */
    scanner_params.sre.esee = 1;

    /* verbose: We are only setting 0 or 1 here.  It is possible to put 2 or 3 for 
       debuging stateful/stateless rules, but it's beyond the scope of this demo program. */
    if (verbose) scanner_params.sre.verbose = 1;
    
    scanner_params.flags = PME_SCAN_PARAMS_RESIDUE | PME_SCAN_PARAMS_SRE |
                           PME_SCAN_PARAMS_PATTERN;

    
    if (ioctl(scan_fd, PMEIO_SETSCAN, &scanner_params) < 0) {
        perror("ERROR: Setting scanner parameters failed");
        return pmscan_error_driver_e;
    }
    
    rc = _pmscan_scan_buffer_list(scan_fd, &scan_buf_list, print_detail);
    
    close(scan_fd);
    
    _pmscan_free_buffer_list(&scan_buf_list);
    
    return rc;
}
