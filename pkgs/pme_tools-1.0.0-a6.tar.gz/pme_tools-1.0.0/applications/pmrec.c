/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <getopt.h>
#include <time.h>
#include <pmrec.h>
#include <log.h>

/* =========================================================================
 *
 * Stand alone regular expression compiler.
 *
 * This compiler uses the Freescale regular expression compiler library.
 * It is a stand alone application that generates binary files which must
 * be fed into the linker loader by the user.
 *
 * =========================================================================*/
void usage(void);

/*
 * The compiler main
 */

int main (int argc, char **argv)
{
   int                      optionIndex             = 0;
   int                      optionVal               = 0;
   int                      useStdin                = 1;
   int                      useDefaultOutput        = 1;
   int                      fileNameSize            = 0;
   char                    *dateString_p            = NULL;
   char                    *outputFileName_p        = NULL;
   char                    *inputFileName_p         = NULL;
   char                     defaultOutputFilename[] = "regex.compiled";
   int                      result;
   time_t                   timeVal;
   pmrec_module_options_t   compileOptions;
   char                    *compileMsg_p            = NULL;

   // Set default compile options

   memset (&compileOptions, 0, sizeof(pmrec_module_options_t));

   compileOptions.debug_level            = pmrec_debug_none_e;
   compileOptions.group_definition       = pmrec_groups_default0_e;
   compileOptions.group_def_filename_p   = NULL;
   compileOptions.equivalence_definition = pmrec_equivalence_default0_e;
   compileOptions.equiv_def_filename_p   = NULL;
   compileOptions.warnings_are_errors    = false;
   compileOptions.suppress_warnings      = false;
   compileOptions.hide_strings           = false;
   compileOptions.one_byte_triggers      = false; // 1 byte right test
   compileOptions.silicon_8572_rev_1_0   = false;

   //rec_yydebug = 1;

#ifndef SOLARIS
   static struct option longOptions[] =
                {
                  {"help",           no_argument,       0, 'h'},
                  {"input",          required_argument, 0, 'i'},
                  {"output",         required_argument, 0, 'o'},
                  {"Werror",         no_argument,       0, 'W'},
                  {"w",              no_argument,       0, 'w'},
                  {"nostrings",      no_argument,       0, 'n'},
                  {"8572rev1.0",     no_argument,       0, 'b'},
#ifdef DEV_DBG
                  {"debug_summary",  no_argument,       0, 's'},
                  {"debug_detailed", no_argument,       0, 'd'},
                  {"debug_test",     no_argument,       0, 't'},
#endif /* DEV_DBG */
                  {0, 0, 0, 0}
                };
#endif // SOLARIS

   time(&timeVal);

   dateString_p = asctime(localtime(&timeVal));

   printf("\n\nDate                         : %s\n", dateString_p);

   // Process options
   while (1)
   {
#ifndef SOLARIS
      optionVal = getopt_long (argc,
                               argv,
#ifdef DEV_DBG
                               "hi:o:Wwnsdtb",
#else
                               "hi:o:Wwnb",
#endif /* DEV_DEBUG */
                               longOptions,
                               &optionIndex);
#else // SOLARIS
      optionVal = getopt (argc,
                          argv,
#ifdef DEV_DBG
                          "hi:o:Wwnsdtb");
#else
                          "hi:o:Wwnb");
#endif /* DEV_DEBUG */
#endif //SOLARIS

      // End of options
      if (optionVal == -1)
      {
         break;
      }

      // Deal with each option
      switch (optionVal)
      {
         case 'h':
            usage();
            exit (0);
            break;

         case 'i':
            fileNameSize = strlen(optarg) + 1;

            inputFileName_p = (char *)malloc(fileNameSize);

            if (inputFileName_p == NULL)
            {
               printf("PMREC: ERROR: Malloc failure while parsing input file option.\n");
               return (pmrec_malloc_failure_e);
            }

            memset(inputFileName_p, 0, fileNameSize);

            strncpy(inputFileName_p,
                    optarg,
                    fileNameSize);

            useStdin = 0;

            break;

         case 'o':
            fileNameSize = strlen(optarg) + 1;

            outputFileName_p = (char *)malloc(fileNameSize);

            if (outputFileName_p == NULL)
            {
               printf("PMREC: ERROR: Malloc failure while parsing output file option.\n");
               return (pmrec_malloc_failure_e);
            }

            memset(outputFileName_p, 0, fileNameSize);

            strncpy(outputFileName_p,
                    optarg,
                    fileNameSize);

            useDefaultOutput = 0;
 
            break;

#ifdef DEV_DBG
         case 's':
            compileOptions.debug_level = compileOptions.debug_level | pmrec_debug_summary_e;
            break;

         case 'd':
            compileOptions.debug_level = compileOptions.debug_level | pmrec_debug_detailed_e;
            break;

         case 't':
            compileOptions.debug_level = compileOptions.debug_level | pmrec_debug_test_e;
            break;
#endif /* DEV_DBG */

         case 'W':
            compileOptions.warnings_are_errors = true;
            break;

         case 'w':
            compileOptions.suppress_warnings = true;
            break;

         case 'n':
            compileOptions.hide_strings = true;
            break;

         case 'b':
            compileOptions.one_byte_triggers    = true; // 1 byte right test
            compileOptions.silicon_8572_rev_1_0 = true;
            break;
         default:
            printf("Unrecognized option =>%s<=\n", *argv);
            usage();
            exit (0);
            break;
      }
   }

   if (useDefaultOutput)
   {
      fileNameSize = strlen(defaultOutputFilename) + 1;

      outputFileName_p = (char *)malloc(fileNameSize);

      if (outputFileName_p == NULL)
      {
         printf("PMREC: ERROR: Malloc failure while creating output file string.\n");
         return (pmrec_malloc_failure_e);
      }

      memset(outputFileName_p, 0, fileNameSize);

      strncpy(outputFileName_p,
              defaultOutputFilename,
              fileNameSize);
   }

   if (useStdin)
   {
      printf ("Reading code from STDIN. CTRL-D on a new line to end input or CTRL-C to exit.\n\n");
      inputFileName_p = NULL;
   }
   else
   {
      printf("Compiling Regex file : %s\n",
             inputFileName_p);
   }

   fflush(NULL);

   // Compile the code
   result = pmrec_compile(inputFileName_p,
                          outputFileName_p,
                          &compileOptions,
                          &compileMsg_p);

   if (compileOptions.warnings_are_errors == 1 &&
       result == pmrec_warnings_e)
   {
      result = pmrec_compile_failed_e;
   }

   if (compileMsg_p != NULL)
   {
      printf("%s\n", compileMsg_p);

      /* Compile message was allocated in compiler lib. Must free here. */
      free (compileMsg_p);
   }

   printf("%s\n", pmrec_get_error_string(result));

   if (inputFileName_p != NULL)
   {
      free(inputFileName_p);
   }

   if (outputFileName_p != NULL)
   {
      free(outputFileName_p);
   }

   return (result);
}

/*
 * Display the help text.
 */
void usage (void)
{
   printf ("\n");
   printf ("   Description:\n");
   printf ("      The regex compiler takes input from a file or STDIN and\n");
   printf ("      converts the regex to patterns in an internal format.\n");
   printf ("      The output must be passed to the linker/loader software in order\n");
   printf ("      to install the patterns on the hardware.\n");
   printf ("\n");
#ifndef SOLARIS
   printf ("   Options:\n");
   printf ("      -h, --help           This help.\n");
   printf ("\n");
   printf ("      -i, --input          The name of the file containing the user's regular expressions.\n");
   printf ("                           Defaults to STDIN.\n");
   printf ("\n");
   printf ("      -o, --output         The name of the file where the output will be placed.\n");
   printf ("                           Defaults to 'regex.compiled'.\n");
   printf ("\n");
   printf ("      -W, --Werror         Warnings are errors.\n");
   printf ("\n");
   printf ("      -w, --w              Suppress warning messages. Note: Ignored if --Werror used.\n");
   printf ("\n");
   printf ("      -n, --nostrings      Do not include expression strings in output binary file.\n");
   printf ("\n");
   printf ("      -b, --8572rev1.0     Compile for 8572 rev 1.0 silicon.\n");
   printf ("\n");
#ifdef DEV_DBG
   printf ("   Debug:\n");
   printf ("      -s, --debug_summary  Summary level debug.\n");
   printf ("\n");
   printf ("      -d, --debug_detailed Show lower level debug (must use with --debug_summary).\n");
   printf ("\n");
   printf ("      -t, --debug_test     Show test debug.\n");
   printf ("\n");
#endif /* DEV_DBG */
   printf ("   Example:\n");
   printf ("      pmrec --input my_expressions --output my_expressions.out\n");
#else // SOLARIS
   printf ("   Options:\n");
   printf ("      -h,       This help.\n");
   printf ("\n");
   printf ("      -i,       The name of the file containing the user's regular expressions.\n");
   printf ("                Defaults to STDIN.\n");
   printf ("\n");
   printf ("      -o,       The name of the file where the output will be placed.\n");
   printf ("                Defaults to 'regex.compiled'.\n");
   printf ("\n");
   printf ("      -W,       Warnings are errors.\n");
   printf ("\n");
   printf ("      -w,       Suppress warning messages. Note: Ignored if --Werror used.\n");
   printf ("\n");
   printf ("      -n,       Do not include expression strings in output binary file.\n");
   printf ("\n");
   printf ("      -l,       Compile file of regexs one at a time to reduce dynamic\n");
   printf ("                memory requirements. (May be slower with this option).\n");
   printf ("                *** Requires write permission to /tmp ***\n");
   printf ("\n");
   printf ("      -b,       Compile for 8572 rev 1.0 silicon.\n");
   printf ("\n");
#ifdef DEV_DBG
   printf ("   Debug:\n");
   printf ("      -s,  Summary level debug.\n");
   printf ("\n");
   printf ("      -d,  Show lower level debug (must use with --debug_summary).\n");
   printf ("\n");
   printf ("      -t,  Show test debug.\n");
   printf ("\n");
#endif /* DEV_DBG */
   printf ("   Example:\n");
   printf ("      pmrec -i my_expressions -o my_expressions.out\n");
#endif // SOLARIS
   printf ("\n");
}
