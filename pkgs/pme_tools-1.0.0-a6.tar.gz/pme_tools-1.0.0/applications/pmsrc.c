/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <getopt.h>
#include <time.h>
#include <pmsrc.h>

#define PMSRC_MAX_STRING_PAD_SIZE 16384

void usage(void);

/*
 * The compiler main
 */

int main (int argc, char **argv)
{
   int                     option_index = 0;
   int                     option_val;
   int                     use_stdin = 1;
   int                     use_default_output = 1;
   int                     file_name_size;
   char                   *date_string;
   time_t                  time_val;
   char                   *output_file_name = NULL;
   char                   *input_file_name = NULL;
   char                    default_output_file_name[] = "stateful_rule.compiled";
   pmsrc_error_codes_t     result;
   pmsrc_module_options_t  compiler_option_list;
   char                   *compiler_msg_p = NULL;

   memset(&compiler_option_list, 0, sizeof(pmsrc_module_options_t));

   // Default to 4 byte report constants
   compiler_option_list.report_cnst_sz = pmsrc_report_cnst_sz4_e;

   // Default string pad
   compiler_option_list.string_pad = PMSRC_DEFAULT_STRING_PAD;

   // Default debug
   compiler_option_list.debug_level = pmsrc_debug_off_e;

   // Default to warnings are not errors
   compiler_option_list.warnings_are_errors = false;

   // Default to show warnings
   compiler_option_list.suppress_warnings = false;

   static struct option long_options[] =
                {
                  {"help",                 no_argument,       0, 'h'},
                  {"input",                required_argument, 0, 'i'},
                  {"output",               required_argument, 0, 'o'},
                  {"report_pad",           required_argument, 0, 'r'},
                  {"string_pad",           required_argument, 0, 'p'},
                  {"report_constant_size", required_argument, 0, 'c'},
                  {"allow_inconclusive",   no_argument,       0, 'a'},
                  {"Werror",               no_argument,       0, 'W'},
                  {"w",                    no_argument,       0, 'w'},
#ifdef DEV_DBG
                  {"debug_summary",        no_argument,       0, 's'},
                  {"debug_test",           no_argument,       0, 't'},
#endif /* DEV_DBG */
                  {0, 0, 0, 0}
                };

   time(&time_val);

   date_string = asctime(localtime(&time_val));

   // Process options
   while (1)
   {
      option_val = getopt_long (argc,
                                argv,
#ifdef DEV_DBG
                                "hi:o:r:p:c:astwW",
#else
                                "hi:o:r:p:c:awW",
#endif /* DEV_DBG */
                                long_options,
                                &option_index);

      // End of options
      if (option_val == -1)
      {
         if (optind < argc)
         {
            printf ("\nUnrecognized command line parameters: ");
            while (optind < argc)
            {
               printf ("%s ", argv[optind++]);
            }
            printf ("\n\n");

            if (output_file_name != NULL)
            {
               free(output_file_name);
            }

            if (input_file_name != NULL)
            {
               free(input_file_name);
            }

            return (pmsrc_compile_failed_e);
         }

         break;
      }

      // Deal with each option
      switch (option_val)
      {
         case 'h':
            usage();
            exit (pmsrc_compile_failed_e);
            break;

         case 'i':
            file_name_size = strlen(optarg) + 1;

            input_file_name = (char *)malloc(file_name_size);

            if (input_file_name == NULL)
            {
               if (output_file_name != NULL)
               {
                  free(output_file_name);
               }

               return(pmsrc_malloc_failure_e);
            }

            memset(input_file_name, 0, file_name_size);

            strncpy(input_file_name,
                    optarg,
                    file_name_size);

            use_stdin = 0;

            break;

         case 'o':
            file_name_size = strlen(optarg) + 1;

            output_file_name = (char *)malloc(file_name_size);

            if (output_file_name == NULL)
            {
               if (input_file_name != NULL)
               {
                  free(input_file_name);
               }

               return(pmsrc_malloc_failure_e);
            }

            memset(output_file_name, 0, file_name_size);

            strncpy(output_file_name,
                    optarg,
                    file_name_size);

            use_default_output = 0;
 
            break;

#ifdef DEV_DBG
         case 's':
            compiler_option_list.debug_level = compiler_option_list.debug_level | pmsrc_debug_summary_e;
            break;

         case 't':
            compiler_option_list.debug_level = compiler_option_list.debug_level | pmsrc_debug_test_e;
            break;
#endif /* DEV_DBG */

         case 'r':
            switch (atoi(optarg))
            {
               case 0:
                  compiler_option_list.report_pad = pmsrc_report_pad_none_e;
                  break;

               case 4:
                  compiler_option_list.report_pad = pmsrc_report_pad4_e;
                  break;

               default:
                  printf ("SRC: ERROR: Illegal report pad size given =>%s<=\n            The only available options are:\n               0: No padding\n               4: Pad to 4 byte boundary.\n", optarg);
                  exit(pmsrc_compile_failed_e);
                  break;
            }
            break;

         case 'p':
            if (atoi(optarg) > 0)
            {
               if (atoi(optarg) % 2 == 0)
               {
                  compiler_option_list.string_pad = atoi(optarg);
               }
               else
               {
                  printf ("SRC: ERROR: Illegal string pad size given =>%s<=\n            The only valid values: 0 < value <= %d and a multiple of 2.\n", optarg, PMSRC_MAX_STRING_PAD_SIZE);
                  exit(pmsrc_compile_failed_e);
                  break;
               }
            }
            else
            {
               printf ("SRC: ERROR: Illegal string pad size given =>%s<=\n            The only valid values: 0 < value <= %d and a multiple of 2.\n", optarg, PMSRC_MAX_STRING_PAD_SIZE);
               exit(pmsrc_compile_failed_e);
               break;
            }
            break;

         case 'a':
            compiler_option_list.allow_inconclusive = true;
            break;

         case 'w':
            compiler_option_list.suppress_warnings = true;
            break;

         case 'W':
            compiler_option_list.warnings_are_errors = true;
            break;

         case 'c':
            switch (atoi(optarg))
            {
               case 2:
                  compiler_option_list.report_cnst_sz = pmsrc_report_cnst_sz2_e;
                  break;

               case 4:
                  compiler_option_list.report_cnst_sz = pmsrc_report_cnst_sz4_e;
                  break;

               case 6:
                  compiler_option_list.report_cnst_sz = pmsrc_report_cnst_sz6_e;
                  break;

               case 8:
                  compiler_option_list.report_cnst_sz = pmsrc_report_cnst_sz8_e;
                  break;

               default:
                  printf ("SRC: ERROR: Illegal report constant size given =>%s<=\n", optarg);
                  printf ("            Allowed values: 2, 4, 6, or 8\n");
                  exit(pmsrc_compile_failed_e);
                  break;
            }
            break;


         default:
            printf("Unrecognized option =>%s<=\n", *argv);
            usage();
            exit (pmsrc_compile_failed_e);
            break;
      }
   }

   if (use_default_output)
   {
      file_name_size = strlen(default_output_file_name) + 1;

      output_file_name = (char *)malloc(file_name_size);

      if (output_file_name == NULL)
      {
         if (input_file_name != NULL)
         {
            free(input_file_name);
         }

         return(pmsrc_malloc_failure_e);
      }

      memset(output_file_name, 0, file_name_size);

      strncpy(output_file_name,
              default_output_file_name,
              file_name_size);
   }

   printf("\n\nDate                         : %s", date_string);

   if (use_stdin)
   {
      printf ("Reading code from STDIN. Use CTRL-D to end input or CTRL-C to exit.\n\n");
      input_file_name = NULL;
   }
   else
   {
      printf("Compiling Stateful rule file : %s\n\n",
             input_file_name);
   }
 
   // Compile the code
   result = pmsrc_compile(input_file_name,
                          output_file_name,
                          &compiler_option_list,
                          &compiler_msg_p);

   if (compiler_option_list.warnings_are_errors == true &&
       result == pmsrc_warnings_e)
   {
      result = pmsrc_compile_failed_e;
   }

   // Print and free compiler message if available.
   if (compiler_msg_p != NULL)
   {
      printf("%s\n", compiler_msg_p);
      free (compiler_msg_p);
   }

   // Output the results
   if (result != pmsrc_ok_e)
   {
      printf("\n");
   }
   else
   {
      printf("Output saved to file         : %s\n\n",
             output_file_name);
   }

   printf("%s\n", pmsrc_get_error_string(result));
   printf("\n");

   if (output_file_name != NULL)
   {
      free(output_file_name);
   }

   if (input_file_name != NULL)
   {
      free(input_file_name);
   }

   return (result);
}

/*
 * Display the help text.
 */
void usage (void)
{
   printf ("\nstateful_rule_compiler\n");
   printf ("   Description:\n");
   printf ("      The stateful rule compiler takes input from a file or STDIN and\n");
   printf ("      converts the user code to low level stateful rule instructions.\n");
   printf ("      The output must be passed to the linker/loader software in order\n");
   printf ("      to install the rules on the hardware.\n");
   printf ("\n");
   printf ("   Options:\n");
   printf ("\n");
   printf ("   -h, --help    This help.\n");
   printf ("\n");
   printf ("   -i, --input <file>                The name of the file containing the users\n");
   printf ("                                     stateful rules.\n");
   printf ("                                     Defaults to STDIN.\n");
   printf ("\n");
   printf ("   -o, --output <file>               The name of the file where the output will\n");
   printf ("                                     be placed.\n");
   printf ("                                     Defaults to 'stateful_rule.compiled'.\n");
   printf ("\n");
   printf ("   -r, --report_pad <size>           Pad reports to this byte boundary.\n");
   printf ("                                     Default is none.\n");
   printf ("                                     Allowed values: 0 or 4\n");
   printf ("\n");
   printf ("   -p, --string_pad <size>           Pad strings to this byte size.\n");
   printf ("                                     Default is %d.\n", PMSRC_DEFAULT_STRING_PAD);
   printf ("                                     Allowed values: 0 < value <= 16384 (multiple of 2)\n");
   printf ("\n");
   printf ("   -c, --report_constant_size <size> Constants within reports will be\n");
   printf ("                                     aligned to this byte boundary.\n");
   printf ("                                     Default is 4.\n");
   printf ("                                     Allowed values: 2, 4, 6, or 8\n");
   printf ("\n");
   printf ("   -a, --allow_inconclusive          Allow inconclusive matching.\n");
   printf ("                                     Default is to disallow inconclusive matches.\n");
   printf ("\n");
   printf ("   -W, --Werror                      Warnings are errors.\n");
   printf ("\n");
   printf ("   -w, --w                           Suppress warning messages. Note: Ignored if --Werror used.\n");
   printf ("\n");
#ifdef DEV_DBG
   printf ("   Debug options:\n");
   printf ("\n");
   printf ("   -s, --debug_summary               Show summary level of debug info.\n");
   printf ("   -t, --debug_test                  Show test info.\n");
#endif /* DEV_DBG */
   printf ("\n");
   printf ("   Example:\n");
   printf ("      stateful_rule_compiler --input my_rules -output my_rules.out\n");
   printf ("\n");
}
