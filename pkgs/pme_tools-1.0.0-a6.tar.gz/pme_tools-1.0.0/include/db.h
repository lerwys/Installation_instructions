/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/****************************************************************************
 *   File Name : db.h
 *
 *   This file defines the public interface to the simple DataBase (DB)
 *   module. 
 *
 *   This simple DB module provides support for managing pointers to
 *   the user records and names of the user records.  The records
 *   themselves must be maintained, i.e., allocated, initialized and
 *   deleted by the user. 
 *
 *   Prior to creating a DB the user should initialize the DB
 *   module with a call to the db_module_init() function.  At
 *   present, the module initialization function performs only some
 *   sanity checks.  After initializing the DB module the user can
 *   create a DB or DBs and add/delete records to/from the DBs.  Each
 *   record added to a DB must have a name that is unique in that DB.
 *   A record can be accessed by its name or by the index assigned to
 *   the record when it was added to the DB.
 *
 ****************************************************************************/
#ifndef DB_H_INCLUDE
#define DB_H_INCLUDE




/*--------------------- Include Files -----------------------------*/

#include <generic_types.h>








/*--------------------- Macro Definitions--------------------------*/
 
/* This macro defines the abbreviated name for this module. */
#define DB_MODULE_NAME                    "DB"


/* This macro defines the maximum size (including the NULL termination
 * character) of a DB name. */
#define DB_NAME_MAX_SIZE                  128







/*--------------------- Type Definitions---------------------------*/

/* This type defines the different error codes that can be returned by
 * the functions in the DB module. */
typedef enum {
  /* "DB: Operation successful." */
  db_ok_e                          =  0,

  /* "DB: Operation failed." */
  db_error_e                       =  1,

  /* "DB: Invalid DB handle." */
  db_invalid_db_handle_e           =  2,

  /* "DB: NULL pointer parameter." */
  db_null_ptr_parameter_e          =  3,

  /* "DB: Name is in use." */
  db_name_is_in_use_e              =  4,

  /* "DB: Name is not in use." */
  db_name_is_not_in_use_e          =  5,

  /* "DB: Failed to create an index table." */
  db_failed_to_create_idx_table_e  =  6,

  /* "DB: More error codes than strings are defined." */
  db_too_few_error_strings_e       =  7,

  /* "DB: More error strings than codes are defined." */
  db_too_many_error_strings_e      =  8,

  /* "DB: Too many records." */
  db_too_many_records_e            =  9,

  /* "DB: Failed to allocate an index." */
  db_failed_to_allocate_index_e    = 10,

  /* "DB: Ran out of memory." */
  db_out_of_memory_e               = 11,

  /* "DB: Index is not allocated." */
  db_index_is_not_allocated_e      = 12,

  /* "DB: Failed to destroy DB index table." */
  db_failed_to_destroy_idx_table_e = 13,

  /* "DB: Invalid name." */
  db_invalid_name_e                = 14,


  db_last_error_code_e,
  db_ensure_this_enum_is_signed_e  = -1  /* do not use! */
} db_status_t;


/* This type is defined for functions that can be used to display the
 * user DB records.  DB module "Show" functions use functions of this
 * type to custom display the user DB records. */
typedef void db_record_show_func_t(
  void     *userRecord_p, 
  char     *recordName_s,
  uint32_t  recordIndex);


/* This type defines the DB statistics. */
typedef struct {
  char      name_s[DB_NAME_MAX_SIZE]; /* DB name */
  uint32_t  recordMaxNum;             /* max. number of DB records */
  uint32_t  recordNum;                /* # of records in DB */
  uint32_t  nameNum;                  /* # of currently used entries */
  uint32_t  nameTableSize;            /* # of indexes in the table */
  uint32_t  usedEntryNum;             /* # of used entries in the table */
  uint32_t  collisionNum;             /* # of name collisions */
  uint32_t  indexCollisionNum;        /* # of indexes with name collisions */
  uint32_t  maxIndexCollisionNum;     /* max. name collisions in an index */
  uint32_t  maxCollisionIndex;        /* index with max. name collisions */
  uint32_t  minIndexCollisionNum;     /* min. name collisions in an index */
  uint32_t  minCollisionIndex;        /* index with min. name collisions */
} db_stats_t;





/*--------------------- Private Global Data Definitions -----------*/








/*--------------------- Function Declarations ---------------------*/

/*
 * Create a new DB.
 *
 * param recordMaxNum  Maximum number of records that can be added to
 *                     the database to be created.
 * param name_p        Name of the database.
 * param handle_p      Pointer to where the handle of the created DB
 *                     should be stored.
 * retval              db_ok_e on success; and error code otherwise.
 *                     When db_ok_e is returned the handle of the
 *                     newly created DB is stored in handle_p.
 */
db_status_t 
db_db_create(
  uint32_t    recordMaxNum,
  const char *name_p,
  handle_t   *handle_p);


/*
 * Return error string for the passed in error code.
 *
 * param errorCode Error code to use.
 * retval          Error string corresponding to the error code passed.
 */
const char *
db_error_string_get(
  db_status_t  errorCode);


/*
 * Destroy the indicated DB.
 *
 * param handle  Handle of the DB to destroy.
 * retval        db_ok_e upon success; an error code otherwise. 
 */
db_status_t
db_db_destroy(
  handle_t  handle);


/*
 * Check if the passed handle is valid.
 *
 * param handle  Handle to validate.
 * retval        true if the handle is valid; false otherwise.
 */
bool
db_is_handle_valid(
  handle_t  handle);


/*
 * Check if the passed index is valid.
 *
 * param handle  Handle of the DB to use.
 * param idx     Index to validate.
 * retval        true if the index is valid; false otherwise.
 */
bool
db_is_index_valid(
  handle_t  handle,
  uint32_t  idx);


/*
 * Initialize the DB module.
 *
 * retval  db_ok_e upon success; an error code otherwise.
 */
db_status_t
db_module_init(void);


/*
 * Displays the name table data and statistics in the indicated DB.
 *
 * param handle      Handle of the DB to use.
 * param showFunc_p  Pointer to a function that could be used to
 *                   display extra information for each name table
 *                   entry. 
 */
void
db_name_table_show(
  handle_t               handle,
  db_record_show_func_t *showFunc_p);


/* 
 * Add a record to the indicated DB.
 *
 * param handle    Handle of the DB to add the record to.
 * param name_p    Name of the record to be added.
 * param record_p  Pointer of the record to be added.
 * param index_p   Pointer to where the records index is to be stored.
 * retval          db_ok_e upon success; an error code otherwise.
 *                 When db_ok_e is returned the index_p returns the
 *                 index assigned to the newly added record.
 */
db_status_t
db_record_add(
  handle_t    handle,
  const char *name_p,
  const void *record_p,
  uint32_t   *index_p);


/*
 * brief Delete all the records in the specified DB.
 *
 * param handle  Handle of the DB to use.
 * retval        db_ok_e upon success; an error code otherwise. 
 */
db_status_t
db_record_all_delete(
  handle_t  handle);


/*
 * Display fields of all the records in the specified DB.
 *
 * param handle      Handle of the DB to use.
 * param showFunc_p  Pointer to a function that will be used to
 *                   display each record.
 * retval            db_ok_e upon success; an error code otherwise. 
 */
db_status_t
db_record_all_show(
  const handle_t         handle,
  db_record_show_func_t *showFunc_p
  );



/*
 * Delete the indexed record from the indicated DB.
 *
 * param handle  Handle of the DB to add the record to.
 * param idx     Index of the record to be deleted.
 * retval        db_ok_e upon success; an error code otherwise. 
 */
db_status_t
db_record_by_index_delete(
  handle_t  handle,
  uint32_t  idx);


/*
 * Get the user record pointer using the record index.
 *
 * param handle  Handle of the DB to use.
 * param idx     Index of the record to retrieve.
 * retval        Pointer to the record stored at the indicated index
 *               location upon success; a NULL pointer otherwise. 
 */
void *
db_record_by_index_get(
  handle_t  handle,
  uint32_t  idx);


/* 
 * Display fields of the indexed record.
 *
 * param handle      Handle of the DB to use.
 * param idx         Index of the record to show.
 * param showFunc_p  Pointer to a function that will be used to
 *                   display the record.
 * retval            db_ok_e upon success; an error code otherwise. 
 */
db_status_t
db_record_by_index_show(
  handle_t               handle,
  uint32_t               idx,
  db_record_show_func_t *showFunc_p);


/*
 * Delete the named record from the indicated DB.
 *
 * param handle  Handle of the DB to add the record to.
 * param name_p  Pointer to the name of the record to be deleted.
 * retval        db_ok_e upon success; an error code otherwise. 
 */
db_status_t
db_record_by_name_delete(
  handle_t    handle,
  const char *name_p);


/*
 * Get the user record pointer using the record name.
 *
 * param handle  Handle of the DB to use.
 * param name_p  Pointer to the name of the record to get.
 * retval        Pointer to the record stored under the indicated
 *               name upon success; a NULL pointer otherwise. 
 */
void *
db_record_by_name_get(
  handle_t    handle,
  const char *name_p);


/* 
 * Display fields of the named record.
 *
 * param handle      Handle of the DB to use.
 * param name_p      Pointer to the name of the record to show.
 * param showFunc_p  Pointer to a function that will be used to
 *                   display the record.
 * retval            db_ok_e upon success; an error code otherwise. 
 */
db_status_t
db_record_by_name_show(
  handle_t               handle,
  const char            *name_p,
  db_record_show_func_t *showFunc_p);


/*
 * Get the name of the record using the record index.
 *
 * param handle  Handle of the DB to use.
 * param idx     Index of the record to retrieve.
 * retval        Pointer to the name of the record stored at the
 *               indicated index location upon success; a NULL
 *               pointer otherwise.  
 */
const char *
db_record_name_get(
  handle_t  handle,
  uint32_t  idx);


/*
 * Get the index of the named record.
 *
 * param handle  Handle of the DB to use.
 * param name_p  Pointer to the name of the record to get.
 * retval        Index of the record with the spceified name
 *               upon success; IDX_NULL_INDEX otherwise.
 */
uint32_t
db_record_index_get(
  handle_t    handle,
  const char *name_p);


/*
 * Get the maximum number of records in the indicated DB.
 *
 * param handle  Handle of the DB to use.
 * retval        Number of allocated records in the DB.  0 upon a
 *               failure. 
 */
uint32_t
db_record_max_number_get(
  handle_t  handle);


/*
 * Get the next allocated record pointer.
 *
 * NOTE: Passing the IDX_NULL_INDEX will result in returning the
 *       record stored at the smallest allocated index.
 *
 * param handle  Handle of the DB to use.
 * param idx_p   The search for the next allocated record is started
 *               from the index following this passed in index.
 * retval        Pointer to the record stored at the next (with
 *               respect to the passed index) allocated index
 *               location upon success; a NULL pointer otherwise. 
 *               When a non-NULL pointer is returned the idx_p is set
 *               to contain the index value associated with the 
 *               returned record.
 */
void *
db_record_next_get(
  handle_t  handle,
  uint32_t  *idx_p);


/*
 * Get the number of records present in the indicated DB.
 *
 * param handle  Handle of the DB to use.
 * retval        Number of allocated records in the DB.  0 upon a
 *               failure. 
 */
uint32_t
db_record_number_get(
  handle_t  handle);


/*
 * Collect the statistics for the indicated DB.
 *
 * param handle     Handle of the DB to use.
 * param dbStats_p  Area where the collected statistics are to be stored.
 * retval           db_ok_e upon success; an error code otherwise.
 *                  When db_ok_e is returned the valid DB statistics
 *                  are returned through the dbStats_p variable.
 */
db_status_t
db_stats_get(
  handle_t    handle,
  db_stats_t *dbStats_p);








/*--------------------- Function Definitions ----------------------*/








#endif /* DB_H_INCLUDE */

