/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef __pmla_h__
#define __pmla_h__

/**********************************************************************
 * File:  pmla.h
 *
 * Description:
 *   This file holds the Pattern Matching Loader Agent API declaration.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <generic_types.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <pmp.h>


/**********************************************************************
 * Macro Definitions
 **********************************************************************/

/* This macro identifify the module name string */
#define PMLA_MODULE_NAME "PMLA"

/* Keep alive values */
#define PMLA_DISABLE_KEEPALIVE 0
#define PMLA_MIN_KEEPALIVE 1
#define PMLA_MAX_KEEPALIVE 18748800

/* Maximum command/notification size */
#define PMLA_MAX_MSG_SIZE 0x00ffffff

/* Infinite timeout value */
#define PMLA_INFINITE (0x7fffffff)

/* Specify the size of the target structure */
#define PMLA_TARGET_MAX_SIZE 128

/* Minimum buffer size to hold a string representing a PMLA target */
#define PMLA_TARGET_STRING_MIN_SIZE 64

/**********************************************************************
 * Types
 **********************************************************************/

/* Error codes */
typedef enum
{
    /* Success code */
    pmlaSuccess_c            =   0, /* The operation completed with success */

    /* Error codes */
    pmlaOutOfMemory_c        =  -1, /* Can't allocate memory */
    pmlaInvalidTarget_c      =  -2, /* Target structure badly populated */
    pmlaInvalidHandle_c      =  -3, /* Invalid Loader Agent handle specified */
    pmlaNotConnected_c       =  -4, /* Currently not connected to target */
    pmlaAlreadyConnected_c   =  -5, /* Already connected to target */
    pmlaInvalidOptionCode_c  =  -6, /* Invalid option code specified */
    pmlaInvalidOptionValue_c =  -7, /* Invalid option value specified */
    pmlaInvalidOptionSize_c  =  -8, /* Invalid option size specified */
    pmlaUnavailableOption_c  =  -9, /* Wrong option for current state */
    pmlaConnectFailure_c     = -10, /* Loader Agent cannot connect to target */
    pmlaBulkInProgress_c     = -11, /* Bulk indication already provided */
    pmlaNotInBulkState_c     = -12, /* Bulk indication was not provided */
    pmlaNoBufferProvided_c   = -13, /* Data buffer is NULL */
    pmlaBufferSizeError_c    = -14, /* Data buffer size is too big */
    pmlaInvalidTimeout_c     = -15, /* Timout value is out of range */
    pmlaLostConnectivity_c   = -16, /* Lost connectivity with the target */
    pmlaTransportError_c     = -17, /* Some kind of transport error */
    pmlaCantDestroy_c        = -18, /* Error while destroying the object */
    pmlaTargetHwFailure_c    = -19, /* Remote target got a hardware failure */
    pmlaTargetSwFailure_c    = -20, /* Remote target got a software failure */
    pmlaUnrecoverableError_c = -21, /* Unrecoverable software error */
    pmlaTimedOut_c           = -22, /* Timed out */
    pmlaTargetHwUnavailable_c= -23, /* Remote target is unavailable */
    pmlaInvalidCommand_c     = -24, /* Specified PMP command is invalid */
    pmlaInvalidNotification_c= -25, /* Received PMP notification is invalid */
    pmlaBufferPending_c      = -26, /* Receive buffer currently pending */

    /* Range of valid error code */
    pmlaErrorFirst_c         = pmlaBufferPending_c,
    pmlaErrorLast_c          = pmlaSuccess_c,
} PmlaError_t;

/* Target descriptor */
typedef union
{
    struct
    {
        int                    channel;    /* Channel to use on target */
        struct sockaddr        addr;       /* Address of the target */
    };
    uint8_t storage[PMLA_TARGET_MAX_SIZE]; /* Target storage size */
} PmlaTarget_t;

/* Options */
typedef enum
{
    pmlaOptionKeepAlive_c = 0,     /* Keep alive option (def.: 0=disabled) */
    pmlaOptionTimeout_c,           /* Timeout option (def.: PMLA_INFINITE) */
    
    pmlaMaxOptions_c,              /* Number of supported options */
} PmlaOptionCode_t;

/**********************************************************************
 * Function Declaration
 **********************************************************************/

/* This function provides a Loader Agent handle.  Such an handle is required
 * on any subsequent Loader Agent operations.  It takes as a parameter a
 * pointer to a target structure and a pointer where to store the newly
 * created Loader Agent handle.  The target arguments describes the target
 * characteristics such as location (remote vs local).  It is the only piece
 * of code that is aware about the Loader Agent medium implementation.
 *
 * The function returns an error code.  When returning pmlaSuccess_c, the
 * function succeeded.  Otherwise, the error code indicate the reason of
 * the failure.  See PmlaError_t for details.
 *
 * When opening a Loader Agent handle, it does not connect to the target
 * immediately.  Rather, it offers the ability to configure additional options
 * before proceeding with contacting the target.  The user must use
 * pmlaConnect(...) in order to connect to the target.
 */
PmlaError_t pmlaOpen ( PmlaTarget_t *target, handle_t *handle );

/* This function provides the ability to tweak the Loader Agent behavior.  
 * The pmlaHandle argument refers to the Loader Agent instance to tweak, the 
 * optionId argument indicates the option to tweak and the arguments option 
 * and optionSize represent the pointer to the option configuration structure 
 * and its associated size.  The function returns an error code based on
 * PmlaError_t.
 */
PmlaError_t pmlaSetOption ( handle_t pmlaHandle,
                            int optionId,
                            void *option,
                            int optionSize );

/* This function provides the ability to retrieve options form the Loader 
 * Agent.  The pmlaHandle argument refers to the Loader Agent instance to 
 * query, the optionId argument indicates the option to retrieve and the 
 * arguments option and optionSize represent the pointer where to store the 
 * option configuration structure and the pointer where to store the 
 * configuration structure size.  Note that optionSize must point to an 
 * initialized variable containing the actual size of the option buffer 
 * before calling this function.  Then after the call, the integer pointed to 
 * by optionSize is modified with the actual structure size used by the 
 * Loader Agent.  The function returns an error code based on PmlaError_t.
 */
PmlaError_t pmlaGetOption ( handle_t pmlaHandle,
                            int optionId,
                            void *option,
                            int *optionSize );

/* When the PMM application is done with the Loader Agent, it must close its 
 * handle in order to release its associated memory and resources properly.  
 * It takes the handle as arguments and return an error code based on 
 * PmlaError_t upon completion.
 *
 * If the handle is connected to the target while closing it, pmlaClose(...)
 * will also implicitly call pmlaDisconnect(...) before proceeding.
 */
PmlaError_t pmlaClose ( handle_t pmlaHandle );

/* After creating an handle, the PMM application can connect to the target.  
 * The PMM application must be connected in order to send commands and 
 * receive notifications.  Connecting to the target implies opening an
 * interface handle and a driver handle to the hardware resources as well 
 * as initializing any resources in the medium.
 *
 * This function takes a Loader Agent as arguments and blocks until the 
 * Loader Agent is fully connected.  It returns an error code based on
 * PmlaError_t indicating if the connection succeeded or not.
 */
PmlaError_t pmlaConnect ( handle_t pmlaHandle );

/* In some situations, the PMM application does not need to be persistently 
 * connected to the hardware.  In such cases, this function is used to 
 * disconnect (and allow re-connect at a later time).  Disconnecting implies 
 * releasing the PM driver resources as well as tearing down the medium.
 *
 * This function takes a Loader Agent as arguments and blocks until the 
 * Loader Agent is fully disconnected.  It then returns an error code based
 * on PmlaError_t.
 */
PmlaError_t pmlaDisconnect ( handle_t pmlaHandle );

/* There are cases where the PMM application sends a batch of commands and 
 * other cases where it only sends incremental commands.  There are many 
 * advantages in terms of performance as well as in data arrangement to
 * convey these commands to the medium and the PM driver.  This function
 * represents an indication to the Loader Agent for cases where a batch of 
 * commands is about to be sent.  It allows the PMM application to keep 
 * sending its command one at a time while indicating to the Loader Agent it 
 * could do a better job handling these commands in bulk rather than 
 * individually.
 *
 * The function takes a Loader Agent handle as arguments and return an
 * error code based on PmlaError_t immediately (does not block).  The
 * PMM application is expected to invoke the pmlaBulkEnd(...) function to
 * provide the end of the bulk indication.
 *
 * This function represents an indication to the Loader Agent that a batch of
 * commands is about to be sent.  It does not guarantee atomicity of the
 * operations.  Most of the time, atomicity is also required along with the
 * bulk indication.  In these cases, the PMM application is required to send an
 * atomic begin request command as the first command following the call to
 * this function.  Refer to the PM command protocol for more information on
 * this.
 */
PmlaError_t pmlaSendBulkBegin ( handle_t pmlaHandle );

/* This is an indication to the Loader Agent that the batch operation (bulk of
 * commands) has now completed.  This means that any subsequent commands are
 * going to be treated as individual commands again.  The function
 * pmlaBulkBegin(...) must have previously been called before calling this
 * function, otherwise, an error code based on PmlaError_t is returned.
 *
 * This function takes a Loader Agent handle as arguments and return
 * immediately (non blocking).  In case of a failure, an error code based on
 * PmlaError_t is returned.  A call to this function does not guarantee
 * that the bulk of commands is fully processed by the hardware.  If the PMM
 * application requires to know when all commands have reached the hardware,
 * it must use the pmlaFlush(...) function for that.
 *
 * Note that if the atomic begin request command was sent, the PMM
 * application is expected to send an atomic end request command prior to
 * call this function.  Failure to do this may lead to dead lock situation
 * based on the medium implementation of the Loader Agent.
 */
PmlaError_t pmlaSendBulkEnd ( handle_t pmlaHandle );

/* The PMM application communicates to the PM driver through the Loader Agent
 * using the PM command protocol.  This function is used to send one of these
 * commands.  It takes as arguments a Loader Agent handle along with a
 * pointer to the command message.
 *
 * Upon completion, the function returns success or an error code based on 
 * PmlaError_t.  This function may be blocking based on the medium 
 * implementation.  However, even in the blocking case, the Loader Agent does 
 * not guarantee that the command has reached the hardware upon returning from
 * the call.  If this behavior is required, the PMM application is required to
 * invoke the function pmlaFlush(...).
 */
PmlaError_t pmlaSend ( handle_t pmlaHandle,
                       pmp_msg_t *cmd );

/* The PM command protocol contains commands that generates a notification.
 * These notification can be passed to the PMM application when invoking this
 * function.  It takes as arguments a Loader Agent handler along with a
 * pointer where to store one notification.
 *
 * This function is blocking until a notification is being retrieved from the
 * Loader Agent or when the operation timed out.  It returns success or an
 * error code based on PmlaError_t.
 *
 * By default, this function blocks undefinitively.  In order to ensure the
 * control is handed back to the PMM, a time out can be set.  This is
 * achieved by callling pmlaSetOption() with pmlaOptionTimeout_c optionId.
 *
 * The only way for this function to succeed is when a complete whole
 * notification is received.  Otherwise, it will return an error 
 * (i.e. pmlaTimedOut_c).
 *
 * Note that if the PMM applications wishes to use pmlaRecv(...) in a
 * non-blocking fashion, it can specifies a timeout value of zero.  In such
 * case, if no notifications are available, the Loader Agent returns
 * immediately.
 *
 * Special care must be taking when using this function inside a bulk
 * operation.  Due to the nature of how bulk commands are conveyed to the
 * hardware, notification may not come before the end of the bulk indication is
 * given to the Loader Agent.  In such situation, the PMM application is
 * expected to provide the end of bulk indication prior to block on
 * pmlaRecv(...).
 */
PmlaError_t pmlaRecv ( handle_t pmlaHandle,
                       pmp_msg_t *notif );

/* For efficiency and performance purposes, the Loader Agent never guarantees
 * when commands sent via the pmlaSend(...) function reaches the hardware
 * upon return.  This behavior is fine most of the time.  However, there are
 * some cases where the PMM application must know when commands reaches the
 * hardware.  A simple scenario is where testing patterns and configuring
 * patterns use a different path.  The PMM application must ensure the
 * commands have all reached the hardware before testing data against the
 * new set of patterns.
 *
 * The Loader Agent provides this information by using this function.  It
 * takes as arguments a Loader Agent handle and blocks until all previously
 * sent commands have reached the hardware.  This functions returns an error
 * code based on PmlaError_t.
 */
PmlaError_t pmlaFlush ( handle_t pmlaHandle );

/* This utility function converts a PmlaTarget_t structure into a printable
 * string.  It takes as arguments a pointer to a PMLA target structure along
 * with a pointer to memory where to store the converted string.  The user
 * of this function must ensure that the string buffer points to a parcel
 * of memory of at least PMLA_TARGET_STRING_MIN_SIZE bytes.  If the user 
 * fails to comply to that condition, a processor exception (i.e. 
 * segmentation fault) may halt the program.
 */
PmlaError_t pmlaTargetString ( PmlaTarget_t *target,
                               char *stringBuffer );

/* This utility function converts a PmlaError_t error code into a 
 * printable string.  It takes as arguments a PmlaError_t code and return
 * the corresponding string representation.  The function always succeed.
 * If the error code is invalid, this function returns a string indicating
 * that the code is invalid.  Note that the return string maps to static
 * memory and shall not be modified.
 */
const char *pmlaErrorString ( PmlaError_t code );

#endif /* __pmla_h__ */
