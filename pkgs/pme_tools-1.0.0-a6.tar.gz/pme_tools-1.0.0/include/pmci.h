/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
#ifndef __pmci_h__
#define __pmci_h__

/**********************************************************************
 * File:  pmci.h
 *
 * Description:
 *   This file holds the Pattern Matching Control Interface API declaration.
 *
 **********************************************************************/

/**********************************************************************
 * Includes
 **********************************************************************/

#include <generic_types.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <pmp.h>

/**********************************************************************
 * Types
 **********************************************************************/

/* Error codes */
typedef enum
{
    /* Success code */
    pmci_success_e                 =   0, /* The operation completed with success */

    /* Error codes */
    pmci_failure_e                 =  -1, /* The operation fail to complete */
    pmci_out_of_memory_e           =  -2, /* Can't allocate memory */
    pmci_invalid_handle_e          =  -3, /* Invalid PMCI handle specified */
    pmci_unavailable_option_e      =  -4, /* The option is not implemented */
    pmci_unavailable_driver_e      =  -5, /* The PM driver is unavailable */
    pmci_invalid_option_code_e     =  -6, /* Invalid option code specified */
    pmci_invalid_option_value_e    =  -7, /* Invalid option value specified */
    pmci_invalid_option_size_e     =  -8, /* Invalid option size specified */
    pmci_not_yet_implemented_e     =  -9, /* Operation not yet implemented */
    pmci_invalid_parameters_e      = -10, /* One or more parameters are invalid */
    pmci_invalid_attribute_id_e    = -11, /* Invalid attribute to get/set request */
    pmci_invalid_attribute_val_e   = -12, /* Invalid attribute value */
    pmci_invalid_attribute_len_e   = -13, /* Invalid attribute length */
    pmci_lost_driver_e             = -14, /* Occurs when the driver locked out */
    pmci_unrecoverable_error_e     = -15, /* Unrecoverable error */
    pmci_invalid_channel_e         = -16, /* Invalid channel number specified */
    pmci_empty_read_e              = -17, /* Read operation return empty buffer */
    pmci_unsupported_hw_revision_e = -18, /* Unsupported HW revision */

    /* Range of valid error code */
    pmci_error_first_e         = pmci_unsupported_hw_revision_e,
    pmci_error_last_e          = pmci_success_e,
} pmci_error_t;

/* Options */
typedef enum
{
    pmci_option_timeout_e                = 0, /* Timeout capability for pmci_read() */
    pmci_option_batch_buffer_threshold_e = 1, /* Batch buffer threshold */

    pmci_num_options_e,                       /* Number of supported options */
} pmci_option_id_t;

/* Default channel for control */
#define PMCI_DEFAULT_CHANNEL     0

/* Infinite timeout value */
#define PMCI_INFINITE            (0x7fffffff)

/* Default and minimal value of atch buffer threshold. */
// TODO defualt is 8M.  Set to 1M for pre-release driver until zero-copy works.
#define PMCI_BATCH_BUFFER_THRESHOLD_DEFAULT (1*1024*1024)
#define PMCI_BATCH_BUFFER_THRESHOLD_MIN (64*1024)

/* Metrics for clearing context by ruleId */
#define PMCI_SRE_CYCLE_INTERVAL  1
#define PMCI_SRE_CLEAR_PRIORITY  1

/**********************************************************************
 * Function Declaration
 **********************************************************************/

/* This function simply opens the PM Control Interface and return its own 
 * handle.  Such an handle is required on any subsequent PM Control Interface
 * operations.
 *
 * The function takes as argument a pointer where to store the newly 
 * created handle.  It returns an error code based on pmci_error_t.
 * See pmci_error_t for details.
 */
pmci_error_t pmci_open(int channel, handle_t *handle);

/* This function provides the ability to tweak the behavior of the PMCI
 * handle by applying options.  The supported options are defined by
 * the pmci_option_id_t type.
 *
 * The function takes as arguments the handle for setting the option, the
 * option identifier to modify, a pointer to the value to use and the
 * size of that value.  Note that each option may have its own value format.
 * The function returns a code based on pmci_error_t type.
 */
pmci_error_t pmci_set_option(handle_t pmci_handle, pmci_option_id_t optionId, 
                          void *option, int optionSize);

/* This function provides the ability to retrieve current value of options
 * used by the PMCI handle.  These are either values set by the user or 
 * default values that did never get changed.
 *
 * The function takes as arguments the handle for getting the option, the
 * option identifier to retrieve, a pointer to store the value and the
 * pointer where to store the option size.  Note that the pointer where to 
 * store the option size must represent size of the buffer where to store the
 * option.  The function returns a code based on pmci_error_t type.
 */
pmci_error_t pmci_get_option(handle_t pmci_handle, pmci_option_id_t optionId, 
                          void *option, int *optionSize);

/* When the user is done with the PM Control Interface, it must close 
 * its handle in order to release its associated memory and resources properly.
 * The function takes the handle as arguments and return an error code based
 * on pmci_error_t upon completion.
 *
 * The function takes a PMCI handle as argument and return an error code based
 * on pmci_error_t type.
 */
pmci_error_t pmci_close(handle_t pmci_handle);

/* The user communicates to the PM driver through the PM Control 
 * Interface using the PM command protocol.  This function is used to write 
 * one or more commands.  It takes as arguments a PM Control Interface handle
 * along with a pointer to the buffer of commands and the associated buffer
 * size.
 *
 * Upon completion, the function return an error code based on pmci_error_t.
 * This function may or may not be blocking.  The user should not make
 * assumptions about if the command(s) has(have) reached the hardware upon 
 * returning from the call.
 */
pmci_error_t pmci_write(handle_t pmci_handle, void *cmds, int cmdsSize);

/* The PM command protocol contains commands that generates a notification.  
 * These notifications can be passed to the user when invoking this 
 * function.  It takes as arguments a Control Interface handler along with a 
 * pointer where to store the notification.
 *
 * This function is blocking until one notification is being retrieved
 * from the PM Driver.  However, the option pmci_option_timeout_e provides
 * the ability to set a timeout value.  This causes the pmci_read()
 * function to return the control when no notification is present for
 * some specified amount of time.  Note that the default timeout value is
 * PMCI_INFINITE.
 */
pmci_error_t pmci_read(handle_t pmci_handle, pmp_msg_t *notif);

/* This function provides the ability to flush the PM driver pipe and ensure
 * no more data are in flight.  The call blocks until the PM driver has ensured
 * its pipe is empty and that all preceding commands have not only reached the
 * hardware but has also completed execution.
 *
 * The function takes a PMCI handle as argument and return an error code based
 * on pmci_error_t type.
 */
pmci_error_t pmci_flush(handle_t pmci_handle);

/* This function provides the ability to clear the stateful rule context
 * associated to a specific sessionId.
 *
 * The function takes a session identifer as argument and return an error
 * code based on pmci_error_t.
 */
pmci_error_t pmci_context_clear_by_session_id(uint32_t sessionId);

/* This utility function converts a pmci_error_t error code into a 
 * printable string.
 *
 * The function takes an error code as argument and return a pointer to 
 * a printable string.
 */
const char *pmci_error_string ( pmci_error_t code );

/* This function set the file descriptor bit in the specified file descriptor
 * set mask.  This provides an application to manipulate the PMCI file 
 * descriptor without having to know how many it uses or what those are.
 *
 * Although it is a function, it uses macro naming convention just to be
 * consistent with the existing macro FD_SET().  The reason it is 
 * implemented as a function was to hide implementation specific from the
 * header file.
 */
void PMCI_FD_SET(handle_t pmci_handle, fd_set *fdset);

/* This function clear the file descriptor bit in the specified file descriptor
 * set mask.  This provides an application to manipulate the PMCI file 
 * descriptor without having to know how many it uses or what those are.
 *
 * Although it is a function, it uses macro naming convention just to be
 * consistent with the existing macro FD_CLR().  The reason it is 
 * implemented as a function was to hide implementation specific from the
 * header file.
 */
void PMCI_FD_CLR(handle_t pmci_handle, fd_set *fdset);

/* This funtion test if the file descriptor set mask contains any of the PMCI
 * file descriptors.  This provides an application to test the PMCI file
 * descriptor whithout having to know how many it uses or what those are.
 *
 * Although it is a function, it uses macro naming convention just to be
 * consistent with the existing macro FD_ISSET().  The reason it is 
 * implemented as a function was to hide implementation specific from the
 * header file.
 */
int PMCI_FD_ISSET(handle_t pmci_handle, fd_set *fdset);

/* This functions provides the highest file descriptor number used by the PMCI
 * handle.  This is useful when an application needs to perform a select 
 * operation that includes the PMCI handle.  Such application can manipulate
 * the PMCI file descriptor without knowing how many it uses or what those are.
 *
 * Although it is a function, it uses macro naming convention just to be
 * consistent with the counter part function PMCI_FD_SET() and PMCI_FD_ISSET().
 * The reason it is implemented as a function was to hide implementation specific
 * from the header file.
 */
int PMCI_FD_GETN(handle_t pmci_handle);

#endif /* __pmci_h__ */
