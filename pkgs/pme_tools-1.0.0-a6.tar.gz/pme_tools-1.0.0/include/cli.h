/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/********************************************************************************
 *   File Name : cli.h
 *
 *   This file defines the public interface to the Command Line Interface 
 *   (CLI) module.
 *
 *******************************************************************************/
#ifndef CLI_H_INCLUDE
#define CLI_H_INCLUDE



/*--------------------- Include Files -----------------------------------------*/

#include <generic_types.h>





/*--------------------- Macro Definitions--------------------------------------*/

/* This macro defines the abbreviated name for this module. */
#define CLI_MODULE_NAME                    "CLI"


/* The next few macros define the supported command flags.  "Or" the
 * different flags together if you need to enable more than one flag. */
#define CLI_NO_CMD_FLAG                    0x00000000
#define CLI_SHOW_EXEC_TIME_CMD_FLAG        0x00000001


/* The next few macros define the supported menu option flags.  "Or" the
 * different flags together if you need to enable more than one flag. */
#define CLI_MENU_NO_OPTION                 0x00000000
/* Setting this flag causes the cli_start() function to return if a 
   command handler returns a non-0 or an unknown command has been entered. */ 
#define CLI_MENU_EXIT_ON_ERROR_OPTION      0x00000001


/* This macro defines the maximum lenght (in bytes) of the command
 * line the user can enter. */
#define CLI_USER_INPUT_MAX_LEN             2048


/* This macro defines the maximum length of the CLI variable name strings
 * (include the terminating NULL character). */  
#define CLI_NAME_MAX_LENGTH                32









/*--------------------- Type Definitions---------------------------------------*/

/* 
 * CLI command handlers.
 *
 * When involked, command parameters will be passed in arg as a single
 * string, context_p will contain the pointer passed in when the
 * command was added. */
typedef int (*cli_cmd_handler_t)(char *arg, void *context_p);


/* CLI Error code */
typedef enum {
  /* "CLI: Operation successful." */
  cli_ok_e                         =  0,

  /* "CLI: Operation failed." */
  cli_error_e                      =  1,

  /* "CLI: Invalid menu handle." */
  cli_invalid_menu_handle_e        =  2,

  /* "CLI: NULL pointer parameter." */
  cli_null_ptr_parameter_e         =  3,

  /* "CLI: Name is invalid." */
  cli_name_is_invalid_e            =  4,

  /* "CLI: Name is too long." */
  cli_name_is_too_long_e           =  5,

  /* "CLI: Out of memory." */
  cli_out_of_memory_e              =  6,

  /* "CLI: Corrupted Menu." */
  cli_corrupted_menu_e             =  7,

  /* "CLI: Too many parameters." */
  cli_too_many_parameters_e        =  8,


  cli_last_error_code_e,
  cli_ensure_this_enum_is_signed_e = -1  /* do not use! */
} cli_status_t;




/*--------------------- Global Data Definitions -------------------------------*/








/*--------------------- Function Declarations ---------------------------------*/

/*
 * @brief Returns CLI Error string by error code.
 * 
 * @param errorCode  Error code returned from CLI functions.
 * @retval           String of error description. 
 */
const char *
cli_error_string_get(
  cli_status_t  errorCode);


/*
 * @brief Create a new CLI menu.
 * 
 * @param name_p            Name of the menu.
 * @param descr_p           Help string of the menu.
 * @param *newMenu          Location to store the new menu handle.
 * @param parentMenuHandle  Parent menu handle.  New menu will become a 
 *                          submenu of that parent menu.
 *                          Use HANDLE_NULL if the new menu has
 *                          no parent menu.
 * @retval                  cli_ok_e upon success and new menu handle in 
 *                          *newMenu; an error code otherwise.
 */
cli_status_t cli_create_menu(
  const char *name_p,
  const char *descr_p,
  handle_t   *newMenu_p,
  handle_t    parentMenuHandle,
  uint32_t    menuOption);

/*
 * @brief Destroy a menu, and it's submenu. (recursive)
 *
 * @param menuHandle  Menu handle of the menu to destroy.
 * @retval            cli_ok_e upon success; an error code otherwise.
 */
cli_status_t cli_destroy_menu(
  handle_t  menuHandle);

/*
 * @brief Register a new command to a menu.
 *
 * @param menuHandle  Menu handle of the target menu.
 * @param name_p      Name of the command.
 * @param descr_p     Help string of the command.
 * @param context_p   A context pointer that will be passed to the
 *                    command handler. 
 * @param cmdHandler  Command handler that will be called if this
 *                    command is involked. 
 * @param cmdFlags    "Or'ed" flags for this command.
 * @retval            cli_ok_e upon success; an error code otherwise.
 */
cli_status_t cli_register_cmd(
  handle_t           menuHandle,
  const char        *name_p,
  const char        *descr_p,
  void              *context_p,
  cli_cmd_handler_t  cmdHandler_p,
  uint32_t           cmdFlags);

/*
 * @brief Start the CLI from the specified menu.
 *
 * @param menuHandle         Start the CLI from this menu.
 * @param historyFileName_p  Filename of the history file.  If NULL,
 *                           then the "._cli_history" name will be used.  
 * @retval                   cli_ok_e upon success; an error code otherwise.
 */
cli_status_t 
cli_start(
  handle_t   menuHandle,
  const char *historyFileName_p);

/*
 * @brief Run a CLI command.
 *
 * @param menuHandle         Run command from this menu, may be modified.
 * @param cmd                The CLI command.  String content will not be modified.  
 * @retval                   Actual return code from CLI handler.
 */
int
cli_run_cmd(
  handle_t   *menuHandle,
  const char *cmd);

/* 
 * @brief Divides the passed in string into independent parameters.
 *
 * @param  string_p      The string to process.
 * @param  argc          Number of the independent arguments inserted into
 *                       the argv_p array.
 * @param  argv_p        Pointer to the array of pointers to the parameters.
 * @param  paramMaxNum   Size of the argv_p array; also the maximum
 *                       allowed number of parameters.
 * @param  delimiters_p  Pointer to the string with the characters
 *                       delimiting the different commands and keywords.
 * @retval               cli_ok_e upon success; cli_too_many_parameters_e 
 *                       if there are more parameters in the string than
 *                       paramMaxNum.
 */
cli_status_t
cli_command_parse(
  char      *string_p,
  int32_t   *argc,
  char     **argv_p,
  uint32_t   paramMaxNum,
  char      *delimiters_p);


/* 
 * @brief Attemp to convert the passed string to an int32_t value.
 *
 * @param  string_p  String to be converted to a int32_t value.
 * @param  value_p   Pointer to where to store the int32_t value.
 * @retval           true if the conversion worked; false otherwise.
 */
bool
cli_int32get(
  char    *string_p,
  int32_t *value_p);


/* 
 * @brief Attemp to convert the passed string to an uint32_t value.
 *
 * @param  string_p  String to be converted to a uint32_t value.
 * @param  value_p   Pointer to where to store the uint32_t value.
 * @retval           true if the conversion worked; false otherwise.
 */
bool
cli_uint32get(
  char     *string_p,
  uint32_t *value_p);


/* 
 * @brief Attemp to convert the passed string to an uint64_t value.
 *
 * @param  string_p  String to be converted to a uint64_t value.
 * @param  value_p   Pointer to where to store the uint64_t value.
 * @retval           true if the conversion worked; false otherwise.
 */
bool
cli_uint64get(
  char     *string_p,
  uint64_t *value_p);


/* 
 * @brief Attempt to convert the passed string to a hexadecimal value.
 *
 * @param  string_p         String to be converted to a hexadecimal value.
 * @param  valueBuffer_p    Pointer to where to store the converted
 *                          hexadecimal value.
 * @param  valueBufferSize  Maximum size (in bytes) of the resulting
 *                          hexadecimal value. 
 * @param  valueLength_p    The length (in bytes) of the converted
 *                          hexadecimal value.
 * @retval                  true if the conversion worked; false otherwise.
 */
bool
cli_hex_get(
  char     *string_p,
  uint8_t  *valueBuffer_p,
  uint32_t  valueBufferSize,
  uint32_t *valueLength_p);







#endif /* CLI_H_INCLUDE */

