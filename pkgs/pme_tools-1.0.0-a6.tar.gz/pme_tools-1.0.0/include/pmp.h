/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/**********************************************************************
 * File:  pmp.h
 *
 * Description:
 *   This file defines the Pattern Matching Protocol (PMP) used between
 *   a host and the Pattern Matching hardware (H/W).
 *
 **********************************************************************/
#ifndef PMP_H_INCLUDE
#define PMP_H_INCLUDE



/**********************************************************************
 * Include Files
 **********************************************************************/

#include <generic_types.h>

/* The code in this file depends on the __BYTE_ORDER macro to be
 * defined.  We check here if it is defined. */
#include <byteswap.h>
#include <endian.h>
#ifndef __BYTE_ORDER
#  error "__BYTE_ORDER is not defined."
#endif

#include <netinet/in.h>





/**********************************************************************
 * Macro Definitions
 **********************************************************************/

/* This macro is to abstract the compiler's "packed" attribute.  It is
 * used to get the compiler to pack structures so that they have
 * predictable sizes. */
#define PMP_PACKED                                 __attribute__((packed))


/* The macros below are used to perform translations from the host to
 * the PM H/W and from the PM H/W to the host formats.  We also define
 * the "ll" versions of the ntoh/hton macros if they are not available. */
#if !defined(htonll) || !defined(ntohll)
#  if __BYTE_ORDER == __BIG_ENDIAN
#    define htonll(x)      (x)
#    define ntohll(x)      (x)
#  else
#    if __BYTE_ORDER == __LITTLE_ENDIAN
#      define htonll(x)    (bswap_64 (x))
#      define ntohll(x)    (bswap_64 (x))
#    endif
#  endif
#endif
#define PMP_HTOPMHWS(x)                            (htons(x))
#define PMP_HTOPMHWL(x)                            (htonl(x))
#define PMP_HTOPMHWLL(x)                           (htonll(x))
#define PMP_PMHWTOHS(x)                            (ntohs(x))
#define PMP_PMHWTOHL(x)                            (ntohl(x))
#define PMP_PMHWTOHLL(x)                           (ntohll(x))


/* This macro defines the current version of the PMP protocol. */
#define PMP_CURRENT_VERSION                        1


/* The next few macros define the sizes (in bytes) of the entries in
 * the different PM H/W tables. */
#define PMP_ONE_BYTE_TRIGGER_ENTRY_SIZE            32
#define PMP_TWO_BYTE_TRIGGER_ENTRY_SIZE            8
#define PMP_VARIABLE_TRIGGER_ENTRY_SIZE            8
#define PMP_CONFIDENCE_ENTRY_SIZE                  4
#define PMP_CONFIRMATION_ENTRY_SIZE                128
#define PMP_USER_DEFINED_GROUP_ENTRY_SIZE          256
#define PMP_EQUIVALENCE_ENTRY_SIZE                 256
#define PMP_SESSION_CONTEXT_ENTRY_SIZE             32
#define PMP_SPECIAL_TRIGGER_ENTRY_SIZE             32


/* The next few macros define the number of entries in the different PM
 * H/W tables. */
#define PMP_CONFIDENCE_ENTRY_NUM_PER_TRIGGER_ENTRY 4

#define PMP_ONE_BYTE_TRIGGER_ENTRY_NUM             1

#define PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V1          512
#define PMP_VARIABLE_TRIGGER_ENTRY_NUM_V1          4096

#define PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V2_0        2048
#define PMP_VARIABLE_TRIGGER_ENTRY_NUM_V2_0        16384

#define PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V2_1        1024
#define PMP_VARIABLE_TRIGGER_ENTRY_NUM_V2_1        8192

#define PMP_SPECIAL_CONFIDENCE_ENTRY_NUM           64
#define PMP_ONE_BYTE_CONFIDENCE_ENTRY_NUM          64

#define PMP_CONFIDENCE_ENTRY_NUM_V1                \
  ((PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V1 +            \
    PMP_VARIABLE_TRIGGER_ENTRY_NUM_V1  +           \
    PMP_ONE_BYTE_CONFIDENCE_ENTRY_NUM +            \
    PMP_SPECIAL_CONFIDENCE_ENTRY_NUM) *            \
   PMP_CONFIDENCE_ENTRY_NUM_PER_TRIGGER_ENTRY)

#define PMP_CONFIDENCE_ENTRY_NUM_V2_0              \
  ((PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V2_0 +          \
    PMP_VARIABLE_TRIGGER_ENTRY_NUM_V2_0  +         \
    PMP_ONE_BYTE_CONFIDENCE_ENTRY_NUM +            \
    PMP_SPECIAL_CONFIDENCE_ENTRY_NUM) *            \
   PMP_CONFIDENCE_ENTRY_NUM_PER_TRIGGER_ENTRY)

#define PMP_CONFIDENCE_ENTRY_NUM_V2_1              \
  ((PMP_TWO_BYTE_TRIGGER_ENTRY_NUM_V2_1 +          \
    PMP_VARIABLE_TRIGGER_ENTRY_NUM_V2_1  +         \
    PMP_ONE_BYTE_CONFIDENCE_ENTRY_NUM +            \
    PMP_SPECIAL_CONFIDENCE_ENTRY_NUM) *            \
   PMP_CONFIDENCE_ENTRY_NUM_PER_TRIGGER_ENTRY)

/*#define PMP_SESSION_ENTRY_NUM                    \
  ((PMP_SESSION_NUM * PMP_SESSION_CONTEXT_SIZE) /  \
  PMP_SESSION_CONTEXT_ENTRY_SIZE) */

#define PMP_EQUIVALENCE_ENTRY_NUM                  1
#define PMP_USER_DEFINED_GROUP_ENTRY_NUM           1
#define PMP_SPECIAL_TRIGGER_ENTRY_NUM              1


/* The next few macros below define the sizes of the different PMP
 * messages.  Note the the macros related to the table read and write
 * messages assume that there is only one entry in the read/write
 * message. */
#define PMP_TABLE_READ_REQUEST_MSG_SIZE               \
  sizeof(pmp_table_read_request_msg_t)
#define PMP_ONE_BYTE_TABLE_READ_REPLY_MSG_SIZE        \
  (sizeof(pmp_table_read_reply_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_ONE_BYTE_TRIGGER_ENTRY_SIZE)
#define PMP_TWO_BYTE_TABLE_READ_REPLY_MSG_SIZE        \
  (sizeof(pmp_table_read_reply_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_TWO_BYTE_TRIGGER_ENTRY_SIZE)
#define PMP_VARIABLE_TABLE_READ_REPLY_MSG_SIZE        \
  (sizeof(pmp_table_read_reply_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_VARIABLE_TRIGGER_ENTRY_SIZE)
#define PMP_CONFIDENCE_TABLE_READ_REPLY_MSG_SIZE      \
  (sizeof(pmp_table_read_reply_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_CONFIDENCE_ENTRY_SIZE)
#define PMP_CONFIRMATION_TABLE_READ_REPLY_MSG_SIZE    \
  (sizeof(pmp_table_read_reply_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_CONFIRMATION_ENTRY_SIZE)
#define PMP_UDG_TABLE_READ_REPLY_MSG_SIZE             \
  (sizeof(pmp_table_read_reply_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_USER_DEFINED_GROUP_ENTRY_SIZE)
#define PMP_EQUIVALENCE_TABLE_READ_REPLY_MSG_SIZE     \
  (sizeof(pmp_table_read_reply_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_EQUIVALENCE_ENTRY_SIZE)
#define PMP_SESSION_TABLE_READ_REPLY_MSG_SIZE         \
  (sizeof(pmp_table_read_reply_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_SESSION_CONTEXT_ENTRY_SIZE)
#define PMP_SPECIAL_TABLE_READ_REPLY_MSG_SIZE         \
  (sizeof(pmp_table_read_reply_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_SPECIAL_TRIGGER_ENTRY_SIZE)

#define PMP_ONE_BYTE_TABLE_WRITE_REQUEST_MSG_SIZE      \
  (sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_ONE_BYTE_TRIGGER_ENTRY_SIZE)
#define PMP_TWO_BYTE_TABLE_WRITE_REQUEST_MSG_SIZE      \
  (sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_TWO_BYTE_TRIGGER_ENTRY_SIZE)
#define PMP_VARIABLE_TABLE_WRITE_REQUEST_MSG_SIZE     \
  (sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_VARIABLE_TRIGGER_ENTRY_SIZE)
#define PMP_CONFIDENCE_TABLE_WRITE_REQUEST_MSG_SIZE   \
  (sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_CONFIDENCE_ENTRY_SIZE)
#define PMP_CONFIRMATION_TABLE_WRITE_REQUEST_MSG_SIZE \
  (sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_CONFIRMATION_ENTRY_SIZE)
#define PMP_UDG_TABLE_WRITE_REQUEST_MSG_SIZE          \
  (sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_USER_DEFINED_GROUP_ENTRY_SIZE)
#define PMP_EQUIVALENCE_TABLE_WRITE_REQUEST_MSG_SIZE  \
  (sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_EQUIVALENCE_ENTRY_SIZE)
#define PMP_SESSION_TABLE_WRITE_REQUEST_MSG_SIZE      \
  (sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_SESSION_CONTEXT_ENTRY_SIZE)
#define PMP_SPECIAL_TABLE_WRITE_REQUEST_MSG_SIZE      \
  (sizeof(pmp_table_write_request_msg_t) - sizeof(pmp_table_entry_t) + \
   PMP_SPECIAL_TRIGGER_ENTRY_SIZE)

#define PMP_TABLE_RESET_REQUEST_MSG_SIZE              \
  (sizeof(pmp_table_reset_request_msg_t))
#define PMP_CTX_ALL_CLEAR_REQUEST_MSG_SIZE            \
  (sizeof(pmp_ctx_all_clear_request_msg_t))

#define PMP_ATTRIBUTE_SET_REQUEST_EMPTY_MSG_SIZE                     \
    (sizeof(pmp_attribute_set_request_msg_t) -                       \
     sizeof(pmp_attribute_t))
#define PMP_ATTRIBUTE_SET_REQUEST_MSG_SIZE(attributeValueSize)       \
    (PMP_ATTRIBUTE_SET_REQUEST_EMPTY_MSG_SIZE +                      \
     attributeValueSize)
#define PMP_ATTRIBUTE_GET_REQUEST_MSG_SIZE                           \
    sizeof(pmp_attribute_get_request_msg_t)
#define PMP_ATTRIBUTE_GET_REPLY_EMPTY_MSG_SIZE                       \
    (sizeof(pmp_attribute_get_reply_msg_t) -                         \
     sizeof(pmp_attribute_t))
#define PMP_ATTRIBUTE_GET_REPLY_MSG_SIZE(attributeValueSize)         \
    (PMP_ATTRIBUTE_GET_REPLY_EMPTY_MSG_SIZE +                        \
     attributeValueSize)

/* The next few macros define names that are (can be) used for PM H/W
 * tables, table entries, etc. */  
#define PMP_UNSUPPORTED_NAME                          "unsupported"
#define PMP_ONE_BYTE_TRIGGER_NAME                     "one-byte"
#define PMP_TWO_BYTE_TRIGGER_NAME                     "two-byte"
#define PMP_VARIABLE_TRIGGER_NAME                     "variable"
#define PMP_CONFIDENCE_NAME                           "confidence"
#define PMP_CONFIRMATION_NAME                         "confirmation"
#define PMP_USER_DEFINED_GROUP_NAME                   "udg"
#define PMP_EQUIVALENCE_NAME                          "equivalence"
#define PMP_SESSION_NAME                              "session"
#define PMP_SPECIAL_NAME                              "special"


/* The next few macros define the request, reply and indication values
 * for the message class flag.  The message class flag can be used to
 * identify the type of a PMP message.  The message class flag is part of 
 * the message type. */
#define PMP_REQUEST_MSG_CLASS_FLAG                    0x00
#define PMP_REPLY_MSG_CLASS_FLAG                      0x80


/* The next few macros define constants associated with the pattern
 * match report records. */
#define PMP_REPORT_WORK_UNIT_OFFSET_SIZE              6
#define PMP_SESSION_RULE_CONTEXT_SIZE                 16
#define PMP_GLOBAL_PERSISTENT_GPRVS_SIZE              16


/* This macro defines the maximum size of the PMP message.  This size
 * includes the header and the data of the message. */
#define PMP_MAX_MSG_SIZE                              65536









/**********************************************************************
 * Type Definitions
 **********************************************************************/

/* This type defines the message types as used by the PMP protocol.
 * Some of the enum values assigned are as expected by the PM H/W and
 * they should not be changed. */
typedef enum {
  pmp_null_msg_type_e                        = 0xff,

  /* Request messages. */
  pmp_table_read_request_msg_type_e     = 0x00 | PMP_REQUEST_MSG_CLASS_FLAG,
  pmp_table_write_request_msg_type_e    = 0x01 | PMP_REQUEST_MSG_CLASS_FLAG,
  pmp_table_reset_request_msg_type_e    = 0x02 | PMP_REQUEST_MSG_CLASS_FLAG,
  pmp_ctx_by_session_id_clear_request_msg_type_e =  \
  0x08 | PMP_REQUEST_MSG_CLASS_FLAG,
  pmp_ctx_by_rule_id_clear_request_msg_type_e    =  \
  0x09 | PMP_REQUEST_MSG_CLASS_FLAG,
  pmp_ctx_all_clear_request_msg_type_e  = 0x0c | PMP_REQUEST_MSG_CLASS_FLAG,
  pmp_attribute_get_request_msg_type_e  = 0x10 | PMP_REQUEST_MSG_CLASS_FLAG,
  pmp_attribute_set_request_msg_type_e  = 0x11 | PMP_REQUEST_MSG_CLASS_FLAG,
  pmp_error_indication_msg_type_e       = 0x1f | PMP_REQUEST_MSG_CLASS_FLAG,

  /* Reply messages. */
  pmp_table_read_reply_msg_type_e       = (pmp_table_read_request_msg_type_e |
                                           PMP_REPLY_MSG_CLASS_FLAG),
  pmp_attribute_get_reply_msg_type_e    = 
  (pmp_attribute_get_request_msg_type_e | PMP_REPLY_MSG_CLASS_FLAG),

  /* Asynchronous messages. */
  pmp_data_scan_msg_type_e              = 0x38,
  pmp_scan_report_indication_msg_type_e = 0x3f,
} pmp_message_type_t;


/* This type defines the PM H/W table identifiers.  The enum values
 * assigned are as expected by the PM H/W and they should not be
 * changed. */  
typedef enum
{
  pmp_null_table_id_e               =  -1U, /* NULL table */

  pmp_one_byte_trigger_table_id_e   = 0x00, /* one-byte trigger table */
  pmp_two_byte_trigger_table_id_e   = 0x01, /* two-byte trigger table */
  pmp_variable_trigger_table_id_e   = 0x02, /* variable trigger table */
  pmp_confidence_table_id_e         = 0x03, /* confidence table */
  pmp_confirmation_table_id_e       = 0x04, /* confirmation table */
  pmp_user_defined_group_table_id_e = 0x05, /* user-defined group table */
  pmp_equivalence_table_id_e        = 0x06, /* equivalence table */
  pmp_session_context_table_id_e    = 0x07, /* session context table */
  pmp_special_trigger_table_id_e    = 0x08, /* special trigger table */

  pmp_table_id_first_table_id_e     = pmp_one_byte_trigger_table_id_e,
  pmp_table_id_last_table_id_e      = pmp_special_trigger_table_id_e
} pmp_table_id_t;


/* This type defines the attributes that can be used in the attribute
 * set and get messages.  The enum values assigned are as expected by
 * the PM H/W and they should not be changed. */
typedef enum
{
  pmp_statistics_attr_id_e                  = 0x00, /* PM stats (set=reset) */
  pmp_hardware_revision_attr_id_e           = 0x01, /* PM hardware revision */
  pmp_protocol_revision_attr_id_e           = 0x02, /* PM protocol revision */
  pmp_atomic_attr_id_e                      = 0x03, /* atomic state */
  pmp_batch_attr_id_e                       = 0x04, /* batch state */
  pmp_sre_end_of_sui_index_attr_id_e        = 0x05, /* end-of-SUI head block */
  pmp_variable_trigger_size_attr_id_e       = 0x06, /* variable trigger size */
  pmp_confidence_chain_max_length_attr_id_e = 0x07, /* confid-coll-chain len.*/
  pmp_sw_database_signature_attr_id_e       = 0x08, /* SW Database signature */
  pmp_drcc_selection_attr_id_e              = 0x09, /* set patterns to count */
  pmp_extension_block_num_attr_id_e         = 0x0a, /* number of ext. blocks */
  pmp_context_max_num_attr_id_e             = 0x0b, /* number of contexts */
  pmp_context_area_size_attr_id_e           = 0x0c, /* size of context area */
  pmp_max_stateful_rule_num_attr_id_e       = 0x0d, /* number of SRE rules */
  pmp_drcc_mask_attr_id_e                   = 0x0e, /* Mask for DRCC select */

  pmp_first_attr_id_e                       = 0x00,
  pmp_last_attr_id_e                        = 0x0e,
} pmp_attribute_id_t;


/* The next few types define the different PMP attribute structures. */
typedef struct {
  uint64_t  pmInputBytes;
  uint64_t  pmOutputBytes;
  uint64_t  pmTriggerOneByteHits;
  uint64_t  pmTriggerTwoByteHits;
  uint64_t  pmTriggerVariableHits;
  uint64_t  pmTriggerSpecialHits;
  uint64_t  pmConfidenceHits;
  uint64_t  pmMatches;
  uint64_t  pmDxeExecutions;
  uint64_t  pmEndOfSuiExecutions;
  uint64_t  pmSuiMatchingPatterns;
  uint64_t  pmSuiGeneratingReports;
  uint64_t  pmInputSuis;
  uint64_t  pmSelectedMatches;
  uint64_t  dfInputBytes;
  uint64_t  dfOutputBytes;
  uint64_t  dfDecompressions;
} PMP_PACKED pmp_statistics_attr_t;
typedef struct {
  uint16_t socFamily;
  uint16_t socMember;
  uint16_t coreId;
  uint8_t  coreMajor;
  uint8_t  coreMinor;
  uint8_t  coreIntegrationOptions;
  uint8_t  coreConfigurationOptions;
  uint16_t unused;    
} PMP_PACKED pmp_hw_revision_t;
typedef struct {
  uint8_t  protocolMajor;
  uint8_t  protocolMinor;
  uint16_t unused;
} PMP_PACKED pmp_protocol_revision_t;
typedef uint32_t pmp_atomic_attr_t;
typedef uint32_t pmp_batch_attr_t;
typedef uint32_t pmp_sre_end_of_sui_index_attr_t;
typedef uint32_t pmp_variable_trigger_size_attr_t;
typedef uint32_t pmp_confidence_chain_max_length_attr_t;
typedef uint32_t pmp_sw_database_signature_attr_t;
typedef uint32_t pmp_drcc_selection_attr_t;
typedef uint32_t pmp_extension_block_num_attr_t;
typedef uint32_t pmp_context_max_num_attr_t;
typedef uint32_t pmp_context_area_size_attr_t;
typedef uint32_t pmp_max_stateful_rule_num_attr_t;


/* This type defines a generic PMP attribute. */
typedef union {
  pmp_statistics_attr_t                   statisticsAttr;
  pmp_hw_revision_t                       hwRevisionAttr;
  pmp_protocol_revision_t                 protocolRevisionAttr;
  pmp_atomic_attr_t                       atomicAttr;
  pmp_batch_attr_t                        batchAttr;
  pmp_sre_end_of_sui_index_attr_t         sreEndOfSuiIndexAttr;
  pmp_variable_trigger_size_attr_t        variableTriggerSizeAttr;
  pmp_confidence_chain_max_length_attr_t  confidenceChainMaxLengthAttr;
  pmp_sw_database_signature_attr_t        swDatabaseSignatureAttr;
  pmp_drcc_selection_attr_t               drccSelectionAttr;
  pmp_extension_block_num_attr_t          extensionBlockNumAttr;
  pmp_context_max_num_attr_t              contextMaxNumAttr;
  pmp_context_area_size_attr_t            contextAreaSizeAttr;
  pmp_max_stateful_rule_num_attr_t        maxStatefulRuleNumAttr;
} PMP_PACKED pmp_attribute_t;


/* The next few types define the entries for the different PM tables. */
typedef uint8_t pmp_one_byte_trigger_entry_t[PMP_ONE_BYTE_TRIGGER_ENTRY_SIZE];
typedef uint8_t pmp_two_byte_trigger_entry_t[PMP_TWO_BYTE_TRIGGER_ENTRY_SIZE];
typedef uint8_t pmp_variable_trigger_entry_t[PMP_VARIABLE_TRIGGER_ENTRY_SIZE];
typedef uint8_t pmp_confidence_entry_t[PMP_CONFIDENCE_ENTRY_SIZE];
typedef uint8_t pmp_confirmation_entry_t[PMP_CONFIRMATION_ENTRY_SIZE];
typedef uint8_t pmp_udg_entry_t[PMP_USER_DEFINED_GROUP_ENTRY_SIZE];
typedef uint8_t pmp_equivalence_entry_t[PMP_EQUIVALENCE_ENTRY_SIZE];
typedef uint8_t pmp_session_context_entry_t[PMP_SESSION_CONTEXT_ENTRY_SIZE];
typedef uint8_t pmp_special_trigger_entry_t[PMP_SPECIAL_TRIGGER_ENTRY_SIZE];


/* This type defines a generic, i.e., unionized, table entry. */
typedef union {
  pmp_one_byte_trigger_entry_t  oneByteTriggerEntry;
  pmp_two_byte_trigger_entry_t  twoByteTriggerEntry;
  pmp_variable_trigger_entry_t  variableTriggerEntry;
  pmp_confidence_entry_t        confidenceEntry;
  pmp_confirmation_entry_t      confirmationEntry;
  pmp_udg_entry_t               udgEntry;
  pmp_equivalence_entry_t       equivalenceEntry;
  pmp_session_context_entry_t   sessionContextEntry;
  pmp_special_trigger_entry_t   specialTriggerEntry;
} PMP_PACKED pmp_table_entry_t;


/* This type defines an index in a table. */
typedef uint32_t pmp_index_t;


/* This type defines the table ID. */
typedef uint32_t pmp_table_id_field_t;


/* This type defines the rule ID. */
typedef uint32_t pmp_rule_id_t;


/* This type defines the attribute ID. */
typedef uint32_t pmp_attribute_id_field_t;


/* This type defines an indexed table entry. */
typedef struct {
  pmp_index_t        index;
  pmp_table_entry_t  entry;
} PMP_PACKED pmp_indexed_table_entry_t;


/* This type defines the header that is used by all the request and
 * reply PMP messages. */
typedef struct {
  uint8_t   protocolVersion;
  uint8_t   msgType;
  uint16_t  reserved;
  uint32_t  msgLength; /* total message length, including the header */
  uint64_t  msgId;
  uint8_t   data[0];
} PMP_PACKED pmp_header_t;


/* pmp_table_read_request_msg_type_e - table read request message. */
typedef struct {
  pmp_header_t               header;
  pmp_table_id_field_t       tableId;
  pmp_index_t                index;
} PMP_PACKED pmp_table_read_request_msg_t;
/* pmp_table_read_reply_msg_type_e - table read reply message. */
typedef struct {
  pmp_header_t               header;
  pmp_table_id_field_t       tableId;
  pmp_indexed_table_entry_t  indexedEntry;
} PMP_PACKED pmp_table_read_reply_msg_t;


/* pmp_table_write_request_msg_type_e - table write request message. */
typedef struct {
  pmp_header_t               header;
  pmp_table_id_field_t       tableId;
  pmp_indexed_table_entry_t  indexedEntry;
} PMP_PACKED pmp_table_write_request_msg_t;


/* pmp_table_reset_request_msg_type_e - table reset request message. */
typedef struct {
  pmp_header_t               header;
  pmp_table_id_field_t       tableId;
} PMP_PACKED pmp_table_reset_request_msg_t;


/* pmp_attribute_get_request_msg_type_e - attribute get request message. */
typedef struct {
  pmp_header_t               header;
  pmp_attribute_id_field_t   attributeId;
} PMP_PACKED pmp_attribute_get_request_msg_t;
/* pmp_attribute_get_reply_msg_type_e - attribute get reply message. */
typedef struct {
  pmp_header_t               header;
  pmp_attribute_id_field_t   attributeId;
  pmp_attribute_t            attributeValue;
} PMP_PACKED pmp_attribute_get_reply_msg_t;


/* pmp_attribute_set_request_msg_type_e - attribute set request message. */
typedef struct {
  pmp_header_t               header;
  pmp_attribute_id_field_t   attributeId;
  pmp_attribute_t            attributeValue;
} PMP_PACKED pmp_attribute_set_request_msg_t;


/* pmp_ctx_by_session_id_clear_request_msg_type_e - clear context by session ID
 * request message. */
typedef struct {
  pmp_header_t               header;
  uint32_t                   sessionId;
  uint32_t                   ruleCap;  /* must be set to zero for now */
} PMP_PACKED pmp_ctx_by_session_id_clear_request_msg_t;

/* pmp_ctx_by_rule_id_clear_request_msg_type_e - clear context by rule
 * ID request message. */ 
typedef struct {
  pmp_header_t               header;
  uint32_t                   firstSessionId;  /* must be set to zero for now */
  uint32_t                   sessionDepth;    /* must be set to zero for now */
  uint32_t                   numberOfSession; /* must be set to zero for now */
  pmp_rule_id_t              ruleIds[1];      /* array of rule IDs */
} PMP_PACKED pmp_ctx_by_rule_id_clear_request_msg_t;


/* pmp_ctx_all_clear_request_msg_type_e - clear the entire context
 * table request message. */ 
typedef struct {
  pmp_header_t               header;
} PMP_PACKED pmp_ctx_all_clear_request_msg_t;


/* pmp_error_indication_msg_type_e - error indication message. */
typedef struct {
  pmp_header_t               header;
  uint32_t                   errorNo;
} PMP_PACKED pmp_error_indication_msg_t;


/* pmp_data_scan_msg_type_e - data scan request message. */
typedef struct {
  pmp_header_t               header;
  uint32_t                   set;
  uint32_t                   subsetMask;
  uint32_t                   sessionId;
  uint8_t                    data[0];
} PMP_PACKED pmp_data_scan_request_msg_t;


/* pmp_scan_report_indication_msg_type_e - data scan report message. */
typedef struct {
  pmp_header_t               header;
  uint32_t                   origOffset;
  uint8_t                    reports[0];
} PMP_PACKED pmp_scan_report_indication_msg_t;


/* This type defines a generic, i.e., unionized, request message.
 * Note that the table types assume that only one entry is present in 
 * the message. */
typedef union {
  pmp_header_t                               header;
  pmp_table_read_request_msg_t               tableReadRequestMsg;
  pmp_table_write_request_msg_t              tableWriteRequestMsg;
  pmp_table_reset_request_msg_t              tableResetRequestMsg;
  pmp_attribute_get_request_msg_t            attributeGetRequestMsg;
  pmp_attribute_set_request_msg_t            attributeSetRequestMsg;
  pmp_ctx_by_session_id_clear_request_msg_t  ctxBySessionIdClearRequestMsg;
  pmp_ctx_by_rule_id_clear_request_msg_t     ctxByRuleIdClearRequestMsg;
  pmp_ctx_all_clear_request_msg_t            ctxAllClearRequestMsg;
  pmp_data_scan_request_msg_t                dataScanRequestMsg_t;
  pmp_error_indication_msg_t                 errorIndicationMsg;
} PMP_PACKED pmp_request_msg_t;


/* This type defines a generic, i.e., unionized, reply message.  Note
 * that the table types assume that only one entry is present in the message.  */
typedef union {
  pmp_header_t                   header;
  pmp_table_read_reply_msg_t     tableReadReplyMsg;
  pmp_attribute_get_reply_msg_t  attributeGetReplyMsg;
} PMP_PACKED pmp_reply_msg_t;


/* This type defines a generic, i.e., unionized, reply message.  Note
 * that the table types assume that only one entry is present in the message. */
typedef union {
  pmp_header_t                      header;
  pmp_scan_report_indication_msg_t  scanReportIndicationMsg;
} PMP_PACKED pmp_indication_msg_t;


/* This type defines a generic, i.e., unionized, reply message.  Note
 * that the table types assume that only one entry is present in the message. */
typedef union {
  pmp_header_t                      header;
  pmp_request_msg_t                 requestMsg;
  pmp_reply_msg_t                   replyMsg;
  pmp_indication_msg_t              indicationMsg;
} PMP_PACKED pmp_msg_t;





/* PM H/W generates expression match and/or rule reports.  Each such
 * report contains a number of records.  Each record has a type.  This
 * enum defines all the supported report record types.  In addition we
 * also define some report record type classes, eg., inconclusive
 * right/left record type classes.  */ 
typedef enum {
  pmp_simple_match_type_e                    = 0x01,
  pmp_verbose_match_type_e                   = 0x02,

  pmp_stateless_rule_e                       = 0x03,
  pmp_dual_state_rule_no_context_e           = 0x04,
  pmp_dual_state_rule_with_context_e         = 0x05,
  pmp_dual_state_rule_with_context_verbose_e = 0x06,
  pmp_multi_state_rule_e                     = 0x07,
  pmp_multi_state_rule_verbose_e             = 0x08,

  pmp_record_type_mask                       = 0x0f,
  
  pmp_rule_report_type_e                     = 0x70,
  
  pmp_end_of_report_type_e                   = 0x80,

  pmp_inconclusive_right_record_type_class   = 0x10,
  pmp_inconclusive_left_record_type_class    = 0x20,
  pmp_full_match_record_type_class           = 0x40,
} pmp_report_record_type_t;
typedef uint8_t pmp_rep_rec_type_t;


/* The next few types define the report records.  Such records are
 * used to build pattern match reports.  A match found by the PM H/W,
 * if it is to be reported, is reported in a match record.  Each
 * report messages is terminated with an end-of-report record.
 *
 * Simple match report - default simple report, one per match. */
typedef struct {
  pmp_rep_rec_type_t  type;             /* bit 4-7 = pmp_simple_match_type_e */
  uint8_t             matchLength;      /* Length of matching bytes. ($N) */
  uint8_t             unitOffset[PMP_REPORT_WORK_UNIT_OFFSET_SIZE];
                                        /* Scan unit offset in 48 bits,
                                         * relative to the head of
                                         * stream.  Starts at 0. ($Si) */
  uint32_t            matchByteOffset;  /* Last byte of the match,
                                         * relative to the scan unit.
                                         * Offset starts at 1 for 
                                         * the first byte. ($M) */ 
  uint32_t            expTag;           /* Tag of matching expression ($T) */
} PMP_PACKED pmp_report_simple_match_record_t;


/* End-of-report record */
typedef struct {
  pmp_rep_rec_type_t  type;              /* pmp_end_of_report_type_e */
  uint32_t            scannedByteLength; /* Total bytes scanned in
                                          * this operation */ 
} PMP_PACKED pmp_report_end_of_report_record_t;


/* Rule report record - This is the format generated by the report {}
   command by the stateful rule compiler.  */
typedef struct {
  pmp_rep_rec_type_t  type;    /* pmp_rule_report_type_e */
  uint8_t             unused;
  uint16_t            length;  /* total report length (including type) */
} PMP_PACKED pmp_report_rule_record_t;

/* Extended match report - This is generated by special stateful rules
   that allows reporting of matches long than 255 bytes.  */

enum { pmp_extended_match_report_code_e = 0xff };

typedef struct {
  pmp_rep_rec_type_t  type;             /* bit 4-7 = pmp_simple_match_type_e */
  uint8_t             oldMatchLength;   /* If the original length == 0xff, software
										   should treat the simple report as 
										   extended report. */
  uint16_t            matchLength;      /* Real mathc length reported by special
										   stateful rule. */
  uint32_t            unitOffset;       /* Scan unit offset trunated to 32 bits,
                                         * relative to the head of
                                         * stream.  Starts at 0. ($Si) */
  uint32_t            matchByteOffset;  /* Last byte of the match,
                                         * relative to the scan unit.
                                         * Offset starts at 1 for 
                                         * the first byte. ($M) */ 
  uint32_t            expTag;           /* Tag of matching expression ($T) */
} PMP_PACKED pmp_report_extended_match_record_t;


/* Verbose match report - for debug purpose */
typedef struct {
  pmp_report_simple_match_record_t simpleMatchRecord;
                            /* Byte 0 bit 4-7 = pmp_verbose_match_type_e
                               Byte 1-16 : Same as the simple match report */
  uint32_t lastLineBreak;   /* Byte 17-20 : last stream position of */
                            /* Line Break character ($Ob) */
  uint32_t lastExtChar;     /* Byte 21-24 : last stream position of */
                            /* Extended ASCII character ($Ox) */
  uint8_t  capturedXSize;   /* Byte 25 : captured $X size ($Xn) */
  uint8_t  capturedYSize;   /* Byte 26 : captured $Y size ($Yn) */

  struct {
#   if __BYTE_ORDER == __LITTLE_ENDIAN
    uint8_t  right     : 1;
    uint8_t  left      : 1;
    uint8_t  fullMatch : 1;
    uint8_t  unused1   : 5;
#   else
#     if __BYTE_ORDER == __BIG_ENDIAN
    uint8_t  unused1   : 5;
    uint8_t  fullMatch : 1;
    uint8_t  left      : 1;
    uint8_t  right     : 1;
#     else
#       error "__BYTE_ORDER is neither __LITTLE_ENDIAN nor __BIG_ENDIAN."
#     endif
#   endif
  } PMP_PACKED inconclusive; /* Byte 27:5 bits of 0, full match bit ($I[5]),  
                                inconclusive left indicator ($I[6]),
                                inconclusive right indicator ($I[7]) */
  uint64_t capturedX;  /* Byte 28-35 : captured $X (0 if no capture) */
  uint64_t capturedY;  /* Byte 36-43 : captured $Y (0 if no capture) */
} PMP_PACKED pmp_report_verbose_match_record_t;


/* Stateless Rule */
typedef struct {
  pmp_rep_rec_type_t  type; /* pmp_stateless_rule_e */
} PMP_PACKED pmp_stateless_rule_record_t;


/* Dual State Rule w/o Context, with Context & Multi State Rule */
typedef struct {
  pmp_rep_rec_type_t type;       /* bit 4-7 = pmp_dual_state_rule_no_context_e
                                         pmp_dual_state_rule_with_context_e  
                                         pmp_multi_state_rule_e */
  uint16_t           ruleNum;    /* Byte 2-3 : Rule Number */
  uint8_t            ruleState;  /* Byte 4 : 7 bits of 0, Rule State Bit */
} PMP_PACKED pmp_stateful_rule_record_t;


/* Dual State Rule with Context & Multi State Rule (verbose mode 3) */
typedef struct {
  pmp_rep_rec_type_t  type;     /* bit 4-7 = 
                                   pmp_dual_state_rule_with_context_verbose_e
                                   pmp_multi_state_rule_verbose_e */
  uint16_t            ruleNum;       /* Byte 2-3 : Rule Number */
  uint8_t             ruleState;     /* Byte 4 : 7 bits of 0, Rule State Bit */
  uint8_t             ruleContext[PMP_SESSION_RULE_CONTEXT_SIZE];
                                     /* Byte 5-20 : Rule Context (left
                                      * aligned 16B reported even if
                                      * rule only uses 2B,4B or 8B) */ 
  uint8_t             globalContext[PMP_GLOBAL_PERSISTENT_GPRVS_SIZE];
                                      /* Byte 21-36 : Global Context */
  uint16_t            sessionPresistentFlags; 
                                     /* Byte 37-38: Session Persistent Flags */
  uint16_t            volatileFlags; /* Byte 39-40: Volatile Flags */
} PMP_PACKED pmp_stateful_rule_verbose_record_t;










/**********************************************************************
 * Private Global Data Definitions
 **********************************************************************/







/**********************************************************************
 * Function Declarations
 **********************************************************************/







/**********************************************************************
 * Function Definitions
 **********************************************************************/






#endif /* PMP_H_INCLUDE */

