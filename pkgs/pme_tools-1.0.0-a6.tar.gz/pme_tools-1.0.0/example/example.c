/************************< BEGIN COPYRIGHT >************************
 *  
 *   Copyright 2009, Freescale Semiconductor, Inc.  All Rights Reserved.
 *  
 *    NOTICE: The information contained in this file is proprietary 
 *    to Freescale Semiconductor and is being made available to 
 *    Freescale's customers under a specific license agreement. 
 *    Use or disclosure of this information is permissible only 
 *    under the terms of the license agreement. 
 *  
 * 
 ************************< END COPYRIGHT >***************************/
/* a private header */
#include <private.h>
/* a shared header */
#include <example.h>
/* a system header */
#include <stdio.h>

int main() {
	printf("hello: %d\n", PRIVATE);
	stuff(); /* from libex.a */
	return 0;
}
